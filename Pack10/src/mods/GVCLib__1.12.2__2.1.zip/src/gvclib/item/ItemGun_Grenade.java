package gvclib.item;

import gvclib.item.gunbase.IGun_Grenade;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Enchantments;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.stats.StatList;
import net.minecraft.util.ActionResult;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.world.World;


	public class ItemGun_Grenade extends ItemGunBase  implements IGun_Grenade{
		public static String ads;
		
		public ItemGun_Grenade() {
			super();
			//this.maxStackSize = 1;
			this.shrinkitem = true;
		}
		
		public void func_77663_a(ItemStack itemstack, World world, Entity entity, int i, boolean flag)
	    {
			super.func_77663_a(itemstack, world, entity, i, flag);
			EntityPlayer entityplayer = (EntityPlayer)entity;
			boolean lflag = cycleBolt(itemstack);
			if (flag) {
				entityplayer.field_70159_w = entityplayer.field_70159_w * this.motion;
				entityplayer.field_70179_y = entityplayer.field_70179_y * this.motion;
			}
			this.gunbase_reload(itemstack, world, entity, i, flag);
			
	    }
		
		public void func_77615_a(ItemStack par1ItemStack, World par2World, EntityLivingBase par3EntityPlayer, int par4){
			if (par3EntityPlayer instanceof EntityPlayer)
	        {
				EntityPlayer entityplayer = (EntityPlayer)par3EntityPlayer;
				int s;
				int li = func_77612_l() - par1ItemStack.func_77952_i();
				boolean lflag = cycleBolt(par1ItemStack);
				boolean var5 = entityplayer.field_71075_bZ.field_75098_d || EnchantmentHelper.func_77506_a(Enchantments.field_185312_x, par1ItemStack) > 0;
				Item item = par1ItemStack.func_77973_b();
				
				if (par1ItemStack == entityplayer.func_184614_ca())
		        {
					
		         if(par1ItemStack.func_77952_i() == this.func_77612_l())
				 {
				 }
		        	else
				 {
						FireBullet(par1ItemStack,par2World,(EntityPlayer) par3EntityPlayer);
						par3EntityPlayer.func_184602_cy();
						entityplayer.func_71029_a(StatList.func_188057_b(this));
				  }
				}
	        }
        	
			
        }
		
		public ActionResult<ItemStack> func_77659_a(World worldIn, EntityPlayer playerIn, EnumHand handIn)
	    {
			ItemStack itemstack = playerIn.func_184586_b(handIn);
	        {
	            playerIn.func_184598_c(handIn);
	            return new ActionResult(EnumActionResult.SUCCESS, itemstack);
	        }
	    }

}
