package gvclib.item;

import java.util.List;
import com.google.common.collect.Multimap;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Enchantments;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ActionResult;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.world.World;


import com.google.common.collect.Multimap;

import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Enchantments;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ActionResult;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.world.World;

public class ItemWeapon_HSword extends ItemWeaponBase
{
    private final float attackdamage;
    private final Item.ToolMaterial material;
    public float dame;
    public double attackspeed = -1.5F;

    public ItemWeapon_HSword(float dame, double as, Item.ToolMaterial material)
    {
    	super(material);
        this.material = material;
        this.func_77656_e(material.func_77997_a());
        this.attackdamage = dame;
        this.attackspeed = as;
        this.movespeed = 0.5F;
    }
    
    public ActionResult<ItemStack> func_77659_a(World worldIn, EntityPlayer playerIn, EnumHand handIn)
    {
		ItemStack itemstack = playerIn.func_184586_b(handIn);
        {
            playerIn.func_184598_c(handIn);
            return new ActionResult(EnumActionResult.SUCCESS, itemstack);
        }
    }
    
    public void attackSwinging(World worldIn, EntityPlayer playerIn) {
			List<Entity> llist = worldIn.func_72839_b(playerIn,
					playerIn.func_174813_aQ()
							.func_72321_a(playerIn.field_70159_w, playerIn.field_70181_x, playerIn.field_70179_y)
							.func_186662_g(2.0D));
			if(playerIn != null){
				if (llist != null) {
					for (int lj = 0; lj < llist.size(); lj++) {
						Entity entity1 = (Entity) llist.get(lj);
						if (entity1.func_70067_L()) {
							if (entity1 != null)
							{
								if (entity1 instanceof EntityLivingBase && entity1 != playerIn) {
									entity1.func_70097_a(DamageSource.func_76358_a(playerIn), this.attackdamage);
								}
							}
						}
					}
				}
			}
    }
    public boolean onEntitySwing(EntityLivingBase entity, ItemStack par1ItemStack) {
    	World par2World = entity.field_70170_p;
    	boolean linfinity = EnchantmentHelper.func_77506_a(Enchantments.field_185312_x, par1ItemStack) > 0;
    	int pluspower = EnchantmentHelper.func_77506_a(Enchantments.field_185309_u, par1ItemStack);
    	
    	boolean left = false;
    	if(entity instanceof EntityPlayer)
    	{
    		EntityPlayer playerIn = (EntityPlayer) entity;
    		if(playerIn.func_184811_cZ().func_185143_a(par1ItemStack.func_77973_b(), 0) == 0) {
    			playerIn.func_184811_cZ().func_185145_a(this, 40);
    			this.attackSwinging(par2World, playerIn);
    		}
    		
    	}
    	return false;
    }
    /**
     * Gets a map of item attribute modifiers, used by ItemSword to increase hit damage.
     */
    public Multimap<String, AttributeModifier> func_111205_h(EntityEquipmentSlot equipmentSlot)
    {
        Multimap<String, AttributeModifier> multimap = super.func_111205_h(equipmentSlot);

        if (equipmentSlot == EntityEquipmentSlot.MAINHAND)
        {
            multimap.put(SharedMonsterAttributes.field_111264_e.func_111108_a(), new AttributeModifier(field_111210_e, "Weapon modifier", (double)this.attackdamage, 0));
            multimap.put(SharedMonsterAttributes.field_188790_f.func_111108_a(), new AttributeModifier(field_185050_h, "Weapon modifier", attackspeed, 0));
        }

        return multimap;
    }
    
    
}
