package gvclib.item;

import gvclib.mod_GVCLib;
import gvclib.item.gunbase.IGun_Shield;
import gvclib.network.GVCLMessageKeyPressed;
import gvclib.network.GVCLPacketHandler;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Enchantments;
import net.minecraft.item.IItemPropertyGetter;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.ActionResult;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundCategory;
import net.minecraft.world.World;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;


	public class ItemGun_Shield extends ItemGunBase implements IGun_Shield{
		public static String ads;
		
		public ItemGun_Shield() {
			super();
			
			
			this.field_77777_bU = 1;
	        
	        this.func_185043_a(new ResourceLocation("hold"), new IItemPropertyGetter()
	        {
	            @SideOnly(Side.CLIENT)
	            public float func_185085_a(ItemStack stack, World worldIn, EntityLivingBase entityIn)
	            {
	            	if (entityIn instanceof EntityPlayer) {
						if (entityIn.func_70093_af() && entityIn.func_184614_ca() == stack) {
							if (!(func_77612_l() - stack.func_77952_i() > 0)) {
								return 1F;
								/*
								 * }else if(stack == entityIn.getActiveItemStack()){
								 * return 3F;
								 */
							} else {
								return 2F;
							}
						} else if ((func_77612_l() - stack.func_77952_i() > 0)) {
							return 0F;
						} else {
							return 1F;
						}
					} else {
						if ((func_77612_l() - stack.func_77952_i() > 0)) {
							return 0F;
						} else {
							return 1F;
						}
					}
				}
	        });
		}
		
		public void func_77663_a(ItemStack itemstack, World world, Entity entity, int i, boolean flag)
	    {
			super.func_77663_a(itemstack, world, entity, i, flag);
			checkTags(itemstack);
			EntityPlayer entityplayer = (EntityPlayer)entity;

			if(!itemstack.func_77942_o())return;
			NBTTagCompound nbt = itemstack.func_77978_p();
			

			boolean gethand = false;
			if(itemstack == entityplayer.func_184592_cb()) {
				gethand = true;
			}else if(flag){
				gethand = true;
			}
			if (gethand) {
				entityplayer.field_70159_w = entityplayer.field_70159_w * this.motion;
				//entityplayer.motionY = entityplayer.motionY * 0.1;
				entityplayer.field_70179_y = entityplayer.field_70179_y * this.motion;
			}
			
			if (entity != null && !world.field_72995_K  && entityplayer != null && !itemstack.func_190926_b()) 
			{
				if(itemstack == entityplayer.func_184592_cb()) {
	    			/*boolean left = nbt.getBoolean("LeftClick");
	    			if (mod_GVCLib.proxy.leftclick()) 
					{
	    				nbt.setBoolean("LeftClick", true);
	    				nbt.setInteger("LeftTime", 0);
						GVCLPacketHandler.INSTANCE.sendToServer(new GVCLMessageKeyPressed(101));
					}*/
	    			if (entityplayer.func_70093_af())
					{
	    				nbt.func_74757_a("CAN_SD", true);
	    				GVCLPacketHandler.INSTANCE.sendToServer(new GVCLMessageKeyPressed(76, true));
	    				//nbt.setBoolean("LeftClick", false);
						//GVCLPacketHandler.INSTANCE.sendToServer(new GVCLMessageKeyPressed(1011));
					}
	    			else {
						//nbt.setBoolean("LeftClick", false);
						//GVCLPacketHandler.INSTANCE.sendToServer(new GVCLMessageKeyPressed(1011));
						nbt.func_74757_a("CAN_SD", false);
	    				GVCLPacketHandler.INSTANCE.sendToServer(new GVCLMessageKeyPressed(76, false));
					}
	    		}else if(flag){
	    			if (entityplayer.func_184607_cu() == itemstack || entityplayer.func_70093_af()) {
	    				nbt.func_74757_a("CAN_SD", true);
	    				GVCLPacketHandler.INSTANCE.sendToServer(new GVCLMessageKeyPressed(75, true));
	    			}else {
	    				nbt.func_74757_a("CAN_SD", false);
	    				GVCLPacketHandler.INSTANCE.sendToServer(new GVCLMessageKeyPressed(75, false));
	    			}
	    		}
			}
			
		//	this.DO_SD(itemstack, world, entityplayer, i, flag);
			/*{
				int left_time = nbt.getInteger("LeftTime");
				boolean left = nbt.getBoolean("LeftClick");
				if(left) {
					if(left_time < 5) {
						nbt.setInteger("LeftTime", ++left_time);
					}else {
						nbt.setInteger("LeftTime", 0);
						nbt.setBoolean("LeftClick", false);
						GVCLPacketHandler.INSTANCE.sendToServer(new GVCLMessageKeyPressed(1011));
					}
					entityplayer.motionX = entityplayer.motionX * 0.5F;
					entityplayer.motionZ = entityplayer.motionZ * 0.5F;
				}
			}*/
			
			
	    }
		
		
		public void DO_SD(ItemStack itemstack, World world, Entity entity, int i, boolean flag) {
			NBTTagCompound nbt = itemstack.func_77978_p();
			boolean can = nbt.func_74767_n("CAN_SD");
			
		}
		
		
		
		
		public void func_77615_a(ItemStack par1ItemStack, World par2World, EntityLivingBase par3EntityPlayer, int par4){
        }
		
		public ActionResult<ItemStack> onItemRightClick(ItemStack itemStackIn, World worldIn, EntityPlayer playerIn, EnumHand hand)
	    {
			boolean flag = this.func_185060_a(playerIn) != null;

	        ActionResult<ItemStack> ret = net.minecraftforge.event.ForgeEventFactory.onArrowNock(itemStackIn, worldIn, playerIn, hand, flag);
	        if (ret != null) return ret;

	        if (!playerIn.field_71075_bZ.field_75098_d && !flag)
	        {
	            return !flag ? new ActionResult(EnumActionResult.FAIL, itemStackIn) : new ActionResult(EnumActionResult.PASS, itemStackIn);
	        }
	        else
	        {
	            playerIn.func_184598_c(hand);
	            return new ActionResult(EnumActionResult.SUCCESS, itemStackIn);
	        }
	    }

}
