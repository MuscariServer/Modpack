package gvclib.item;

import java.util.List;
import com.google.common.collect.Multimap;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.EnumAction;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.DamageSource;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;


import com.google.common.collect.Multimap;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.EnumAction;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.DamageSource;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

public class ItemWeapon_Spear extends ItemWeaponBase// implements IReachItem
{
    private final float attackdamage;
    private final Item.ToolMaterial material;
    public float dame;
    public double attackspeed;
    public double reach;

    public ItemWeapon_Spear(float dame, double as, Item.ToolMaterial material)
    {
    	super(material);
        this.material = material;
        this.func_77656_e(material.func_77997_a());
        this.attackdamage = dame;
        this.attackspeed = as;
        this.reach = 6;
        this.movespeed = 1.0F;
    }

    /**
     * returns the action that specifies what animation to play when the items is being used
     */
    public EnumAction func_77661_b(ItemStack stack)
    {
        return EnumAction.BOW;
    }
    
    /*public ActionResult<ItemStack> onItemRightClick(World worldIn, EntityPlayer playerIn, EnumHand handIn)
    {
		ItemStack itemstack = playerIn.getHeldItem(handIn);
		if(playerIn.isSneaking()){
			return new ActionResult(EnumActionResult.PASS, itemstack);
		}else
        {
            playerIn.setActiveHand(handIn);
            //this.attackSwinging(worldIn, playerIn);
            //playerIn.getCooldownTracker().setCooldown(this, 20);
            return new ActionResult(EnumActionResult.SUCCESS, itemstack);
        }
    }*/
    
    public void func_77663_a(ItemStack itemstack, World worldIn, Entity entity, int i, boolean flag) {
    	if(entity instanceof EntityPlayer && entity != null) {
    		EntityPlayer playerIn = (EntityPlayer) entity;
    		if(flag && playerIn.field_110158_av == 1) {
    			if(itemstack != null) {
    				this.ItemReach(itemstack, worldIn, playerIn);
    			}
    		}
    	}
    }
    
    public void attackSwinging(World worldIn, EntityPlayer playerIn) {
			List<Entity> llist = worldIn.func_72839_b(playerIn,
					playerIn.func_174813_aQ()
							.func_72321_a(playerIn.field_70159_w, playerIn.field_70181_x, playerIn.field_70179_y)
							.func_186662_g(2.0D));
			if(playerIn != null){
				if (llist != null) {
					for (int lj = 0; lj < llist.size(); lj++) {
						Entity entity1 = (Entity) llist.get(lj);
						if (entity1.func_70067_L()) {
							if (entity1 != null)
							{
								if (entity1 instanceof EntityLivingBase && entity1 != playerIn) {
									entity1.func_70097_a(DamageSource.func_76358_a(playerIn), this.attackdamage);
								}
							}
						}
					}
				}
			}
    }
    
   
    /**
     * Gets a map of item attribute modifiers, used by ItemSword to increase hit damage.
     */
    public Multimap<String, AttributeModifier> func_111205_h(EntityEquipmentSlot equipmentSlot)
    {
        Multimap<String, AttributeModifier> multimap = super.func_111205_h(equipmentSlot);

        if (equipmentSlot == EntityEquipmentSlot.MAINHAND)
        {
            multimap.put(SharedMonsterAttributes.field_111264_e.func_111108_a(), new AttributeModifier(field_111210_e, "Weapon modifier", (double)this.attackdamage, 0));
            multimap.put(SharedMonsterAttributes.field_188790_f.func_111108_a(), new AttributeModifier(field_185050_h, "Weapon modifier", attackspeed, 0));
        }

        return multimap;
    }

    public void ItemReach(ItemStack itemstack, World worldIn, EntityPlayer playerIn) {
    	//RayTraceResult raytraceresult = axisalignedbb.calculateIntercept(start, end);
		//playerIn.playerc
		Vec3d pos = playerIn.func_174824_e((float) this.reach);
		double d = this.reach;
		Vec3d lock = playerIn.func_70040_Z();
		Vec3d var8 = pos.func_72441_c(lock.field_72450_a * d, lock.field_72448_b * d, lock.field_72449_c * d);
		List<Entity> llist = worldIn.func_72839_b(playerIn,
				playerIn.func_174813_aQ()
						.func_72321_a(lock.field_72450_a * d, lock.field_72448_b * d, lock.field_72449_c * d)
						.func_186662_g(0.15D));
		if(playerIn != null){
			if (llist != null) {
				for (int lj = 0; lj < llist.size(); lj++) {
					Entity entity1 = (Entity) llist.get(lj);
					if (entity1.func_70067_L()) {
						float bordersize = entity1.func_70111_Y();
						AxisAlignedBB aabb = entity1.func_174813_aQ().func_72321_a(bordersize, bordersize, bordersize);
						RayTraceResult mop0 = aabb.func_72327_a(pos, var8);
						boolean en = false;
						if (entity1 != null)
						{
							if (entity1 instanceof EntityLivingBase && entity1 != playerIn) {
								if (aabb.func_72318_a(pos))
								{
									if (0.0D < d || d == 0.0D)
									{
										//pointedEntity = entity;
										en = true;
										d = 0.0D;
									}
								} else if (mop0 != null)
								{
									double d1 = pos.func_72438_d(mop0.field_72307_f);
									
									if (d1 < d || d == 0.0D)
									{
										//pointedEntity = entity;
										en = true;
										d = d1;
									}
								}
								if(en) {
								entity1.func_70097_a(DamageSource.func_76358_a(playerIn), this.attackdamage);
								break;
								}
							}
						}
					}
				}
			}
		}
    }
    
	/*@Override
	public float getExtendedReach(World world, EntityLivingBase entity, ItemStack itemstack) {
		// TODO 自動生成されたメソッド・スタブ
		return 8;
	}*/
    
}
