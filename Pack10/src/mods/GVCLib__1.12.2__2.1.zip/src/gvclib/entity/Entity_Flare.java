package gvclib.entity;

import net.minecraft.entity.EnumCreatureAttribute;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.monster.EntityGolem;
import net.minecraft.entity.passive.IAnimals;
import net.minecraft.init.Blocks;
import net.minecraft.init.SoundEvents;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public class Entity_Flare extends EntityGolem implements IAnimals
{
    public Entity_Flare(World worldIn)
    {
        super(worldIn);
        this.func_70105_a(1F, 1F);
    }

    protected void func_110147_ax()
    {
        super.func_110147_ax();
        this.func_110148_a(SharedMonsterAttributes.field_111267_a).func_111128_a(1D);
    }

    protected void func_70088_a()
    {
        super.func_70088_a();
    }
    
    @SideOnly(Side.CLIENT)
    public int getBrightnessForRender(float partialTicks)
    {
        return 15728880;
    }

    /**
     * Gets how bright this entity is.
     */
    public float getBrightness(float partialTicks)
    {
        return 1.0F;
    }
    /**
     * Checks to make sure the light is not too bright where the mob is spawning
     */
    protected boolean isValidLightLevel()
    {
        return true;
    }
    
    public int id = 0;
    public double gra = 0.7D;
    public int time;
    public void func_70071_h_()
    {
        super.func_70071_h_();
        this.field_70170_p.func_175688_a(EnumParticleTypes.CLOUD, this.field_70165_t, this.field_70163_u + 0D, this.field_70161_v, 0.0D, 0.0D, 0.0D, new int[0]);
        this.field_70181_x *= gra;
        ++time;
        if(time > 600){
        	if (!this.field_70170_p.field_72995_K)
            {
                this.func_70106_y();
            }
        }
        if(id == 1 && this.field_70122_E) {
        	BlockPos blockpos = new BlockPos(this.field_70165_t, this.func_174813_aQ().field_72338_b, this.field_70161_v);
        	if (!this.field_70170_p.field_72995_K) {
        		this.field_70170_p.func_180501_a(blockpos, Blocks.field_150478_aa.func_176223_P(), 2);
				this.func_184185_a(SoundEvents.field_187891_gV, 1.0F, 1.0F);
				 this.func_70106_y();
			}
        }
    }
    
    /**
     * Determines if an entity can be despawned, used on idle far away entities
     */
    protected boolean func_70692_ba()
    {
    	{
        return false;
    	}
    }
    /**
     * Get this Entity's EnumCreatureAttribute
     */
    public EnumCreatureAttribute func_70668_bt()
    {
        return EnumCreatureAttribute.UNDEAD;
    }
}
