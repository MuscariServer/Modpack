package gvclib.entity.trader;

import gvclib.mod_GVCLib;
import gvclib.entity.living.EntityGVCLivingBase;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.monster.IMob;
import net.minecraft.entity.passive.IAnimals;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.IInventoryChangedListener;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.EnumDifficulty;
import net.minecraft.world.EnumSkyBlock;
import net.minecraft.world.World;

//import mcdungeons.mod_MCDungeons;
//import mcdungeons.entity.MCDContainerInventoryBox;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.monster.IMob;
import net.minecraft.entity.passive.IAnimals;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.IInventoryChangedListener;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.EnumDifficulty;
import net.minecraft.world.EnumSkyBlock;
import net.minecraft.world.World;

public class EntityNPCBase extends EntityGVCLivingBase implements IAnimals,IInventoryChangedListener
{
	
	public ContainerInventoryBox horseChest;
	
	/**売り物*/
	public Item[] sell = new Item[256];//売り物
	/**売り物*/
	public int[] sell_id = new int[256];//売り物
	/**売り物
	 * 買える量*/
	public int[] sell_size = new int[256];//売り物の量
	/**売り物
	 * 必要なエメラルドの数*/
	public int[] sellm = new int[256];//販売価格
	
	/**プレイヤーが売れるもの*/
	public int buyid = 0;
	/**プレイヤーが売れるもの*/
	public Item[] buy = new Item[256];//売り物]
	/**プレイヤーが売れるもの
	 * 帰ってくるエメラルド*/
	public int[] buy_size = new int[256];//売り物の量
	/**プレイヤーが売れるもの
	 * 必要数*/
	public int[] buym = new int[256];//販売価格
	
	/**手に持っているかどうか*/
	public boolean[] hand  = new boolean[256];//手に持っているかどうか
	
	/**手に持っているかどうか_アイテムの買い取り*/
	public boolean[] hand_buy  = new boolean[256];//手に持っているかどうか
	
    public EntityNPCBase(World worldIn)
    {
        super(worldIn);
        this.initHorseChest();
        for(int x = 0; x < 9; ++x) {
			hand[0 + x] = false;
		}
        hand[10] = false;
        hand_buy[10] = false;
    }
    
    public boolean func_184645_a(EntityPlayer player, EnumHand hand)
    {
	 cooltime = 0;
	NBTTagCompound nbt = player.getEntityData();
	nbt.func_74768_a("vi", this.func_145782_y());
	player.openGui(mod_GVCLib.INSTANCE, 2,
			player.field_70170_p, (int) player.field_70165_t, (int) player.field_70163_u, (int) player.field_70161_v);
            return true;
    }
    
    public void func_70636_d() {
		super.func_70636_d();
		{
			this.trade();
			this.sellitem();
			//this.DefaultSellItem();
		}
    }
    
    /*public void DefaultSellItem() {
    	this.buy_default_[0] = Items.IRON_INGOT;
		this.buy_default__size[0] = 1;
		this.buy_default_m[0] = 4;
		this.buy_default_[1] = Items.GOLD_INGOT;
		this.buy_default__size[1] = 1;
		this.buy_default_m[1] = 2;
		this.buy_default_[2] = Items.DIAMOND;
		this.buy_default__size[2] = 1;
		this.buy_default_m[2] = 1;
    }*/
    
    /**
     * (abstract) Protected helper method to write subclass entity data to NBT.
     */
    public void func_70014_b(NBTTagCompound compound)
    {
        super.func_70014_b(compound);

        {
            NBTTagList nbttaglist = new NBTTagList();

            for (int i = 0; i < this.horseChest.func_70302_i_(); ++i)
            {
                ItemStack itemstack = this.horseChest.func_70301_a(i);

                if (!itemstack.func_190926_b())
                {
                    NBTTagCompound nbttagcompound = new NBTTagCompound();
                    nbttagcompound.func_74774_a("Slot", (byte)i);
                    itemstack.func_77955_b(nbttagcompound);
                    nbttaglist.func_74742_a(nbttagcompound);
                }
            }

            compound.func_74782_a("Items", nbttaglist);
        }
    }

    /**
     * (abstract) Protected helper method to read subclass entity data from NBT.
     */
    public void func_70037_a(NBTTagCompound compound)
    {
        super.func_70037_a(compound);
        {
            NBTTagList nbttaglist = compound.func_150295_c("Items", 10);
            this.initHorseChest();

            for (int i = 0; i < nbttaglist.func_74745_c(); ++i)
            {
                NBTTagCompound nbttagcompound = nbttaglist.func_150305_b(i);
                int j = nbttagcompound.func_74771_c("Slot") & 255;

                if (j >= 0 && j < this.horseChest.func_70302_i_())
                {
                    this.horseChest.func_70299_a(j, new ItemStack(nbttagcompound));
                }
            }
        }

        this.updateHorseSlots();
    }
    
    public int[] sell_slotcount = new int[256];//
    
    public int sell_page = 1;
    public int sell_now_id = 0;
    
	public void trade() {
		 ItemStack itemstack = this.horseChest.func_70301_a(0);
		 int page = 10 * this.sell_now_id;
	        if (!itemstack.func_190926_b() && itemstack.func_77973_b() == Items.field_151166_bC)
	        {
	        	
	        	for(int x = 0; x < 9; ++x) {
	        		ItemStack sell_slot = this.horseChest.func_70301_a(1 + x);
        			int sellslotkosuu = sell_slot.func_190916_E();
	        		if(itemstack.func_190916_E() >= this.sellm[0 + x + page] ){
	        			if((sell_slot.func_190926_b() || this.sell_size[0 + x + page] > sellslotkosuu) && hand[0 + x + page]) 
			        	{
			        		itemstack.func_190918_g(this.sellm[0 + x + page]);
			        		hand[0 + x + page] = false;
			        	}else
	        			{
	        				this.horseChest.func_70299_a(1 + x, 
	        						new ItemStack(this.sell[0 + x + page], this.sell_size[0 + x + page], this.sell_id[0 + x + page]));
	        				hand[0 + x + page] = true;
	        			}
		        	}else {
		        		this.horseChest.func_70299_a(1 + x, this.horseChest.func_70301_a(1 + x).field_190927_a);
		        	}
	        		//sell_slotcount[0 + x] = sellslotkosuu;
	        	}
	        }else {
	        	for(int x = 0; x < 9; ++x) {
	        		this.horseChest.func_70299_a(1 + x, this.horseChest.func_70301_a(1 + x).field_190927_a);
	        		hand[0 + x + page] = false;
	        	}
	        	
	        }
	}
	
	public int buy_page = 1;
    public int buy_now_id = 0;
	
	public void sellitem() {
		ItemStack itemstack = this.horseChest.func_70301_a(10);
		if (!itemstack.func_190926_b()) {
			int idbuy = 0;
			
			for (int ite = 0; ite < 256; ++ite) 
			{
				if ( itemstack.func_77973_b() == buy[ite] && buy[ite] != null) {
					idbuy = ite;
					break;
				}
			}
			if ( itemstack.func_77973_b() == buy[idbuy] && buy[idbuy] != null) {
				if (itemstack.func_190916_E() >= this.buym[idbuy]) {
					if (this.horseChest.func_70301_a(11).func_190926_b() && hand_buy[10]) {
						itemstack.func_190918_g(this.buym[idbuy]);
						hand_buy[10] = false;
					} else {
						this.horseChest.func_70299_a(11, new ItemStack(Items.field_151166_bC, this.buy_size[idbuy]));
						hand_buy[10] = true;
					}
				} else {
					this.horseChest.func_70299_a(11, this.horseChest.func_70301_a(11).field_190927_a);
				}
			} else {
				this.horseChest.func_70299_a(11, this.horseChest.func_70301_a(11).field_190927_a);
				hand_buy[10] = false;
			}
		} else {
			this.horseChest.func_70299_a(11, this.horseChest.func_70301_a(11).field_190927_a);
			hand_buy[10] = false;
		}
	}
	/*public void selldefaultitem() {
		ItemStack itemstack = this.horseChest.getStackInSlot(10);
		if (!itemstack.isEmpty()) {
			int idbuy_default_ = 0;
			
			for (int ite = 0; ite < 256; ++ite) 
			{
				if ( itemstack.getItem() == buy_default_[ite] && buy_default_[ite] != null) {
					idbuy_default_ = ite;
					break;
				}
			}
			if ( itemstack.getItem() == buy_default_[idbuy_default_] && buy_default_[idbuy_default_] != null) {
				if (itemstack.getCount() >= this.buy_default_m[idbuy_default_]) {
					if (this.horseChest.getStackInSlot(11).isEmpty() && hand[10]) {
						itemstack.shrink(this.buy_default_m[idbuy_default_]);
						hand[10] = false;
					} else {
						this.horseChest.setInventorySlotContents(11, new ItemStack(Items.EMERALD, this.buy_default__size[idbuy_default_]));
						hand[10] = true;
					}
				} else {
					this.horseChest.setInventorySlotContents(11, this.horseChest.getStackInSlot(11).EMPTY);
				}
			} else {
				this.horseChest.setInventorySlotContents(11, this.horseChest.getStackInSlot(11).EMPTY);
				hand[10] = false;
			}
		} else {
			this.horseChest.setInventorySlotContents(11, this.horseChest.getStackInSlot(11).EMPTY);
			hand[10] = false;
		}
	}*/
    
    public boolean CanAttack(Entity entity){
    	if(entity instanceof IMob && ((EntityLivingBase) entity).func_110143_aJ() > 0.0F){
    		return true;
    	}else
    	{
    		return false;
    	}
    }
    /*public boolean CanAttack(Entity entity){
    	{
    		return false;
    	}
    }*/
    
    
    
    /**
    * Checks to make sure the light is not too bright where the mob is spawning
    */
   protected boolean isValidLightLevel()
   {
       BlockPos blockpos = new BlockPos(this.field_70165_t, this.func_174813_aQ().field_72338_b, this.field_70161_v);

       if (this.field_70170_p.func_175642_b(EnumSkyBlock.SKY, blockpos) > this.field_70146_Z.nextInt(32))
       {
           return false;
       }
       else
       {
           int i = this.field_70170_p.func_175671_l(blockpos);

           if (this.field_70170_p.func_72911_I())
           {
               int j = this.field_70170_p.func_175657_ab();
               this.field_70170_p.func_175692_b(10);
               i = this.field_70170_p.func_175671_l(blockpos);
               this.field_70170_p.func_175692_b(j);
           }

           return i <= this.field_70146_Z.nextInt(8);
       }
   }

   /**
    * Checks if the entity's current position is a valid location to spawn this entity.
    */
   public boolean func_70601_bi()
   {
       return this.field_70170_p.func_175659_aa() != EnumDifficulty.PEACEFUL && this.isValidLightLevel() && super.func_70601_bi();
   }
    
    /**
     * Determines if an entity can be despawned, used on idle far away entities
     */
    protected boolean func_70692_ba()
    {
    	return false;
    }
    
   
    protected int getInventorySize()
    {
        return 32;
    }

    protected void initHorseChest()
    {
    	ContainerInventoryBox containerhorsechest = this.horseChest;
        this.horseChest = new ContainerInventoryBox("HorseChest", this.getInventorySize());
        this.horseChest.func_110133_a(this.func_70005_c_());

        if (containerhorsechest != null)
        {
            containerhorsechest.func_110132_b(this);
            int i = Math.min(containerhorsechest.func_70302_i_(), this.horseChest.func_70302_i_());

            for (int j = 0; j < i; ++j)
            {
                ItemStack itemstack = containerhorsechest.func_70301_a(j);

                if (!itemstack.func_190926_b())
                {
                    this.horseChest.func_70299_a(j, itemstack.func_77946_l());
                }
            }
        }

        this.horseChest.func_110134_a(this);
        this.updateHorseSlots();
    }
    
    public void func_76316_a(IInventory invBasic)
    {
    	this.updateHorseSlots();
    }
    /**
     * Updates the items in the saddle and armor slots of the horse's inventory.
     */
    protected void updateHorseSlots()
    {
    	ContainerInventoryBox containerhorsechest = this.horseChest;
    	if (containerhorsechest != null)
        {
    		//this.horseChest.setInventorySlotContents(11, new ItemStack(Items.EMERALD));
        }
    }
    public void func_70071_h_()
    {
        super.func_70071_h_();
        this.updateHorseSlots();
       
    }
    
    public int getInventoryColumns()
    {
        return 5;
    }
}
