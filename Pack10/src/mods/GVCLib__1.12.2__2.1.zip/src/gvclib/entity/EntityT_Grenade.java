package gvclib.entity;

import java.util.List;
import gvclib.network.GVCLClientMessageKeyPressed;
import gvclib.network.GVCLPacketHandler;
import gvclib.world.GVCExplosionBase;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityAreaEffectCloud;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.MoverType;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.MobEffects;
import net.minecraft.init.PotionTypes;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.datafix.DataFixer;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.world.World;


import gvclib.network.GVCLClientMessageKeyPressed;
import gvclib.network.GVCLPacketHandler;
import gvclib.world.GVCExplosionBase;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityAreaEffectCloud;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.MoverType;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.init.MobEffects;
import net.minecraft.init.PotionTypes;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.potion.PotionEffect;
import net.minecraft.potion.PotionType;
import net.minecraft.potion.PotionUtils;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.datafix.DataFixer;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.world.World;

public class EntityT_Grenade extends EntityBBase {
	public EntityT_Grenade(World worldIn) {
		super(worldIn);
	}

	public EntityT_Grenade(World worldIn, EntityLivingBase throwerIn) {
		super(worldIn, throwerIn);
	}

	public EntityT_Grenade(World worldIn, double x, double y, double z) {
		super(worldIn, x, y, z);
	}

	public static void func_189662_a(DataFixer p_189662_0_) {
		EntityBBase.func_189661_a(p_189662_0_, "Snowball");
	}

	protected void func_70088_a()
    {
		//super.entityInit();
    	this.field_70180_af.func_187214_a(Model, new String("gvclib:textures/entity/dynamite.mqo"));
        this.field_70180_af.func_187214_a(Tex, new String("gvclib:textures/entity/dynamite.png"));
        this.field_70180_af.func_187214_a(ModelF, new String("gvclib:textures/entity/mflash.mqo"));
        this.field_70180_af.func_187214_a(TexF, new String("gvclib:textures/entity/mflash.png"));
    }
	
	public void func_70071_h_()
    {
        //super.onUpdate();
		if (!this.field_70170_p.field_72995_K)
        {
            this.func_70052_a(6, this.func_184202_aL());
        }

        this.func_70030_z();
        this.field_70169_q = this.field_70165_t;
        this.field_70167_r = this.field_70163_u;
        this.field_70166_s = this.field_70161_v;

        if (!this.func_189652_ae())
        {
            //this.motionY -= 0.03999999910593033D;
        	this.field_70181_x -= 0.03999999910593033D - this.gra;
        }

        this.func_70091_d(MoverType.SELF,this.field_70159_w, this.field_70181_x, this.field_70179_y);
        this.field_70159_w *= 0.9800000190734863D;
        this.field_70181_x *= 0.9800000190734863D;
        this.field_70179_y *= 0.9800000190734863D;

        if (this.field_70122_E)
        {
            this.field_70159_w *= 0.699999988079071D;
            this.field_70179_y *= 0.699999988079071D;
            this.field_70181_x *= -0.5D;
        }

        ++time;
        if(this.exsmoke) {
        	if(time > timemax * 10){
        		if(!this.field_70170_p.field_72995_K){
        			this.func_70106_y();
                }
        	}else
        	if(time > timemax){
        		if(!this.field_70170_p.field_72995_K){
                	this.explode();
                }
        	}
        }else {
        	if(time > timemax){
            	
                Entity entity = null;
                List<Entity> list = this.field_70170_p.func_72839_b(this, 
                		this.func_174813_aQ().func_72321_a(this.field_70159_w, this.field_70181_x, this.field_70179_y).func_186662_g((double)exlevel*2));
                double d0 = 0.0D;

                for (int i = 0; i < list.size(); ++i)
                {
                    Entity entity1 = (Entity)list.get(i);

                    if (entity1.func_70067_L())
                    {
                        if (entity1 == this.ignoreEntity)
                        {}
                        else if (this.field_70173_aa < 2 && this.ignoreEntity == null)
                        {
                            this.ignoreEntity = entity1;
                        }
                        else
                        {
                            if (entity1 instanceof EntityLivingBase)
                            {
                            	double dx = Math.abs(entity1.field_70165_t - this.field_70165_t);
                        		double dz = Math.abs(entity1.field_70161_v - this.field_70161_v);
                        		float dd = (float)Math.sqrt((dx * dx) + (dz * dz));
                        		if(dd > Bdamege)dd = Bdamege;
                        		float dame = Bdamege - dd;
                				//entity1.attackEntityFrom(DamageSource.causeMobDamage(this.getThrower()), Bdamege);
                            }
                            
                        }
                    }
                }
            	
            	if(!this.field_70170_p.field_72995_K){
            	this.func_70106_y();
            	this.explode();
            	}
            }else
            {
                this.func_70072_I();
                this.field_70170_p.func_175688_a(EnumParticleTypes.SMOKE_NORMAL, this.field_70165_t, this.field_70163_u + 0.5D, this.field_70161_v, 0.0D, 0.0D, 0.0D, new int[0]);
            }
        }
    }
	
	private void explode()
    {
        //this.world.createExplosion(this, this.posX, this.posY + (double)(this.height / 16.0F), this.posZ, exlevel, ex);
        if(this.getThrower() != null) {
        	if(this.exsmoke) {
        		
        		
        		if(time %5 == 0)GVCLPacketHandler.INSTANCE2.sendToAll(
        				new GVCLClientMessageKeyPressed(0, this.func_145782_y(), exlevel, this.field_70165_t, this.field_70163_u, this.field_70161_v));
        		 
        		
        		
        		{
        			 Entity entity = null;
                     List<Entity> list = this.field_70170_p.func_72839_b(this, 
                     		this.func_174813_aQ().func_72321_a(this.field_70159_w, this.field_70181_x, this.field_70179_y).func_186662_g((double)exlevel*2));
                     for (int i = 0; i < list.size(); ++i)
                     {
                         Entity entity1 = (Entity)list.get(i);

                         if (entity1.func_70067_L())
                         {
                             if (entity1 == this.ignoreEntity)
                             {}
                             else if (this.field_70173_aa < 2 && this.ignoreEntity == null)
                             {
                                 this.ignoreEntity = entity1;
                             }
                             else
                             {
                                 if (entity1 instanceof EntityLivingBase)
                                 {
                                	 EntityLivingBase en = (EntityLivingBase) entity1;
                                	 en.func_70690_d(new PotionEffect(MobEffects.field_76421_d, 20, 1));
                                	 if (!(entity1 instanceof EntityPlayer))
                                     {
                                		 en.func_70690_d(new PotionEffect(MobEffects.field_76440_q, 20, 1));
                                     }
                                 }
                             }
                         }
                     }
        		 }
        	}
        	else if(this.exflash){
        		GVCExplosionBase.ExplosionKai(this.getThrower(), this, this.field_70165_t + 0, this.field_70163_u + 0, this.field_70161_v + 0, this.exlevel, this.exfire,  this.ex);
        		{
       			 Entity entity = null;
                    List<Entity> list = this.field_70170_p.func_72839_b(this, 
                    		this.func_174813_aQ().func_72321_a(this.field_70159_w, this.field_70181_x, this.field_70179_y).func_186662_g((double)exlevel*2));
                    for (int i = 0; i < list.size(); ++i)
                    {
                        Entity entity1 = (Entity)list.get(i);

                        if (entity1.func_70067_L())
                        {
                            if (entity1 == this.ignoreEntity)
                            {}
                            else if (this.field_70173_aa < 2 && this.ignoreEntity == null)
                            {
                                this.ignoreEntity = entity1;
                            }
                            else
                            {
                                if (entity1 instanceof EntityLivingBase)
                                {
                               	 EntityLivingBase en = (EntityLivingBase) entity1;
                               	 en.func_70690_d(new PotionEffect(MobEffects.field_76440_q, 40, 1));
                                }
                            }
                        }
                    }
       		 }
        	}
        	else if(this.exgas){
        		//  ItemStack itemstack = new ItemStack(Items.POTIONITEM);
                //  PotionType potiontype = PotionUtils.getPotionFromItem(itemstack);
        		EntityAreaEffectCloud entityareaeffectcloud = new EntityAreaEffectCloud(this.field_70170_p, this.field_70165_t, this.field_70163_u, this.field_70161_v);
                entityareaeffectcloud.func_184481_a(this.getThrower());
                entityareaeffectcloud.func_184483_a(exlevel*2);
                entityareaeffectcloud.func_184486_b(timemax * 10);
                entityareaeffectcloud.func_184495_b(-0.5F);
                entityareaeffectcloud.func_184485_d(10);
                entityareaeffectcloud.func_184487_c(-entityareaeffectcloud.func_184490_j() / (float)entityareaeffectcloud.func_184489_o());
                //entityareaeffectcloud.setPotion(potiontype);
                entityareaeffectcloud.func_184484_a(PotionTypes.field_185254_z);

                /*for (PotionEffect potioneffect : PotionUtils.getFullEffectsFromItem(p_190542_1_))
                {
                    entityareaeffectcloud.addEffect(new PotionEffect(potioneffect));
                }*/

              /*  NBTTagCompound nbttagcompound = p_190542_1_.getTagCompound();

                if (nbttagcompound != null && nbttagcompound.hasKey("CustomPotionColor", 99))
                {
                    entityareaeffectcloud.setColor(nbttagcompound.getInteger("CustomPotionColor"));
                }*/

                this.field_70170_p.func_72838_d(entityareaeffectcloud);
                this.func_70106_y();
        	}
        	else {
        		GVCExplosionBase.ExplosionKai(this.getThrower(), this, this.field_70165_t + 0, this.field_70163_u + 0, this.field_70161_v + 0, this.exlevel, this.exfire,  this.ex);
        	}
        }
    }
	
	/**
	 * Called when this EntityThrowable hits a block or entity.
	 */
	protected void onImpact(RayTraceResult result) {
	}

	@Override
	public void func_70186_c(double x, double y, double z, float velocity, float inaccuracy) {
		// TODO 自動生成されたメソッド・スタブ
		
	}
}
