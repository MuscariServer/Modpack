package gvclib.entity.living;

import java.util.List;
import gvclib.entity.EntityBBase;
import gvclib.entity.EntityB_Bullet;
import gvclib.entity.EntityB_BulletAA;
import gvclib.entity.EntityB_BulletFire;
import gvclib.entity.EntityB_GrenadeB;
import gvclib.entity.EntityB_Missile;
import gvclib.entity.EntityB_Shell;
import gvclib.entity.EntityTNTBase;
import gvclib.entity.EntityT_Flash;
import gvclib.entity.EntityT_Grenade;
import gvclib.entity.EntityT_TNT;
import gvclib.entity.Entity_Flare;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.monster.IMob;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.projectile.EntityTippedArrow;
import net.minecraft.init.MobEffects;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.DamageSource;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;


import gvclib.entity.EntityBBase;
import gvclib.entity.EntityB_Bullet;
import gvclib.entity.EntityB_BulletAA;
import gvclib.entity.EntityB_BulletFire;
import gvclib.entity.EntityB_GrenadeB;
import gvclib.entity.EntityB_Missile;
import gvclib.entity.EntityB_Shell;
import gvclib.entity.EntityTNTBase;
import gvclib.entity.EntityT_Flash;
import gvclib.entity.EntityT_Grenade;
import gvclib.entity.EntityT_TNT;
import gvclib.entity.Entity_Flare;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.monster.IMob;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.projectile.EntityTippedArrow;
import net.minecraft.init.MobEffects;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.DamageSource;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public class PL_Weapon {

	public static void AttacktaskGunner(EntityGVCLivingBase entity, int id, EntityPlayer player, double range,
    		String model, String tex,String modelf, String texf,int ftime, SoundEvent sound
    		, float f, double w, double h, double z, double px, double py, double pz, Vec3d lock, float rote, double maxy, double miny
    		, int dame, float speed, float recoil, float ex, boolean extrue, int kazu,  double gra, int maxtime, int dameid){
    		List<Entity> llist = entity.field_70170_p.func_72839_b(entity,
					entity.func_174813_aQ().func_72321_a(entity.field_70159_w, entity.field_70181_x, entity.field_70179_y).func_186662_g(range));
			if (llist != null) {
				for (int lj = 0; lj < llist.size(); lj++) {
					Entity entity1 = (Entity) llist.get(lj);
					if (entity1.func_70067_L()) {
						{
							if (entity1 instanceof IMob && entity1 != null && ((EntityLivingBase) entity1).func_110143_aJ() > 0.0F && entity.func_110143_aJ() > 0.0F) 
							{
								double ddy = Math.abs(entity1.field_70163_u - entity.field_70163_u);
								double dyp = entity.field_70163_u + maxy;
								double dym = entity.field_70163_u - miny;
								double d5 = entity1.field_70165_t - entity.field_70165_t;
								double d7 = entity1.field_70161_v - entity.field_70161_v;
								double d6 = entity1.field_70163_u - entity.field_70163_u;
								double d1 = entity.field_70163_u - (entity1.field_70163_u);
								double d3 = (double) MathHelper.func_76133_a(d5 * d5 + d7 * d7);
								float f11 = (float) (-(Math.atan2(d1, d3) * 180.0D / Math.PI));
								rote
										= -((float) Math.atan2(d5, d7)) * 180.0F / (float) Math.PI;
								if (dyp > entity1.field_70163_u && dym < entity1.field_70163_u) {
									Weapon(entity, id, player, model, tex, modelf, texf, ftime, sound, 
											f, w, h, z, px, py, pz, lock, rote, maxy, miny,
											dame, speed, recoil, ex,extrue, kazu, gra, maxtime, dameid);
									break;
								}
								
							}
						}
						
					}
				}
			}
    }
	
	public static void Weapon(EntityGVCLivingBase entity, int id, EntityPlayer player, 
			String model, String tex, String modelf, String texf,int ftime,
			SoundEvent sound,
			float f, double w, double h, double z, double px, double py, double pz, Vec3d lock, float rote, double maxy, double miny,
    		int power, float speed, float bure, float ex, boolean extrue,int kazu, double gra, int maxtime, int dameid)
	{
		WeaponAttack(entity, id,  player, 
				 model,  tex,  modelf,  texf, ftime,
				 sound,
				 f,  w,  h,  z, 0,  px,  py,  pz,  lock,  rote,  maxy,  miny,
	    		 power,  speed,  bure,  ex,  extrue, kazu,  gra,  maxtime,  dameid);
	}
	
	public static void WeaponAttack(EntityGVCLivingBase entity, int id, EntityPlayer player, 
			String model, String tex, String modelf, String texf,int ftime,
			SoundEvent sound,
			float f, double w, double h, double z, double yoffset, double px, double py, double pz,  Vec3d lock, float rote, double maxy, double miny,
    		int power, float speed, float bure, float ex, boolean extrue,int kazu, double gra, int maxtime, int dameid)
	{
		int ra = entity.field_70170_p.field_73012_v.nextInt(10) + 1;
    	float val = ra * 0.02F;
		entity.field_70170_p.func_184148_a((EntityPlayer) null, entity.field_70165_t, entity.field_70163_u,
				entity.field_70161_v, sound, SoundCategory.NEUTRAL, 5.0F, 0.9F + val);
    	double xx11 = 0;
		double zz11 = 0;
		xx11 -= MathHelper.func_76126_a(rote * 0.01745329252F) * z;
		zz11 += MathHelper.func_76134_b(rote * 0.01745329252F) * z;
		xx11 -= MathHelper.func_76126_a(rote * 0.01745329252F + f) * w;
		zz11 += MathHelper.func_76134_b(rote * 0.01745329252F + f) * w;
		double kaku = 0;
		//kaku += lock.y * 2;
		kaku = MathHelper.func_76133_a(z* z + w*w) * Math.tan(Math.toRadians(-entity.field_70125_A)) * 0.4D;
		Vec3d locked = player.func_70040_Z();
		if(id < 10){
			for (int ka = 0; ka < kazu; ++ka) {
				EntityBBase var3;
				{
					if (id == 1) {
						var3 = new EntityB_BulletAA(player.field_70170_p, player);
					} else if (id == 2) {
						var3 = new EntityB_GrenadeB(player.field_70170_p, player);
					} else if (id == 3) {
						var3 = new EntityB_Shell(player.field_70170_p, player);
					} else if (id == 4) {
						var3 = new EntityB_Missile(player.field_70170_p, player);
						EntityB_Missile mi = (EntityB_Missile) var3;
						mi.speedd = speed;
					} else if (id == 5) {
						var3 = new EntityB_BulletAA(player.field_70170_p, player);
						var3.bulletDameID = 1;
					} else if (id == 6) {
						var3 = new EntityB_BulletFire(player.field_70170_p, player);
						var3.timemax = 10;
					} else if (id == 7) {
						var3 = new EntityB_BulletAA(player.field_70170_p, entity);
						EntityB_BulletAA aa = (EntityB_BulletAA) var3;
						aa.exnear = true;
					} else if (id == 8) {
						var3 = new EntityB_Missile(player.field_70170_p, entity);
						EntityB_Missile mi = (EntityB_Missile) var3;
						mi.speedd = speed;
						mi.autoaim = false;
					} else if (id == 9) {
						var3 = new EntityT_Grenade(player.field_70170_p, player);
					} else {
						var3 = new EntityB_Bullet(player.field_70170_p, player);
					}
					var3.Bdamege = power;
					var3.gra = gra;
					var3.friend = entity;
					var3.exlevel = ex;
					var3.ex = extrue;
					var3.muteki = true;
					var3.mitarget = entity.mitarget;
					var3.setModel(model);
					var3.setTex(tex);
					var3.timemax = maxtime;
					//var3.setModelF("gvclib:textures/entity/mfire.mqo");
					//var3.setTexF("gvclib:textures/entity/mfire.png");
					var3.bulletDameID = dameid;
					var3.func_70012_b(px + xx11, py + h + kaku, pz + zz11, player.field_70177_z,
							player.field_70125_A);
					var3.setThrowableHeading(lock.field_72450_a, lock.field_72448_b + 0.03 + yoffset, lock.field_72449_c, speed, bure);
					if (!player.field_70170_p.field_72995_K) {
						player.field_70170_p.func_72838_d(var3);
					}
				}
				{
					EntityT_Flash flash = new EntityT_Flash(player.field_70170_p, player);
					flash.gra = 0.03;
					flash.timemax = ftime;
					flash.setModel(modelf);
					flash.setTex(texf);
					flash.func_70012_b(px + xx11, py + h + kaku, pz + zz11, player.field_70177_z,
							player.field_70125_A);
					flash.setThrowableHeading(lock.field_72450_a, lock.field_72448_b + 0.03 + yoffset, lock.field_72449_c, 0.1F, 0);
					if (!player.field_70170_p.field_72995_K) {
						player.field_70170_p.func_72838_d(flash);
					}
				}
			}
		}else if(id >= 10 && id < 20){
			EntityTNTBase var3;
			if(id == 0){
				var3 = new EntityT_TNT(player.field_70170_p, player);
			}else{
				var3 = new EntityT_TNT(player.field_70170_p, player);
			}
			var3.Bdamege = power;
			var3.friend = entity;
			var3.exlevel = ex;
			var3.ex = extrue;
			var3.muteki = true;
			var3.exinground = true;
		//	var3.exnear = true;
			var3.extime = 200;
			var3.func_70012_b(px + xx11, py + h + kaku, pz + zz11,
					player.field_70177_z, player.field_70125_A);
			var3.setThrowableHeading(lock.field_72450_a, locked.field_72448_b + 0.03, lock.field_72449_c, speed, bure);
			if (!player.field_70170_p.field_72995_K) {
				player.field_70170_p.func_72838_d(var3);
			}
		}
		else if(id == 21){
			for (int ka = 0; ka < kazu; ++ka) {
				int xx = player.field_70170_p.field_73012_v.nextInt(6);
				int zz = player.field_70170_p.field_73012_v.nextInt(6);
				Entity_Flare var8 = new Entity_Flare(player.field_70170_p);
				var8.field_70181_x = speed;
				var8.func_70012_b(px - 3 + xx, py, pz - 3 + zz,
						var8.field_70759_as, var8.field_70125_A);
				if (!player.field_70170_p.field_72995_K) {
					player.field_70170_p.func_72838_d(var8);
				}
			}
		}
		else if(id == 51){
			for (int ka = 0; ka < kazu; ++ka) {
				int xx = player.field_70170_p.field_73012_v.nextInt(6);
				int zz = player.field_70170_p.field_73012_v.nextInt(6);
				EntityTippedArrow var3 = new EntityTippedArrow(player.field_70170_p);
				var3.func_70012_b(px + xx11, py + h + kaku, pz + zz11,
						player.field_70177_z, player.field_70125_A);
				var3.func_70186_c(lock.field_72450_a, locked.field_72448_b + 0.03, lock.field_72449_c, speed, bure);
				if (!player.field_70170_p.field_72995_K) {
					player.field_70170_p.func_72838_d(var3);
				}
			}
		}
		else if(id == 30){
			double x2 = 0;
			double z2 = 0;
			x2 -= MathHelper.func_76126_a(entity.rotation * 0.01745329252F) * 2.0;
			z2 += MathHelper.func_76134_b(entity.rotation * 0.01745329252F) * 2.0;
			AxisAlignedBB axisalignedbb2 = new AxisAlignedBB(
					player.field_70165_t + x2, player.field_70163_u, player.field_70161_v + z2, 
					player.field_70165_t + x2, player.field_70163_u, player.field_70161_v + z2)
	        		.func_72321_a(3, 5, 3);
			List<Entity> llist = player.field_70170_p.func_72839_b(player,axisalignedbb2);
			if (llist != null) {
				for (int lj = 0; lj < llist.size(); lj++) {
					Entity entity1 = (Entity) llist.get(lj);
					if (entity1.func_70067_L() && entity1 instanceof EntityLivingBase && entity1 != null) {
						if(entity1 != player && entity1 != player.func_184179_bs()){
							entity1.func_70097_a(DamageSource.func_76358_a(player), power);
							
						}
					}
				}
			}
		}
	}

	public static void EntityLock(EntityGVCLivingBase entity, EntityPlayer player, boolean aam) {
		{
			Vec3d looken = player.func_70040_Z();
			Vec3d locken = player.func_70040_Z();
			float d = 100;
			boolean lock = false;
			//if (entity.ontick % 2 == 0)
			{
				//List llist = entity.world.getEntitiesWithinAABBExcludingEntity(entity, axisalignedbb);
				List<Entity> llist = player.field_70170_p.func_72839_b(player,
						player.func_174813_aQ()
								.func_72321_a(locken.field_72450_a * d, locken.field_72448_b * d, locken.field_72449_c * d)
								.func_186662_g(0.25D));
				if (llist != null) {
					for (int lj = 0; lj < llist.size(); lj++) {

						Entity entity1 = (Entity) llist.get(lj);
						if (entity1.func_70067_L()) {
							boolean flag = entity.func_70635_at().func_75522_a(entity1);
							if (entity1 instanceof IMob && entity1 != null && entity1 != player
									&& entity1 != entity && flag) {
								BlockPos bp = entity1.field_70170_p.func_175645_m(new BlockPos(entity1.field_70165_t, entity1.field_70163_u, entity1.field_70161_v));
								if(aam) {
									if(entity1.field_70163_u > bp.func_177956_o() + 5){
										entity.mitarget = (EntityLivingBase) entity1;
										lock = true;
										break;
									}
								}else {
									 if(entity1.field_70163_u < bp.func_177956_o() + 5 || entity1.field_70122_E){
										entity.mitarget = (EntityLivingBase) entity1;
										lock = true;
										break;
									}
								}
							}
						}
					}
				}
			}
			if(lock && entity.mitarget !=null){
				if (entity.ontick % 3 == 0) {
					//NBTTagCompound nbt = entity.mitarget.getEntityData();
					//nbt.setInteger("LockOnTime", 200);
					entity.mitarget.func_70690_d(new PotionEffect(MobEffects.field_188423_x, 10, 10));
				}
				if (entity.ontick % 10 == 0) {
		//			entity.playSound(GVCSoundEvent.sound_lock, 0.4F, 1.0F);
				}
			}
		}
		/*for (int l1 = 0; l1 < 100; l1++) {
			double x2 = 0;
			double z2 = 0;
			x2 -= MathHelper.sin(player.rotationYawHead * 0.01745329252F) * l1;
			z2 += MathHelper.cos(player.rotationYawHead * 0.01745329252F) * l1;
			double k = player.posX;
			double l = player.posY;
			double i = player.posZ;
			Vec3d looken = player.getLookVec();
			Vec3d locken = player.getLookVec();
			float d = 100;
			double yy = looken.y * l1;
			AxisAlignedBB axisalignedbb = (new AxisAlignedBB((double) (k), (double) (l), (double) (i),
					(double) (k + x2), (double) (l + yy), (double) (i + z2))).grow(1);
			boolean lock = false;
			if (entity.ontick % 2 == 0)
			{
				//List llist = entity.world.getEntitiesWithinAABBExcludingEntity(entity, axisalignedbb);
				List<Entity> llist = player.world.getEntitiesWithinAABBExcludingEntity(player,
						player.getEntityBoundingBox()
								.expand(locken.x * d, locken.y * d, locken.z * d)
								.grow(0.15D));
				if (llist != null) {
					for (int lj = 0; lj < llist.size(); lj++) {

						Entity entity1 = (Entity) llist.get(lj);
						if (entity1.canBeCollidedWith()) {
							boolean flag = entity.getEntitySenses().canSee(entity1);
							if (entity1 instanceof IMob && entity1 != null && entity1 != player
									&& entity1 != entity && flag) {
								BlockPos bp = entity1.world.getHeight(new BlockPos(entity1.posX, entity1.posY, entity1.posZ));
								if(aam && entity1.posY > bp.getY() + 5){
									entity.mitarget = (EntityLivingBase) entity1;
									lock = true;
									break;
								}else if(entity1.posY < bp.getY() + 5){
									entity.mitarget = (EntityLivingBase) entity1;
									lock = true;
									break;
								}
							}
						}
					}
				}
			}
			if(lock && entity.mitarget !=null){
				if (entity.ontick % 3 == 0) {
					NBTTagCompound nbt = entity.mitarget.getEntityData();
					nbt.setInteger("LockOnTime", 200);
					entity.mitarget.addPotionEffect(new PotionEffect(MobEffects.GLOWING, 10, 10));
				}
				if (entity.ontick % 10 == 0) {
		//			entity.playSound(GVCSoundEvent.sound_lock, 0.4F, 1.0F);
				}
			}
		}*/
		
	}
}
