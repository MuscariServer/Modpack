package gvclib.entity.living.cnt.ai;

import java.util.List;
import gvclib.entity.living.EntityGVCLivingBase;
import gvclib.entity.living.PL_RoteModel;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;


import gvclib.entity.living.EntityGVCLivingBase;
import gvclib.entity.living.ISoldier;
import gvclib.entity.living.PL_RoteModel;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public class AI_EntityMove_Heli_Squad {
	public static void moveheli(EntityGVCLivingBase entity, EntityGVCLivingBase ridding, float f1, float sp,
			float turnspeed, double max, double range, int gy) {
		entity.target = false;
		boolean can_flight = false;
		BlockPos bp = entity.field_70170_p.func_175645_m(new BlockPos(entity.field_70165_t, entity.field_70163_u, entity.field_70161_v));
		int genY = bp.func_177956_o() + gy;
		if (entity.field_70163_u <= genY) {
			if (entity.throttle < entity.thmax) {
				++entity.throttle;
			}
			entity.thpower = entity.thpower + entity.thmaxa;
			entity.throttle_up = 1;
		}
		else if (entity.field_70163_u > genY + 5) {
			if (entity.thpower > entity.thmax / 2) {
				entity.thpower = entity.thpower + entity.thmina;
			}
			if (entity.throttle > entity.thmax / 2) {
				--entity.throttle;
			}
			entity.throttle_up = -1;
		}else {
			entity.throttle_up = 0;
		}
		
		if (entity.field_70163_u > genY - 5) {
			can_flight = true;
		}
		
		VehicleAI_RotationYawOffset.offset(entity, ridding);
//		ridding.rotationYaw = ridding.rotationYawHead = entity.rotationYaw;
		if (!ridding.getTargetEntity_isLiving()){
			double x = ridding.field_70165_t;
			double y = ridding.field_70163_u;
			double z = ridding.field_70161_v;
			double han = range;
			AxisAlignedBB axisalignedbb2 = (new AxisAlignedBB((double) (x - han), (double) (y - han),
					(double) (z - han), (double) (x + han), (double) (y + han), (double) (z + han)))
							.func_186662_g(han);
			List<Entity> llist = ridding.field_70170_p.func_72839_b(entity, axisalignedbb2);
			if (llist != null) {
				//player
				for (int lj = 0; lj < llist.size(); lj++) {
					Entity entity1 = (Entity) llist.get(lj);
					if (entity1.func_70067_L()) {
						if (ridding.getMoveT() == 0)//follow
						{
							if (entity1 != null && entity1 instanceof EntityPlayerMP) {
								EntityPlayer player = (EntityPlayer) entity1;
								//System.out.println(String.format("m"));
								if (ridding.isOwner(player)) {
									double d5 = entity1.field_70165_t - entity.field_70165_t;
									double d7 = entity1.field_70161_v - entity.field_70161_v;
									double d6 = entity1.field_70163_u - entity.field_70163_u;
									double d1 = entity.field_70163_u - (entity1.field_70163_u);
									double d3 = (double) MathHelper.func_76133_a(d5 * d5 + d7 * d7);
									float f11 = (float) (-(Math.atan2(d1, d3) * 180.0D / Math.PI));
									entity.rote = -((float) Math.atan2(d5, d7)) * 180.0F / (float) Math.PI;

									{
										rote(entity, turnspeed);
									}

									double ddx = Math.abs(d5);
									double ddz = Math.abs(d7);
									if ((ddx > 15 || ddz > 15)) {
										entity.setAIType(0);
									}else {
										
									}
								}
							}
						}
					}
				}
				//player
			}
		}else
		{
			List<Entity> llist = entity.field_70170_p.func_72839_b(entity,
					entity.func_174813_aQ().func_72321_a(entity.field_70159_w, entity.field_70181_x, entity.field_70179_y).func_186662_g(range));
			if (llist != null) {
				for (int lj = 0; lj < llist.size(); lj++) {
					Entity entity1 = (Entity) llist.get(lj);
					if (entity1.func_70067_L()) {
						boolean flag = entity.func_70635_at().func_75522_a(entity1);
						if (ridding.targetentity == entity1 && ridding.CanAttack(entity1)) {
							double d5 = entity1.field_70165_t - entity.field_70165_t;
							double d7 = entity1.field_70161_v - entity.field_70161_v;
							double d6 = entity1.field_70163_u - entity.field_70163_u;
							double d1 = entity.field_70163_u - (entity1.field_70163_u);
							double d3 = (double) MathHelper.func_76133_a(d5 * d5 + d7 * d7);
							float f11 = (float) (-(Math.atan2(d1, d3) * 180.0D / Math.PI));
							entity.rote = -((float) Math.atan2(d5, d7)) * 180.0F / (float) Math.PI;

							{
								rote(entity, turnspeed);
							}

							double ddx = Math.abs(d5);
							double ddz = Math.abs(d7);
							if ((ddx > max || ddz > max)) {
								entity.setAIType3(0);
							}else {
								entity.setAIType3(1);
							}

							if (flag) {
								ridding.targetentity = (EntityLivingBase) entity1;
							}
							ridding.target = true;
							break;
						} else
						if (ridding.CanAttack(entity1) && flag) {
							{
								ridding.targetentity = (EntityLivingBase) entity1;
								ridding.target = true;
								break;
							}
						}
					}
				}
			}
		}
		if(ridding.getMoveT() == 2){
			{
				double d51 = entity.getMoveX() - entity.field_70165_t;
				double d71 = entity.getMoveZ()- entity.field_70161_v;
				double d61 = entity.getMoveY() - entity.field_70163_u;
				double d11 = entity.field_70163_u - (entity.getMoveY());
				double d31 = (double) MathHelper.func_76133_a(d51 * d51 + d71 * d71);
				float f111 = (float) (-(Math.atan2(d11, d31) * 180.0D / Math.PI));
				entity.rote = -((float) Math.atan2(d51, d71)) * 180.0F / (float) Math.PI;

				{
					rote(entity, turnspeed);
				}

				double ddx = Math.abs(d51);
				double ddz = Math.abs(d71);
				if ((ddx > max || ddz > max)) {
					entity.setAIType(0);
				}else {
					
				}
			} 
		}
			
			if(can_flight ){
				if(ridding.getTargetEntity_isLiving()) {
					if(ridding.getMoveT() == 3) {
					}else {
						if(entity.getAIType() == 1) {
							if(entity.throte < 50){
								entity.throte = entity.throte + 2;
							}
						}else
						if(entity.getAIType() == 2) {
							if(entity.throte > -50){
								entity.throte = entity.throte - 2;
							}
						}else
						if(entity.getAIType() == 3) {
							entity.field_70125_A = entity.rotationp_max/2;
						}else{
							entity.field_70125_A = entity.rotationp_min/2;
						}
					}
				}else {
					if(entity.getAIType3() == 0)entity.field_70125_A = entity.rotationp_min/2;
				}
				
			}
			entity.field_70127_C = entity.field_70125_A;
	}
	
	private static void rote(EntityGVCLivingBase entity, float turnspeed) {
		if(entity.rote > 360 || entity.rote < -360) {
			entity.rote = entity.rote %360;
		}
		float f3 = (float) (entity.field_70759_as - entity.rote);
		if(entity.field_70759_as != entity.rote){
    		if(f3 > turnspeed){
				if(f3 > 180F){
					PL_RoteModel.rotemodel(entity,+ turnspeed);
				}else{
					PL_RoteModel.rotemodel(entity,- turnspeed);
				}
			}
			else if(f3 < -turnspeed){
				if(f3 < -180F){
					PL_RoteModel.rotemodel(entity,- turnspeed);
				}else{
					PL_RoteModel.rotemodel(entity,+ turnspeed);
				}
			}
        }
		entity.field_70177_z  = entity.field_70759_as;
		/*if(entity.rotationYawHead - entity.rote > 180) {
			entity.rote = entity.rote + 360;
		}
		if(entity.rotationYawHead - entity.rote < -180) {
			entity.rote = entity.rote - 360;
		}
		if (entity.rotationYawHead != entity.rote) {
			if (entity.rotationYawHead < entity.rote) {
				entity.rotationYawHead = entity.rotationYawHead + turnspeed;
				entity.rotationYaw = entity.rotationYaw + turnspeed;
				entity.prevRotationYaw = entity.prevRotationYaw + turnspeed;
				entity.prevRotationYawHead = entity.prevRotationYawHead + turnspeed;
			} else if (entity.rotationYawHead > entity.rote) {
				entity.rotationYawHead = entity.rotationYawHead - turnspeed;
				entity.rotationYaw = entity.rotationYaw - turnspeed;
				entity.prevRotationYaw = entity.prevRotationYaw - turnspeed;
				entity.prevRotationYawHead = entity.prevRotationYawHead - turnspeed;
			}
		}*/
	}
	
}
