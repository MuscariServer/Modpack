package gvclib.entity.living;

import gvclib.entity.EntityB_Bullet;
import gvclib.entity.EntityB_BulletAA;
import gvclib.entity.EntityB_GrenadeB;
import gvclib.entity.EntityB_Shell;
import net.minecraft.entity.Entity;
import net.minecraft.entity.projectile.EntityArrow;
import net.minecraft.util.math.MathHelper;

public class AI_Damage {

	public static float TankArmor(EntityGVCLivingBase entity, Entity entityin, float part2, float min, float nom, float max, float rotehead){
float da = 1;
		
		double ix = 0;
		double iy = 0;
		double iz = 0;
		float f11 = rotehead * (2 * (float) Math.PI / 360);
		{
			double ex = entity.field_70165_t;
			double ey = entity.field_70163_u;
			double ez = entity.field_70161_v;
			ix -= MathHelper.func_76126_a(f11) * 2;
			iz += MathHelper.func_76134_b(f11) * 2;
			double px = entity.field_70165_t + ix;
			double pz = entity.field_70161_v + iz;
			double px1 = entity.field_70165_t - ix;
			double pz1 = entity.field_70161_v - iz;
			if(rotehead >= -22.5 && rotehead <= 22.5){
				if(ez >= pz){
					da = da * min;
				}
				else if(ez <= pz1){
					da = da * max;
				}
				else{
					da = da * nom;
				}
			}
			if(rotehead >= 22.5 && rotehead <= 67.5){
				if(ez >= pz && ex <= px){
					da = da * min;
				}
				else if(ez <= pz1 && ex >= px1){
					da = da * max;
				}
				else{
					da = da * nom;
				}
			}
			if(rotehead >= 67.5 && rotehead <= 112.5){
				if(ex <= px){
					da = da * min;
				}
				else if(ex >= px1){
					da = da * max;
				}
				else{
					da = da * nom;
				}
			}
			if(rotehead >= 112.5 && rotehead <= 157.5){
				if(ez <= pz && ex <= px){
					da = da * min;
				}
				else if(ez >= pz1 && ex >= px1){
					da = da * max;
				}
				else{
					da = da * nom;
				}
			}
			
			if(rotehead >= 157.5 && rotehead <= -157.5){
				if(ez <= pz){
					da = da * min;
				}
				else if(ez >= pz1){
					da = da * max;
				}
				else{
					da = da * nom;
				}
			}
			if(rotehead >= -157.5 && rotehead <= -112.5){
				if(ez <= pz && ex >= px){
					da = da * min;
				}
				else if(ez >= pz1 && ex <= px1){
					da = da * max;
				}
				else{
					da = da * nom;
				}
			}
			if(rotehead >= -112.5 && rotehead <= -67.5){
				if(ex >= px){
					da = da * min;
				}
				else if(ex <= px1){
					da = da * max;
				}
				else{
					da = da * nom;
				}
			}
			if(rotehead >= -67.5 && rotehead <= -22.5){
				if(ez >= pz && ex >= px){
					da = da * min;
				}
				else if(ez <= pz1 && ex <= px1){
					da = da * max;
				}
				else{
					da = da * nom;
				}
			}
		}
		//da = da * this.AntiBullet(entity, part2);
		if(da < 1){
		//	entity.playSound("random.anvil_land", 5F, 2F);
		}else if(da == 1){
	//		this.playSound("random.anvil_land", 5F, 1F);
		}else
		if(da > 1){
		//	entity.playSound("random.anvil_land", 5F, 1F);
		}
		return da;
		
	}
	
	
	public static float newAntiBullet(EntityGVCLivingBase entity, Entity entityIn, float part2, float level, float level1,  float level2, float level3){
		float ab = 1;
		if(entityIn instanceof EntityArrow)
		{
			ab = level;
        }
		if(entityIn instanceof EntityB_Bullet)
		{
			EntityB_Bullet bullet = (EntityB_Bullet) entityIn;
			if(bullet.bulletDameID == 1 || bullet.bulletDameID == 3) {
				ab = level1;
			}else {
				ab = level;
			}
        }
    	if(entityIn instanceof EntityB_BulletAA)
        {
    		ab = level1;
        }
    	if(entityIn instanceof EntityB_GrenadeB)
        {
    		ab = level2;
        }
    	if(entityIn instanceof EntityB_Shell)
        {
    		ab = level3;
        }
    	return ab;
	}
	
	public static float AntiBullet(EntityGVCLivingBase entity, Entity entityIn, float part2, int level){
		float ab = 1;
		if(entityIn instanceof EntityB_Bullet)
		{
			if(level >= 1){
				ab =  0;
			}else{
				ab =  0.25F;
			}
        }
    	if(entityIn instanceof EntityB_BulletAA)
        {
    		if(level >= 3){
    			ab =  0;
			}
    		else if(level >= 2){
    			ab =  0.25F;
    		}else if(level >= 1){
    			ab =  0.5F;
			}else{
				ab =  1F;
			}
        }
    	if(entityIn instanceof EntityB_Shell)
        {
    		if(level >= 5){
    			ab =  0;
			}
    		else if(level >= 3){
    			ab =  0.25F;
			}
    		else{
    			ab =  1F;
			}
        }
    	if(entityIn instanceof EntityB_GrenadeB)
        {
    		return 0.5F;
        }
    	return ab;
	}
}
