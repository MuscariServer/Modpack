package gvclib.entity.living.cnt.ai;

import java.util.List;
import gvclib.entity.living.EntityGVCLivingBase;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.MathHelper;


import gvclib.entity.living.EntityGVCLivingBase;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.MathHelper;

public class AI_GetTarget_OnRidding {
	public static void load(EntityGVCLivingBase entity, double range, double maxy, double miny, float yawbase,  float maxyaw, float minyaw){
		double k = entity.field_70165_t;
		double l = entity.field_70163_u;
		double i = entity.field_70161_v;
		double han = range;
		if(!entity.field_70170_p.field_72995_K){
			AxisAlignedBB axisalignedbb = (new AxisAlignedBB((double) (k - han), (double) (l - miny),(double) (i - han), 
					(double) (k + han), (double) (l + maxy), (double) (i + han)))
							.func_186662_g(1);
			List<Entity> llist = entity.field_70170_p.func_72839_b(entity,axisalignedbb);
			if (llist != null) {
				for (int lj = 0; lj < llist.size(); lj++) {
					Entity entity1 = (Entity) llist.get(lj);
					if (entity1.func_70067_L()) {
						if (entity.CanAttack(entity1) && entity1 != null 
								&& ((EntityLivingBase) entity1).func_110143_aJ() > 0.0F && entity.func_110143_aJ() > 0.0F) 
						{
							if(entity.targetentity == null) {
								boolean flag = entity.func_70635_at().func_75522_a(entity1);
								double d5 = entity1.field_70165_t - entity.field_70165_t;
								double d7 = entity1.field_70161_v - entity.field_70161_v;
								double d6 = entity1.field_70163_u - entity.field_70163_u;
								double d1 = entity.field_70163_u - (entity1.field_70163_u);
					            double d3 = (double)MathHelper.func_76133_a(d5 * d5 + d7 * d7);
					            float f11 = (float)(-(Math.atan2(d1, d3) * 180.0D / Math.PI));
					            float rotep_offset = -f11 + 10;
					            float yaw= -((float) Math.atan2(d5, d7)) * 180.0F / (float) Math.PI;
					            if(rotep_offset <= entity.rotationp_min && rotep_offset >= entity.rotationp_max && flag) {
					            	boolean ok = false;
					            	if(yaw > yawbase - minyaw && yaw < yawbase + maxyaw){
					            		ok = true;
					            	}
					            	if(yawbase - minyaw < -180){
					            		float y = yawbase - minyaw + 360;
					            		if(yaw < yawbase + maxyaw && yaw + 360 > y) {
					            			ok = true;
					            		}
					            	}
					            	if(yawbase + maxyaw > 180){
					            		float y = yawbase + maxyaw - 360;
					            		if(yaw > yawbase - minyaw && yaw - 360 < y) {
					            			ok = true;
					            		}
					            	}
									if(ok){
										entity.targetentity = (EntityLivingBase) entity1;
										entity.setMobMode(1);
										entity.sneak = true;
										entity.setattacktask(true);
										break;
									}
								}
							}
						}
					}
				}
			}
		}
	}
	
	public static boolean getRange(EntityGVCLivingBase entity, double range, double maxy, double miny, float yawbase,  float maxyaw, float minyaw){
		boolean task = false;
		double k = entity.field_70165_t;
		double l = entity.field_70163_u;
		double i = entity.field_70161_v;
		double han = range;
		AxisAlignedBB axisalignedbb = (new AxisAlignedBB((double) (k - han), (double) (l - miny),(double) (i - han), 
				(double) (k + han), (double) (l + maxy), (double) (i + han)))
						.func_186662_g(1);
		List<Entity> llist = entity.field_70170_p.func_72839_b(entity,axisalignedbb);
				//entity.getEntityBoundingBox().expand(entity.motionX, entity.motionY, entity.motionZ).grow(range));
		if (llist != null) {
			for (int lj = 0; lj < llist.size(); lj++) {
				Entity entity1 = (Entity) llist.get(lj);
				if (entity1.func_70067_L()) {
					if (entity.targetentity == entity1 && entity.CanAttack(entity1) && entity1 != null 
							&& ((EntityLivingBase) entity1).func_110143_aJ() > 0.0F && entity.func_110143_aJ() > 0.0F) 
					{
						boolean flag = entity.func_70635_at().func_75522_a(entity1);
						double ddy = Math.abs(entity1.field_70163_u - entity.field_70163_u);
						double dyp = entity.field_70163_u + maxy;
						double dym = entity.field_70163_u - miny;
						double d5 = entity1.field_70165_t - entity.field_70165_t;
						double d7 = entity1.field_70161_v - entity.field_70161_v;
						float yaw= -((float) Math.atan2(d5, d7)) * 180.0F / (float) Math.PI;
						if (dyp > entity1.field_70163_u && dym < entity1.field_70163_u) {
							boolean ok = false;
			            	if(yaw > yawbase - minyaw && yaw < yawbase + maxyaw){
			            		ok = true;
			            	}
			            	if(yawbase - minyaw < -180){
			            		float y = yawbase - minyaw + 360;
			            		if(yaw < yawbase + maxyaw && yaw + 360 > y) {
			            			ok = true;
			            		}
			            	}
			            	if(yawbase + maxyaw > 180){
			            		float y = yawbase + maxyaw - 360;
			            		if(yaw > yawbase - minyaw && yaw - 360 < y) {
			            			ok = true;
			            		}
			            	}
			            	if(ok) {
			            		if(entity1.func_184218_aH() && entity1.func_184187_bx() != null && entity1.func_184187_bx() instanceof EntityLivingBase) {
									EntityLivingBase en = (EntityLivingBase) entity1.func_184187_bx();
									if(en.func_110143_aJ()> 0.0F ) {
										task = true;
										break;
									}
								}else{
									task = true;
									break;
								}
			            	}
						}
					}
				}
			}
		}
		return task;
	}
}
