package gvclib.entity.living;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.math.Vec3d;

public class PL_TankMove {
	
	public static void move2(EntityLivingBase player, EntityGVCLivingBase entity, float sp, float turnspeed){
		if(player.field_70759_as > 360F || player.field_70759_as < -360F){
			player.field_70759_as = 0;
			player.field_70177_z = 0;
			player.field_70126_B = 0;
			player.field_70758_at = 0;
			player.field_70761_aq = 0;
		}
		if(player.field_70759_as > 180F){
			player.field_70759_as = -179F;
			player.field_70177_z = -179F;
			player.field_70126_B = -179F;
			player.field_70758_at = -179F;
			player.field_70761_aq = -179F;
		}
		if(player.field_70759_as < -180F){
			player.field_70759_as = 179F;
			player.field_70177_z = 179F;
			player.field_70126_B = 179F;
			player.field_70758_at = 179F;
			player.field_70761_aq = 179F;
		}
		if (player.field_191988_bg > 0.0F) {
			if(entity.throttle < entity.thmax){
				entity.throttle = entity.throttle + entity.thmaxa;
			}
			rotecrawler(entity, 0, true,1);
			rotecrawler(entity, 1, true,1);
		}
		if (player.field_191988_bg < 0.0F) {
			if(entity.throttle > entity.thmin){
				entity.throttle = entity.throttle + entity.thmina;
			}
			rotecrawler(entity, 0, false,1);
			rotecrawler(entity, 1, false,1);
		}
		/*if (player.moveForward > 0.0F) {
			if(entity.throttle < entity.thmax){
				++entity.throttle;
			}
		}
		if (player.moveForward < 0.0F) {
			if(entity.throttle >= 1){
				--entity.throttle;
			}
		}
		if( entity.throttle >= 0){
			if(entity.thpower < entity.throttle){
				if( entity.throttle > entity.thmax-5){
					entity.thpower = entity.thpower + entity.thmaxa;
				}else{
					entity.thpower = entity.thpower + entity.thmaxa*0.5;
				}
			}else{
				entity.thpower = entity.thpower + entity.thmina;
			}
			if(entity.throttle <= 0 && entity.throttle > 0){
				entity.thpower = entity.thpower + entity.thmina * 2;
			}
		}*/
		//if(tro != 0)
		{
			if (player.field_70702_br < 0.0F) {
				if (player.field_191988_bg >= 0.0F) {
					entity.field_70759_as = entity.field_70759_as + turnspeed;
					entity.field_70177_z = entity.field_70177_z + turnspeed;
					//entity.prevRotationYaw = entity.prevRotationYaw + turnspeed;
					//entity.prevRotationYawHead = entity.prevRotationYawHead + turnspeed;
					//rotecrawler(entity, 1, true,1);
					//rotecrawler(entity, 0, false,1);
				}else {
					entity.field_70759_as = entity.field_70759_as - turnspeed;
					entity.field_70177_z = entity.field_70177_z - turnspeed;
					//entity.prevRotationYaw = entity.prevRotationYaw - turnspeed;
					//entity.prevRotationYawHead = entity.prevRotationYawHead - turnspeed;
					//rotecrawler(entity, 0, true,1);
					//rotecrawler(entity, 1, false,1);
				}
			}
			if (player.field_70702_br > 0.0F) {
				if (player.field_191988_bg >= 0.0F) {
					entity.field_70759_as = entity.field_70759_as - turnspeed;
					entity.field_70177_z = entity.field_70177_z - turnspeed;
					//entity.prevRotationYaw = entity.prevRotationYaw - turnspeed;
					//entity.prevRotationYawHead = entity.prevRotationYawHead - turnspeed;
					//rotecrawler(entity, 0, true,1);
					//rotecrawler(entity, 1, false,1);
				}else {
					entity.field_70759_as = entity.field_70759_as + turnspeed;
					entity.field_70177_z = entity.field_70177_z + turnspeed;
					//entity.prevRotationYaw = entity.prevRotationYaw + turnspeed;
					//entity.prevRotationYawHead = entity.prevRotationYawHead + turnspeed;
					//rotecrawler(entity, 1, true,1);
					//rotecrawler(entity, 0, false,1);
				}
			}
		}
	}
	public static void rotecrawler(EntityGVCLivingBase entity, int id, boolean on, int r){
		if(id == 0) {
			if(!on) {
				if(entity.throttle_r <= 7){
					entity.throttle_r = entity.throttle_r + (r);
				}else{
					entity.throttle_r = 0;
				}
			}else {
				if(entity.throttle_r > 0){
					entity.throttle_r = entity.throttle_r - (r);
				}else{
					entity.throttle_r = 7;
				}
			}
		}
		if(id == 1) {
			if(!on) {
				if(entity.throttle_l <= 7){
					entity.throttle_l = entity.throttle_l + (r);
				}else{
					entity.throttle_l = 0;
				}
			}else {
				if(entity.throttle_l > 0){
					entity.throttle_l = entity.throttle_l - (r);
				}else{
					entity.throttle_l = 7;
				}
			}
		}
	}
	
	
	public static void move(EntityLivingBase player, EntityGVCLivingBase entity, float sp, float turnspeed){
		if(player.field_70759_as > 360F || player.field_70759_as < -360F){
			player.field_70759_as = 0;
			player.field_70177_z = 0;
			player.field_70126_B = 0;
			player.field_70758_at = 0;
			player.field_70761_aq = 0;
		}
		if(player.field_70759_as > 180F){
			player.field_70759_as = -179F;
			player.field_70177_z = -179F;
			player.field_70126_B = -179F;
			player.field_70758_at = -179F;
			player.field_70761_aq = -179F;
		}
		if(player.field_70759_as < -180F){
			player.field_70759_as = 179F;
			player.field_70177_z = 179F;
			player.field_70126_B = 179F;
			player.field_70758_at = 179F;
			player.field_70761_aq = 179F;
		}
		
		Vec3d look = entity.func_70040_Z();
		if (player.field_191988_bg > 0.0F) {
			entity.field_70159_w = look.field_72450_a * sp * 5;
			entity.field_70179_y = look.field_72449_c * sp * 5;
			
		}
		if (player.field_191988_bg < 0.0F) {
			entity.field_70159_w = - look.field_72450_a * sp * 2;
			entity.field_70179_y = - look.field_72449_c * sp * 2;
			
		}
		
		if (player.field_70702_br < 0.0F) {
			entity.field_70759_as = entity.field_70759_as + turnspeed;
			entity.field_70177_z = entity.field_70177_z + turnspeed;
			entity.field_70126_B = entity.field_70126_B + turnspeed;
			entity.field_70758_at = entity.field_70758_at + turnspeed;
		}
		if (player.field_70702_br > 0.0F) {
			entity.field_70759_as = entity.field_70759_as - turnspeed;
			entity.field_70177_z = entity.field_70177_z - turnspeed;
			entity.field_70126_B = entity.field_70126_B - turnspeed;
			entity.field_70758_at = entity.field_70758_at - turnspeed;
		}
	}
	
	public static void movecar(EntityLivingBase player, EntityGVCLivingBase entity, float sp, float turnspeed){
		if(player.field_70759_as > 360F || player.field_70759_as < -360F){
			player.field_70759_as = 0;
			player.field_70177_z = 0;
			player.field_70126_B = 0;
			player.field_70758_at = 0;
			player.field_70761_aq = 0;
		}
		if(player.field_70759_as > 180F){
			player.field_70759_as = -179F;
			player.field_70177_z = -179F;
			player.field_70126_B = -179F;
			player.field_70758_at = -179F;
			player.field_70761_aq = -179F;
		}
		if(player.field_70759_as < -180F){
			player.field_70759_as = 179F;
			player.field_70177_z = 179F;
			player.field_70126_B = 179F;
			player.field_70758_at = 179F;
			player.field_70761_aq = 179F;
		}
		boolean handle = false;
		boolean handle_front = true;
		if (player.field_191988_bg > 0.0F) {
			if(entity.throttle < entity.thmax){
				entity.throttle = entity.throttle + entity.thmaxa;
			}
			rotecrawler(entity, 0, true,1);
			rotecrawler(entity, 1, true,1);
			handle = true;
			handle_front = true;
		}
		if (player.field_191988_bg < 0.0F) {
			if(entity.throttle > entity.thmin){
				entity.throttle = entity.throttle + entity.thmina;
			}
			rotecrawler(entity, 0, false,1);
			rotecrawler(entity, 1, false,1);
			handle = true;
			handle_front = false;
		}
		if(entity.throttle > 0) {
			handle = true;
			handle_front = true;
		}else if(entity.throttle < 0) {
			handle = true;
			handle_front = false;
		}else {
			handle = false;
		}
		if(handle) {
			if(handle_front) {
				if (player.field_70702_br < 0.0F) {
					entity.field_70759_as = entity.field_70759_as + turnspeed;
					entity.field_70177_z = entity.field_70177_z + turnspeed;
					//player.rotationYawHead = player.rotationYawHead + turnspeed;
					//player.rotationYaw = player.rotationYaw+ turnspeed;
					//player.rotationYawHead += turnspeed;
					//player.rotationYaw += turnspeed;
					/*player.setRenderYawOffset(entity.rotationYawHead);
					player.rotationYaw += turnspeed;
					player.setRotationYawHead(player.rotationYaw);*/
				}
				if (player.field_70702_br > 0.0F) {
					entity.field_70759_as = entity.field_70759_as - turnspeed;
					entity.field_70177_z = entity.field_70177_z - turnspeed;
					//player.rotationYawHead = player.rotationYawHead - turnspeed;
					//player.rotationYaw = player.rotationYaw - turnspeed;
					//player.rotationYawHead -= turnspeed;
					//player.rotationYaw -= turnspeed;
					/*player.setRenderYawOffset(entity.rotationYawHead);
					player.rotationYaw -= turnspeed;
					player.setRotationYawHead(player.rotationYaw);*/
				}
			}else {
				if (player.field_70702_br < 0.0F) {
					entity.field_70759_as = entity.field_70759_as - turnspeed;
					entity.field_70177_z = entity.field_70177_z - turnspeed;
					//player.rotationYawHead = player.rotationYawHead - turnspeed;
					//player.rotationYaw = player.rotationYaw - turnspeed;
					//player.rotationYawHead -= turnspeed;
					//player.rotationYaw -= turnspeed;
					/*player.setRenderYawOffset(entity.rotationYawHead);
					player.rotationYaw -= turnspeed;
					player.setRotationYawHead(player.rotationYaw);*/
				}
				if (player.field_70702_br > 0.0F) {
					entity.field_70759_as = entity.field_70759_as + turnspeed;
					entity.field_70177_z = entity.field_70177_z + turnspeed;
					//player.rotationYawHead = player.rotationYawHead + turnspeed;
					//player.rotationYaw = player.rotationYaw+ turnspeed;
					//player.rotationYawHead -= turnspeed;
					//player.rotationYaw -= turnspeed;
					/*player.setRenderYawOffset(entity.rotationYawHead);
					player.rotationYaw += turnspeed;
					player.setRotationYawHead(player.rotationYaw);*/
				}
			}
			/*player.setRenderYawOffset(entity.rotationYawHead);
	        float f = MathHelper.wrapDegrees(player.rotationYaw - entity.rotationYawHead);
	        float f1 = MathHelper.clamp(f, -105.0F, 105.0F);
	        player.prevRotationYaw += f1 - f;
	        player.rotationYaw += f1 - f;
	        player.setRotationYawHead(player.rotationYaw);*/
		}
		
	}
}
