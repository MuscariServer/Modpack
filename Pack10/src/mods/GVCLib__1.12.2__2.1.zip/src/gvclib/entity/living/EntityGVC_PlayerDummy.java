package gvclib.entity.living;

import java.util.List;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.passive.IAnimals;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.DamageSource;
import net.minecraft.util.text.TextComponentTranslation;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;


import javax.annotation.Nullable;

import gvclib.entity.EntityBBase;
import gvclib.entity.living.AI_EntityMoveS_Squad;
import gvclib.entity.living.EntityGVCLivingBase;
import gvclib.entity.living.ISoldier;
import gvclib.world.GVCExplosionBase;
import hmggirlfront.mod_GirlFront;
import hmggirlfront.items.ItemDollAttachment;
import hmggirlfront.items.ItemDollCN;
import hmggirlfront.items.ItemDollGunBase;
import hmggirlfront.network.GFClientMessageKeyPressed;
import hmggirlfront.network.GFPacketHandler;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.MoverType;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIFleeSun;
import net.minecraft.entity.ai.EntityAIRestrictSun;
import net.minecraft.entity.ai.EntityAISwimming;
import net.minecraft.entity.item.EntityFireworkRocket;
import net.minecraft.entity.monster.IMob;
import net.minecraft.entity.passive.IAnimals;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.Items;
import net.minecraft.init.MobEffects;
import net.minecraft.init.SoundEvents;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.network.datasync.DataParameter;
import net.minecraft.network.datasync.DataSerializers;
import net.minecraft.network.datasync.EntityDataManager;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumHand;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.text.TextComponentTranslation;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;
import objmodel.IModelCustom;

public class EntityGVC_PlayerDummy extends EntityGVCLivingBase implements IAnimals, ISoldier {
	
	
	public EntityGVC_PlayerDummy(World worldIn) {
		super(worldIn);
		//this.setSize(0.8F, 0.6F);
		this.biped = true;
	}

	private EntityLivingBase thrower;
    private String throwerName;
	
	protected void func_184651_r() {
	}

	protected void func_110147_ax() {
		super.func_110147_ax();
		this.func_110148_a(SharedMonsterAttributes.field_111267_a).func_111128_a(20D);
		// this.getEntityAttribute(SharedMonsterAttributes.KNOCKBACK_RESISTANCE).setBaseValue(20D);
		this.func_110148_a(SharedMonsterAttributes.field_111263_d).func_111128_a(0.25D);
	}

	
	@Nullable
    public EntityLivingBase getThrower()
    {
        if (this.thrower == null && this.throwerName != null && !this.throwerName.isEmpty())
        {
            this.thrower = this.field_70170_p.func_72924_a(this.throwerName);

            if (this.thrower == null && this.field_70170_p instanceof WorldServer)
            {
                try
                {
                    Entity entity = ((WorldServer)this.field_70170_p).func_175733_a(UUID.fromString(this.throwerName));

                    if (entity instanceof EntityLivingBase)
                    {
                        this.thrower = (EntityLivingBase)entity;
                    }
                }
                catch (Throwable var2)
                {
                    this.thrower = null;
                }
            }
        }

        return this.thrower;
    }
	
	protected void func_180481_a(DifficultyInstance difficulty) {
		super.func_180481_a(difficulty);
		
	}
	
	public boolean func_70097_a(DamageSource source, float par2)
    {
		if(this.getOwner() != null) {
			this.getOwner().func_70097_a(source, par2);
			if (this.getOwner().func_184187_bx() != null && this.getOwner().func_184187_bx() instanceof EntityMAVBase) {
				EntityMAVBase vehicle = (EntityMAVBase) this.getOwner().func_184187_bx();
				this.getOwner().func_184210_p();
				this.getOwner().func_70634_a(vehicle.getMoveX(), vehicle.getMoveY(), vehicle.getMoveZ());
				if(vehicle.return_basepoint) {
					vehicle.func_70634_a(vehicle.getMoveX(), vehicle.getMoveY(), vehicle.getMoveZ());
				}
				if(this.getOwner()  instanceof EntityPlayer) {
					EntityPlayer player = (EntityPlayer) this.getOwner();
					if(this.field_70170_p.field_72995_K)
						player.func_145747_a(new TextComponentTranslation("Body is attacked!", new Object[0]));
				}
				if (!this.field_70170_p.field_72995_K) {
					this.func_70106_y();
				}
			}
		}
		return super.func_70097_a(source, par2);
    }
	
	protected void func_70609_aI() {
		/*if(this.getOwner() != null) {
			if (!this.world.isRemote) {
				this.getOwner().setDead();
			}
		}*/
		if (!this.field_70170_p.field_72995_K) {
			this.func_70106_y();
		}
	}
	
	/**
     * Determines if an entity can be despawned, used on idle far away entities
     */
    protected boolean func_70692_ba()
    {
    	return false;
    }
	
	
	
	/*public boolean processInteract(EntityPlayer player, EnumHand hand)
    {
		if(!player.world.isRemote) {
	//		this.setDead();
		}
		
        	return true;
    }*/
	 
	/**
	 * Called frequently so the entity can update its state every tick as
	 * required. For example, zombies and skeletons use this to react to
	 * sunlight and start to burn.
	 */
	 public String sound;
	 public String modid;
	 public boolean reset = true;
	public void func_70636_d() {
		super.func_70636_d();
		this.biped = false;
		this.func_82168_bl();
		
		if(this.getMoveX() == 0 && this.getMoveY() == 0 && this.getMoveZ() == 0){
			this.setMoveX((int)this.field_70165_t);
			this.setMoveY((int)this.field_70163_u);
			this.setMoveZ((int)this.field_70161_v);
		}
		else
		{
			this.func_70634_a(this.getMoveX(), this.getMoveY(), this.getMoveZ());
		}
		
		float sp = 0.08F;
		int max = 15;
		int range = 30;
		int range2 = 30;
		newmove(this, 0, sp, 0, max, range, range2, 10);
		
	}
	
	public static void newmove(EntityGVCLivingBase entity, int id, float sp, float turnspeed, double max, double range1, double range2, double followrange) {
		
	}
	
	
}
