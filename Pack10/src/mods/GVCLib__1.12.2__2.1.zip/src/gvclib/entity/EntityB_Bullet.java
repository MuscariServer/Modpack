package gvclib.entity;

import gvclib.mod_GVCLib;
import gvclib.entity.living.EntityVehicleBase;
import gvclib.event.GVCSoundEvent;
import gvclib.network.GVCLClientMessageKeyPressed;
import gvclib.network.GVCLPacketHandler;
import io.netty.buffer.ByteBuf;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.datafix.DataFixer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.world.World;

public class EntityB_Bullet extends EntityBBase {
	public EntityB_Bullet(World worldIn) {
		super(worldIn);
	}

	public EntityB_Bullet(World worldIn, EntityLivingBase throwerIn) {
		super(worldIn, throwerIn);
	}

	public EntityB_Bullet(World worldIn, double x, double y, double z) {
		super(worldIn, x, y, z);
	}

	public static void func_189662_a(DataFixer p_189662_0_) {
		EntityB_Bullet.func_189661_a(p_189662_0_, "EntityB_Bullet");
	}

	public void func_70071_h_()
    {
        super.func_70071_h_();
        //if(this.smoke)
        if (!this.inGround) {
        	 if(mod_GVCLib.cfg_bullet_smoke)
             {
             this.field_70170_p.func_175688_a(EnumParticleTypes.SMOKE_LARGE, this.field_70165_t, this.field_70163_u + 0D, this.field_70161_v, 0.0D, 0.0D, 0.0D, new int[0]);
             }else {
             	this.field_70170_p.func_175688_a(EnumParticleTypes.CRIT, this.field_70165_t, this.field_70163_u + 0D, this.field_70161_v, 0.0D, 0.0D, 0.0D, new int[0]);
             }
        	 if(this.field_70170_p.func_72820_D() %2 == 0 && time > 5 && fly_sound) {
        		 this.func_184185_a(GVCSoundEvent.sound_hit, 0.5F, 1.2F / (this.field_70146_Z.nextFloat() * 0.2F + 0.9F));
        	 }
        }
       
    }
	
	public void func_70106_y(){
		this.field_70170_p.func_175688_a(EnumParticleTypes.SNOWBALL, this.field_70165_t, this.field_70163_u + 0D, this.field_70161_v, 0.0D, 0.0D, 0.0D, new int[0]);
		super.func_70106_y();
	}
	
	/**
	 * Called when this EntityThrowable hits a block or entity.
	 */
	protected void onImpact(RayTraceResult result) {
		Entity entity = result.field_72308_g;
		if (entity != null){
			boolean ap = false;
			//if (result.entityHit != null && result.entityHit != this.friend && result.entityHit != this.getThrower()) 
			//if () 
			{
				int i = Bdamege;
				if (this.muteki) {
					result.field_72308_g.field_70172_ad = 0;
				}
				if(this.bulletDameID == 1 || this.bulletDameID == 3){
					//i = (int) (i *0.75);
					if(i < 0) {
						if(result.field_72308_g instanceof EntityLivingBase) {
							EntityLivingBase en = (EntityLivingBase) result.field_72308_g;
							if(en.func_110143_aJ() < en.func_110138_aP()) {
								en.func_70606_j(en.func_110143_aJ() + (i * -1));
								GVCLPacketHandler.INSTANCE2.sendToAll(new GVCLClientMessageKeyPressed(801, result.field_72308_g.func_145782_y()));
		        			}
						}
					}else if(i > 0){
					result.field_72308_g.func_70097_a(GVCDamageSource.causeBulletAP(this, this.getThrower()), (float) i);
					ap = true;
					}else {
						
					}
				}else if(this.P_ID != 0){
					if(result.field_72308_g instanceof EntityLivingBase) {
						EntityLivingBase en = (EntityLivingBase) result.field_72308_g;
						//en.addPotionEffect(new PotionEffect(MobEffects.SLOWNESS, 200, 10));
						en.func_70690_d(new PotionEffect(Potion.func_188412_a(this.P_ID), this.P_TIME, this.P_LEVEL));
					}
					if(i < 0) {
						if(result.field_72308_g instanceof EntityLivingBase) {
							EntityLivingBase en = (EntityLivingBase) result.field_72308_g;
							if(en.func_110143_aJ() < en.func_110138_aP()) {
								en.func_70606_j(en.func_110143_aJ() + (i * -1));
								GVCLPacketHandler.INSTANCE2.sendToAll(new GVCLClientMessageKeyPressed(801, result.field_72308_g.func_145782_y()));
		        			}
						}
					}else {
						result.field_72308_g.func_70097_a(DamageSource.func_76356_a(this, this.getThrower()), (float)i);//1
					}
					
				}else {
					if(i < 0) {
						if(result.field_72308_g instanceof EntityLivingBase) {
							EntityLivingBase en = (EntityLivingBase) result.field_72308_g;
							if(en.func_110143_aJ() < en.func_110138_aP()) {
								en.func_70606_j(en.func_110143_aJ() + (i * -1));
								GVCLPacketHandler.INSTANCE2.sendToAll(new GVCLClientMessageKeyPressed(801, result.field_72308_g.func_145782_y()));
		        			}
						}
					}else {
						result.field_72308_g.func_70097_a(DamageSource.func_76356_a(this, this.getThrower()), (float) i);
					}
				}
			}
			
			this.field_70170_p.func_175688_a(EnumParticleTypes.CLOUD, this.field_70165_t, this.field_70163_u + 0D, this.field_70161_v, 0.0D, 0.0D, 0.0D, new int[0]);

			boolean dead_flag = true;
			if(result.field_72308_g instanceof EntityVehicleBase) {
				EntityVehicleBase vehicle = (EntityVehicleBase) result.field_72308_g;
				if(Bdamege > vehicle.normal_anti_bullet) {
					dead_flag = false;
				}
			}
			
			if (!this.field_70170_p.field_72995_K && !ap) {
				if(dead_flag)this.func_70106_y();
			}
			if(this.bulletDameID == 4 || this.exlevel >= 1) {
				if (!this.field_70170_p.field_72995_K) {
					this.field_70170_p.func_72876_a(this, this.field_70165_t + 0, this.field_70163_u + 0, this.field_70161_v + 0, this.exlevel, false);
				}
			}
		}else {
			{
				if(!this.inGround) {
					if(this.bulletDameID == 4 || this.exlevel >= 1) {
						if (!this.field_70170_p.field_72995_K) {
							this.field_70170_p.func_72876_a(this, this.field_70165_t + 0, this.field_70163_u + 0, this.field_70161_v + 0, this.exlevel, false);
						}
					}
				}
	            BlockPos blockpos = result.func_178782_a();
	            this.xTile = blockpos.func_177958_n();
	            this.yTile = blockpos.func_177956_o();
	            this.zTile = blockpos.func_177952_p();
	            IBlockState iblockstate = this.field_70170_p.func_180495_p(blockpos);
	            this.inTile = iblockstate.func_177230_c();
	            this.inData = this.inTile.func_176201_c(iblockstate);
	            this.field_70159_w = (double)((float)(result.field_72307_f.field_72450_a - this.field_70165_t));
	            this.field_70181_x = (double)((float)(result.field_72307_f.field_72448_b - this.field_70163_u));
	            this.field_70179_y = (double)((float)(result.field_72307_f.field_72449_c - this.field_70161_v));
	            float f2 = MathHelper.func_76133_a(this.field_70159_w * this.field_70159_w + this.field_70181_x * this.field_70181_x + this.field_70179_y * this.field_70179_y);
	            this.field_70165_t -= this.field_70159_w / (double)f2 * 0.05000000074505806D;
	            this.field_70163_u -= this.field_70181_x / (double)f2 * 0.05000000074505806D;
	            this.field_70161_v -= this.field_70179_y / (double)f2 * 0.05000000074505806D;
	            //this.playSound(SoundEvents.ENTITY_ARROW_HIT, 1.0F, 1.2F / (this.rand.nextFloat() * 0.2F + 0.9F));
	            this.func_184185_a(GVCSoundEvent.sound_hit, 1.0F, 1.2F / (this.field_70146_Z.nextFloat() * 0.2F + 0.9F));
	            this.inGround = true;
	           // this.arrowShake = 7;
	           // this.setIsCritical(false);

	            if (iblockstate.func_185904_a() != Material.field_151579_a)
	            {
	                this.inTile.func_180634_a(this.field_70170_p, blockpos, iblockstate, this);
	            }
	        }
		}
	}
	
	protected void onBreak(RayTraceResult result) {
		/*BlockPos blockpos = result.getBlockPos();
        IBlockState iblockstate = this.world.getBlockState(blockpos);
        Block block2 = iblockstate.getBlock();
		if(block2 != null){
			if (block2 == Blocks.GLASS_PANE || block2 == Blocks.TALLGRASS){
				Block block = this.world.getBlockState(result.getBlockPos()).getBlock();
				int blockmeta = this.world.getBlockState(result.getBlockPos())
						.getBlock().getMetaFromState(this.world.getBlockState(result.getBlockPos()));
			//	BlockPos blockpos = result.getBlockPos();
				IBlockState iblock = this.world.getBlockState(result.getBlockPos()).getBlock().getStateFromMeta(blockmeta);

				block.onBlockDestroyedByPlayer(this.world, blockpos, iblock);
				block.dropBlockAsItem(this.world, blockpos, iblock, blockmeta);
				this.world.setBlockToAir(blockpos);
			}
		}
		*/
	}

	@Override
	public void func_70186_c(double x, double y, double z, float velocity, float inaccuracy) {
		// TODO 自動生成されたメソッド・スタブ
		
	}
	
	public void writeSpawnData(ByteBuf buffer){
		super.writeSpawnData(buffer);
	}
	public void readSpawnData(ByteBuf additionalData){
		super.readSpawnData(additionalData);
	}
}
