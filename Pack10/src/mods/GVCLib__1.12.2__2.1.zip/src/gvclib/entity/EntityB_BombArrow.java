package gvclib.entity;

import java.util.List;
import gvclib.world.GVCExplosionBase;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.init.Blocks;
import net.minecraft.init.SoundEvents;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.datafix.DataFixer;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;


import gvclib.world.GVCExplosionBase;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.init.Blocks;
import net.minecraft.init.SoundEvents;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.datafix.DataFixer;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

public class EntityB_BombArrow extends EntityTNTBase {
	public EntityB_BombArrow(World worldIn) {
		super(worldIn);
		this.timemax = 1200;
	}

	public EntityB_BombArrow(World worldIn, EntityLivingBase throwerIn) {
		super(worldIn, throwerIn);
		this.timemax = 1200;
	}

	public EntityB_BombArrow(World worldIn, double x, double y, double z) {
		super(worldIn, x, y, z);
		this.timemax = 1200;
	}

	public static void func_189662_a(DataFixer p_189662_0_) {
		EntityBBase.func_189661_a(p_189662_0_, "Snowball");
	}

	protected void func_70088_a()
    {
    	//this.dataManager.register(Model, new String("gvclib:textures/entity/ATGrenade.obj"));
        //this.dataManager.register(Tex, new String("gvclib:textures/entity/ATGrenade.png"));
		this.field_70180_af.func_187214_a(Model, new String("gvclib:textures/entity/C4.obj"));
        this.field_70180_af.func_187214_a(Tex, new String("gvclib:textures/entity/C4.png"));
    }
	public boolean hit = false;
	 private int xTile;
	    private int yTile;
	    private int zTile;
	    private Block inTile;
	    private int inData;
	    private Entity targeten;
	
	public void func_70071_h_()
    {
		this.field_70142_S = this.field_70165_t;
        this.field_70137_T = this.field_70163_u;
        this.field_70136_U = this.field_70161_v;
        super.func_70071_h_();

        //this.worldObj.spawnParticle(EnumParticleTypes.CLOUD, this.posX, this.posY + 0D, this.posZ, 0.0D, 0.0D, 0.0D, new int[0]);
        
        if (this.throwableShake > 0)
        {
            --this.throwableShake;
        }

        if (this.inGround)
        {
            if (this.field_70170_p.func_180495_p(new BlockPos(this.xTile, this.yTile, this.zTile)).func_177230_c() == this.inTile)
            {
                ++this.ticksInGround;

                if (this.ticksInGround == 1200)
                {
                    this.func_70106_y();
                }

                return;
            }

            this.inGround = false;
            this.field_70159_w *= (double)(this.field_70146_Z.nextFloat() * 0.2F);
            this.field_70181_x *= (double)(this.field_70146_Z.nextFloat() * 0.2F);
            this.field_70179_y *= (double)(this.field_70146_Z.nextFloat() * 0.2F);
            this.ticksInGround = 0;
            this.ticksInAir = 0;
        }
        else
        {
        	if(hit){
            	List llist = this.field_70170_p.func_72839_b(this, this.func_174813_aQ()
                		.func_72321_a(this.field_70159_w, this.field_70181_x, this.field_70179_y).func_186662_g(100.0D));
                EntityLivingBase entitylivingbase = this.getThrower();
                if(llist!=null){
                    for (int lj = 0; lj < llist.size(); lj++) {
                    	
                    	Entity entity1 = (Entity)llist.get(lj);
                    	if (entity1.func_70067_L() && (entity1 != entitylivingbase))
                        {
                    		if (entity1 != null)
                            {
                    			if (entity1 instanceof EntityLivingBase && entity1 == this.targeten && entity1.func_145782_y() == this.inData)
                                {
                    				double var4 = entity1.field_70165_t - this.field_70165_t;
    								double var6 = (entity1.field_70163_u + (double) entity1.func_70047_e())- this.field_70163_u;
    								double var8 = entity1.field_70161_v - this.field_70161_v;
    								this.field_70159_w = (var4) * 0.03D * (time/10);
                                    this.field_70181_x = (var6) * 0.03D * (time/10);
                                    this.field_70179_y = (var8) * 0.03D * (time/10);
                                    break;
                                }
                            }
                        }
                    }
                }
            }
            ++this.ticksInAir;
        }

        Vec3d vec3d = new Vec3d(this.field_70165_t, this.field_70163_u, this.field_70161_v);
        Vec3d vec3d1 = new Vec3d(this.field_70165_t + this.field_70159_w, this.field_70163_u + this.field_70181_x, this.field_70161_v + this.field_70179_y);
        RayTraceResult raytraceresult = this.field_70170_p.func_72933_a(vec3d, vec3d1);
        vec3d = new Vec3d(this.field_70165_t, this.field_70163_u, this.field_70161_v);
        vec3d1 = new Vec3d(this.field_70165_t + this.field_70159_w, this.field_70163_u + this.field_70181_x, this.field_70161_v + this.field_70179_y);

        if (raytraceresult != null)
        {
            vec3d1 = new Vec3d(raytraceresult.field_72307_f.field_72450_a, raytraceresult.field_72307_f.field_72448_b, raytraceresult.field_72307_f.field_72449_c);
        }

        Entity entity = null;
        List<Entity> list = this.field_70170_p.func_72839_b(this, this.func_174813_aQ().func_72321_a(this.field_70159_w, this.field_70181_x, this.field_70179_y).func_186662_g(1.0D));
        double d0 = 0.0D;
        boolean flag = false;

        for (int i = 0; i < list.size(); ++i)
        {
            Entity entity1 = (Entity)list.get(i);

            if (entity1.func_70067_L())
            {
                if (entity1 == this.ignoreEntity)
                {
                    flag = true;
                }
                else if (this.field_70173_aa < 2 && this.ignoreEntity == null)
                {
                    this.ignoreEntity = entity1;
                    flag = true;
                }
                else
                {
                    flag = false;
                    AxisAlignedBB axisalignedbb = entity1.func_174813_aQ().func_186662_g(0.30000001192092896D);
                    RayTraceResult raytraceresult1 = axisalignedbb.func_72327_a(vec3d, vec3d1);

                    if (raytraceresult1 != null)
                    {
                        double d1 = vec3d.func_72436_e(raytraceresult1.field_72307_f);

                        if (d1 < d0 || d0 == 0.0D)
                        {
                            entity = entity1;
                            d0 = d1;
                        }
                    }
                }
            }
        }

        if (this.ignoreEntity != null)
        {
            if (flag)
            {
                this.ignoreTime = 2;
            }
            else if (this.ignoreTime-- <= 0)
            {
                this.ignoreEntity = null;
            }
        }

        if (entity != null)
        {
            raytraceresult = new RayTraceResult(entity);
        }

        if (raytraceresult != null)
        {
            if (raytraceresult.field_72313_a == RayTraceResult.Type.BLOCK && this.field_70170_p.func_180495_p(raytraceresult.func_178782_a()).func_177230_c() == Blocks.field_150427_aO)
            {
                this.func_181015_d(raytraceresult.func_178782_a());
            }
            //else if(raytraceresult.entityHit != this.friend && raytraceresult.entityHit != this.getThrower())
            else
            {
              //  if(!net.minecraftforge.common.ForgeHooks.onThrowableImpact(this, raytraceresult))
                this.onImpact(raytraceresult);
            }
        }

        this.field_70165_t += this.field_70159_w;
        this.field_70163_u += this.field_70181_x;
        this.field_70161_v += this.field_70179_y;
        float f = MathHelper.func_76133_a(this.field_70159_w * this.field_70159_w + this.field_70179_y * this.field_70179_y);
        this.field_70177_z = (float)(MathHelper.func_181159_b(this.field_70159_w, this.field_70179_y) * (180D / Math.PI));

        for (this.field_70125_A = (float)(MathHelper.func_181159_b(this.field_70181_x, (double)f) * (180D / Math.PI)); this.field_70125_A - this.field_70127_C < -180.0F; this.field_70127_C -= 360.0F)
        {
            ;
        }

        while (this.field_70125_A - this.field_70127_C >= 180.0F)
        {
            this.field_70127_C += 360.0F;
        }

        while (this.field_70177_z - this.field_70126_B < -180.0F)
        {
            this.field_70126_B -= 360.0F;
        }

        while (this.field_70177_z - this.field_70126_B >= 180.0F)
        {
            this.field_70126_B += 360.0F;
        }

        this.field_70125_A = this.field_70127_C + (this.field_70125_A - this.field_70127_C) * 0.2F;
        this.field_70177_z = this.field_70126_B + (this.field_70177_z - this.field_70126_B) * 0.2F;
        float f1 = 0.99F;
        float f2 = this.getGravityVelocity();

        if (this.func_70090_H())
        {
            for (int j = 0; j < 4; ++j)
            {
                float f3 = 0.25F;
                this.field_70170_p.func_175688_a(EnumParticleTypes.WATER_BUBBLE, this.field_70165_t - this.field_70159_w * 0.25D, this.field_70163_u - this.field_70181_x * 0.25D, this.field_70161_v - this.field_70179_y * 0.25D, this.field_70159_w, this.field_70181_x, this.field_70179_y, new int[0]);
            }

            f1 = 0.8F;
        }

        this.field_70159_w *= (double)f1;
        this.field_70181_x *= (double)f1;
        this.field_70179_y *= (double)f1;

        if (!this.func_189652_ae())
        {
            this.field_70181_x -= (double)f2 - this.gra;
        }

        this.func_70107_b(this.field_70165_t, this.field_70163_u, this.field_70161_v);
        
        ++time;
        if(time > timemax){
        	if(!this.field_70170_p.field_72995_K){
        	this.func_70106_y();
        	}
        }
    }
	/**
	 * Called when this EntityThrowable hits a block or entity.
	 */
	protected void onImpact(RayTraceResult result) {
		Entity entity = result.field_72308_g;
		{
			this.func_184185_a(SoundEvents.field_187731_t, 1.0F, 1.2F / (this.field_70146_Z.nextFloat() * 0.2F + 0.9F));
			if (result.field_72308_g != null && result.field_72308_g != this.friend && result.field_72308_g != this.getThrower()) {
				this.targeten = result.field_72308_g;
    			this.inData = result.field_72308_g.func_145782_y();
    			this.hit = true;
			}else{
				BlockPos blockpos = result.func_178782_a();
    			if(blockpos != null)
    			{
    				this.xTile = blockpos.func_177958_n();
                    this.yTile = blockpos.func_177956_o();
                    this.zTile = blockpos.func_177952_p();
                    IBlockState iblockstate = this.field_70170_p.func_180495_p(blockpos);
                    this.inTile = iblockstate.func_177230_c();
                    this.inData = this.inTile.func_176201_c(iblockstate);
                    this.field_70159_w = (double)((float)(result.field_72307_f.field_72450_a - this.field_70165_t));
                    this.field_70181_x = (double)((float)(result.field_72307_f.field_72448_b - this.field_70163_u));
                    this.field_70179_y = (double)((float)(result.field_72307_f.field_72449_c - this.field_70161_v));
                    float f2 = MathHelper.func_76133_a(this.field_70159_w * this.field_70159_w + this.field_70181_x * this.field_70181_x + this.field_70179_y * this.field_70179_y);
                    this.field_70165_t -= this.field_70159_w / (double)f2 * 0.05000000074505806D;
                    this.field_70163_u -= this.field_70181_x / (double)f2 * 0.05000000074505806D;
                    this.field_70161_v -= this.field_70179_y / (double)f2 * 0.05000000074505806D;
                    //this.playSound(SoundEvents.ENTITY_ARROW_HIT, 1.0F, 1.2F / (this.rand.nextFloat() * 0.2F + 0.9F));
                    this.inGround = true;

                    if (iblockstate.func_185904_a() != Material.field_151579_a)
                    {
                        this.inTile.func_180634_a(this.field_70170_p, blockpos, iblockstate, this);
                    }
        	        
    			}
			}
		
		}
		/*if (entity != null)
        {
			this.playSound(SoundEvents.ENTITY_ARROW_HIT, 1.0F, 1.2F / (this.rand.nextFloat() * 0.2F + 0.9F));
            DamageSource damagesource;

            if(this.getThrower() != null)
            {
                damagesource = DamageSource.causeThrownDamage(this, this.getThrower());
            }else{
            	 damagesource = DamageSource.causeThrownDamage(this, this);
            }

            if (entity.attackEntityFrom(damagesource, 0))
            {
            	this.targeten = result.entityHit;
    			this.inData = result.entityHit.getEntityId();
    			this.hit = true;
            }else{
    			BlockPos blockpos = result.getBlockPos();
    			//if(blockpos != null)
    			{
    				this.xTile = blockpos.getX();
                    this.yTile = blockpos.getY();
                    this.zTile = blockpos.getZ();
                    IBlockState iblockstate = this.worldObj.getBlockState(blockpos);
                    this.inTile = iblockstate.getBlock();
                    this.inData = this.inTile.getMetaFromState(iblockstate);
                    this.motionX = (double)((float)(result.hitVec.xCoord - this.posX));
                    this.motionY = (double)((float)(result.hitVec.yCoord - this.posY));
                    this.motionZ = (double)((float)(result.hitVec.zCoord - this.posZ));
                    float f2 = MathHelper.sqrt_double(this.motionX * this.motionX + this.motionY * this.motionY + this.motionZ * this.motionZ);
                    this.posX -= this.motionX / (double)f2 * 0.05000000074505806D;
                    this.posY -= this.motionY / (double)f2 * 0.05000000074505806D;
                    this.posZ -= this.motionZ / (double)f2 * 0.05000000074505806D;
                    //this.playSound(SoundEvents.ENTITY_ARROW_HIT, 1.0F, 1.2F / (this.rand.nextFloat() * 0.2F + 0.9F));
                    this.inGround = true;

                    if (iblockstate.getMaterial() != Material.AIR)
                    {
                        this.inTile.onEntityCollidedWithBlock(this.worldObj, blockpos, iblockstate, this);
                    }
        	        
    			}
    		}
        }
		
		/*if (result.entityHit != this.friend && result.entityHit != this.getThrower() && result.entityHit != null) {
			
			
		}
		
		{
			BlockPos blockpos = result.getBlockPos();
            this.xTile = blockpos.getX();
            this.yTile = blockpos.getY();
            this.zTile = blockpos.getZ();
            IBlockState iblockstate = this.worldObj.getBlockState(blockpos);
            this.inTile = iblockstate.getBlock();
            this.inData = this.inTile.getMetaFromState(iblockstate);
            this.motionX = (double)((float)(result.hitVec.xCoord - this.posX));
            this.motionY = (double)((float)(result.hitVec.yCoord - this.posY));
            this.motionZ = (double)((float)(result.hitVec.zCoord - this.posZ));
            float f2 = MathHelper.sqrt_double(this.motionX * this.motionX + this.motionY * this.motionY + this.motionZ * this.motionZ);
            this.posX -= this.motionX / (double)f2 * 0.05000000074505806D;
            this.posY -= this.motionY / (double)f2 * 0.05000000074505806D;
            this.posZ -= this.motionZ / (double)f2 * 0.05000000074505806D;
            //this.playSound(SoundEvents.ENTITY_ARROW_HIT, 1.0F, 1.2F / (this.rand.nextFloat() * 0.2F + 0.9F));
            this.inGround = true;

            if (iblockstate.getMaterial() != Material.AIR)
            {
                this.inTile.onEntityCollidedWithBlock(this.worldObj, blockpos, iblockstate, this);
            }
	        
		}
		
		/*if (result.entityHit != this.friend && result.entityHit != this.getThrower()) {
			this.targeten = result.entityHit;
			this.inData = result.entityHit.getEntityId();
			this.hit = true;
			this.playSound(SoundEvents.ENTITY_ARROW_HIT, 1.0F, 1.2F / (this.rand.nextFloat() * 0.2F + 0.9F));
		}else{
			BlockPos blockpos = result.getBlockPos();
            this.xTile = blockpos.getX();
            this.yTile = blockpos.getY();
            this.zTile = blockpos.getZ();
            IBlockState iblockstate = this.worldObj.getBlockState(blockpos);
            this.inTile = iblockstate.getBlock();
            this.inData = this.inTile.getMetaFromState(iblockstate);
            this.motionX = (double)((float)(result.hitVec.xCoord - this.posX));
            this.motionY = (double)((float)(result.hitVec.yCoord - this.posY));
            this.motionZ = (double)((float)(result.hitVec.zCoord - this.posZ));
            float f2 = MathHelper.sqrt_double(this.motionX * this.motionX + this.motionY * this.motionY + this.motionZ * this.motionZ);
            this.posX -= this.motionX / (double)f2 * 0.05000000074505806D;
            this.posY -= this.motionY / (double)f2 * 0.05000000074505806D;
            this.posZ -= this.motionZ / (double)f2 * 0.05000000074505806D;
            //this.playSound(SoundEvents.ENTITY_ARROW_HIT, 1.0F, 1.2F / (this.rand.nextFloat() * 0.2F + 0.9F));
            this.inGround = true;

            if (iblockstate.getMaterial() != Material.AIR)
            {
                this.inTile.onEntityCollidedWithBlock(this.worldObj, blockpos, iblockstate, this);
            }
	        
		}*/
	}
	
	public void ExGrenade(){
		if(this.getThrower() != null){
			//this.worldObj.createExplosion(this.getThrower(), this.posX + 0, this.posY + 0, this.posZ + 0, this.exlevel, this.ex);
			GVCExplosionBase.ExplosionKai(this.getThrower(), this, this.field_70165_t + 0, this.field_70163_u + 0, this.field_70161_v + 0, this.exlevel, false,  this.ex);
		}
		if (!this.field_70170_p.field_72995_K)
		{
			this.func_70106_y();
		}
	}

	@Override
	public void func_70186_c(double x, double y, double z, float velocity, float inaccuracy) {
		// TODO 自動生成されたメソッド・スタブ
		
	}
	
}
