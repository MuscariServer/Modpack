package gvclib.gui;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.IContainerListener;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.Slot;
import net.minecraft.item.ItemStack;
import net.minecraft.item.crafting.FurnaceRecipes;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public class ContainerInventoryEntityGVC extends Container
{
    private final IInventory tileFurnace;
    private int cookTime;
    private int totalCookTime;
    private int furnaceBurnTime;
    private int currentItemBurnTime;

    public ContainerInventoryEntityGVC(InventoryPlayer playerInventory, IInventory furnaceInventory)
    {
        this.tileFurnace = furnaceInventory;
        this.func_75146_a(new Slot(furnaceInventory, 0, 56, 35));
        this.func_75146_a(new Slot(furnaceInventory, 1, 20, 35));
        this.func_75146_a(new Slot(furnaceInventory, 2, 38, 17));
        this.func_75146_a(new Slot(furnaceInventory, 3, 38, 53));
        this.func_75146_a(new Slot(furnaceInventory, 4, 38, 35));
        //this.addSlotToContainer(new Slot(furnaceInventory, 5, 110, 53));
        //this.addSlotToContainer(new Slot(furnaceInventory, 6, 142, 35));
       
        //this.addSlotToContainer(new SlotFurnaceFuel(furnaceInventory, 1, 56, 53));
        //this.addSlotToContainer(new SlotFurnaceOutput(playerInventory.player, furnaceInventory, 4, 142, 35));
        this.func_75146_a(new Slot(furnaceInventory, 5, 116, 35));
        this.func_75146_a(new Slot(furnaceInventory, 6, 134, 35));
        this.func_75146_a(new Slot(furnaceInventory, 7, 152, 35));
        this.func_75146_a(new Slot(furnaceInventory, 8, 116, 53));
        this.func_75146_a(new Slot(furnaceInventory, 9, 134, 53));
        this.func_75146_a(new Slot(furnaceInventory, 10, 152, 53));

        for (int i = 0; i < 3; ++i)
        {
            for (int j = 0; j < 9; ++j)
            {
                this.func_75146_a(new Slot(playerInventory, j + i * 9 + 9, 8 + j * 18, 84 + i * 18));
            }
        }

        for (int k = 0; k < 9; ++k)
        {
            this.func_75146_a(new Slot(playerInventory, k, 8 + k * 18, 142));
        }
    }

    public void func_75132_a(IContainerListener listener)
    {
        super.func_75132_a(listener);
        listener.func_175173_a(this, this.tileFurnace);
    }

    /**
     * Looks for changes made in the container, sends them to every listener.
     */
    public void func_75142_b()
    {
        super.func_75142_b();

        for (int i = 0; i < this.field_75149_d.size(); ++i)
        {
            IContainerListener icontainerlistener = this.field_75149_d.get(i);

            if (this.cookTime != this.tileFurnace.func_174887_a_(2))
            {
                icontainerlistener.func_71112_a(this, 2, this.tileFurnace.func_174887_a_(2));
            }

            if (this.furnaceBurnTime != this.tileFurnace.func_174887_a_(0))
            {
                icontainerlistener.func_71112_a(this, 0, this.tileFurnace.func_174887_a_(0));
            }

            if (this.currentItemBurnTime != this.tileFurnace.func_174887_a_(1))
            {
                icontainerlistener.func_71112_a(this, 1, this.tileFurnace.func_174887_a_(1));
            }

            if (this.totalCookTime != this.tileFurnace.func_174887_a_(3))
            {
                icontainerlistener.func_71112_a(this, 3, this.tileFurnace.func_174887_a_(3));
            }
        }

        this.cookTime = this.tileFurnace.func_174887_a_(2);
        this.furnaceBurnTime = this.tileFurnace.func_174887_a_(0);
        this.currentItemBurnTime = this.tileFurnace.func_174887_a_(1);
        this.totalCookTime = this.tileFurnace.func_174887_a_(3);
    }

    @SideOnly(Side.CLIENT)
    public void func_75137_b(int id, int data)
    {
        this.tileFurnace.func_174885_b(id, data);
    }

    /**
     * Determines whether supplied player can use this container
     */
    public boolean func_75145_c(EntityPlayer playerIn)
    {
        return this.tileFurnace.func_70300_a(playerIn);
    }

    /**
     * Handle when the stack in slot {@code index} is shift-clicked. Normally this moves the stack between the player
     * inventory and the other inventory(s).
     */
    public ItemStack func_82846_b(EntityPlayer playerIn, int index)
    {
        ItemStack itemstack = ItemStack.field_190927_a;
        Slot slot = this.field_75151_b.get(index);

        if (slot != null && slot.func_75216_d())
        {
            ItemStack itemstack1 = slot.func_75211_c();
            itemstack = itemstack1.func_77946_l();

            if (index == 2)
            {
                if (!this.func_75135_a(itemstack1, 3, 39, true))
                {
                    return ItemStack.field_190927_a;
                }

                slot.func_75220_a(itemstack1, itemstack);
            }
            else if (index != 1 && index != 0)
            {
                if (!FurnaceRecipes.func_77602_a().func_151395_a(itemstack1).func_190926_b())
                {
                    if (!this.func_75135_a(itemstack1, 0, 1, false))
                    {
                        return ItemStack.field_190927_a;
                    }
                }
                /*else if (TileEntityM_Crafting.isItemFuel(itemstack1))
                {
                    if (!this.mergeItemStack(itemstack1, 1, 2, false))
                    {
                        return ItemStack.EMPTY;
                    }
                }*/
                else if (index >= 3 && index < 30)
                {
                    if (!this.func_75135_a(itemstack1, 30, 39, false))
                    {
                        return ItemStack.field_190927_a;
                    }
                }
                else if (index >= 30 && index < 39 && !this.func_75135_a(itemstack1, 3, 30, false))
                {
                    return ItemStack.field_190927_a;
                }
            }
            else if (!this.func_75135_a(itemstack1, 3, 39, false))
            {
                return ItemStack.field_190927_a;
            }

            if (itemstack1.func_190926_b())
            {
                slot.func_75215_d(ItemStack.field_190927_a);
            }
            else
            {
                slot.func_75218_e();
            }

            if (itemstack1.func_190916_E() == itemstack.func_190916_E())
            {
                return ItemStack.field_190927_a;
            }

            slot.func_190901_a(playerIn, itemstack1);
        }

        return itemstack;
    }
}
