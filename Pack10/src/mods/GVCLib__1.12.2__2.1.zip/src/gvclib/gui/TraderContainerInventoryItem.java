package gvclib.gui;

import gvclib.entity.trader.EntityNPCBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.Slot;
import net.minecraft.item.ItemStack;

public class TraderContainerInventoryItem extends Container
{
    private final IInventory horseInventory;
    private final EntityNPCBase horse;

    public TraderContainerInventoryItem(IInventory playerInventory, IInventory horseInventoryIn, final EntityNPCBase horse, EntityPlayer player)
    {
        this.horseInventory = horseInventoryIn;
        this.horse = horse;
        int i = 3;
        horseInventoryIn.func_174889_b(player);
        int j = -18;

        //if (horse instanceof AbstractChestHorse && ((AbstractChestHorse)horse).hasChest())
        /*{
            for (int k = 0; k < 3; ++k)
            {
                for (int l = 0; l < ((EntityNPC_T)horse).getInventoryColumns(); ++l)
                {
                    this.addSlotToContainer(new Slot(horseInventoryIn, 0 + l + k * ((EntityNPC_T)horse).getInventoryColumns(), 80 + l * 18, 18 + k * 18));
                }
            }
        }*/
        {
        	//buy
        	this.func_75146_a(new Slot(horseInventoryIn, 0, 8, 18));
        }
        {
        	//for (int k = 0; k < 3; ++k)
            {
        		this.func_75146_a(new Slot_OutPut(horseInventoryIn, 1, 62, 18));
        		this.func_75146_a(new Slot_OutPut(horseInventoryIn, 2, 62, 36));
        		this.func_75146_a(new Slot_OutPut(horseInventoryIn, 3, 62, 54));
        		
        		this.func_75146_a(new Slot_OutPut(horseInventoryIn, 4, 98, 18));
        		this.func_75146_a(new Slot_OutPut(horseInventoryIn, 5, 98, 36));
        		this.func_75146_a(new Slot_OutPut(horseInventoryIn, 6, 98, 54));
        		
        		this.func_75146_a(new Slot_OutPut(horseInventoryIn, 7, 134, 18));
        		this.func_75146_a(new Slot_OutPut(horseInventoryIn, 8, 134, 36));
        		this.func_75146_a(new Slot_OutPut(horseInventoryIn, 9, 134, 54));
            }
        }
        {
        	//sell
        	this.func_75146_a(new Slot(horseInventoryIn, 10, 8, 54));
        	this.func_75146_a(new Slot_OutPut(horseInventoryIn, 11, 37, 54));
        }

        for (int i1 = 0; i1 < 3; ++i1)
        {
            for (int k1 = 0; k1 < 9; ++k1)
            {
                this.func_75146_a(new Slot(playerInventory, k1 + i1 * 9 + 9, 8 + k1 * 18, 102 + i1 * 18 + -18));
            }
        }

        for (int j1 = 0; j1 < 9; ++j1)
        {
            this.func_75146_a(new Slot(playerInventory, j1, 8 + j1 * 18, 142));
        }
    }

    /**
     * Determines whether supplied player can use this container
     */
    public boolean func_75145_c(EntityPlayer playerIn)
    {
        return this.horseInventory.func_70300_a(playerIn) && this.horse.func_70089_S() && this.horse.func_70032_d(playerIn) < 8.0F;
    }

    /**
     * Handle when the stack in slot {@code index} is shift-clicked. Normally this moves the stack between the player
     * inventory and the other inventory(s).
     */
    public ItemStack func_82846_b(EntityPlayer playerIn, int index)
    {
        ItemStack itemstack = ItemStack.field_190927_a;
        Slot slot = this.field_75151_b.get(index);

        if (slot != null && slot.func_75216_d())
        {
            ItemStack itemstack1 = slot.func_75211_c();
            itemstack = itemstack1.func_77946_l();

            if (index < this.horseInventory.func_70302_i_())
            {
                if (!this.func_75135_a(itemstack1, this.horseInventory.func_70302_i_(), this.field_75151_b.size(), true))
                {
                    return ItemStack.field_190927_a;
                }
            }
            else if (this.func_75139_a(1).func_75214_a(itemstack1) && !this.func_75139_a(1).func_75216_d())
            {
                if (!this.func_75135_a(itemstack1, 1, 2, false))
                {
                    return ItemStack.field_190927_a;
                }
            }
            else if (this.func_75139_a(0).func_75214_a(itemstack1))
            {
                if (!this.func_75135_a(itemstack1, 0, 1, false))
                {
                    return ItemStack.field_190927_a;
                }
            }
            else if (this.horseInventory.func_70302_i_() <= 2 || !this.func_75135_a(itemstack1, 2, this.horseInventory.func_70302_i_(), false))
            {
                return ItemStack.field_190927_a;
            }

            if (itemstack1.func_190926_b())
            {
                slot.func_75215_d(ItemStack.field_190927_a);
            }
            else
            {
                slot.func_75218_e();
            }
            
            /*{
            	ItemStack is = this.horseInventory.getStackInSlot(10);

                if (!is.isEmpty() && is.getItem() == Items.EMERALD)
                {
                	this.horseInventory.setInventorySlotContents(11, new ItemStack(Items.EMERALD));
                	if(playerIn.inventory.addItemStackToInventory(this.horseInventory.getStackInSlot(11))) {
                		is.shrink(1);
                	}
                }
            }*/
            
        }

        return itemstack;
    }

    /**
     * Called when the container is closed.
     */
    public void func_75134_a(EntityPlayer playerIn)
    {
        super.func_75134_a(playerIn);
        this.horseInventory.func_174886_c(playerIn);
    }
}
