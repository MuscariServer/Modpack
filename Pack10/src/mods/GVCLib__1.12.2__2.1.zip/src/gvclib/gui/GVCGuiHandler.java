package gvclib.gui;
 
import java.util.List;
import gvclib.block.tile.TileEntityInvasion;
import gvclib.entity.living.EntityMobVehicle_Inv_Base;
import gvclib.entity.trader.EntityNPCBase;
import gvclib.item.ItemGunBase;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.fml.common.network.IGuiHandler;


import gvclib.block.tile.TileEntityInvasion;
import gvclib.entity.living.EntityMobVehicle_Inv_Base;
import gvclib.entity.living.EntityVehicleBase;
import gvclib.entity.trader.EntityNPCBase;
import gvclib.item.ItemGunBase;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.fml.common.network.IGuiHandler;
 
public class GVCGuiHandler implements IGuiHandler
{
    /*
        ServerでGUIが開かれたときに呼ばれる
        通常はContainerを生成する。
     */
    @Override
    public Object getServerGuiElement(int ID, EntityPlayer player, World world, int x, int y, int z)
    {
    	ItemStack itemstack = player.func_184614_ca();
        if(ID == 0){
            return new GVCContainerInventoryItem(player.field_71071_by, itemstack);
        }
        if(ID == 3){
        	if(itemstack.func_77973_b() instanceof ItemGunBase) {
            return new GVCGunReloadtestContainer();
        	}
        }
        BlockPos pos = new BlockPos(x, y, z);
		if (ID == 1) {
			if (!world.func_175667_e(pos)) {
				return null;
			}else {
				TileEntity tileentity = world.func_175625_s(pos);
				if (tileentity instanceof TileEntityInvasion) {
					//System.out.println(String.format("2"));
					return new ContainerInventoryEntityGVC(player.field_71071_by, (TileEntityInvasion) tileentity);
				}
			}
		}
		if(ID == 2){
        	NBTTagCompound nbt = player.getEntityData();
        	int enid = nbt.func_74762_e("vi");
        	EntityNPCBase en = null;
        	List<Entity> llist = player.field_70170_p.func_72839_b(player,
        			player.func_174813_aQ().func_72321_a(player.field_70159_w, player.field_70181_x, player.field_70179_y).func_186662_g(2));
    		if (llist != null) {
    			for (int lj = 0; lj < llist.size(); lj++) {
    				Entity entity1 = (Entity) llist.get(lj);
    				if (entity1.func_70067_L() && entity1.func_145782_y() == enid) {
    					en = (EntityNPCBase) entity1;
    				}
    			}
    		}
    		if(en != null) {
    			return new TraderContainerInventoryItem(player.field_71071_by, en.horseChest,en,  player);
    		}else {
    			return null;
    		}
        }
		if(ID == 4){
        	NBTTagCompound nbt = player.getEntityData();
        	int enid = nbt.func_74762_e("vi");
        	EntityMobVehicle_Inv_Base en = null;
        	List<Entity> llist = player.field_70170_p.func_72839_b(player,
        			player.func_174813_aQ().func_72321_a(player.field_70159_w, player.field_70181_x, player.field_70179_y).func_186662_g(2));
    		if (llist != null) {
    			for (int lj = 0; lj < llist.size(); lj++) {
    				Entity entity1 = (Entity) llist.get(lj);
    				if (entity1.func_70067_L() && entity1.func_145782_y() == enid) {
    					en = (EntityMobVehicle_Inv_Base) entity1;
    				}
    			}
    		}
    		if(en != null) {
    			return new GVCContainerInventory_vehicle(player.field_71071_by, en.horseChest,en,  player);
    		}else {
    			return null;
    		}
        }
		/*if(ID == 5){
        	NBTTagCompound nbt = player.getEntityData();
        	int enid = nbt.getInteger("vi");
        	EntityVehicleBase en = null;
        	List<Entity> llist = player.world.getEntitiesWithinAABBExcludingEntity(player,
        			player.getEntityBoundingBox().expand(player.motionX, player.motionY, player.motionZ).grow(2));
    		if (llist != null) {
    			for (int lj = 0; lj < llist.size(); lj++) {
    				Entity entity1 = (Entity) llist.get(lj);
    				if (entity1.canBeCollidedWith() && entity1.getEntityId() == enid) {
    					en = (EntityVehicleBase) entity1;
    				}
    			}
    		}
    		if(en != null) {
    			return new GVCContainerVehicle_Motion();
    		}else {
    			return null;
    		}
        }*/
        return null;
    }
 
    /*
        ClientでGUIが開かれたときに呼ばれる
        通常はGUIを生成する
     */
    @Override
    public Object getClientGuiElement(int ID, EntityPlayer player, World world, int x, int y, int z)
    {
    	ItemStack itemstack = player.func_184614_ca();
        if(ID == 0){
            return new GVCGuiInventoryItem(player.field_71071_by, itemstack);
        }
        if(ID == 3){
        	if(itemstack.func_77973_b() instanceof ItemGunBase) {
        		ItemGunBase gun = (ItemGunBase) itemstack.func_77973_b();
        		 return new GVCGunReloadtestGuiInventory(player.field_71071_by, itemstack, gun);
        	}
        }
        BlockPos pos = new BlockPos(x, y, z);
        if (ID == 1) {
			if (!world.func_175667_e(pos)) {
				return null;
			}else {
				TileEntity tileentity = world.func_175625_s(pos);
				if (tileentity instanceof TileEntityInvasion) {
					//System.out.println(String.format("1"));
					return new GuiInventoryEntityGVC(player.field_71071_by, (TileEntityInvasion) tileentity, (TileEntityInvasion) tileentity);
				}
			}
		}
        if(ID == 2){
        	NBTTagCompound nbt = player.getEntityData();
        	int enid = nbt.func_74762_e("vi");
        	EntityNPCBase en = null;
        	List<Entity> llist = player.field_70170_p.func_72839_b(player,
        			player.func_174813_aQ().func_72321_a(player.field_70159_w, player.field_70181_x, player.field_70179_y).func_186662_g(2));
    		if (llist != null) {
    			for (int lj = 0; lj < llist.size(); lj++) {
    				Entity entity1 = (Entity) llist.get(lj);
    				if (entity1.func_70067_L() && entity1.func_145782_y() == enid) {
    					en = (EntityNPCBase) entity1;
    				}
    			}
    		}
    		if(en != null) {
    			return new TraderGuiInventoryItem(player.field_71071_by, en.horseChest,en);
    		}else {
    			return null;
    		}
        }
        if(ID == 4){
        	NBTTagCompound nbt = player.getEntityData();
        	int enid = nbt.func_74762_e("vi");
        	EntityMobVehicle_Inv_Base en = null;
        	List<Entity> llist = player.field_70170_p.func_72839_b(player,
        			player.func_174813_aQ().func_72321_a(player.field_70159_w, player.field_70181_x, player.field_70179_y).func_186662_g(2));
    		if (llist != null) {
    			for (int lj = 0; lj < llist.size(); lj++) {
    				Entity entity1 = (Entity) llist.get(lj);
    				if (entity1.func_70067_L() && entity1.func_145782_y() == enid) {
    					en = (EntityMobVehicle_Inv_Base) entity1;
    				}
    			}
    		}
    		if(en != null) {
    			return new GVCGuiInventoryItem_vehicle(player.field_71071_by, en.horseChest,en);
    		}else {
    			return null;
    		}
        }
       /* if(ID == 5){
        	NBTTagCompound nbt = player.getEntityData();
        	int enid = nbt.getInteger("vi");
        	EntityVehicleBase en = null;
        	List<Entity> llist = player.world.getEntitiesWithinAABBExcludingEntity(player,
        			player.getEntityBoundingBox().expand(player.motionX, player.motionY, player.motionZ).grow(2));
    		if (llist != null) {
    			for (int lj = 0; lj < llist.size(); lj++) {
    				Entity entity1 = (Entity) llist.get(lj);
    				if (entity1.canBeCollidedWith() && entity1.getEntityId() == enid) {
    					en = (EntityVehicleBase) entity1;
    				}
    			}
    		}
    		if(en != null) {
    			return new GVCGuiInventoryVehicle_Motion(player, en);
    		}else {
    			return null;
    		}
        }*/
        return null;
    }
}
