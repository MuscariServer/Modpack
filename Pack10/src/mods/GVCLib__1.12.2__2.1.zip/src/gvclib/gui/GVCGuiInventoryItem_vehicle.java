package gvclib.gui;

import java.awt.Color;
import java.io.IOException;
import gvclib.entity.living.EntityMobVehicle_Inv_Base;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderItem;
import net.minecraft.client.renderer.texture.TextureMap;
import net.minecraft.client.resources.I18n;
import net.minecraft.inventory.IInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import org.lwjgl.opengl.GL11;


import org.lwjgl.opengl.GL11;

import gvclib.entity.living.EntityMobVehicle_Inv_Base;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderItem;
import net.minecraft.client.renderer.texture.TextureMap;
import net.minecraft.client.resources.I18n;
import net.minecraft.inventory.IInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
public class GVCGuiInventoryItem_vehicle extends GuiContainer
{
    //private static final ResourceLocation HORSE_GUI_TEXTURES = new ResourceLocation("pixelcaravan:textures/gui/guitest.png");
	private static final ResourceLocation CHEST_GUI_TEXTURE = new ResourceLocation("gvclib:textures/gui/gui_tank.png");
    /** The player inventory bound to this GUI. */
    private final IInventory playerInventory;
    /** The horse inventory bound to this GUI. */
    private final IInventory horseInventory;
    /** The EntityHorse whose inventory is currently being accessed. */
    private final EntityMobVehicle_Inv_Base trader;
    /** The mouse x-position recorded during the last rendered frame. */
    private float mousePosx;
    /** The mouse y-position recorded during the last renderered frame. */
    private float mousePosY;

    private final int inventoryRows;
    
    public GVCGuiInventoryItem_vehicle(IInventory playerInv, IInventory horseInv, EntityMobVehicle_Inv_Base horse)
    {
        super(new GVCContainerInventory_vehicle(playerInv, horseInv, horse, Minecraft.func_71410_x().field_71439_g));
        this.playerInventory = playerInv;
        this.horseInventory = horseInv;
        this.trader = horse;
        this.field_146291_p = false;
        //this.ySize = 222;
        this.inventoryRows = horse.slot_max / 9;
       // this.ySize = 114 + this.inventoryRows * 18;
       // this.xSize = 237;
    }

    public void func_73866_w_()
    {
    	super.func_73866_w_();
    }
    
    /**
     * Draw the foreground layer for the GuiContainer (everything in front of the items)
     */
    protected void func_146979_b(int mouseX, int mouseY)
    {
        //this.fontRenderer.drawString(trader.getCustomNameTag(), 8, 6, 4210752);
    	this.field_146289_q.func_78276_b(I18n.func_135052_a("container.crafting"), 8, 6, 4210752);
        this.field_146289_q.func_78276_b(I18n.func_135052_a("container.inventory"), 8, this.field_147000_g - 96 + 2, 4210752);
    }

    protected void func_146284_a(GuiButton button) throws IOException
    {
    	 
    }
    
    /**
     * Draws the background layer of this container (behind the items).
     */
    protected void func_146976_a(float partialTicks, int mouseX, int mouseY)
    {
        GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
        	this.field_146297_k.func_110434_K().func_110577_a(CHEST_GUI_TEXTURE);
            int i = (this.field_146294_l - this.field_146999_f) / 2;
            int j = (this.field_146295_m - this.field_147000_g) / 2;
            this.func_73729_b(i, j, 0, 0, this.field_146999_f, this.field_147000_g);
            //this.drawTexturedModalRect(i, j, 0, 0, 220, 212);
           // this.drawTexturedModalRect(i, j, 0, 0, this.xSize, this.inventoryRows * 18 + 17);
            //this.drawTexturedModalRect(i, j + this.inventoryRows * 18 + 17, 0, 126, this.xSize, 96);
            /*if(trader != null){
            	GL11.glPushMatrix();
            	GL11.glScalef(1F, 1F, 1F);
            	GuiInventory.drawEntityOnScreen((i+ 100), (j + 20), 17, 300, 0, trader);
            	GL11.glPopMatrix();
            }*/
        {
        	FontRenderer fontReader = field_146297_k.field_71466_p;
    		field_146297_k.field_71466_p.func_78264_a(field_146297_k.func_152349_b());
            GL11.glPushMatrix();
    		GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
    		GlStateManager.func_187428_a(GlStateManager.SourceFactor.SRC_ALPHA,
    				GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE,
    				GlStateManager.DestFactor.ZERO);
    		field_146297_k.field_71446_o.func_110577_a(TextureMap.field_110575_b);
    		{
				String d1 = String.format("%1$3d", (int)trader.func_110143_aJ());
				String d2 = String.format("%1$3d", (int)trader.func_110138_aP());
				fontReader.func_78276_b("HP : "  + d1 + " / " + d2,  i + 10, j + 22, Color.BLACK.getRGB());
			}
    		{
				String d1 = String.format("%1$.2f", trader.sp * 100);
				fontReader.func_78276_b("SPEED: "  + d1,  i + 10, j + 32, Color.BLACK.getRGB());
			}
    		{
				String d1 = String.format("%1$.2f", trader.turnspeed);
				fontReader.func_78276_b("TURN-SPD: "  + d1,  i + 10, j + 42, Color.BLACK.getRGB());
			}
    		{
				String d1 = String.format("%1$.1f", -trader.rotationp_max);
				String d2 = String.format("%1$.1f", -trader.rotationp_min);
				fontReader.func_78276_b("E/D ANGLE: "  + d1 + " / " + d2,  i + 10, j + 52, Color.BLACK.getRGB());
			}
    		
    		RenderItem renderitem = field_146297_k.func_175599_af();
    		{
    			ItemStack item =  new ItemStack(trader.fuel_item);
				if (!item.func_190926_b()) {
					renderitem.func_175042_a(item, i + 80,j + 18);
				}
    		}
    		{
    			ItemStack item =  new ItemStack(trader.weapon1_item);
				if (!item.func_190926_b()) {
					renderitem.func_175042_a(item, i + 80,j + 36);
				}
    		}
    		{
    			ItemStack item =  new ItemStack(trader.weapon2_item);
				if (!item.func_190926_b()) {
					renderitem.func_175042_a(item, i + 80,j + 54);
				}
    		}
    		GL11.glPopMatrix();
        }
        
        
        
    }
    
    /**
     * Draws the screen and all the components in it.
     */
    public void func_73863_a(int mouseX, int mouseY, float partialTicks)
    {
        this.func_146276_q_();
        this.mousePosx = (float)mouseX;
        this.mousePosY = (float)mouseY;
        super.func_73863_a(mouseX, mouseY, partialTicks);
        this.func_191948_b(mouseX, mouseY);
    }
}
