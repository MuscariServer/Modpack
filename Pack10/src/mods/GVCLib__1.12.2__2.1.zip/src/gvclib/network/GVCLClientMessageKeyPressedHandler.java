package gvclib.network;
import gvclib.mod_GVCLib;
import gvclib.block.tile.TileEntityInvasion;
import gvclib.entity.EntityBBase;
import gvclib.entity.living.EntityGVCLivingBase;
import gvclib.entity.living.EntityMobVehicle_Inv_Base;
import gvclib.entity.trader.EntityNPCBase;
import gvclib.item.ItemGunBase;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;
 
public class GVCLClientMessageKeyPressedHandler implements IMessageHandler<GVCLClientMessageKeyPressed, IMessage> {
 
    @Override
    public IMessage onMessage(GVCLClientMessageKeyPressed message, MessageContext ctx) {
        EntityPlayer player = mod_GVCLib.proxy.getEntityPlayerInstance();
    	 //EntityPlayer player = ctx.getServerHandler().player;
        
        if(player == null)return null;
        
        
      //受け取ったMessageクラスのkey変数の数字をチャットに出力
        if(message.key == 1){
        	ItemStack itemstack = ((EntityPlayer)(player)).func_184614_ca();
            int li = itemstack.func_77958_k() - itemstack.func_77952_i();
            if(!itemstack.func_190926_b() && itemstack.func_77973_b() instanceof ItemGunBase){
            	ItemGunBase gun = (ItemGunBase) itemstack.func_77973_b();
            	gun.zandan = gun.getDamage(itemstack);
    			}
    	    itemstack.func_77972_a(li, player);
        }/**/
        
        if(message.key == 2){
        	if(player.func_145782_y() == message.fre) {
        		player.field_70125_A = (float) (message.posx);
          }
        }/**/
        
        if(message.key == 3){
        	if(player.func_145782_y() == message.fre) {
        		//player.rotationPitch = (float) (message.posx);
                ItemStack itemstack = ((EntityPlayer)(player)).func_184614_ca();
                if(!itemstack.func_190926_b() && itemstack.func_77973_b() instanceof ItemGunBase){
                	ItemGunBase gun = (ItemGunBase) itemstack.func_77973_b();
                	NBTTagCompound nbt = itemstack.func_77978_p();
                	nbt.func_74757_a("Recoiled", message.boolean_hantei);
        		}
            }
        }/**/
        if(message.key == 31){
        	if(player.func_145782_y() == message.fre) {
        		//player.rotationPitch = (float) (message.posx);
                ItemStack itemstack = ((EntityPlayer)(player)).func_184592_cb();
                if(!itemstack.func_190926_b() && itemstack.func_77973_b() instanceof ItemGunBase){
                	ItemGunBase gun = (ItemGunBase) itemstack.func_77973_b();
                	NBTTagCompound nbt = itemstack.func_77978_p();
                	nbt.func_74757_a("Recoiled", message.boolean_hantei);
        		}
            }
        }/**/
        if(message.key == 4){
        	if(player.func_145782_y() == message.fre) {
                ItemStack itemstack = ((EntityPlayer)(player)).func_184614_ca();
                if(!itemstack.func_190926_b() && itemstack.func_77973_b() instanceof ItemGunBase){
                	ItemGunBase gun = (ItemGunBase) itemstack.func_77973_b();
                	NBTTagCompound nbt = itemstack.func_77978_p();
                	nbt.func_74757_a("Cocking", message.boolean_hantei);
        		}
            }
        }/**/
        if(message.key == 41){
        	if(player.func_145782_y() == message.fre) {
                ItemStack itemstack = ((EntityPlayer)(player)).func_184592_cb();
                if(!itemstack.func_190926_b() && itemstack.func_77973_b() instanceof ItemGunBase){
                	ItemGunBase gun = (ItemGunBase) itemstack.func_77973_b();
                	NBTTagCompound nbt = itemstack.func_77978_p();
                	nbt.func_74757_a("Cocking", message.boolean_hantei);
        		}
            }
        }/**/
        if(message.key == 5){
        	if(player.func_145782_y() == message.fre) {
                ItemStack itemstack = ((EntityPlayer)(player)).func_184614_ca();
                if(!itemstack.func_190926_b()){
                	//itemstack.shrink(1);
                	int li = itemstack.func_77958_k() - itemstack.func_77952_i();
                	if (li > 0)itemstack.func_77972_a(1, (EntityLivingBase) player);
        		}
            }
        }/**/
        if(message.key == 6){
        	if(player.func_145782_y() == message.fre) {
            	ItemStack itemstack = ((EntityPlayer)(player)).func_184614_ca();
                if(!itemstack.func_190926_b()){
                	//itemstack.shrink(1);
        		}
            }
        }/**/
        
        if(message.key == 10){
    		if(player.func_145782_y() == message.fre)
    		{
    			NBTTagCompound nbt = player.getEntityData();
    			nbt.func_74768_a("hitentity", 20);
    			{
    				//player.playSound(SoundEvents.ENTITY_ARROW_HIT, 1.0F, 1.2F);
    			}
    		}
    	}
        if(message.key == 9){
    		if(player.func_145782_y() == message.fre)
    		{
    			NBTTagCompound nbt = player.getEntityData();
    			nbt.func_74768_a("hitentitydead", 20);
    		}
    	}
        if(message.key == 11){
    		if(player.func_145782_y() == message.fre)
    		{
    			NBTTagCompound nbt = player.getEntityData();
    			nbt.func_74768_a("hitentity_headshot", 20);
    			{
    				//player.playSound(SoundEvents.ENTITY_ARROW_HIT, 1.0F, 1.2F);
    			}
    		}
    	}
        
        
        if(message.key == 321){
        	World world;
        	//System.out.println(String.format("world"));
//          System.out.println("debug");
          if(ctx.side.isServer()) {
              world = ctx.getServerHandler().field_147369_b.field_70170_p;
          }else{
              world = mod_GVCLib.proxy.getCilentWorld();
          }
          try {
              if(world != null){
            	  //System.out.println(String.format("world"));
                  Entity tgtEntity = world.func_73045_a(message.fre);
                  if(message.data != null && tgtEntity != null && tgtEntity instanceof EntityBBase) {
                      tgtEntity.field_70159_w = message.data.motionX;
                      tgtEntity.field_70181_x = message.data.motionY;
                      tgtEntity.field_70179_y = message.data.motionZ;
                      tgtEntity.field_70165_t = message.data.posX;
                      tgtEntity.field_70163_u = message.data.posY;
                      tgtEntity.field_70161_v = message.data.posZ;
                      //System.out.println(String.format("chach"));
                  }
              }
//          bullet = message.bullet.setdata(bullet);
//          System.out.println("bullet "+ bullet);
          }catch (ClassCastException e) {
              e.printStackTrace();
          }catch (Exception e){
              e.printStackTrace();
          }
        }
        
        if(message.key == 61){
        	World world;
          if(ctx.side.isServer()) {
              world = ctx.getServerHandler().field_147369_b.field_70170_p;
          }else{
              world = mod_GVCLib.proxy.getCilentWorld();
          }
          try {
              if(world != null){
            	  //System.out.println(String.format("world"));
                  Entity tgtEntity = world.func_73045_a(message.fre);
                  if(tgtEntity != null && tgtEntity instanceof EntityLivingBase) {
                	  NBTTagCompound target_nbt = tgtEntity.getEntityData();
          			if(target_nbt != null) {
          				target_nbt.func_74768_a("lockon", 100);
          				//System.out.println("2");
          				ItemStack itemstack = ((EntityPlayer)(player)).func_184614_ca();
          	            if(!itemstack.func_190926_b() && itemstack.func_77973_b() instanceof ItemGunBase){
          	            	ItemGunBase gun = (ItemGunBase) itemstack.func_77973_b();
          	            	gun.mitarget = (EntityLivingBase) tgtEntity;
          	    		}
          			}
                  }
              }
          }catch (ClassCastException e) {
              e.printStackTrace();
          }catch (Exception e){
              e.printStackTrace();
          }
        }
        if(message.key == 62){
        	ItemStack itemstack = ((EntityPlayer)(player)).func_184614_ca();
	            if(!itemstack.func_190926_b() && itemstack.func_77973_b() instanceof ItemGunBase){
	            	ItemGunBase gun = (ItemGunBase) itemstack.func_77973_b();
	            	gun.mitarget = null;
	    		}
        }
        
        {
       	 if(message.key == 1310){
       		if(player.func_145782_y() == message.fre) {
       			ItemStack itemstack = ((EntityPlayer)(player)).func_184614_ca();
             	if(!itemstack.func_190926_b()){
     				ItemGunBase gun = (ItemGunBase) itemstack.func_77973_b();
     				NBTTagCompound nbtgun = itemstack.func_77978_p();
     				nbtgun.func_74768_a("RecoiledTime", 0);
     				nbtgun.func_74757_a("Recoiled", true);
     			}
       		}
             	
         }
       	 if(message.key == 1311){
       		 if(player.func_145782_y() == message.fre) {
       			ItemStack itemstack = ((EntityPlayer)(player)).func_184614_ca();
              	if(!itemstack.func_190926_b()){
      				ItemGunBase gun = (ItemGunBase) itemstack.func_77973_b();
      				NBTTagCompound nbtgun = itemstack.func_77978_p();
      				nbtgun.func_74768_a("RecoiledTime", message.da);
      				nbtgun.func_74757_a("Recoiled", false);
      			}
              }
       		}
       }
        
        
        
        
        
        
        
        
        if(message.key == 12){
        	EntityLivingBase en = (EntityLivingBase) player.field_70170_p.func_73045_a(message.fre);
        	if (player.func_184187_bx() instanceof EntityGVCLivingBase && player.func_184187_bx() != null && player.func_184187_bx() == en) {// 1
        		EntityGVCLivingBase base = (EntityGVCLivingBase) en;
        		base.server2 = true;
        	}
        }
        if(message.key == 13){
        	EntityLivingBase en = (EntityLivingBase) player.field_70170_p.func_73045_a(message.fre);
        	if (player.func_184187_bx() instanceof EntityGVCLivingBase && player.func_184187_bx() != null && player.func_184187_bx() == en) {// 1
        		EntityGVCLivingBase base = (EntityGVCLivingBase) en;
        		base.serverspace = true;
        	}
        }
        if(message.key == 14){
        	EntityLivingBase en = (EntityLivingBase) player.field_70170_p.func_73045_a(message.fre);
        	if (player.func_184187_bx() instanceof EntityGVCLivingBase && player.func_184187_bx() != null && player.func_184187_bx() == en) {// 1
        		EntityGVCLivingBase base = (EntityGVCLivingBase) en;
        		base.serverx = true;
        	}
        }
        if(message.key == 15){
        	EntityLivingBase en = (EntityLivingBase) player.field_70170_p.func_73045_a(message.fre);
        	if (player.func_184187_bx() instanceof EntityGVCLivingBase && player.func_184187_bx() != null && player.func_184187_bx() == en) {// 1
        		EntityGVCLivingBase base = (EntityGVCLivingBase) en;
        		base.serverg = true;
        	}
        }
        if(message.key == 16){
        	EntityLivingBase en = (EntityLivingBase) player.field_70170_p.func_73045_a(message.fre);
        	if (player.func_184187_bx() instanceof EntityGVCLivingBase && player.func_184187_bx() != null && player.func_184187_bx() == en) {// 1
        		EntityGVCLivingBase base = (EntityGVCLivingBase) en;
        		base.serverc = true;
        	}
        }
        if(message.key == 17){
        	EntityLivingBase en = (EntityLivingBase) player.field_70170_p.func_73045_a(message.fre);
        	if (player.func_184187_bx() instanceof EntityGVCLivingBase && player.func_184187_bx() != null && player.func_184187_bx() == en) {// 1
        		EntityGVCLivingBase base = (EntityGVCLivingBase) en;
        		base.serverz = true;
        	}
        }
        if(message.key == 18){
        	EntityLivingBase en = (EntityLivingBase) player.field_70170_p.func_73045_a(message.fre);
        	if (player.func_184187_bx() instanceof EntityGVCLivingBase && player.func_184187_bx() != null && player.func_184187_bx() == en) {// 1
        		EntityGVCLivingBase base = (EntityGVCLivingBase) en;
        		base.serverh = true;
        	}
        }
        
        if(message.key == 100){
        	BlockPos pos = new BlockPos(message.posx, message.posy, message.posz);
        	if(pos != null && player.field_70170_p.func_175625_s(pos) instanceof TileEntityInvasion) {
        		TileEntityInvasion tile  = (TileEntityInvasion) player.field_70170_p.func_175625_s(pos);
				tile.spwan_range = message.enid;
        	}
    	}
        if(message.key == 101){
        	BlockPos pos = new BlockPos(message.posx, message.posy, message.posz);
        	if(pos != null && player.field_70170_p.func_175625_s(pos) instanceof TileEntityInvasion) {
        		TileEntityInvasion tile  = (TileEntityInvasion) player.field_70170_p.func_175625_s(pos);
				tile.setHP(message.enid);
        	}
    	}
        if(message.key == 102){
        	BlockPos pos = new BlockPos(message.posx, message.posy, message.posz);
        	if(pos != null && player.field_70170_p.func_175625_s(pos) instanceof TileEntityInvasion) {
        		TileEntityInvasion tile  = (TileEntityInvasion) player.field_70170_p.func_175625_s(pos);
        		tile.setLevel(message.enid);
        	}
    	}
        if(message.key == 103){
        	BlockPos pos = new BlockPos(message.posx, message.posy, message.posz);
        	if(pos != null && player.field_70170_p.func_175625_s(pos) instanceof TileEntityInvasion) {
        		TileEntityInvasion tile  = (TileEntityInvasion) player.field_70170_p.func_175625_s(pos);
        		tile.setTicks(message.enid);
        	}
    	}
        
        
        
        if(message.key == 201){
        	EntityLivingBase en = (EntityLivingBase) player.field_70170_p.func_73045_a(message.fre);
        	if (en != null && en instanceof EntityGVCLivingBase) {// 1
        		EntityGVCLivingBase base = (EntityGVCLivingBase) en;
        		base.setattacktask(true);
        	}
        }
        if(message.key == 202){
        	EntityLivingBase en = (EntityLivingBase) player.field_70170_p.func_73045_a(message.fre);
        	if (en != null && en instanceof EntityGVCLivingBase) {// 1
        		EntityGVCLivingBase base = (EntityGVCLivingBase) en;
        		base.setattacktask(false);
        	}
        }
        
        
        
        if(message.key == 0){
        	if(player != null){
            	Entity en = (Entity) player.field_70170_p.func_73045_a(message.enid);
    			if(en != null){
    				if(en.field_70170_p != null) {
    					if (message.strength >= 2.0F) {
    						if (message.strength >= 4.0F) {
    							int a = 0;
    							a = (int) (6 + message.strength);
    							for (int ii = 0; ii < a; ++ii) {
    								int xx = en.field_70170_p.field_73012_v.nextInt(a);
    								int zz = en.field_70170_p.field_73012_v.nextInt(a);
    								int yy = en.field_70170_p.field_73012_v.nextInt(a);
    								en.field_70170_p.func_175688_a(EnumParticleTypes.EXPLOSION_HUGE, message.posx - (a / 2) + xx,
    										message.posy - (a / 2) + yy, message.posz - (a / 2) + zz, 1.0D, 0.0D, 0.0D, new int[0]);
    							}
    							en.field_70170_p.func_175688_a(EnumParticleTypes.EXPLOSION_HUGE, message.posx, message.posy, message.posz, 1.0D,
    									0.0D, 0.0D, new int[0]);
    						} else {
    							en.field_70170_p.func_175688_a(EnumParticleTypes.EXPLOSION_HUGE, message.posx, message.posy, message.posz, 1.0D,
    									0.0D, 0.0D, new int[0]);
    						}
    					} else {
    						en.field_70170_p.func_175688_a(EnumParticleTypes.EXPLOSION_LARGE, message.posx, message.posy, message.posz, 1.0D, 0.0D,
    								0.0D, new int[0]);
    					}
    				}
    	    	}
    		}
        }
        
        if(message.key == 2000){
        	EntityLivingBase en = (EntityLivingBase) player.field_70170_p.func_73045_a(message.fre);
        	if (en != null && en instanceof EntityGVCLivingBase) {// 1
        		EntityGVCLivingBase base = (EntityGVCLivingBase) en;
        		base.startuptime = message.da;
        	}
        }
        if(message.key == 2001){
        	EntityLivingBase en = (EntityLivingBase) player.field_70170_p.func_73045_a(message.fre);
        	if (en != null && en instanceof EntityGVCLivingBase) {// 1
        		EntityGVCLivingBase base = (EntityGVCLivingBase) en;
        		base.cooltime = message.da;
        	}
        }
        if(message.key == 2002){
        	EntityLivingBase en = (EntityLivingBase) player.field_70170_p.func_73045_a(message.fre);
        	if (en != null && en instanceof EntityGVCLivingBase) {// 1
        		EntityGVCLivingBase base = (EntityGVCLivingBase) en;
        		base.cooltime2 = message.da;
        	}
        }
        if(message.key == 2003){
        	EntityLivingBase en = (EntityLivingBase) player.field_70170_p.func_73045_a(message.fre);
        	if (en != null && en instanceof EntityGVCLivingBase) {// 1
        		EntityGVCLivingBase base = (EntityGVCLivingBase) en;
        		base.cooltime3 = message.da;
        	}
        }
        if(message.key == 2004){
        	EntityLivingBase en = (EntityLivingBase) player.field_70170_p.func_73045_a(message.fre);
        	if (en != null && en instanceof EntityGVCLivingBase) {// 1
        		EntityGVCLivingBase base = (EntityGVCLivingBase) en;
        		base.cooltime4 = message.da;
        	}
        }
        if(message.key == 2005){
        	EntityLivingBase en = (EntityLivingBase) player.field_70170_p.func_73045_a(message.fre);
        	if (en != null && en instanceof EntityGVCLivingBase) {// 1
        		EntityGVCLivingBase base = (EntityGVCLivingBase) en;
        		base.cooltime5 = message.da;
        	}
        }
        if(message.key == 2006){
        	EntityLivingBase en = (EntityLivingBase) player.field_70170_p.func_73045_a(message.fre);
        	if (en != null && en instanceof EntityGVCLivingBase) {// 1
        		EntityGVCLivingBase base = (EntityGVCLivingBase) en;
        		base.cooltime6 = message.da;
        	}
        }
        if(message.key == 2007){
        	EntityLivingBase en = (EntityLivingBase) player.field_70170_p.func_73045_a(message.fre);
        	if (en != null && en instanceof EntityGVCLivingBase) {// 1
        		EntityGVCLivingBase base = (EntityGVCLivingBase) en;
        		base.gun_count1 = message.da;
        	}
        }
        if(message.key == 2008){
        	EntityLivingBase en = (EntityLivingBase) player.field_70170_p.func_73045_a(message.fre);
        	if (en != null && en instanceof EntityGVCLivingBase) {// 1
        		EntityGVCLivingBase base = (EntityGVCLivingBase) en;
        		base.gun_count2 = message.da;
        	}
        }
        if(message.key == 2009){
        	EntityLivingBase en = (EntityLivingBase) player.field_70170_p.func_73045_a(message.fre);
        	if (en != null && en instanceof EntityGVCLivingBase) {// 1
        		EntityGVCLivingBase base = (EntityGVCLivingBase) en;
        		base.gun_count3 = message.da;
        	}
        }
        if(message.key == 2010){
        	EntityLivingBase en = (EntityLivingBase) player.field_70170_p.func_73045_a(message.fre);
        	if (en != null && en instanceof EntityGVCLivingBase) {// 1
        		EntityGVCLivingBase base = (EntityGVCLivingBase) en;
        		base.gun_count4 = message.da;
        	}
        }
        if(message.key == 2011){
        	EntityLivingBase en = (EntityLivingBase) player.field_70170_p.func_73045_a(message.fre);
        	if (en != null && en instanceof EntityGVCLivingBase) {// 1
        		EntityGVCLivingBase base = (EntityGVCLivingBase) en;
        		base.aitypetime = message.da;
        	}
        }
        if(message.key == 2012){
        	EntityLivingBase en = (EntityLivingBase) player.field_70170_p.func_73045_a(message.fre);
        	if (en != null && en instanceof EntityGVCLivingBase) {// 1
        		EntityGVCLivingBase base = (EntityGVCLivingBase) en;
        		base.aitypetime2 = message.da;
        	}
        }
        if(message.key == 2013){
        	EntityLivingBase en = (EntityLivingBase) player.field_70170_p.func_73045_a(message.fre);
        	if (en != null && en instanceof EntityGVCLivingBase) {// 1
        		EntityGVCLivingBase base = (EntityGVCLivingBase) en;
        		base.aitypetime3 = message.da;
        	}
        }
        
        if(message.key == 1500){
        	EntityLivingBase en = (EntityLivingBase) player.field_70170_p.func_73045_a(message.fre);
        	if (en != null && en instanceof EntityNPCBase) {// 1
        		EntityNPCBase base = (EntityNPCBase) en;
        		if(base.sell_now_id < base.sell_page - 1) {
        			++base.sell_now_id;
        		}
        		int page = 10 * base.sell_now_id;
        		for(int x = 0; x < 9; ++x) {
        			base.hand[0 + x + page] = false;
	        	}
        	}
        }
        if(message.key == 1501){
        	EntityLivingBase en = (EntityLivingBase) player.field_70170_p.func_73045_a(message.fre);
        	if (en != null && en instanceof EntityNPCBase) {// 1
        		EntityNPCBase base = (EntityNPCBase) en;
        		if(base.sell_now_id > 0) {
        			--base.sell_now_id;
        		}
        		int page = 10 * base.sell_now_id;
        		for(int x = 0; x < 9; ++x) {
        			base.hand[0 + x + page] = false;
	        	}
        	}
        }
        
        if(message.key == 1502){
        	EntityLivingBase en = (EntityLivingBase) player.field_70170_p.func_73045_a(message.fre);
        	if (en != null && en instanceof EntityNPCBase) {// 1
        		EntityNPCBase base = (EntityNPCBase) en;
        		if(base.buy_now_id < base.buy_page - 1) {
        			++base.buy_now_id;
        		}
        	}
        }
        if(message.key == 1503){
        	EntityLivingBase en = (EntityLivingBase) player.field_70170_p.func_73045_a(message.fre);
        	if (en != null && en instanceof EntityNPCBase) {// 1
        		EntityNPCBase base = (EntityNPCBase) en;
        		if(base.buy_now_id > 0) {
        			--base.buy_now_id;
        		}
        	}
        }
        if(message.key == 801){
        	EntityLivingBase en = (EntityLivingBase) player.field_70170_p.func_73045_a(message.fre);
        	if (en != null && en instanceof EntityLivingBase) {// 1
        		
        		for (int k = 0; k < 5; ++k) {
					double d2 = en.field_70170_p.field_73012_v.nextGaussian() * 0.02D;
					double d0 = en.field_70170_p.field_73012_v.nextGaussian() * 0.02D;
					double d1 = en.field_70170_p.field_73012_v.nextGaussian() * 0.02D;
					en.field_70170_p.func_175688_a(EnumParticleTypes.VILLAGER_HAPPY,
							en.field_70165_t + (double) (en.field_70170_p.field_73012_v.nextFloat() * en.field_70130_N * 2.0F) - (double) en.field_70130_N,
							en.field_70163_u + (double) (en.field_70170_p.field_73012_v.nextFloat() * en.field_70131_O),
							en.field_70161_v + (double) (en.field_70170_p.field_73012_v.nextFloat() * en.field_70130_N * 2.0F) - (double) en.field_70130_N,
							d2, d0, d1);
				}
        	}
        }
        
        if (message.key == 3063) {
        	EntityLivingBase en = (EntityLivingBase) player.field_70170_p.func_73045_a(message.fre);
        	if (en != null && en instanceof EntityMobVehicle_Inv_Base) {// 1
        		EntityMobVehicle_Inv_Base base = (EntityMobVehicle_Inv_Base) en;
				Item item = new Item().func_150899_d(message.da);
				if(item != null) {
					base.horseChest.func_70299_a(message.enid, new ItemStack(item, (int)message.kaku));
					//System.out.println(String.format("0"));
				}
        	}
		}
        
        if(message.key == 422){
        	EntityLivingBase en = (EntityLivingBase) player.field_70170_p.func_73045_a(message.fre);
        	if (en != null && en instanceof EntityLivingBase) {// 1
        		EntityLivingBase base = (EntityLivingBase) en;
        		base.field_70122_E = message.boolean_hantei;
        	}
        }
        
        if(message.key == 444){
        	EntityLivingBase en = (EntityLivingBase) player.field_70170_p.func_73045_a(message.fre);
        	if (en != null && en instanceof EntityGVCLivingBase) {// 1
        		EntityGVCLivingBase gvc_en = (EntityGVCLivingBase) en;
        		if(en.func_184179_bs() != null) {
        			en.func_184179_bs().func_70634_a(gvc_en.getMoveX(), gvc_en.getMoveY(), gvc_en.getMoveZ());
        			en.func_184179_bs().func_184210_p();
        			
        		}
        	}
        }
        
		return null;
    }
}
