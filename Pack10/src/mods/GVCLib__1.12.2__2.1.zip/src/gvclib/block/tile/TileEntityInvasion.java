package gvclib.block.tile;

import java.util.List;
import gvclib.gui.ContainerInventoryEntityGVC;
import gvclib.network.GVCLClientMessageKeyPressed;
import gvclib.network.GVCLPacketHandler;
import net.minecraft.block.Block;
import net.minecraft.entity.Entity;
import net.minecraft.entity.monster.IMob;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.init.Items;
import net.minecraft.init.SoundEvents;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.ISidedInventory;
import net.minecraft.inventory.ItemStackHelper;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntityLockable;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.ITickable;
import net.minecraft.util.NonNullList;
import net.minecraft.util.datafix.DataFixer;
import net.minecraft.util.datafix.FixTypes;
import net.minecraft.util.datafix.walkers.ItemStackDataLists;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.text.TextComponentTranslation;
import net.minecraft.world.World;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;


import gvclib.gui.ContainerInventoryEntityGVC;
import gvclib.network.GVCLClientMessageKeyPressed;
import gvclib.network.GVCLPacketHandler;
import net.minecraft.block.Block;
import net.minecraft.entity.Entity;
import net.minecraft.entity.monster.IMob;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.init.Items;
import net.minecraft.init.SoundEvents;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.ISidedInventory;
import net.minecraft.inventory.ItemStackHelper;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntityLockable;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.ITickable;
import net.minecraft.util.NonNullList;
import net.minecraft.util.datafix.DataFixer;
import net.minecraft.util.datafix.FixTypes;
import net.minecraft.util.datafix.walkers.ItemStackDataLists;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.text.TextComponentTranslation;
import net.minecraft.world.World;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public abstract class TileEntityInvasion extends TileEntityLockable implements ITickable, ISidedInventory
{
    private static final int[] SLOTS_TOP = new int[] {0};
    private static final int[] SLOTS_BOTTOM = new int[] {2, 1};
    private static final int[] SLOTS_SIDES = new int[] {1};
    /** The ItemStacks that hold the items currently being used in the furnace */
    public NonNullList<ItemStack> furnaceItemStacks = NonNullList.<ItemStack>func_191197_a(16, ItemStack.field_190927_a);
    /** The number of ticks that the furnace will keep burning */
    private int furnaceBurnTime;
    /** The number of ticks that a fresh copy of the currently-burning item would keep the furnace burning for */
    private int currentItemBurnTime;
    private int cookTime;
    private int totalCookTime;
    private String furnaceCustomName;
    
    public int ticks;
    public int level;
    public boolean canspawn = false;
    public boolean e_can = false;
    public boolean w_can = false;
    public boolean s_can = false;
    public boolean n_can = false;
    public int spwan_range = 64;
    
    public int spawntime = 1200;
    public boolean endress = false;
    
    public int uticks;
    public int hp = 0;
    
    public int mob_type = 0;
    public int mob_level = 0;

    public int func_70302_i_()
    {
        return this.furnaceItemStacks.size();
    }

    public boolean func_191420_l()
    {
        for (ItemStack itemstack : this.furnaceItemStacks)
        {
            if (!itemstack.func_190926_b())
            {
                return false;
            }
        }

        return true;
    }

    /**
     * Returns the stack in the given slot.
     */
    public ItemStack func_70301_a(int index)
    {
        return this.furnaceItemStacks.get(index);
    }

    /**
     * Removes up to a specified number of items from an inventory slot and returns them in a new stack.
     */
    public ItemStack func_70298_a(int index, int count)
    {
        return ItemStackHelper.func_188382_a(this.furnaceItemStacks, index, count);
    }

    /**
     * Removes a stack from the given slot and returns it.
     */
    public ItemStack func_70304_b(int index)
    {
        return ItemStackHelper.func_188383_a(this.furnaceItemStacks, index);
    }

    /**
     * Sets the given item stack to the specified slot in the inventory (can be crafting or armor sections).
     */
    public void func_70299_a(int index, ItemStack stack)
    {
        ItemStack itemstack = this.furnaceItemStacks.get(index);
        boolean flag = !stack.func_190926_b() && stack.func_77969_a(itemstack) && ItemStack.func_77970_a(stack, itemstack);
        this.furnaceItemStacks.set(index, stack);

        if (stack.func_190916_E() > this.func_70297_j_())
        {
            stack.func_190920_e(this.func_70297_j_());
        }

        if (index == 0 && !flag)
        {
            this.totalCookTime = this.getCookTime(stack);
            this.cookTime = 0;
            this.func_70296_d();
        }
    }

    /**
     * Get the name of this object. For players this returns their username
     */
    public String func_70005_c_()
    {
        //return this.hasCustomName() ? this.furnaceCustomName : "container.furnace";
    	return this.func_145818_k_() ? this.furnaceCustomName : "InvasionBlock";
    }

    /**
     * Returns true if this thing is named
     */
    public boolean func_145818_k_()
    {
        return this.furnaceCustomName != null && !this.furnaceCustomName.isEmpty();
    }

    public void setCustomInventoryName(String p_145951_1_)
    {
        this.furnaceCustomName = p_145951_1_;
    }

    public static void registerFixesFurnace(DataFixer fixer)
    {
        fixer.func_188258_a(FixTypes.BLOCK_ENTITY, new ItemStackDataLists(TileEntityInvasion.class, new String[] {"Items"}));
    }

    public void func_145839_a(NBTTagCompound compound)
    {
        super.func_145839_a(compound);
        this.furnaceItemStacks = NonNullList.<ItemStack>func_191197_a(this.func_70302_i_(), ItemStack.field_190927_a);
        ItemStackHelper.func_191283_b(compound, this.furnaceItemStacks);
        this.furnaceBurnTime = compound.func_74762_e("BurnTime");
        this.cookTime = compound.func_74762_e("CookTime");
        this.totalCookTime = compound.func_74762_e("CookTimeTotal");
       // this.currentItemBurnTime = getItemBurnTime(this.furnaceItemStacks.get(1));

        this.ticks = compound.func_74762_e("Ticks");
    	this.level = compound.func_74762_e("Level");
    	
    	this.e_can = compound.func_74767_n("E_spawn");
    	this.w_can = compound.func_74767_n("W_spawn");
    	this.s_can = compound.func_74767_n("S_spawn");
    	this.n_can = compound.func_74767_n("N_spawn");
    	this.spwan_range = compound.func_74762_e("Spawn_Range");
    	
    	this.uticks = compound.func_74762_e("UniversalTicks");
    	this.hp = compound.func_74762_e("HP");
        
        if (compound.func_150297_b("CustomName", 8))
        {
            this.furnaceCustomName = compound.func_74779_i("CustomName");
        }
    }

    public NBTTagCompound func_189515_b(NBTTagCompound compound)
    {
        super.func_189515_b(compound);
        //compound.setInteger("BurnTime", (short)this.furnaceBurnTime);
        compound.func_74768_a("CookTime", (short)this.cookTime);
        compound.func_74768_a("CookTimeTotal", (short)this.totalCookTime);
        ItemStackHelper.func_191282_a(compound, this.furnaceItemStacks);

        compound.func_74768_a("Ticks", ticks);
    	compound.func_74768_a("Level", level);
    	
    	compound.func_74757_a("E_spawn", e_can);
    	compound.func_74757_a("W_spawn", w_can);
    	compound.func_74757_a("S_spawn", s_can);
    	compound.func_74757_a("N_spawn", n_can);
            
    	compound.func_74768_a("Spawn_Range", spwan_range);
    	compound.func_74768_a("UniversalTicks", uticks);
    	compound.func_74768_a("HP", hp);
        
        if (this.func_145818_k_())
        {
            compound.func_74778_a("CustomName", this.furnaceCustomName);
        }

        return compound;
    }

    /**
     * Returns the maximum stack size for a inventory slot. Seems to always be 64, possibly will be extended.
     */
    public int func_70297_j_()
    {
        return 64;
    }

    /**
     * Furnace isBurning
     */
    public boolean isBurning()
    {
        return this.furnaceBurnTime > 0;
    }

    @SideOnly(Side.CLIENT)
    public static boolean isBurning(IInventory inventory)
    {
        return inventory.func_174887_a_(0) > 0;
    }
    
    @SideOnly(Side.CLIENT)
    public static int getClientTick(TileEntityInvasion inv)
    {
        return inv.getTicks();
    }
    @SideOnly(Side.CLIENT)
    public static int getClientLevel(TileEntityInvasion inv)
    {
        return inv.getLevel();
    }
    @SideOnly(Side.CLIENT)
    public static int getClientHP(TileEntityInvasion inv)
    {
        return inv.getHP();
    }
    @SideOnly(Side.CLIENT)
    public static int getClientRange(TileEntityInvasion inv)
    {
        return inv.spwan_range;
    }

    /**
     * Like the old updateEntity(), except more generic.
     */
    @Override
    public void func_73660_a()
    {
    	{
    		GVCLPacketHandler.INSTANCE2.sendToAll(new GVCLClientMessageKeyPressed(100, spwan_range,
    				this.func_174877_v().func_177958_n(), this.func_174877_v().func_177956_o(), this.func_174877_v().func_177952_p()));
    		GVCLPacketHandler.INSTANCE2.sendToAll(new GVCLClientMessageKeyPressed(101, getHP(),
    				this.func_174877_v().func_177958_n(), this.func_174877_v().func_177956_o(), this.func_174877_v().func_177952_p()));
    		GVCLPacketHandler.INSTANCE2.sendToAll(new GVCLClientMessageKeyPressed(102, getLevel(),
    				this.func_174877_v().func_177958_n(), this.func_174877_v().func_177956_o(), this.func_174877_v().func_177952_p()));
    		GVCLPacketHandler.INSTANCE2.sendToAll(new GVCLClientMessageKeyPressed(103, getTicks(),
    				this.func_174877_v().func_177958_n(), this.func_174877_v().func_177956_o(), this.func_174877_v().func_177952_p()));
    		ItemStack e = (ItemStack)this.furnaceItemStacks.get(0);
        	ItemStack w = (ItemStack)this.furnaceItemStacks.get(1);
        	ItemStack n = (ItemStack)this.furnaceItemStacks.get(2);
        	ItemStack s = (ItemStack)this.furnaceItemStacks.get(3);
        	ItemStack can = (ItemStack)this.furnaceItemStacks.get(4);
        	if(((!e.func_190926_b() && getMobLevel(e.func_77973_b()))
        			|| (!w.func_190926_b() && getMobLevel(w.func_77973_b()))
        			|| (!n.func_190926_b() && getMobLevel(n.func_77973_b()))
        			|| (!s.func_190926_b() && getMobLevel(s.func_77973_b())))
        			&& !can.func_190926_b() && getCan(can.func_77973_b())) {
        		this.canspawn = true;
        	}else {
        		this.canspawn = false;
        	}
        	if(!e.func_190926_b() && getMobLevel(e.func_77973_b())) {
        		e_can = true;
        	}else {
        		e_can = false;
        	}
        	if(!w.func_190926_b() && getMobLevel(w.func_77973_b())) {
        		w_can = true;
        	}else {
        		w_can = false;
        	}
        	if(!n.func_190926_b() && getMobLevel(n.func_77973_b())) {
        		n_can = true;
        	}else {
        		n_can = false;
        	}
        	if(!s.func_190926_b() && getMobLevel(s.func_77973_b())) {
        		s_can = true;
        	}else {
        		s_can = false;
        	}
        	//mob_type = getType(this.furnaceItemStacks.get(4).getItem());
    	}
    	if (this.canspawn) {
			Block block = this.field_145850_b.func_180495_p(this.field_174879_c).func_177230_c();
			Entity entity = null;
			int x = this.field_174879_c.func_177958_n();
			int y = this.field_174879_c.func_177956_o();
			int z = this.field_174879_c.func_177952_p();

			if (this.getLevel() > 10  && !this.endress) {
				this.PlayerMessage(3);
				this.getBonus(field_145850_b, x, y, z, 0);
			}

			if (this.getUTicks() >= 10) {
				this.setUTicks(0);
				int k = this.field_174879_c.func_177958_n();
				int l = this.field_174879_c.func_177956_o();
				int i = this.field_174879_c.func_177952_p();
				boolean dame = false;
				int han = 2;
				{
					AxisAlignedBB axisalignedbb = (new AxisAlignedBB((double) (k - han), (double) (l - han),
							(double) (i - han), (double) (k + han), (double) (l + han), (double) (i + han)))
									.func_186662_g(1);
					List llist = this.field_145850_b.func_72839_b(entity, axisalignedbb);
					double d0 = 8.0D;
					if (llist != null) {
						for (int lj = 0; lj < llist.size(); lj++) {
							Entity entity1 = (Entity) llist.get(lj);
							if (entity1.func_70067_L()) {
								if (entity1 instanceof IMob && entity1 != null && !this.field_145850_b.field_72995_K) {
									dame = true;
									break;
								}
							}
						}
					}
				}
				if (dame) {
					this.setHP(this.getHP() + 1);
					this.PlayerMessage(1);
				}
			} else {
				this.setUTicks(this.getUTicks() + 1);
			}

			if (this.getTicks() >= spawntime && (this.getLevel() <= 10 || this.endress)) {
				this.setTicks(0);
				this.setLevel(getLevel() + 1);
				this.setHP(this.getHP() - 10);
				if (this.getHP() < 0) {
					this.setHP(0);
				}
				if(this.getLevel() <= 10 || this.endress) {
					if (this.e_can) {
						this.EntitySpwan(field_145850_b, this.spwan_range, 0, 0, this.getLevel());
					}
					if (this.w_can) {
						this.EntitySpwan(field_145850_b, -this.spwan_range, 0, 0, this.getLevel());
					}
					if (this.s_can) {
						this.EntitySpwan(field_145850_b, 0, 0, this.spwan_range, this.getLevel());
					}
					if (this.n_can) {
						this.EntitySpwan(field_145850_b, 0, 0, -this.spwan_range, this.getLevel());
					}
					this.PlayerMessage(0);
				}
			} else {
				if(this.getLevel() < 1 && this.getTicks() < 1) {
					this.PlayerMessage(-1);
				}
				this.setTicks(this.getTicks() + 1);
			}
			if((this.spawntime - this.getTicks()) == 60){
				this.PlayerMessage(4);
			}
			if((this.spawntime - this.getTicks()) == 40){
				this.PlayerMessage(5);
			}
			if((this.spawntime - this.getTicks()) == 20){
				this.PlayerMessage(6);
			}

			if (this.getHP() >= 100) {
				if (!this.field_145850_b.field_72995_K) {
					this.field_145850_b.func_175698_g(field_174879_c);
				}
				this.PlayerMessage(2);
			}

		}
    }
    public abstract boolean getCan(Item item);
    //public abstract int getType(Item item);
    public abstract boolean getMobLevel(Item item);
    public abstract void EntitySpwan(World world,int xx, int yy, int zz, int id);
    
    public abstract void getBonus(World world,int xx, int yy, int zz, int id);
    
    
    public int getTicks() {
		return ticks;
	}
	public void setTicks(int i) {
		this.ticks = i;
	}
	public int getUTicks() {
		return uticks;
	}
	public void setUTicks(int i) {
		this.uticks = i;
	}
	
	public int getLevel() {
		return level;
	}
	public void setLevel(int i) {
		this.level = i;
	}
	public int getHP() {
		return hp;
	}
	public void setHP(int i) {
		this.hp = i;
	}
    
	 public void PlayerMessage(int id){
	    	Entity entity = null;
	    	int k = this.field_174879_c.func_177958_n();
	        int l = this.field_174879_c.func_177956_o();
	        int i = this.field_174879_c.func_177952_p();
	        AxisAlignedBB axisalignedbb = (new AxisAlignedBB((double)(k-100), (double)(l-20), (double)(i-100), (double)(k + 100), (double)(l + 20), (double)(i + 100)))
	        		.func_186662_g(200);
	        List llist = this.field_145850_b.func_72839_b(entity, axisalignedbb);
	        double d0 = 8.0D;
	        if(llist!=null){
	            for (int lj = 0; lj < llist.size(); lj++) {
	            	
	            	Entity entity1 = (Entity)llist.get(lj);
	            	if (entity1.func_70067_L())
	                {
	            		if (entity1 instanceof EntityPlayer && entity1 != null && !this.field_145850_b.field_72995_K)
	                    {
	            			EntityPlayer placer = (EntityPlayer) entity1;
	            			if(id == -1){
	            				placer.func_184185_a(SoundEvents.field_187689_f, 1.0F, 1.0F);
	                			((EntityPlayer)placer).func_145747_a(new TextComponentTranslation("Wave : Ready", new Object[0]));
	            			}
	            			if(id == 0){
	            				placer.func_184185_a(SoundEvents.field_187689_f, 1.0F, 1.0F);
	            				String le = String.valueOf(this.getLevel());
	                			((EntityPlayer)placer).func_145747_a(new TextComponentTranslation("Wave : " + le, new Object[0]));
	                			if(!this.e_can){
	                        		//((EntityPlayer)placer).addChatMessage(new TextComponentTranslation("East false", new Object[0]));
	                        	}
	                			String le1 = String.valueOf(100 - this.getHP());
	                			((EntityPlayer)placer).func_145747_a(new TextComponentTranslation("Base HP : " + le1, new Object[0]));
	            			}
	            			if(id == 1){
	            				String le = String.valueOf(100 - this.getHP());
	                			((EntityPlayer)placer).func_145747_a(new TextComponentTranslation("Base HP : " + le, new Object[0]));
	            			}
	            			if(id == 2){
	                			((EntityPlayer)placer).func_145747_a(new TextComponentTranslation("Base was broken!", new Object[0]));
	            			}
	            			if(id == 3){
	                			((EntityPlayer)placer).func_145747_a(new TextComponentTranslation("Mission Clear!", new Object[0]));
	            			}
	            			if(id == 4){
	                			((EntityPlayer)placer).func_145747_a(new TextComponentTranslation("Next : 3", new Object[0]));
	            			}
	            			if(id == 5){
	                			((EntityPlayer)placer).func_145747_a(new TextComponentTranslation("Next : 2", new Object[0]));
	            			}
	            			if(id == 6){
	                			((EntityPlayer)placer).func_145747_a(new TextComponentTranslation("Next : 1", new Object[0]));
	            			}
	                    }
	            		
	                }
	            }
	        }
	    }
	
	
    public int getCookTime(ItemStack stack)
    {
        return 200;
    }

    

    /**
     * Don't rename this method to canInteractWith due to conflicts with Container
     */
    public boolean func_70300_a(EntityPlayer player)
    {
        if (this.field_145850_b.func_175625_s(this.field_174879_c) != this)
        {
            return false;
        }
        else
        {
            return player.func_70092_e((double)this.field_174879_c.func_177958_n() + 0.5D, (double)this.field_174879_c.func_177956_o() + 0.5D, (double)this.field_174879_c.func_177952_p() + 0.5D) <= 64.0D;
        }
    }

    public void func_174889_b(EntityPlayer player)
    {
    }

    public void func_174886_c(EntityPlayer player)
    {
    }

    /**
     * Returns true if automation is allowed to insert the given stack (ignoring stack size) into the given slot. For
     * guis use Slot.isItemValid
     */
    public boolean func_94041_b(int index, ItemStack stack)
    {
        if (index == 2)
        {
            return false;
        }
        else if (index != 1)
        {
            return true;
        }
        else
        {
            ItemStack itemstack = this.furnaceItemStacks.get(1);
            //return isItemFuel(stack) || SlotFurnaceFuel.isBucket(stack) && itemstack.getItem() != Items.BUCKET;
            return false;
        }
    }

    public int[] func_180463_a(EnumFacing side)
    {
        if (side == EnumFacing.DOWN)
        {
            return SLOTS_BOTTOM;
        }
        else
        {
            return side == EnumFacing.UP ? SLOTS_TOP : SLOTS_SIDES;
        }
    }

    /**
     * Returns true if automation can insert the given item in the given slot from the given side.
     */
    public boolean func_180462_a(int index, ItemStack itemStackIn, EnumFacing direction)
    {
        return this.func_94041_b(index, itemStackIn);
    }

    /**
     * Returns true if automation can extract the given item in the given slot from the given side.
     */
    public boolean func_180461_b(int index, ItemStack stack, EnumFacing direction)
    {
        if (direction == EnumFacing.DOWN && index == 1)
        {
            Item item = stack.func_77973_b();

            if (item != Items.field_151131_as && item != Items.field_151133_ar)
            {
                return false;
            }
        }

        return true;
    }

    public String func_174875_k()
    {
        return "minecraft:furnace";
    }

    public Container func_174876_a(InventoryPlayer playerInventory, EntityPlayer playerIn)
    {
        return new ContainerInventoryEntityGVC(playerInventory, this);
    }

    public int func_174887_a_(int id)
    {
        switch (id)
        {
            case 0:
                return this.furnaceBurnTime;
            case 1:
                return this.currentItemBurnTime;
            case 2:
                return this.cookTime;
            case 3:
                return this.totalCookTime;
            default:
                return 0;
        }
    }

    public void func_174885_b(int id, int value)
    {
        switch (id)
        {
            case 0:
                this.furnaceBurnTime = value;
                break;
            case 1:
                this.currentItemBurnTime = value;
                break;
            case 2:
                this.cookTime = value;
                break;
            case 3:
                this.totalCookTime = value;
        }
    }

    public int func_174890_g()
    {
        return 4;
    }

    public void func_174888_l()
    {
        this.furnaceItemStacks.clear();
    }
}
