package gvclib.block.tile;
 
import net.minecraft.block.Block;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.ITickable;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
 
public class TileEntityB_Fire extends TileEntity implements ITickable
{
	public boolean spawn = false;
	
	public int count = 0;
	
	public int id = 0;
    
	@SideOnly(Side.CLIENT)
    public double func_145833_n()
    {
        return 65536.0D;
    }
	
    @Override
	public void func_73660_a() {
    	Block block = this.field_145850_b.func_180495_p(this.field_174879_c).func_177230_c();
        
        int x = this.field_174879_c.func_177958_n();
        int y= this.field_174879_c.func_177956_o();
        int z = this.field_174879_c.func_177952_p();
        ++count;
       if(count > 200 + this.field_145850_b.field_73012_v.nextInt(60)) {
    	   if(!this.field_145850_b.field_72995_K){
           	this.field_145850_b.func_175698_g(this.field_174879_c);
           }
       }
	}
	
}
