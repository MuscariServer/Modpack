package gvclib.block;

import java.util.Random;
import gvclib.block.tile.TileEntityB_Fire;
import javax.annotation.Nullable;
import net.minecraft.block.BlockContainer;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.init.SoundEvents;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.util.EnumBlockRenderType;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;


import javax.annotation.Nullable;

import gvclib.block.tile.TileEntityB_Fire;
import net.minecraft.block.BlockContainer;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.init.SoundEvents;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.util.EnumBlockRenderType;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public class BlockB_Fire extends BlockContainer
{
	
	protected static final AxisAlignedBB CACTUS_AABB = new AxisAlignedBB(0.0D, 0.0D, 0.0D, 1.0D, 0.3D, 1.0D);
	
    public BlockB_Fire()
    {
    	super(Material.field_151581_o);
        func_149722_s();
        func_149713_g(1);
        func_149715_a(1.0F);
    }
    @Override
    public void func_180663_b(World worldIn, BlockPos pos, IBlockState state){
    	worldIn.func_184134_a((double)((float)pos.func_177958_n() + 0.5F), (double)((float)pos.func_177956_o() + 0.5F), (double)((float)pos.func_177952_p() + 0.5F), 
        		SoundEvents.field_187646_bt, SoundCategory.BLOCKS, 1.0F, 1F, false);
    }
    @Override
	public TileEntity func_149915_a(World worldIn, int meta) {
		return new TileEntityB_Fire();
	}
    
    /**
     * Called When an Entity Collided with the Block
     */
    public void func_180634_a(World worldIn, BlockPos pos, IBlockState state, Entity entityIn)
    {
    	double x = pos.func_177958_n();
    	double y = pos.func_177956_o();
    	double z = pos.func_177952_p();
    	//if (!worldIn.isRemote) 
    	if(entityIn instanceof EntityLivingBase){
    		EntityLivingBase en = (EntityLivingBase) entityIn;
    		//en.addPotionEffect(new PotionEffect(MobEffects., 10, 10));
    		en.func_70015_d(15);
		}
    }
    
    @SideOnly(Side.CLIENT)
    public void func_180655_c(IBlockState stateIn, World worldIn, BlockPos pos, Random rand)
    {
        if (rand.nextInt(24) == 0)
        {
            worldIn.func_184134_a((double)((float)pos.func_177958_n() + 0.5F), (double)((float)pos.func_177956_o() + 0.5F), (double)((float)pos.func_177952_p() + 0.5F), 
            		SoundEvents.field_187643_bs, SoundCategory.BLOCKS, 1.0F + rand.nextFloat(), rand.nextFloat() * 0.7F + 0.3F, false);
        }

        for (int i = 0; i < 3; ++i)
        {
            double d0 = (double)pos.func_177958_n() + rand.nextDouble();
            double d1 = (double)pos.func_177956_o() + rand.nextDouble() * 0.5D + 0.5D;
            double d2 = (double)pos.func_177952_p() + rand.nextDouble();
            worldIn.func_175688_a(EnumParticleTypes.SMOKE_LARGE, d0, d1, d2, 0.0D, 0.0D, 0.0D);
        }
    }
    
    @Nullable
    public AxisAlignedBB func_180646_a(IBlockState blockState, IBlockAccess worldIn, BlockPos pos)
    {
        return field_185506_k;
    }
    /**
     * Return an AABB (in world coords!) that should be highlighted when the player is targeting this Block
     */
    @SideOnly(Side.CLIENT)
    public AxisAlignedBB func_180640_a(IBlockState state, World worldIn, BlockPos pos)
    {
        return CACTUS_AABB.func_186670_a(pos);
    }
    public boolean func_149686_d(IBlockState state)
    {
        return false;
    }
    /**
     * Returns the quantity of items to drop on block destruction.
     */
    public int func_149745_a(Random random)
    {
        return 0;
    }

    @SideOnly(Side.CLIENT)
    public BlockRenderLayer func_180664_k()
    {
        return BlockRenderLayer.CUTOUT;
    }

    protected boolean func_149700_E()
    {
        return true;
    }
    /**
     * Used to determine ambient occlusion and culling when rebuilding chunks for render
     */
    public boolean func_149662_c(IBlockState state)
    {
        return false;
    }
    /**
     * The type of render function called. 3 for standard block models, 2 for TESR's, 1 for liquids, -1 is no render
     */
    public EnumBlockRenderType func_149645_b(IBlockState state)
    {
        return EnumBlockRenderType.MODEL;
    }
}
