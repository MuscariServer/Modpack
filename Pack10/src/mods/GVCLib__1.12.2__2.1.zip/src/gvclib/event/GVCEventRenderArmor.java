package gvclib.event;

import gvclib.item.ItemArmor_NewObj;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ModelBiped;
import net.minecraft.client.renderer.entity.RenderBiped;
import net.minecraft.client.renderer.entity.RenderLivingBase;
import net.minecraft.client.renderer.entity.RenderPlayer;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.ItemBow;
import net.minecraft.item.ItemStack;
import net.minecraftforge.client.event.RenderLivingEvent;
import net.minecraftforge.client.event.RenderPlayerEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public class GVCEventRenderArmor
{
  public GVCEventRenderArmor() {}
  
  @SideOnly(Side.CLIENT)
  @SubscribeEvent
	  public void renderLivingPost(RenderPlayerEvent.Post event)
	  {
		ItemStack itemstack = event.getEntityPlayer().func_184614_ca();
		RenderPlayer renderplayer = event.getRenderer();
		if(itemstack != null && itemstack.func_77973_b() instanceof ItemBow){
			{
		//	renderplayer.modelArmor.aimedBow = renderplayer.modelArmorChestplate.aimedBow = renderplayer.getMainModel().aimedBow = true;
			}
		}
		if(!itemstack.func_190926_b() && itemstack.func_77973_b() instanceof ItemBow){
			renderplayer.func_177087_b().field_187076_m = ModelBiped.ArmPose.BOW_AND_ARROW;
			renderplayer.func_177087_b().field_187075_l = ModelBiped.ArmPose.BOW_AND_ARROW;
		}
	  }
  
  @SideOnly(Side.CLIENT)
  @SubscribeEvent
	  public void renderLiving(RenderPlayerEvent.Pre event)
	  {
		ItemStack itemstack = event.getEntityPlayer().func_184614_ca();
		RenderPlayer renderplayer = event.getRenderer();
		if(itemstack != null && itemstack.func_77973_b() instanceof ItemBow){
			{
		//	renderplayer.modelArmor.aimedBow = renderplayer.modelArmorChestplate.aimedBow = renderplayer.getMainModel().aimedBow = true;
			}
		}
		if(!itemstack.func_190926_b() && itemstack.func_77973_b() instanceof ItemBow){
			renderplayer.func_177087_b().field_187076_m = ModelBiped.ArmPose.BOW_AND_ARROW;
			renderplayer.func_177087_b().field_187075_l = ModelBiped.ArmPose.BOW_AND_ARROW;
		}
		
		renderplayer.func_177087_b().field_78116_c.field_78807_k = false;
		renderplayer.func_177087_b().field_178720_f.field_78807_k = false;
		renderplayer.func_177087_b().field_78115_e.field_78807_k = false;
		renderplayer.func_177087_b().field_178723_h.field_78807_k = false;
		renderplayer.func_177087_b().field_178724_i.field_78807_k = false;
		renderplayer.func_177087_b().field_178721_j.field_78807_k = false;
		renderplayer.func_177087_b().field_178722_k.field_78807_k = false;
		renderplayer.func_177087_b().field_178723_h.field_82908_p = 0;
		
		if ((event.getEntityPlayer().func_184582_a(EntityEquipmentSlot.HEAD) != null)
				&& (event.getEntityPlayer().func_184582_a(EntityEquipmentSlot.HEAD).func_77973_b() instanceof ItemArmor_NewObj)) {
			ItemArmor_NewObj armor = (ItemArmor_NewObj) event.getEntityPlayer().func_184582_a(EntityEquipmentSlot.HEAD).func_77973_b();
			if(!armor.render_head){
				renderplayer.func_177087_b().field_78116_c.field_78807_k = true;
				renderplayer.func_177087_b().field_178720_f.field_78807_k = true;
			}
			if(!armor.render_body){
				renderplayer.func_177087_b().field_78115_e.field_78807_k = true;
			}
			if(!armor.render_rarm){
				//renderplayer.getMainModel().bipedRightArm.isHidden = true;
				renderplayer.func_177087_b().field_178723_h.field_82908_p = -1000;
			}
			if(!armor.render_larm){
				renderplayer.func_177087_b().field_178724_i.field_78807_k = true;
			}
			if(!armor.render_rleg){
				renderplayer.func_177087_b().field_178721_j.field_78807_k = true;
			}
			if(!armor.render_lleg){
				renderplayer.func_177087_b().field_178722_k.field_78807_k = true;
			}
		}
		if ((event.getEntityPlayer().func_184582_a(EntityEquipmentSlot.CHEST) != null)
				&& (event.getEntityPlayer().func_184582_a(EntityEquipmentSlot.CHEST).func_77973_b() instanceof ItemArmor_NewObj)) {
			ItemArmor_NewObj armor = (ItemArmor_NewObj) event.getEntityPlayer().func_184582_a(EntityEquipmentSlot.CHEST).func_77973_b();
			if(!armor.render_head){
				renderplayer.func_177087_b().field_78116_c.field_78807_k = true;
				renderplayer.func_177087_b().field_178720_f.field_78807_k = true;
			}
			if(!armor.render_body){
				renderplayer.func_177087_b().field_78115_e.field_78807_k = true;
			}
			if(!armor.render_rarm){
				//renderplayer.getMainModel().bipedRightArm.showModel = false;
				renderplayer.func_177087_b().field_178723_h.field_82908_p = -1000;
			}
			if(!armor.render_larm){
				renderplayer.func_177087_b().field_178724_i.field_78807_k = true;
			}
			if(!armor.render_rleg){
				renderplayer.func_177087_b().field_178721_j.field_78807_k = true;
			}
			if(!armor.render_lleg){
				renderplayer.func_177087_b().field_178722_k.field_78807_k = true;
			}
		}
		if ((event.getEntityPlayer().func_184582_a(EntityEquipmentSlot.LEGS) != null)
				&& (event.getEntityPlayer().func_184582_a(EntityEquipmentSlot.LEGS).func_77973_b() instanceof ItemArmor_NewObj)) {
			ItemArmor_NewObj armor = (ItemArmor_NewObj) event.getEntityPlayer().func_184582_a(EntityEquipmentSlot.LEGS).func_77973_b();
			if(!armor.render_head){
				renderplayer.func_177087_b().field_78116_c.field_78807_k = true;
				renderplayer.func_177087_b().field_178720_f.field_78807_k = true;
			}
			if(!armor.render_body){
				renderplayer.func_177087_b().field_78115_e.field_78807_k = true;
			}
			if(!armor.render_rarm){
				//renderplayer.getMainModel().bipedRightArm.isHidden = true;
				renderplayer.func_177087_b().field_178723_h.field_82908_p = -1000;
			}
			if(!armor.render_larm){
				renderplayer.func_177087_b().field_178724_i.field_78807_k = true;
			}
			if(!armor.render_rleg){
				renderplayer.func_177087_b().field_178721_j.field_78807_k = true;
			}
			if(!armor.render_lleg){
				renderplayer.func_177087_b().field_178722_k.field_78807_k = true;
			}
		}
		if ((event.getEntityPlayer().func_184582_a(EntityEquipmentSlot.FEET) != null)
				&& (event.getEntityPlayer().func_184582_a(EntityEquipmentSlot.FEET).func_77973_b() instanceof ItemArmor_NewObj)) {
			ItemArmor_NewObj armor = (ItemArmor_NewObj) event.getEntityPlayer().func_184582_a(EntityEquipmentSlot.FEET).func_77973_b();
			if(!armor.render_head){
				renderplayer.func_177087_b().field_78116_c.field_78807_k = true;
				renderplayer.func_177087_b().field_178720_f.field_78807_k = true;
			}
			if(!armor.render_body){
				renderplayer.func_177087_b().field_78115_e.field_78807_k = true;
			}
			if(!armor.render_rarm){
				//renderplayer.getMainModel().bipedRightArm.isHidden = true;
				renderplayer.func_177087_b().field_178723_h.field_82908_p = -1000;
			}
			if(!armor.render_larm){
				renderplayer.func_177087_b().field_178724_i.field_78807_k = true;
			}
			if(!armor.render_rleg){
				renderplayer.func_177087_b().field_178721_j.field_78807_k = true;
			}
			if(!armor.render_lleg){
				renderplayer.func_177087_b().field_178722_k.field_78807_k = true;
			}
		}
		
		
		
	  }
  @SideOnly(Side.CLIENT)
  @SubscribeEvent
	  public void renderLivingMob(RenderLivingEvent.Pre event)
	  {
	    EntityLivingBase entity = event.getEntity();
		ItemStack itemstack = event.getEntity().func_184614_ca();
		RenderLivingBase render = event.getRenderer();
		if(render instanceof RenderBiped){
			RenderBiped renderplayer = (RenderBiped) render;
			ModelBiped model = (ModelBiped) renderplayer.func_177087_b();
			{
				model.field_78116_c.field_78807_k = false;
				model.field_178720_f.field_78807_k = false;
				model.field_78115_e.field_78807_k = false;
				model.field_178723_h.field_78807_k = false;
				model.field_178724_i.field_78807_k = false;
				model.field_178721_j.field_78807_k = false;
				model.field_178722_k.field_78807_k = false;
				{
					model.field_178723_h.field_82908_p = 0;
				}
				
				if ((event.getEntity().func_184582_a(EntityEquipmentSlot.HEAD) != null)
						&& (event.getEntity().func_184582_a(EntityEquipmentSlot.HEAD).func_77973_b() instanceof ItemArmor_NewObj)) {
					ItemArmor_NewObj armor = (ItemArmor_NewObj) event.getEntity().func_184582_a(EntityEquipmentSlot.HEAD).func_77973_b();
					if(!armor.render_head){
						model.field_78116_c.field_78807_k = true;
						model.field_178720_f.field_78807_k = true;
					}
					if(!armor.render_body){
						model.field_78115_e.field_78807_k = true;
					}
					if(!armor.render_rarm){
						//model.bipedRightArm.isHidden = true;
						if(Minecraft.func_71410_x().field_71474_y.field_74320_O != 0){
							model.field_178723_h.field_82908_p = -1000;
						}else{
							model.field_178723_h.field_82908_p = 0;
						}
					}
					if(!armor.render_larm){
						model.field_178724_i.field_78807_k = true;
					}
					if(!armor.render_rleg){
						model.field_178721_j.field_78807_k = true;
					}
					if(!armor.render_lleg){
						model.field_178722_k.field_78807_k = true;
					}
				}
				if ((event.getEntity().func_184582_a(EntityEquipmentSlot.CHEST) != null)
						&& (event.getEntity().func_184582_a(EntityEquipmentSlot.CHEST).func_77973_b() instanceof ItemArmor_NewObj)) {
					ItemArmor_NewObj armor = (ItemArmor_NewObj) event.getEntity().func_184582_a(EntityEquipmentSlot.CHEST).func_77973_b();
					if(!armor.render_head){
						model.field_78116_c.field_78807_k = true;
						model.field_178720_f.field_78807_k = true;
					}
					if(!armor.render_body){
						model.field_78115_e.field_78807_k = true;
					}
					if(!armor.render_rarm){
						//model.bipedRightArm.showModel = false;
						if(Minecraft.func_71410_x().field_71474_y.field_74320_O != 0){
							model.field_178723_h.field_82908_p = -1000;
						}else{
							model.field_178723_h.field_82908_p = 0;
						}
					}
					if(!armor.render_larm){
						model.field_178724_i.field_78807_k = true;
					}
					if(!armor.render_rleg){
						model.field_178721_j.field_78807_k = true;
					}
					if(!armor.render_lleg){
						model.field_178722_k.field_78807_k = true;
					}
				}
				if ((event.getEntity().func_184582_a(EntityEquipmentSlot.LEGS) != null)
						&& (event.getEntity().func_184582_a(EntityEquipmentSlot.LEGS).func_77973_b() instanceof ItemArmor_NewObj)) {
					ItemArmor_NewObj armor = (ItemArmor_NewObj) event.getEntity().func_184582_a(EntityEquipmentSlot.LEGS).func_77973_b();
					if(!armor.render_head){
						model.field_78116_c.field_78807_k = true;
						model.field_178720_f.field_78807_k = true;
					}
					if(!armor.render_body){
						model.field_78115_e.field_78807_k = true;
					}
					if(!armor.render_rarm){
						//model.bipedRightArm.isHidden = true;
						if(Minecraft.func_71410_x().field_71474_y.field_74320_O != 0){
							model.field_178723_h.field_82908_p = -1000;
						}else{
							model.field_178723_h.field_82908_p = 0;
						}
					}
					if(!armor.render_larm){
						model.field_178724_i.field_78807_k = true;
					}
					if(!armor.render_rleg){
						model.field_178721_j.field_78807_k = true;
					}
					if(!armor.render_lleg){
						model.field_178722_k.field_78807_k = true;
					}
				}
				if ((event.getEntity().func_184582_a(EntityEquipmentSlot.FEET) != null)
						&& (event.getEntity().func_184582_a(EntityEquipmentSlot.FEET).func_77973_b() instanceof ItemArmor_NewObj)) {
					ItemArmor_NewObj armor = (ItemArmor_NewObj) event.getEntity().func_184582_a(EntityEquipmentSlot.FEET).func_77973_b();
					if(!armor.render_head){
						model.field_78116_c.field_78807_k = true;
						model.field_178720_f.field_78807_k = true;
					}
					if(!armor.render_body){
						model.field_78115_e.field_78807_k = true;
					}
					if(!armor.render_rarm){
						//model.bipedRightArm.isHidden = true;
						if(Minecraft.func_71410_x().field_71474_y.field_74320_O != 0){
							model.field_178723_h.field_82908_p = -1000;
						}else{
							model.field_178723_h.field_82908_p = 0;
						}
					}
					if(!armor.render_larm){
						model.field_178724_i.field_78807_k = true;
					}
					if(!armor.render_rleg){
						model.field_178721_j.field_78807_k = true;
					}
					if(!armor.render_lleg){
						model.field_178722_k.field_78807_k = true;
					}
				}
			}
		}
		
	  }
  
}
