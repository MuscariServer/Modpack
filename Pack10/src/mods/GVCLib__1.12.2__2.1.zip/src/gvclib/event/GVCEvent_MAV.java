package gvclib.event;

import gvclib.mod_GVCLib;
import gvclib.entity.living.EntityGVCLivingBase;
import gvclib.entity.living.EntityMAVBase;
import gvclib.entity.living.EntityMobVehicle_Inv_Base;
import gvclib.network.GVCLClientMessageKeyPressed;
import gvclib.network.GVCLMessageKeyPressed;
import gvclib.network.GVCLPacketHandler;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.DamageSource;
import net.minecraftforge.event.entity.EntityMountEvent;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.living.LivingEvent.LivingUpdateEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class GVCEvent_MAV {
	
	@SubscribeEvent
	public void onRiddingMountEvent(LivingUpdateEvent event) {
		Entity target = event.getEntityLiving();
		//Entity ride = event.getEntityBeingMounted();
		if (target != null && target instanceof EntityPlayer) 
		{
			EntityPlayer player = (EntityPlayer) target;
			if (player.func_184187_bx() instanceof EntityMAVBase && player.func_184187_bx() != null) {// 1
				EntityMAVBase vehicle = (EntityMAVBase) player.func_184187_bx();
				{
					boolean kz = mod_GVCLib.proxy.keyz();
					if (kz) {
						vehicle.serverz = true;
						GVCLPacketHandler.INSTANCE.sendToServer(new GVCLMessageKeyPressed(17, vehicle.func_145782_y()));
						GVCLPacketHandler.INSTANCE2.sendToAll(new GVCLClientMessageKeyPressed(17, vehicle.func_145782_y()));
					}
					if(vehicle.serverz) {
						player.func_70634_a(vehicle.getMoveX(), vehicle.getMoveY(), vehicle.getMoveZ());
						if (player.func_184218_aH())
				        {
							
							player.func_184210_p();
							if(!vehicle.field_70170_p.field_72995_K && vehicle.getThrower() != null) {
								vehicle.getThrower().func_70106_y();
							}
				        }
						player.func_70634_a(vehicle.getMoveX(), vehicle.getMoveY(), vehicle.getMoveZ());
						if(vehicle.return_basepoint) {
							vehicle.func_70634_a(vehicle.getMoveX(), vehicle.getMoveY(), vehicle.getMoveZ());
						}
						vehicle.serverz = false;
					}
				}
			}
		}
	}
	
	@SubscribeEvent
	public void onRiddingDisMountEvent(EntityMountEvent event) {
		Entity target = event.getEntityMounting();
		Entity ride = event.getEntityBeingMounted();
		if (target != null && target instanceof EntityPlayer) 
		{
			EntityPlayer player = (EntityPlayer) target;
			if(ride != null && ride instanceof EntityMAVBase) {
				EntityMAVBase vehicle = (EntityMAVBase)ride;
				{
					if(player.func_70093_af()) {
						event.setCanceled(true);
						/*player.setPositionAndUpdate(vehicle.getMoveX(), vehicle.getMoveY(), vehicle.getMoveZ());
						if(!vehicle.world.isRemote && vehicle.getThrower() != null) {
							vehicle.getThrower().setDead();
						}*/
					}
				}
			}
		}
	}
	
	/*@SubscribeEvent
	public void onRiddingDisMountEvent(EntityMountEvent event) {
		Entity target = event.getEntityMounting();
		Entity ride = event.getEntityBeingMounted();
		if (target != null && target instanceof EntityPlayer) 
		{
			EntityPlayer player = (EntityPlayer) target;
			if(ride != null && ride instanceof EntityMAV) {
				EntityMAV vehicle = (EntityMAV)ride;
				{
					boolean kz = mod_GVCLib.proxy.keyz();
					if (kz) {
						GVCLPacketHandler.INSTANCE.sendToServer(new GVCLMessageKeyPressed(17, vehicle.getEntityId()));
					}
					if(vehicle.serverz) {
						player.setPositionAndUpdate(vehicle.getMoveX(), vehicle.getMoveY(), vehicle.getMoveZ());
						if(!vehicle.world.isRemote && vehicle.getThrower() != null) {
							vehicle.getThrower().setDead();
						}
						vehicle.serverz = false;
					}
					///if(player.isSneaking()) {
						player.setPositionAndUpdate(vehicle.getMoveX(), vehicle.getMoveY(), vehicle.getMoveZ());
						if(!vehicle.world.isRemote && vehicle.getThrower() != null) {
							vehicle.getThrower().setDead();
						}
					}///
				}
			}
		}
	}*/
	
	
	@SubscribeEvent
	public void onHurtEvent(LivingHurtEvent event) {
		EntityLivingBase target = event.getEntityLiving();
		if (target instanceof EntityPlayer && target != null) 
		{
			if (target.func_184187_bx() != null && target.func_184187_bx() instanceof EntityMAVBase) {
				event.setAmount(0);
	    		//amount = 0.0F;
	            event.setCanceled(true);
			}
		}
	}
	
	@SubscribeEvent
	  public void onLivingFromDollEvent(LivingAttackEvent event)
	  {
		EntityLivingBase target = event.getEntityLiving();
		if (target instanceof EntityPlayer && target != null) 
		{
			if (target.func_184187_bx() != null && target.func_184187_bx() instanceof EntityMAVBase) {
	            event.setCanceled(true);
			}
		}
	  }
	
}
