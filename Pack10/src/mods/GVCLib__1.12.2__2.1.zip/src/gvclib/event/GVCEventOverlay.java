package gvclib.event;

import org.lwjgl.opengl.GL11;
import gvclib.item.ItemArmor_Base;
import gvclib.item.ItemArmor_NewObj;
import gvclib.mod_GVCLib;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiIngame;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.World;
import net.minecraftforge.client.event.FOVUpdateEvent;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.client.FMLClientHandler;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;


import gvclib.mod_GVCLib;
import gvclib.item.ItemArmor_Base;
import gvclib.item.ItemArmor_NewObj;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiIngame;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.World;
import net.minecraftforge.client.event.FOVUpdateEvent;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.client.FMLClientHandler;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public class GVCEventOverlay {

	public boolean zoomtype;
	
	@SideOnly(Side.CLIENT)
    @SubscribeEvent
	  public void renderfovGun(FOVUpdateEvent event)
	  {
		Minecraft minecraft = FMLClientHandler.instance().getClient();
		EntityPlayer entityplayer = event.getEntity();
		ItemStack itemstack = entityplayer.func_184614_ca();
		if (FMLCommonHandler.instance().getSide() == Side.CLIENT) {
			if ((entityplayer.func_184582_a(EntityEquipmentSlot.HEAD) != null)
					&& (entityplayer.func_184582_a(EntityEquipmentSlot.HEAD).func_77973_b() instanceof ItemArmor_NewObj)) {
				ItemArmor_NewObj armor = (ItemArmor_NewObj) entityplayer.func_184582_a(EntityEquipmentSlot.HEAD).func_77973_b();
				
			}
		}
	  }
	
	@SideOnly(Side.CLIENT)
	  @SubscribeEvent
	  public void onEvent(RenderGameOverlayEvent.Text event)
	  {
		  Minecraft minecraft = FMLClientHandler.instance().getClient();
		  World world = FMLClientHandler.instance().getWorldClient();
		  ScaledResolution scaledresolution = new ScaledResolution(minecraft);
	        int i = scaledresolution.func_78326_a();
	        int j = scaledresolution.func_78328_b();
			EntityPlayer entityplayer = minecraft.field_71439_g;
			ItemStack itemstack = ((EntityPlayer)(entityplayer)).func_184614_ca();
			FontRenderer fontrenderer = minecraft.field_71466_p;
	        minecraft.field_71460_t.func_78478_c();
	        //OpenGlHelper.
	        
	        boolean cx = true;
	        if(entityplayer != null && mod_GVCLib.cfg_debag) {
	        	RenderHUDEvent renderevent = new RenderHUDEvent(minecraft);
	        	renderevent.renderBenri(minecraft, entityplayer, i, j);
	        }
	        
	        
        if(FMLCommonHandler.instance().getSide() == Side.CLIENT) 
		{
        	if ((entityplayer.func_184582_a(EntityEquipmentSlot.HEAD) != null)
					&& (entityplayer.func_184582_a(EntityEquipmentSlot.HEAD).func_77973_b() instanceof ItemArmor_NewObj)) {
				ItemArmor_NewObj armor = (ItemArmor_NewObj) entityplayer.func_184582_a(EntityEquipmentSlot.HEAD).func_77973_b();
				if(armor.gazo &&armor. gazotex != null){
					if(minecraft.field_71474_y.field_74320_O != 0){
						if(armor.tps){
							//this.renderPumpkinBlur(minecraft,scaledresolution, "handmadearmors:textures/misc/" + armor.gazotex, armor.tou);
							this.renderPumpkinBlur(minecraft,scaledresolution, armor.gazotex, armor.tou);
						}
					}else{
						this.renderPumpkinBlur(minecraft,scaledresolution, armor.gazotex, armor.tou);
					}
				}
			}
        	if ((entityplayer.func_184582_a(EntityEquipmentSlot.HEAD) != null)
					&& (entityplayer.func_184582_a(EntityEquipmentSlot.HEAD).func_77973_b() instanceof ItemArmor_Base)) {
        		ItemArmor_Base armor = (ItemArmor_Base) entityplayer.func_184582_a(EntityEquipmentSlot.HEAD).func_77973_b();
				if(armor.gazo &&armor. gazotex != null){
					if(minecraft.field_71474_y.field_74320_O != 0){
						if(armor.tps){
							//this.renderPumpkinBlur(minecraft,scaledresolution, "handmadearmors:textures/misc/" + armor.gazotex, armor.tou);
							this.renderPumpkinBlur(minecraft,scaledresolution, armor.gazotex, armor.tou);
						}
					}else{
						this.renderPumpkinBlur(minecraft,scaledresolution, armor.gazotex, armor.tou);
					}
				}
			}
        	
        	GuiIngame g  = minecraft.field_71456_v;
        	GL11.glPushMatrix();
    		GL11.glEnable(GL11.GL_BLEND);
    		GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
    		NBTTagCompound nbts = entityplayer.getEntityData();
    		int nb = nbts.func_74762_e("hitentity");
    		if(nb >= 1)
    		{
    			minecraft.field_71460_t.func_78478_c();
    			minecraft.field_71446_o.func_110577_a(new ResourceLocation("gvclib:textures/items/hit.png"));
    			GL11.glTranslatef(0.5F,0F, 0F);
    			GL11.glScalef(0.0625f, 0.0625f, 1);
    			g.func_73729_b((scaledresolution.func_78326_a()/2-8)*16,
    					(scaledresolution.func_78328_b()/2-8)*16, 0,0, 256, 256);
    		nbts.func_74768_a("hitentity", nb-1);
    		}
    		GL11.glPopMatrix();
    		
    		
    		GL11.glPushMatrix();
    		GL11.glEnable(GL11.GL_BLEND);
    		GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
    		int nbd = nbts.func_74762_e("hitentitydead");
    		if(nbd >= 1)
    		{
    			minecraft.field_71460_t.func_78478_c();
    			minecraft.field_71446_o.func_110577_a(new ResourceLocation("gvclib:textures/items/hitdead.png"));
    			GL11.glTranslatef(0.5F,0F, 0F);
    			GL11.glScalef(0.0625f, 0.0625f, 1);
    			g.func_73729_b((scaledresolution.func_78326_a()/2-8)*16,
    					(scaledresolution.func_78328_b()/2-8)*16, 0,0, 256, 256);
    		nbts.func_74768_a("hitentitydead", nbd-1);
    		}
    		GL11.glPopMatrix();
    		
    		GL11.glPushMatrix();
    		GL11.glEnable(GL11.GL_BLEND);
    		GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
    		int nbdh = nbts.func_74762_e("hitentity_headshot");
    		if(nbdh >= 1)
    		{
    			fontrenderer.func_175063_a("HEADSHOT", scaledresolution.func_78326_a()/2 - 15,  scaledresolution.func_78328_b()/2+15, 0xFFFFFF);
    		nbts.func_74768_a("hitentity_headshot", nbdh-1);
    		}
    		GL11.glPopMatrix();
    		
    		
    		//lockon
    		/*{
    			GL11.glPushMatrix();
        		GL11.glEnable(GL11.GL_BLEND);
        		GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
            Entity entity = null;
            List llist = entityplayer.world.getEntitiesWithinAABBExcludingEntity(entityplayer, entityplayer.getEntityBoundingBox()
            		.expand(entityplayer.motionX, entityplayer.motionY, entityplayer.motionZ).grow(100.0D));
            if(llist!=null){
                for (int lj = 0; lj < llist.size(); lj++) {
                	
                	Entity entity1 = (Entity)llist.get(lj);
                	if (entity1.canBeCollidedWith() && (entity1 != entityplayer))
                    {
                		if (!(entity1 instanceof EntityPlayer) && (entity1 != entityplayer)
                				&& entity1 != null)
                        {
                			if (entity1 instanceof EntityLivingBase)
                            {
    								if(entity1 instanceof EntityLivingBase){
    		            				EntityLivingBase en = (EntityLivingBase) entity1;
    		            				if(en.isPotionActive(MobEffects.GLOWING)){
    								minecraft.renderEngine.bindTexture(new ResourceLocation("gvclib:textures/items/hit.png"));
    		            	    			//GL11.glTranslatef(0.5F,0F, 0F);
    		            	    			//GL11.glScalef(0.0625f, 0.0625f, 1);
    		            	    			g.drawTexturedModalRect((scaledresolution.getScaledWidth()/2-8),
    		            	    					(scaledresolution.getScaledHeight()/2-8), 0,0, 256, 256);
    								}
                                 }
                            }
                        }
                    }
                }
            }
        		
        		GL11.glPopMatrix();
    		}*/
        	
		}
        
	  }
	
	@SideOnly(Side.CLIENT)
	protected void renderPumpkinBlur(Minecraft minecraft, ScaledResolution scaledRes, String adss, float tou) {
		//GL11.glPushMatrix();// 12
		GL11.glEnable(GL11.GL_BLEND);
		GlStateManager.func_179097_i();
		GlStateManager.func_179132_a(false);
		GlStateManager.func_187428_a(GlStateManager.SourceFactor.SRC_ALPHA,
				GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE,
				GlStateManager.DestFactor.ZERO);
		//GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
		GL11.glColor4f(1.0F, 1.0F, 1.0F, tou);
		GlStateManager.func_179118_c();
		minecraft.func_110434_K().func_110577_a(new ResourceLocation(adss));
		Tessellator tessellator = Tessellator.func_178181_a();
		BufferBuilder bufferbuilder = tessellator.func_178180_c();
        bufferbuilder.func_181668_a(7, DefaultVertexFormats.field_181707_g);
        bufferbuilder.func_181662_b(0.0D, (double)scaledRes.func_78328_b(), -90.0D).func_187315_a(0.0D, 1.0D).func_181675_d();
        bufferbuilder.func_181662_b((double)scaledRes.func_78326_a(), (double)scaledRes.func_78328_b(), -90.0D).func_187315_a(1.0D, 1.0D).func_181675_d();
        bufferbuilder.func_181662_b((double)scaledRes.func_78326_a(), 0.0D, -90.0D).func_187315_a(1.0D, 0.0D).func_181675_d();
        bufferbuilder.func_181662_b(0.0D, 0.0D, -90.0D).func_187315_a(0.0D, 0.0D).func_181675_d();
		tessellator.func_78381_a();
		GlStateManager.func_179132_a(true);
		GlStateManager.func_179126_j();
		GlStateManager.func_179141_d();
		GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
		GL11.glDisable(GL11.GL_BLEND);
		//GL11.glPopMatrix();// 12
	}
	
	
	
	
	protected void thisrenderCrosshairs()
  {
      bind(Gui.field_110324_m);
      GL11.glEnable(GL11.GL_BLEND);
      OpenGlHelper.func_148821_a(GL11.GL_ONE_MINUS_DST_COLOR, GL11.GL_ONE_MINUS_SRC_COLOR, 1, 0);
      OpenGlHelper.func_148821_a(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA, 1, 0);
      GL11.glDisable(GL11.GL_BLEND);
  }
	private void bind(ResourceLocation res)
  {
		Minecraft.func_71410_x().func_110434_K().func_110577_a(res);
  }
	
}
