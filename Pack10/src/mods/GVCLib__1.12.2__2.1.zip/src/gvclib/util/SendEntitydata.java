package gvclib.util;

import java.io.Serializable;
import gvclib.entity.EntityBBase;


import gvclib.entity.EntityBBase;

public class SendEntitydata implements Serializable{
    public double motionX;
    public double motionY;
    public double motionZ;
    public boolean inGround;
    public double posX;
    public double posY;
    public double posZ;
    public SendEntitydata(EntityBBase entityin){
        motionX = entityin.field_70159_w;
        motionY = entityin.field_70181_x;
        motionZ = entityin.field_70179_y;
        inGround = entityin.inGround;
        posX = entityin.field_70165_t;
        posY = entityin.field_70163_u;
        posZ = entityin.field_70161_v;
    }
}
