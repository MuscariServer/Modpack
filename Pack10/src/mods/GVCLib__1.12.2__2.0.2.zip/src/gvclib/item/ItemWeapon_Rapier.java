package gvclib.item;

import com.google.common.collect.Multimap;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.EnumAction;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.DamageSource;


import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.EnumAction;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.DamageSource;

public class ItemWeapon_Rapier extends ItemWeaponBase// implements IReachItem
{
    private final float attackdamage;
    private final Item.ToolMaterial material;
    public float dame;
    public double attackspeed;
    public double reach;

    public ItemWeapon_Rapier(float dame, double as, Item.ToolMaterial material)
    {
    	super(material);
        this.material = material;
        this.func_77656_e(material.func_77997_a());
        this.attackdamage = dame;
        this.attackspeed = as;
        this.movespeed = 1.0F;
    }

    /**
     * returns the action that specifies what animation to play when the items is being used
     */
    public EnumAction func_77661_b(ItemStack stack)
    {
        return EnumAction.NONE;
    }
    
    /**
     * Current implementations of this method in child classes do not use the entry argument beside ev. They just raise
     * the damage on the stack.
     */
    public boolean func_77644_a(ItemStack stack, EntityLivingBase target, EntityLivingBase attacker)
    {
        stack.func_77972_a(1, attacker);
        target.field_70172_ad = 0;
        if(target != null && attacker != null) {
        	target.func_70097_a(DamageSource.func_76354_b(attacker, attacker), this.attackdamage);
        }
        return true;
    }
    
   
    /**
     * Gets a map of item attribute modifiers, used by ItemSword to increase hit damage.
     */
    public Multimap<String, AttributeModifier> func_111205_h(EntityEquipmentSlot equipmentSlot)
    {
        Multimap<String, AttributeModifier> multimap = super.func_111205_h(equipmentSlot);

        if (equipmentSlot == EntityEquipmentSlot.MAINHAND)
        {
            multimap.put(SharedMonsterAttributes.field_111264_e.func_111108_a(), new AttributeModifier(field_111210_e, "Weapon modifier", (double)this.attackdamage, 0));
            multimap.put(SharedMonsterAttributes.field_188790_f.func_111108_a(), new AttributeModifier(field_185050_h, "Weapon modifier", attackspeed, 0));
        }

        return multimap;
    }
    
}
