package gvclib.item;

import com.google.common.collect.Multimap;
import gvclib.item.gunbase.IGun_Sword;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Enchantments;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.ActionResult;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundCategory;
import net.minecraft.world.World;


import gvclib.item.gunbase.IGun_Sword;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Enchantments;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.ActionResult;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundCategory;
import net.minecraft.world.World;


	public class ItemGun_SWORD extends ItemGunBase implements IGun_Sword{
		public static String ads;
		
		public ItemGun_SWORD() {
			super();
			this.field_77777_bU = 1;
		}
		
		public void func_77663_a(ItemStack itemstack, World world, Entity entity, int i, boolean flag)
	    {
			EntityPlayer entityplayer = (EntityPlayer)entity;
			int s;
			int li = func_77612_l() - itemstack.func_77952_i();
			boolean lflag = cycleBolt(itemstack);
			boolean var5 = entityplayer.field_71075_bZ.field_75098_d || EnchantmentHelper.func_77506_a(Enchantments.field_185312_x, itemstack) > 0;
			Item item = itemstack.func_77973_b();
			ItemStack item_m = entityplayer.func_184614_ca();
			ItemStack item_o = entityplayer.func_184592_cb();
			
			NBTTagCompound nbt = itemstack.func_77978_p();
			boolean recoiled = nbt.func_74767_n("Recoiled");
			int recoiledtime = nbt.func_74762_e("RecoiledTime");
			{
				boolean cocking = nbt.func_74767_n("Cocking");
				int cockingtime = nbt.func_74762_e("CockingTime");
				if(!cocking && flag){
					++cockingtime;
					nbt.func_74768_a("CockingTime", cockingtime);
					if(cockingtime == 2 && flag && !this.semi){
						//world.playSoundAtEntity(entityplayer, this.soundcock, 1.0F, 1.0F);
						world.func_184148_a((EntityPlayer)null, entityplayer.field_70165_t, entityplayer.field_70163_u, entityplayer.field_70161_v,
								this.fires_cock, SoundCategory.NEUTRAL, 1.0F, 1.0F);
					}
					if(cockingtime > cocktime && flag){
						nbt.func_74768_a("CockingTime", 0);
						nbt.func_74757_a("Cocking", true);
					}
				}
			}
			
			{
				if(!recoiled){
					++recoiledtime;
					nbt.func_74768_a("RecoiledTime", recoiledtime);
					if(recoiledtime > 0){
						nbt.func_74768_a("RecoiledTime", 0);
						nbt.func_74757_a("Recoiled", true);
					}
				}
			}
			
			
			{
				ItemGunBase gun = (ItemGunBase) itemstack.func_77973_b();
				if (itemstack.func_77952_i() == itemstack.func_77958_k() && flag && entityplayer.field_71071_by.func_70431_c(new ItemStack(this.magazine))) {
						if (entity != null && entity instanceof EntityPlayer) {
							if (itemstack == entityplayer.func_184614_ca()) {
								int reloadti = nbt.func_74762_e("RloadTime");
								{
									gun.retime = reloadti;
									++reloadti;
									if (reloadti == gun.reloadtime) {
										gun.retime = reloadti = 0;
										nbt.func_74768_a("RloadTime", 0);
										{
										getReload(itemstack, world, entityplayer);
										}
										gun.resc = 0;
									}else{
										nbt.func_74768_a("RloadTime", reloadti);
									}
								}
							}
						}
				}
			}
			if(!world.field_72995_K && this.retime == 2 && flag){
				world.func_184148_a((EntityPlayer)null, entityplayer.field_70165_t, entityplayer.field_70163_u, entityplayer.field_70161_v,
						this.fires_reload, SoundCategory.NEUTRAL, 1.0F, 1.0F);
			}

			if (flag) {
				entityplayer.field_70159_w = entityplayer.field_70159_w * this.motion;
				//entityplayer.motionY = entityplayer.motionY * 0.1;
				entityplayer.field_70179_y = entityplayer.field_70179_y * this.motion;
			}
			
			if (flag && !itemstack.func_190926_b() && entityplayer != null) {
				if(itemstack.func_77973_b() instanceof ItemGunBase) {
					ItemGunBase gun = (ItemGunBase) itemstack.func_77973_b();
					this.Attachment(gun, itemstack, world, entityplayer, i, flag);
				}
			}
			super.func_77663_a(itemstack, world, entity, i, flag);
	    }
		
		@Override
		public byte getCycleCountrecoilre(ItemStack pItemstack) {
			return 3;
		}
		
		
		public void func_77615_a(ItemStack par1ItemStack, World par2World, EntityLivingBase par3EntityPlayer, int par4){
        }
		
		public ActionResult<ItemStack> onItemRightClick(ItemStack itemStackIn, World worldIn, EntityPlayer playerIn, EnumHand hand)
	    {
			boolean flag = this.func_185060_a(playerIn) != null;

	        ActionResult<ItemStack> ret = net.minecraftforge.event.ForgeEventFactory.onArrowNock(itemStackIn, worldIn, playerIn, hand, flag);
	        if (ret != null) return ret;

	        if (!playerIn.field_71075_bZ.field_75098_d && !flag)
	        {
	            return !flag ? new ActionResult(EnumActionResult.FAIL, itemStackIn) : new ActionResult(EnumActionResult.PASS, itemStackIn);
	        }
	        else
	        {
	            playerIn.func_184598_c(hand);
	            return new ActionResult(EnumActionResult.SUCCESS, itemStackIn);
	        }
	    }

        public void FireBullet(ItemStack par1ItemStack, World par2World, EntityPlayer par3EntityPlayer) 
		{
        	//par1ItemStack.damageItem(1, par3EntityPlayer);
		}
		
		public void getReload(ItemStack par1ItemStack, World par2World, EntityPlayer par3EntityPlayer) 
		{
			//par2World.playSound((EntityPlayer)null, par3EntityPlayer.posX, par3EntityPlayer.posY, par3EntityPlayer.posZ,
        	//		GVCSoundEvent.Reload, SoundCategory.NEUTRAL, 1.0F, 1.0F);
			
			int li = func_77612_l() - par1ItemStack.func_77952_i();
			boolean linfinity = EnchantmentHelper.func_77506_a(Enchantments.field_185312_x, par1ItemStack) > 0;
			ItemStack item = this.func_185060_a(par3EntityPlayer);
			if(!par3EntityPlayer.field_71075_bZ.field_75098_d || par3EntityPlayer.field_71071_by.func_70431_c(new ItemStack(this.magazine))){
			        par1ItemStack.func_77972_a(li, par3EntityPlayer);
					setDamage(par1ItemStack, -this.func_77612_l());
					if (!linfinity) {
						item.func_190918_g(1);
						if (item.func_190926_b())
		                {
							par3EntityPlayer.field_71071_by.func_184437_d(item);
		                }
					}
			}
		}
    
		public Multimap<String, AttributeModifier> func_111205_h(EntityEquipmentSlot equipmentSlot)
	    {
	        Multimap<String, AttributeModifier> multimap = super.func_111205_h(equipmentSlot);

	        if (equipmentSlot == EntityEquipmentSlot.MAINHAND)
	        {
	            multimap.put(SharedMonsterAttributes.field_111264_e.func_111108_a(), new AttributeModifier(field_111210_e, "Weapon modifier", (double)this.attackDamage, 0));
	            multimap.put(SharedMonsterAttributes.field_188790_f.func_111108_a(), new AttributeModifier(field_185050_h, "Weapon modifier", -2.4000000953674316D, 0));
	        }

	        return multimap;
	    }
		
}
