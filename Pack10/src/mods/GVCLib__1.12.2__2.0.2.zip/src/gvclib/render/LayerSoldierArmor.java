package gvclib.render;

import net.minecraft.client.model.ModelBiped;
import net.minecraft.client.renderer.entity.RenderLivingBase;
import net.minecraft.client.renderer.entity.layers.LayerArmorBase;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
public class LayerSoldierArmor extends LayerArmorBase<ModelBiped>
{
	float size;
	float armorsize;
    public LayerSoldierArmor(RenderLivingBase<?> rendererIn)
    {
        super(rendererIn);
        //this.size = size;
        //this.armorsize = armorsize;
    }

    protected void func_177177_a()
    {
        //this.modelLeggings = new ModelSoldier(this.size, false);
        //this.modelArmor = new ModelSoldier(this.armorsize, false);
    	this.field_177189_c = new ModelSoldier(0.5F, false);
        this.field_177186_d = new ModelSoldier(1.0F, false);
    }

    @SuppressWarnings("incomplete-switch")
    protected void func_188359_a(ModelBiped p_188359_1_, EntityEquipmentSlot slotIn)
    {
        this.setModelVisible(p_188359_1_);

        switch (slotIn)
        {
            case HEAD:
                p_188359_1_.field_78116_c.field_78806_j = true;
                p_188359_1_.field_178720_f.field_78806_j = true;
                break;
            case CHEST:
                p_188359_1_.field_78115_e.field_78806_j = true;
                p_188359_1_.field_178723_h.field_78806_j = true;
                p_188359_1_.field_178724_i.field_78806_j = true;
                break;
            case LEGS:
                p_188359_1_.field_78115_e.field_78806_j = true;
                p_188359_1_.field_178721_j.field_78806_j = true;
                p_188359_1_.field_178722_k.field_78806_j = true;
                break;
            case FEET:
                p_188359_1_.field_178721_j.field_78806_j = true;
                p_188359_1_.field_178722_k.field_78806_j = true;
        }
    }

    protected void setModelVisible(ModelBiped model)
    {
        model.func_178719_a(false);
    }

    /*@Override
    protected ModelBiped getArmorModelHook(net.minecraft.entity.EntityLivingBase entity, net.minecraft.item.ItemStack itemStack, EntityEquipmentSlot slot, ModelBiped model)
    {
        return net.minecraftforge.client.ForgeHooksClient.getArmorModel(entity, itemStack, slot, model);
    }*/
}
