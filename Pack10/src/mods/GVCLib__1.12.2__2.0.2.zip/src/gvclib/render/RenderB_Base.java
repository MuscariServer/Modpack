package gvclib.render;

import java.io.IOException;
import gvclib.entity.EntityBBase;
import gvclib.mod_GVCLib;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.resources.IResource;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import objmodel.AdvancedModelLoader;
import objmodel.IModelCustom;


import gvclib.mod_GVCLib;
import gvclib.entity.EntityBBase;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.resources.IResource;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import objmodel.AdvancedModelLoader;
import objmodel.IModelCustom;

@SideOnly(Side.CLIENT)
public class RenderB_Base<T extends EntityBBase> extends Render<T>
{
	private static final IModelCustom tankk = AdvancedModelLoader.loadModel(new ResourceLocation("gvclib:textures/entity/mflash.mqo"));
    private static final ResourceLocation boatTextures0 = new ResourceLocation("gvclib:textures/entity/mflash.png");
    public RenderB_Base(RenderManager renderManagerIn)
    {
        super(renderManagerIn);
    }

    //public  int moi = 0;
	//public  String[] modelt = new String[64];
	//public  IModelCustom[] model = new IModelCustom[64];
    /**
     * Renders the desired {@code T} type Entity.
     */
    public void func_76986_a(T entity, double x, double y, double z, float entityYaw, float partialTicks)
    {
    	
    	Minecraft minecraft = Minecraft.func_71410_x();
    	if(minecraft.func_175610_ah() < 15)return;
        //this.bindEntityTexture(new ResourceLocation(entity.getModel()));
        GlStateManager.func_179094_E();
        //GlStateManager.disableLighting();
        GlStateManager.func_179109_b((float)x, (float)y, (float)z);
        GlStateManager.func_179114_b(entity.field_70126_B + (entity.field_70177_z - entity.field_70126_B) * partialTicks, 0.0F, 1.0F, 0.0F);
        //GlStateManager.rotate(entity.prevRotationPitch + (entity.rotationPitch - entity.prevRotationPitch) * partialTicks, 1.0F, 0.0F, 0.0F);
        GlStateManager.func_179114_b(-entity.field_70125_A, 1.0F, 0.0F, 0.0F);
        
        if(entity.model == null && entity.getModel() != null){
        	boolean mo = false;
        	for(int ii = 0; ii < 1024; ++ii) {
        		if(mod_GVCLib.modelt[ii] != null && mod_GVCLib.modelt[ii].equals(entity.getModel())) {
        			entity.model  = mod_GVCLib.model[ii];
        			mo = true;
        			break;
        		}
        	}
        	if(!mo) 
        	{
        		ResourceLocation resource = new ResourceLocation(entity.getModel());
        		try {
					IResource res = Minecraft.func_71410_x().func_110442_L().func_110536_a(resource);
					if(res != null) {
	        			entity.model = AdvancedModelLoader.loadModel(resource);
	            		++mod_GVCLib.entityid;
	            		mod_GVCLib.model[mod_GVCLib.entityid] = entity.model;
	            		mod_GVCLib.modelt[mod_GVCLib.entityid] = entity.getModel();
	            		System.out.println(String.format("HMGGVC-" + mod_GVCLib.entityid));
	        		}
				} catch (IOException e) {
					//e.printStackTrace();
					System.out.println(String.format("warning! not exist model!::::" + entity.getModel()));
				}
        		
        	}
			
		}
        
        if(entity.model != null){
            minecraft.func_110434_K().func_110577_a(new ResourceLocation(entity.getTex()));
        	//minecraft.getTextureManager().bindTexture(entity.entity_tex);
            {
            	 GlStateManager.func_179094_E();
                 entity.model.renderPart("bullet_no_rote");
            	 GlStateManager.func_179121_F();
            }
            {
            	 GlStateManager.func_179094_E();
            	 if(!entity.field_70122_E) {
            		 GlStateManager.func_179114_b(entity.time * 10, 0.0F, 0.0F, 1.0F);
            	 }
                 entity.model.renderPart("bullet");
            	 GlStateManager.func_179121_F();
            }
            {
           	 GlStateManager.func_179094_E();
           	 if(!entity.field_70122_E) {
           		 GlStateManager.func_179114_b(entity.time * 10, 1.0F, 0.0F, 0.0F);
           	 }
                entity.model.renderPart("bullet_x");
           	 GlStateManager.func_179121_F();
           }
            {
              	 GlStateManager.func_179094_E();
              	 if(!entity.field_70122_E) {
              		 GlStateManager.func_179114_b(entity.time * 10, 0.0F, 1.0F, 0.0F);
              	 }
                   entity.model.renderPart("bullet_y");
              	 GlStateManager.func_179121_F();
              }
            
            
            
            {
            	GlStateManager.func_179140_f();
            	float size = partialTicks * 0.4F + 1;
            	GlStateManager.func_179152_a(size, size, size);
            	entity.model.renderPart("bullet_e_1");
            	 GlStateManager.func_179145_e();
            }
        }
        GlStateManager.func_179109_b((float)-x, (float)-y, (float)-z);
        GlStateManager.func_179121_F();
        
        //*/
        
        
        /*{//flash
        	GlStateManager.pushMatrix();
            //GlStateManager.translate((float)entity.startposX, (float)entity.startposY, (float)entity.startposZ);
        	GlStateManager.translate((float)x, (float)y, (float)z);
        	float xx = (float) (x - entity.startposX);
        	float yy = (float) (y - entity.startposY);
        	float zz = (float) (z - entity.startposZ);
        	//GlStateManager.translate((float)x - xx, (float)y - yy, (float)z - zz);
        	//GlStateManager.translate((float)-entity.startposX, (float)-entity.startposY, (float)-entity.startposZ);
            GlStateManager.rotate(180F, 0.0F, 1.0F, 0.0F);
            GlStateManager.color(1F, 1F, 1F, 1F);
            GlStateManager.rotate(entity.prevRotationYaw + (entity.rotationYaw - entity.prevRotationYaw) * partialTicks, 0.0F, 1.0F, 0.0F);
            //GlStateManager.rotate(entity.prevRotationPitch + (entity.rotationPitch - entity.prevRotationPitch) * partialTicks, 1.0F, 0.0F, 0.0F);
            GlStateManager.rotate(-entity.rotationPitch, 1.0F, 0.0F, 0.0F);
            if(entity.time <= 3)
            {
            	if(entity.modelf == null && entity.getModelF() != null){
        			{
        				entity.modelf = AdvancedModelLoader
        						.loadModel(new ResourceLocation(entity.getModelF()));
        			}
        		}
            	if(entity.modelf != null){
					if (entity.time <= 1) {
						minecraft.getTextureManager().bindTexture(new ResourceLocation(entity.getTexF()));
						entity.modelf.renderPart("mat1");
						entity.modelf.renderPart("bullet");
					}
					if (entity.time == 2) {
						minecraft.getTextureManager().bindTexture(new ResourceLocation(entity.getTexF()));
						entity.modelf.renderPart("bullet2");
					}
                }
            }
            GlStateManager.popMatrix();
        }*/
        
        super.func_76986_a(entity, x, y, z, entityYaw, partialTicks);
    }

	@Override
	protected ResourceLocation func_110775_a(T entity) {
		// TODO �����������ꂽ���\�b�h�E�X�^�u
		return boatTextures0;
	}
}
