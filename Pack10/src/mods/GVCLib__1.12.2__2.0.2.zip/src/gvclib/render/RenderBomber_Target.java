package gvclib.render;

import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL12;
import gvclib.entity.living.EntityGVCLivingBase;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraftforge.fml.client.FMLClientHandler;
import objmodel.AdvancedModelLoader;
import objmodel.IModelCustom;


import gvclib.entity.living.EntityGVCLivingBase;
import gvclib.entity.living.EntityVehicleBase;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.text.TextComponentTranslation;
import net.minecraftforge.fml.client.FMLClientHandler;
import objmodel.AdvancedModelLoader;
import objmodel.IModelCustom;

public class RenderBomber_Target {

	private static final ResourceLocation t1 = new ResourceLocation("gvclib:textures/marker/bomberpoint.png");
    private static final IModelCustom marker = AdvancedModelLoader.loadModel(new ResourceLocation("gvclib:textures/marker/bomberpoint.mqo"));
    
	public static void can(EntityGVCLivingBase entity) {
		
		BlockPos basep = FMLClientHandler.instance().getClient().field_71441_e.func_175645_m(new BlockPos(entity.field_70165_t, entity.field_70163_u, entity.field_70161_v));
		float bsp = (float)Math.tan((entity.field_70159_w * entity.field_70159_w) + (entity.field_70179_y * entity.field_70179_y)) * 10;
		//double ve = Math.sqrt((bsp * Math.cos(0)) * (bsp * Math.cos(0)) + 2 * basep.getY() * 0.03F);
		float xspeed = (float) (bsp * Math.sqrt((2  * (entity.field_70163_u - basep.func_177956_o()) * 0.65F  ) / 0.03F));
		
		float xx = xspeed;
		float zz = 0;
		float xxx = 0;
		float yyy = 0;
		float zzz = 0;
		float yaw = entity.field_70759_as * (2 * (float) Math.PI / 360);
		xxx -= MathHelper.func_76126_a(yaw) * xx;
		zzz += MathHelper.func_76134_b(yaw) * xx;
		xxx -= MathHelper.func_76126_a(yaw - 1.57F) * zz;
		zzz += MathHelper.func_76134_b(yaw - 1.57F) * zz;
		BlockPos bp = FMLClientHandler.instance().getClient().field_71441_e.func_175645_m(new BlockPos(xxx + entity.field_70165_t, entity.field_70163_u, zzz + entity.field_70161_v));
		yyy = bp.func_177956_o();
		
		float x = xxx;
		float y = (float)(yyy - entity.field_70163_u);
		float z = zzz;
		
		
		GL11.glPushMatrix();//glstart
		GL11.glRotatef(180F, 0.0F, 1.0F, 0.0F);
		GL11.glEnable(GL12.GL_RESCALE_NORMAL);
		{
			float value = (float)(entity.field_70163_u - yyy) * 0.2F;
			
			GL11.glTranslatef(x, y, z);
			
			GL11.glScalef(1F + value, 1F, 1F + value);
			
			//GL11.glTranslatef(0.0F, value, 0.0F);
			GlStateManager.func_179140_f();
			Minecraft.func_71410_x().field_71446_o.func_110577_a(t1);
	        marker.renderPart("mat1");
	        GlStateManager.func_179145_e();
		}
		GL11.glColor4f(1F, 1F, 1F, 1F);
		GL11.glDisable(GL12.GL_RESCALE_NORMAL);
		GL11.glPopMatrix();//glend
	}
	
}
