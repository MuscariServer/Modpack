package gvclib.render;

import java.io.IOException;
import gvclib.entity.EntityB_Cratridge;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.resources.IResource;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import objmodel.AdvancedModelLoader;
import objmodel.IModelCustom;


import gvclib.entity.EntityB_Cratridge;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.resources.IResource;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import objmodel.AdvancedModelLoader;
import objmodel.IModelCustom;

@SideOnly(Side.CLIENT)
public class RenderB_Cratridge<T extends EntityB_Cratridge> extends Render<T> {
	private static final IModelCustom tankk = AdvancedModelLoader
			.loadModel(new ResourceLocation("gvclib:textures/model/smoke.obj"));
	private static final ResourceLocation boatTextures0 = new ResourceLocation("gvclib:textures/model/smoke0.png");

	public RenderB_Cratridge(RenderManager renderManagerIn) {
		super(renderManagerIn);
	}

	/**
	 * Renders the desired {@code T} type Entity.
	 */
	public void func_76986_a(T entity, double x, double y, double z, float entityYaw, float partialTicks) {
		// this.bindEntityTexture(new ResourceLocation(entity.getModel()));
		GlStateManager.func_179094_E();
		// GlStateManager.disableLighting();
		GlStateManager.func_179109_b((float) x, (float) y, (float) z);
		GlStateManager.func_179114_b(entity.field_70126_B + (entity.field_70177_z - entity.field_70126_B) * partialTicks,
				0.0F, 1.0F, 0.0F);
		// GlStateManager.rotate(entity.prevRotationPitch + (entity.rotationPitch -
		// entity.prevRotationPitch) * partialTicks, 1.0F, 0.0F, 0.0F);
		GlStateManager.func_179114_b(-entity.field_70125_A, 1.0F, 0.0F, 0.0F);

		if (entity.model == null && entity.getModel() != null) {
			ResourceLocation resource = new ResourceLocation(entity.getModel());
			try {
				IResource res = Minecraft.func_71410_x().func_110442_L().func_110536_a(resource);
				if (res != null) {
					entity.model = AdvancedModelLoader.loadModel(resource);
				}
			} catch (IOException e) {
				// e.printStackTrace();
				System.out.println(String.format("warning! not exist model!::::" + entity.getModel()));
			}
		}
		Minecraft minecraft = Minecraft.func_71410_x();
		minecraft.func_110434_K().func_110577_a(new ResourceLocation(entity.getTex()));
		if(entity.model != null)entity.model.renderPart("mat1");
		GlStateManager.func_179121_F();
		super.func_76986_a(entity, x, y, z, entityYaw, partialTicks);
	}

	@Override
	protected ResourceLocation func_110775_a(T entity) {
		// TODO �����������ꂽ���\�b�h�E�X�^�u
		return boatTextures0;
	}
}
