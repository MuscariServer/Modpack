package gvclib.render;

import gvclib.mod_GVCLib;
import gvclib.entity.EntityB_Grapple;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import objmodel.AdvancedModelLoader;
import objmodel.IModelCustom;

@SideOnly(Side.CLIENT)
public class RenderB_Grapple<T extends EntityB_Grapple> extends Render<T>
{
	private static final IModelCustom tankk = AdvancedModelLoader.loadModel(new ResourceLocation("gvclib:textures/entity/mflash.mqo"));
    private static final ResourceLocation boatTextures0 = new ResourceLocation("gvclib:textures/entity/mflash.png");
    public static final ResourceLocation ENDERCRYSTAL_BEAM_TEXTURES = new ResourceLocation("textures/entity/endercrystal/endercrystal_beam.png");
   
    public RenderManager rendermanager;
    
    public RenderB_Grapple(RenderManager renderManagerIn)
    {
        super(renderManagerIn);
        rendermanager = renderManagerIn;
    }
    /**
     * Renders the desired {@code T} type Entity.
     */
    public void func_76986_a(T entity, double x, double y, double z, float entityYaw, float partialTicks)
    {
    	super.func_76986_a(entity, x, y, z, entityYaw, partialTicks);
    	
    	Minecraft minecraft = Minecraft.func_71410_x();
        //this.bindEntityTexture(new ResourceLocation(entity.getModel()));
        GlStateManager.func_179094_E();
        //GlStateManager.disableLighting();
        GlStateManager.func_179109_b((float)x, (float)y, (float)z);
        GlStateManager.func_179114_b(entity.field_70126_B + (entity.field_70177_z - entity.field_70126_B) * partialTicks, 0.0F, 1.0F, 0.0F);
        //GlStateManager.rotate(entity.prevRotationPitch + (entity.rotationPitch - entity.prevRotationPitch) * partialTicks, 1.0F, 0.0F, 0.0F);
        GlStateManager.func_179114_b(-entity.field_70125_A, 1.0F, 0.0F, 0.0F);
        
        if(entity.model == null && entity.getModel() != null){
        	boolean mo = false;
        	for(int ii = 0; ii < 1024; ++ii) {
        		if(mod_GVCLib.modelt[ii] != null && mod_GVCLib.modelt[ii].equals(entity.getModel())) {
        			entity.model  = mod_GVCLib.model[ii];
        			mo = true;
        			break;
        		}
        	}
        	if(!mo) 
        	{
        		entity.model = AdvancedModelLoader
						.loadModel(new ResourceLocation(entity.getModel()));
        		++mod_GVCLib.entityid;
        		mod_GVCLib.model[mod_GVCLib.entityid] = entity.model;
        		mod_GVCLib.modelt[mod_GVCLib.entityid] = entity.getModel();
        		System.out.println(String.format("HMGGVC-" + mod_GVCLib.entityid));
        	}
			
		}
        
        if(entity.model != null){
            minecraft.func_110434_K().func_110577_a(new ResourceLocation(entity.getTex()));
        	//minecraft.getTextureManager().bindTexture(entity.entity_tex);
            {
            	 GlStateManager.func_179094_E();
            	 if(!entity.field_70122_E) {
            		 GlStateManager.func_179114_b(entity.time * 10, 0.0F, 0.0F, 1.0F);
            	 }
                 entity.model.renderPart("bullet");
            	 GlStateManager.func_179121_F();
            }
        }
        GlStateManager.func_179109_b((float)-x, (float)-y, (float)-z);
        GlStateManager.func_179121_F();
        
        
        
        
        //EntityLivingBase entityplayer = entity.angler;
    	EntityLivingBase entityplayer = Minecraft.func_71410_x().field_71439_g;

        if (entityplayer != null && entity.isOwner(entityplayer))
        {
        	//System.out.println(String.format("render"));
        	this.func_110776_a(ENDERCRYSTAL_BEAM_TEXTURES);
        	Tessellator tessellator = Tessellator.func_178181_a();
            BufferBuilder bufferbuilder = tessellator.func_178180_c();
            int k = 1;
            float f7 = entityplayer.func_70678_g(partialTicks);
            float f8 = MathHelper.func_76126_a(MathHelper.func_76129_c(f7) * (float)Math.PI);
            float f9 = (entityplayer.field_70760_ar + (entityplayer.field_70761_aq - entityplayer.field_70760_ar) * partialTicks) * 0.017453292F;
            double d0 = (double)MathHelper.func_76126_a(f9);
            double d1 = (double)MathHelper.func_76134_b(f9);
            double d2 = (double)k * 0.35D;
            double d3 = 0.8D;
            double d4;
            double d5;
            double d6;
            double d7;

            if ((rendermanager.field_78733_k == null || rendermanager.field_78733_k.field_74320_O <= 0) && entityplayer == Minecraft.func_71410_x().field_71439_g)
            {
                float f10 = Minecraft.func_71410_x().func_175598_ae().field_78733_k.field_74334_X;
                f10 = f10 / 100.0F;
                Vec3d vec3d = new Vec3d((double)k * -0.36D * (double)f10, -0.045D * (double)f10, 0.4D);
                vec3d = vec3d.func_178789_a(-(entityplayer.field_70127_C + (entityplayer.field_70125_A - entityplayer.field_70127_C) * partialTicks) * 0.017453292F);
                vec3d = vec3d.func_178785_b(-(entityplayer.field_70126_B + (entityplayer.field_70177_z - entityplayer.field_70126_B) * partialTicks) * 0.017453292F);
                vec3d = vec3d.func_178785_b(f8 * 0.5F);
                vec3d = vec3d.func_178789_a(-f8 * 0.7F);
                d4 = entityplayer.field_70169_q + (entityplayer.field_70165_t - entityplayer.field_70169_q) * (double)partialTicks + vec3d.field_72450_a;
                d5 = entityplayer.field_70167_r + (entityplayer.field_70163_u - entityplayer.field_70167_r) * (double)partialTicks + vec3d.field_72448_b;
                d6 = entityplayer.field_70166_s + (entityplayer.field_70161_v - entityplayer.field_70166_s) * (double)partialTicks + vec3d.field_72449_c;
                d7 = (double)entityplayer.func_70047_e();
            }
            else
            {
                d4 = entityplayer.field_70169_q + (entityplayer.field_70165_t - entityplayer.field_70169_q) * (double)partialTicks - d1 * d2 - d0 * 0.8D;
                d5 = entityplayer.field_70167_r + (double)entityplayer.func_70047_e() + (entityplayer.field_70163_u - entityplayer.field_70167_r) * (double)partialTicks - 0.45D;
                d6 = entityplayer.field_70166_s + (entityplayer.field_70161_v - entityplayer.field_70166_s) * (double)partialTicks - d0 * d2 + d1 * 0.8D;
                d7 = entityplayer.func_70093_af() ? -0.1875D : 0.0D;
            }

            double d13 = entity.field_70169_q + (entity.field_70165_t - entity.field_70169_q) * (double)partialTicks;
            double d8 = entity.field_70167_r + (entity.field_70163_u - entity.field_70167_r) * (double)partialTicks + 0.25D;
            double d9 = entity.field_70166_s + (entity.field_70161_v - entity.field_70166_s) * (double)partialTicks;
            double d10 = (double)((float)(d4 - d13));
            double d11 = (double)((float)(d5 - d8)) + d7;
            double d12 = (double)((float)(d6 - d9));
            GlStateManager.func_179090_x();
            GlStateManager.func_179140_f();
            bufferbuilder.func_181668_a(3, DefaultVertexFormats.field_181706_f);
            int l = 16;

            for (int i1 = 0; i1 <= 16; ++i1)
            {
                float f11 = (float)i1 / 16.0F;
                bufferbuilder.func_181662_b(x + d10 * (double)f11, y + d11 * (double)(f11 * f11 + f11) * 0.5D + 0.25D, z + d12 * (double)f11).func_181669_b(0, 0, 0, 255).func_181675_d();
            }

            tessellator.func_78381_a();
            GlStateManager.func_179145_e();
            GlStateManager.func_179098_w();/**/
        	//float f = MathHelper.sin(((float)entity.healingEnderCrystal.ticksExisted + partialTicks) * 0.2F) / 2.0F + 0.5F;
        	/*GlStateManager.pushMatrix();
        	this.bindTexture(ENDERCRYSTAL_BEAM_TEXTURES);
            float f = 0;
            renderCrystalBeams(x, y, z, partialTicks, entity.posX + (entity.prevPosX - entity.posX) * (double)(1.0F - partialTicks), 
            		entity.posY + (entity.prevPosY - entity.posY) * (double)(1.0F - partialTicks), 
            		entity.posZ + (entity.prevPosZ - entity.posZ) * (double)(1.0F - partialTicks), entity.ticksExisted, 
            		entityplayer.posX, (double)f + entityplayer.posY, entityplayer.posZ);
            GlStateManager.popMatrix();*/
        }
        
        
    }

    public static void renderCrystalBeams(double p_188325_0_, double p_188325_2_, double p_188325_4_, float p_188325_6_, double p_188325_7_, double p_188325_9_, double p_188325_11_, int p_188325_13_, double p_188325_14_, double p_188325_16_, double p_188325_18_)
    {
        float f = (float)(p_188325_14_ - p_188325_7_);
        float f1 = (float)(p_188325_16_ - p_188325_9_);
        float f2 = (float)(p_188325_18_ - p_188325_11_);
        float f3 = MathHelper.func_76129_c(f * f + f2 * f2);
        float f4 = MathHelper.func_76129_c(f * f + f1 * f1 + f2 * f2);
        GlStateManager.func_179094_E();
        GlStateManager.func_179109_b((float)p_188325_0_, (float)p_188325_2_ + 2.0F, (float)p_188325_4_);
        GlStateManager.func_179114_b((float)(-Math.atan2((double)f2, (double)f)) * (180F / (float)Math.PI) - 90.0F, 0.0F, 1.0F, 0.0F);
        GlStateManager.func_179114_b((float)(-Math.atan2((double)f3, (double)f1)) * (180F / (float)Math.PI) - 90.0F, 1.0F, 0.0F, 0.0F);
        Tessellator tessellator = Tessellator.func_178181_a();
        BufferBuilder bufferbuilder = tessellator.func_178180_c();
        RenderHelper.func_74518_a();
        GlStateManager.func_179129_p();
        GlStateManager.func_179103_j(7425);
        float f5 = 0.0F - ((float)p_188325_13_ + p_188325_6_) * 0.01F;
        float f6 = MathHelper.func_76129_c(f * f + f1 * f1 + f2 * f2) / 32.0F - ((float)p_188325_13_ + p_188325_6_) * 0.01F;
        bufferbuilder.func_181668_a(5, DefaultVertexFormats.field_181709_i);
        int i = 8;

        for (int j = 0; j <= 8; ++j)
        {
            float f7 = MathHelper.func_76126_a((float)(j % 8) * ((float)Math.PI * 2F) / 8.0F) * 0.75F;
            float f8 = MathHelper.func_76134_b((float)(j % 8) * ((float)Math.PI * 2F) / 8.0F) * 0.75F;
            float f9 = (float)(j % 8) / 8.0F;
            bufferbuilder.func_181662_b((double)(f7 * 0.2F), (double)(f8 * 0.2F), 0.0D).func_187315_a((double)f9, (double)f5).func_181669_b(0, 0, 0, 255).func_181675_d();
            bufferbuilder.func_181662_b((double)f7, (double)f8, (double)f4).func_187315_a((double)f9, (double)f6).func_181669_b(255, 255, 255, 255).func_181675_d();
        }

        tessellator.func_78381_a();
        GlStateManager.func_179089_o();
        GlStateManager.func_179103_j(7424);
        RenderHelper.func_74519_b();
        GlStateManager.func_179121_F();
    }
    
	@Override
	protected ResourceLocation func_110775_a(T entity) {
		// TODO �����������ꂽ���\�b�h�E�X�^�u
		return boatTextures0;
	}
}
