package gvclib.render;

import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL12;
import gvclib.entity.living.EntityGVCLivingBase;
import gvclib.item.ItemArmor_NewObj;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ModelBiped;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.ItemBow;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.EnumHand;
import net.minecraft.util.EnumHandSide;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraftforge.fml.client.FMLClientHandler;


import gvclib.entity.living.EntityGVCLivingBase;
import gvclib.item.ItemArmor_NewObj;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ModelBiped;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.ItemBow;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.EnumHand;
import net.minecraft.util.EnumHandSide;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraftforge.fml.client.FMLClientHandler;

//2019/11/9以前のもの
public class ModelArmorNewObj_backup extends ModelBiped {
	public ModelArmorNewObj_backup() {
		field_78090_t = 512;
		field_78089_u = 256;
	}

	@Override
	public void func_78088_a(Entity p_78088_1_, float p_78088_2_, float p_78088_3_, float p_78088_4_, float p_78088_5_,
			float p_78088_6_, float p_78088_7_) {
		this.func_78087_a(p_78088_2_, p_78088_3_, p_78088_4_, p_78088_5_, p_78088_6_, p_78088_7_, p_78088_1_);

	}

	private void setRotation(ModelRenderer model, float x, float y, float z) {
		model.field_78795_f = x;
		model.field_78796_g = y;
		model.field_78808_h = z;
	}
	@Override
//	@SuppressWarnings("incomplete-switch")
	public void func_78087_a(float p_78087_1_, float p_78087_2_, float p_78087_3_, float p_78087_4_,
			float p_78087_5_, float p_78087_6_, Entity p_78087_7_) {
		{
			this.field_187076_m = null;
		//	this.aimedBow = false;
			
			EntityLivingBase el = (EntityLivingBase) p_78087_7_;
			ItemStack itemstack = el.func_184614_ca();
			if(itemstack != null){
				this.field_187076_m = ModelBiped.ArmPose.ITEM;
				if(itemstack.func_77973_b() instanceof ItemBow && el.func_184587_cr()){
					this.field_187076_m = ModelBiped.ArmPose.BOW_AND_ARROW;
			//		this.aimedBow = true;
				}
			}
			
			
			
			this.field_78116_c.field_78796_g = p_78087_4_ / (180F / (float)Math.PI);
	        this.field_78116_c.field_78795_f = p_78087_5_ / (180F / (float)Math.PI);
	        this.field_178720_f.field_78796_g = this.field_78116_c.field_78796_g;
	        this.field_178720_f.field_78795_f = this.field_78116_c.field_78795_f;
	        this.field_178723_h.field_78795_f = MathHelper.func_76134_b(p_78087_1_ * 0.6662F + (float)Math.PI) * 2.0F * p_78087_2_ * 0.5F;
	        this.field_178724_i.field_78795_f = MathHelper.func_76134_b(p_78087_1_ * 0.6662F) * 2.0F * p_78087_2_ * 0.5F;
	        this.field_178723_h.field_78808_h = 0.0F;
	        this.field_178724_i.field_78808_h = 0.0F;
	        this.field_178721_j.field_78795_f = MathHelper.func_76134_b(p_78087_1_ * 0.6662F) * 1.4F * p_78087_2_;
	        this.field_178722_k.field_78795_f = MathHelper.func_76134_b(p_78087_1_ * 0.6662F + (float)Math.PI) * 1.4F * p_78087_2_;
	        this.field_178721_j.field_78796_g = 0.0F;
	        this.field_178722_k.field_78796_g = 0.0F;

	        if (this.field_78093_q)
	        {
	            this.field_178723_h.field_78795_f += -((float)Math.PI / 5F);
	            this.field_178724_i.field_78795_f += -((float)Math.PI / 5F);
	            this.field_178721_j.field_78795_f = -((float)Math.PI * 2F / 5F);
	            this.field_178722_k.field_78795_f = -((float)Math.PI * 2F / 5F);
	            this.field_178721_j.field_78796_g = ((float)Math.PI / 10F);
	            this.field_178722_k.field_78796_g = -((float)Math.PI / 10F);
	        }

	        this.field_178723_h.field_78796_g = 0.0F;
	        this.field_178724_i.field_78796_g = 0.0F;
	        float f6;
	        float f7;

	        if (this.field_78095_p > 0.0F)
	        {
	            EnumHandSide enumhandside = this.func_187072_a(el);
	            ModelRenderer modelrenderer = this.func_187074_a(enumhandside);
	            float f1 = this.field_78095_p;
	            this.field_78115_e.field_78796_g = MathHelper.func_76126_a(MathHelper.func_76129_c(f1) * ((float)Math.PI * 2F)) * 0.2F;

	            if (enumhandside == EnumHandSide.LEFT)
	            {
	                this.field_78115_e.field_78796_g *= -1.0F;
	            }

	            this.field_178723_h.field_78798_e = MathHelper.func_76126_a(this.field_78115_e.field_78796_g) * 5.0F;
	            this.field_178723_h.field_78800_c = -MathHelper.func_76134_b(this.field_78115_e.field_78796_g) * 5.0F;
	            this.field_178724_i.field_78798_e = -MathHelper.func_76126_a(this.field_78115_e.field_78796_g) * 5.0F;
	            this.field_178724_i.field_78800_c = MathHelper.func_76134_b(this.field_78115_e.field_78796_g) * 5.0F;
	            this.field_178723_h.field_78796_g += this.field_78115_e.field_78796_g;
	            this.field_178724_i.field_78796_g += this.field_78115_e.field_78796_g;
	            this.field_178724_i.field_78795_f += this.field_78115_e.field_78796_g;
	            f1 = 1.0F - this.field_78095_p;
	            f1 = f1 * f1;
	            f1 = f1 * f1;
	            f1 = 1.0F - f1;
	            float f2 = MathHelper.func_76126_a(f1 * (float)Math.PI);
	            float f3 = MathHelper.func_76126_a(this.field_78095_p * (float)Math.PI) * -(this.field_78116_c.field_78795_f - 0.7F) * 0.75F;
	            modelrenderer.field_78795_f = (float)((double)modelrenderer.field_78795_f - ((double)f2 * 1.2D + (double)f3));
	            modelrenderer.field_78796_g += this.field_78115_e.field_78796_g * 2.0F;
	            modelrenderer.field_78808_h += MathHelper.func_76126_a(this.field_78095_p * (float)Math.PI) * -0.4F;
	        }

	        if (this.field_78117_n)
	        {
	            this.field_78115_e.field_78795_f = 0.5F;
	            this.field_178723_h.field_78795_f += 0.4F;
	            this.field_178724_i.field_78795_f += 0.4F;
	            this.field_178721_j.field_78798_e = 4.0F;
	            this.field_178722_k.field_78798_e = 4.0F;
	            this.field_178721_j.field_78797_d = 9.0F;
	            this.field_178722_k.field_78797_d = 9.0F;
	            this.field_78116_c.field_78797_d = 1.0F;
	            this.field_178720_f.field_78797_d = 1.0F;
	        }
	        else
	        {
	            this.field_78115_e.field_78795_f = 0.0F;
	            this.field_178721_j.field_78798_e = 0.1F;
	            this.field_178722_k.field_78798_e = 0.1F;
	            this.field_178721_j.field_78797_d = 12.0F;
	            this.field_178722_k.field_78797_d = 12.0F;
	            this.field_78116_c.field_78797_d = 0.0F;
	            this.field_178720_f.field_78797_d = 0.0F;
	        }

	        this.field_178723_h.field_78808_h -= MathHelper.func_76134_b(p_78087_3_ * 0.09F) * 0.05F + 0.05F;
	        this.field_178724_i.field_78808_h += MathHelper.func_76134_b(p_78087_3_ * 0.09F) * 0.05F + 0.05F;
	        this.field_178723_h.field_78795_f += MathHelper.func_76126_a(p_78087_3_ * 0.067F) * 0.05F;
	        this.field_178724_i.field_78795_f -= MathHelper.func_76126_a(p_78087_3_ * 0.067F) * 0.05F;

	        if (this.field_187076_m == ModelBiped.ArmPose.BOW_AND_ARROW)
	        {
	            this.field_178723_h.field_78796_g = -0.1F + this.field_78116_c.field_78796_g;
	            this.field_178724_i.field_78796_g = 0.1F + this.field_78116_c.field_78796_g + 0.4F;
	            this.field_178723_h.field_78795_f = -((float)Math.PI / 2F) + this.field_78116_c.field_78795_f;
	            this.field_178724_i.field_78795_f = -((float)Math.PI / 2F) + this.field_78116_c.field_78795_f;
	        }
		}
		
		
		Minecraft minecraft = FMLClientHandler.instance().getClient();
		if (p_78087_7_ instanceof EntityLivingBase) {
			EntityLivingBase entity = (EntityLivingBase) p_78087_7_;
			boolean isSneak = false;
			if(entity.func_70093_af() || this.field_78117_n) {
				isSneak = true;
				//System.out.println(String.format("input"));
			}
			if(entity instanceof EntityGVCLivingBase) {
				EntityGVCLivingBase ent = (EntityGVCLivingBase) entity;
				if(ent.sneak && ent.func_184592_cb().func_190926_b()) {
					isSneak = true;
				}
			}
			GL11.glPushMatrix();
			GL11.glEnable(GL12.GL_RESCALE_NORMAL);
			GL11.glRotatef(180F, 1.0F, 0.0F, 0.0F);
			GL11.glTranslatef(0, -1.5F, 0);
			if ((entity.func_184582_a(EntityEquipmentSlot.HEAD) != null)
					&& (entity.func_184582_a(EntityEquipmentSlot.HEAD).func_77973_b() instanceof ItemArmor_NewObj)) {
				ItemArmor_NewObj armor = (ItemArmor_NewObj) entity.func_184582_a(EntityEquipmentSlot.HEAD).func_77973_b();
				GL11.glPushMatrix();
				Minecraft.func_71410_x().field_71446_o.func_110577_a(new ResourceLocation(armor.obj_tex));
				GL11.glTranslatef(0F, 1.5F, 0.0F);
				if (isSneak) {
					GL11.glTranslatef(0F, -0.20F, 0.0F);
				}
				{
					GL11.glRotated(180.0F - entity.field_70759_as - (180.0F - entity.field_70761_aq), 0.0F, 1.0F,
							0.0F);
					GL11.glRotated(entity.field_70125_A, 1.0F, 0.0F, 0.0F);
				}
				GL11.glTranslatef(0F, -1.5F, 0.0F);
				armor.obj_model.renderPart("head");
				this.field_178720_f.field_78806_j = false;
				this.field_78116_c.field_78806_j = false;
				GL11.glPopMatrix();
			}
			if ((entity.func_184582_a(EntityEquipmentSlot.CHEST) != null)
					&& (entity.func_184582_a(EntityEquipmentSlot.CHEST).func_77973_b() instanceof ItemArmor_NewObj)) {
				ItemArmor_NewObj armor = (ItemArmor_NewObj) entity.func_184582_a(EntityEquipmentSlot.CHEST).func_77973_b();
				{//chest
					GL11.glPushMatrix();
					Minecraft.func_71410_x().field_71446_o.func_110577_a(new ResourceLocation(armor.obj_tex));
					GL11.glTranslatef(0F, 1.5F, 0.0F);
					if(isSneak){
					//	GL11.glTranslatef(0F, -0.05F, 0.0F);
						GL11.glRotated(30, 1.0F, 0.0F, 0.0F);
						GL11.glTranslatef(0F, -0.20F, 0.0F);
						//GL11.glRotatef(this.body_rotex * (180F / (float)Math.PI), 1.0F, 0.0F, 0.0F);
					}
					GL11.glTranslatef(0F, -1.5F, 0.0F);
					armor.obj_model.renderPart("body");
					{
						NBTTagCompound nbt = entity.getEntityData();
						boolean para = nbt.func_74767_n("Para");
						if(para){
							armor.obj_model.renderPart("parachute");
						}else{
							armor.obj_model.renderPart("parachute1");
						}
					}
					{
						BlockPos bp = entity.field_70170_p.func_175645_m(new BlockPos(entity.field_70165_t, entity.field_70163_u, entity.field_70161_v));
						int genY = bp.func_177956_o() + 3;
						if(entity != null && !(entity instanceof EntityPlayer)){
							if(entity.field_70163_u > genY){
								armor.obj_model.renderPart("parachute");
							}else{
								armor.obj_model.renderPart("parachute1");
							}
						}
					}
					
					this.field_78115_e.field_78806_j = false;
					GL11.glPopMatrix();
				}//chest
				
				{//leftarm
					GL11.glPushMatrix();
					Minecraft.func_71410_x().field_71446_o.func_110577_a(new ResourceLocation(armor.obj_tex));
					//GL11.glTranslatef(0F, 1.5F, 0.0F);
					GL11.glTranslatef(0.375F, 1.375F, 0.0F);//offset_start
					if(isSneak && !(this.field_187076_m == ModelBiped.ArmPose.BOW_AND_ARROW)){
					//	GL11.glTranslatef(0F, -0.05F, 0.0F);
						GL11.glRotated(22.5F, 1.0F, 0.0F, 0.0F);
						//GL11.glRotatef(this.leftarm_rotex * (180F / (float)Math.PI), 1.0F, 0.0F, 0.0F);
					}
					if(isSneak){
						//this.bipedLeftArm.rotateAngleX += 0.4F;
						    GL11.glRotated(-22.5F, 1.0F, 0.0F, 0.0F);
							GL11.glTranslatef(0F, -0.20F, 0.0F);
					}
					if (this.field_187076_m == ModelBiped.ArmPose.BOW_AND_ARROW)
			        {
						GL11.glRotated(180.0F - entity.field_70759_as - (180.0F - entity.field_70761_aq), 0.0F, 1.0F,0.0F);
						
			        }
					if(!entity.func_184586_b(EnumHand.OFF_HAND).func_190926_b()) {
			        	this.field_178724_i.field_78795_f = this.field_178724_i.field_78795_f * 0.5F - ((float)Math.PI / 10F);
			        }
					GL11.glRotatef(this.field_178724_i.field_78795_f * (180F / (float)Math.PI), 1.0F, 0.0F, 0.0F);
					GL11.glRotatef(this.field_178724_i.field_78796_g * (180F / (float)Math.PI), 0.0F, 1.0F, 0.0F);
					GL11.glRotatef(this.field_178724_i.field_78808_h * (180F / (float)Math.PI), 0.0F, 0.0F, 1.0F);
					if (this.field_187076_m == ModelBiped.ArmPose.BOW_AND_ARROW)
			        {
						GL11.glRotatef(-30, 0.0F, 0.0F, 1.0F);
			        }
					GL11.glTranslatef(-0.375F, -1.375F, 0.0F);//offset_end
					//GL11.glTranslatef(0F, -1.5F, 0.0F);
					armor.obj_model.renderPart("leftarm");
					this.field_78115_e.field_78806_j = false;
					GL11.glPopMatrix();
				}//leftarm
				
				{//rightarm
					GL11.glPushMatrix();
					Minecraft.func_71410_x().field_71446_o.func_110577_a(new ResourceLocation(armor.obj_tex));
					//GL11.glTranslatef(0F, 1.5F, 0.0F);
					GL11.glTranslatef(-0.375F, 1.375F, 0.0F);//offset_start
					
			//		GL11.glTranslatef(-this.rightarm_posx, -rightarm_posy, -rightarm_posz);
					
					if(isSneak && !(this.field_187076_m == ModelBiped.ArmPose.BOW_AND_ARROW)){
					//	GL11.glTranslatef(0F, -0.05F, 0.0F);
						GL11.glRotated(22.5F, 1.0F, 0.0F, 0.0F);
						//GL11.glRotatef(this.rightarm_rotex * (180F / (float)Math.PI), 1.0F, 0.0F, 0.0F);
					}
					if(isSneak){
						//this.bipedRightArm.rotateAngleX += 0.4F;
						 GL11.glRotated(-22.5F, 1.0F, 0.0F, 0.0F);
							GL11.glTranslatef(0F, -0.20F, 0.0F);
					}
					if (this.field_187076_m == ModelBiped.ArmPose.BOW_AND_ARROW)
			        {
						GL11.glRotated(180.0F - entity.field_70759_as - (180.0F - entity.field_70761_aq), 0.0F, 1.0F,0.0F);
			        }
					if(!entity.func_184586_b(EnumHand.MAIN_HAND).func_190926_b()) {
			        	this.field_178723_h.field_78795_f = this.field_178723_h.field_78795_f * 0.5F - ((float)Math.PI / 10F);
			        }
					GL11.glRotatef(this.field_178723_h.field_78795_f * (180F / (float)Math.PI), 1.0F, 0.0F, 0.0F);
					GL11.glRotatef(this.field_178723_h.field_78796_g * (180F / (float)Math.PI), 0.0F, 1.0F, 0.0F);
					GL11.glRotatef(this.field_178723_h.field_78808_h * (180F / (float)Math.PI), 0.0F, 0.0F, 1.0F);
					if (this.field_187076_m == ModelBiped.ArmPose.BOW_AND_ARROW)
			        {
						GL11.glRotatef(5, 0.0F, 0.0F, 1.0F);
			        }
					GL11.glTranslatef(0.375F, -1.375F, 0.0F);//offset_end
					//GL11.glTranslatef(0F, -1.5F, 0.0F);
					armor.obj_model.renderPart("rightarm");
					this.field_78115_e.field_78806_j = false;
					GL11.glPopMatrix();
				}//rightarm
			}
			if ((entity.func_184582_a(EntityEquipmentSlot.LEGS) != null)
					&& (entity.func_184582_a(EntityEquipmentSlot.LEGS).func_77973_b() instanceof ItemArmor_NewObj)) {
				ItemArmor_NewObj armor = (ItemArmor_NewObj) entity.func_184582_a(EntityEquipmentSlot.LEGS).func_77973_b();
				GL11.glPushMatrix();
				Minecraft.func_71410_x().field_71446_o.func_110577_a(new ResourceLocation(armor.obj_tex));
				GL11.glTranslatef(0F, 1.5F, 0.0F);
				if(isSneak){
					GL11.glTranslatef(0F, 0.1875F, -0.25F);
				}
				GL11.glTranslatef(0F, -1.5F, 0.0F);
				armor.obj_model.renderPart("leg");
				this.field_78115_e.field_78806_j = false;
				GL11.glPopMatrix();
				
				GL11.glPushMatrix();
				Minecraft.func_71410_x().field_71446_o.func_110577_a(new ResourceLocation(armor.obj_tex));
				GL11.glTranslatef(-0.125F, 0.75F, 0.0F);
				if(isSneak){
					GL11.glTranslatef(0F, 0.1875F, -0.25F);
				}
				GL11.glRotatef(this.field_178721_j.field_78795_f * (180F / (float)Math.PI), 1.0F, 0.0F, 0.0F);
				GL11.glRotatef(this.field_178721_j.field_78796_g * (180F / (float)Math.PI), 0.0F, 1.0F, 0.0F);
				GL11.glRotatef(this.field_178721_j.field_78808_h * (180F / (float)Math.PI), 0.0F, 0.0F, 1.0F);
				GL11.glTranslatef(0.125F, -0.75F, 0.0F);
				armor.obj_model.renderPart("rightleg");
				this.field_78115_e.field_78806_j = false;
				GL11.glPopMatrix();
				
				GL11.glPushMatrix();
				Minecraft.func_71410_x().field_71446_o.func_110577_a(new ResourceLocation(armor.obj_tex));
				GL11.glTranslatef(0.125F, 0.75F, 0.0F);
				if(isSneak){
					GL11.glTranslatef(0F, 0.1875F, -0.25F);
				}
				GL11.glRotatef(this.field_178722_k.field_78795_f * (180F / (float)Math.PI), 1.0F, 0.0F, 0.0F);
				GL11.glRotatef(this.field_178722_k.field_78796_g * (180F / (float)Math.PI), 0.0F, 1.0F, 0.0F);
				GL11.glRotatef(this.field_178722_k.field_78808_h * (180F / (float)Math.PI), 0.0F, 0.0F, 1.0F);
				GL11.glTranslatef(-0.125F, -0.75F, 0.0F);
				armor.obj_model.renderPart("leftleg");
				this.field_78115_e.field_78806_j = false;
				GL11.glPopMatrix();
			}
			if ((entity.func_184582_a(EntityEquipmentSlot.FEET) != null)
					&& (entity.func_184582_a(EntityEquipmentSlot.FEET).func_77973_b() instanceof ItemArmor_NewObj)) {
				ItemArmor_NewObj armor = (ItemArmor_NewObj) entity.func_184582_a(EntityEquipmentSlot.FEET).func_77973_b();
				GL11.glPushMatrix();
				Minecraft.func_71410_x().field_71446_o.func_110577_a(new ResourceLocation(armor.obj_tex));
				GL11.glTranslatef(-0.125F, 0.75F, 0.0F);
				if(isSneak){
					GL11.glTranslatef(0F, 0.1875F, -0.25F);
				}
				GL11.glRotatef(this.field_178721_j.field_78795_f * (180F / (float)Math.PI), 1.0F, 0.0F, 0.0F);
				GL11.glRotatef(this.field_178721_j.field_78796_g * (180F / (float)Math.PI), 0.0F, 1.0F, 0.0F);
				GL11.glRotatef(this.field_178721_j.field_78808_h * (180F / (float)Math.PI), 0.0F, 0.0F, 1.0F);
				GL11.glTranslatef(0.125F, -0.75F, 0.0F);
				armor.obj_model.renderPart("rightboots");
				this.field_78115_e.field_78806_j = false;
				GL11.glPopMatrix();
				
				GL11.glPushMatrix();
				Minecraft.func_71410_x().field_71446_o.func_110577_a(new ResourceLocation(armor.obj_tex));
				GL11.glTranslatef(0.125F, 0.75F, 0.0F);
				if(isSneak){
					GL11.glTranslatef(0F, 0.1875F, -0.25F);
				}
				GL11.glRotatef(this.field_178722_k.field_78795_f * (180F / (float)Math.PI), 1.0F, 0.0F, 0.0F);
				GL11.glRotatef(this.field_178722_k.field_78796_g * (180F / (float)Math.PI), 0.0F, 1.0F, 0.0F);
				GL11.glRotatef(this.field_178722_k.field_78808_h * (180F / (float)Math.PI), 0.0F, 0.0F, 1.0F);
				GL11.glTranslatef(-0.125F, -0.75F, 0.0F);
				armor.obj_model.renderPart("leftboots");
				this.field_78115_e.field_78806_j = false;
				GL11.glPopMatrix();
			}

			GL11.glDisable(GL12.GL_RESCALE_NORMAL);
			GL11.glPopMatrix();

		}
	}

}
