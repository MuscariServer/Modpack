package gvclib.render;

import org.lwjgl.opengl.GL11;
import gvclib.entity.EntityT_GrenadeT;
import gvclib.mod_GVCLib;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderItem;
import net.minecraft.client.renderer.block.model.ItemCameraTransforms;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.texture.TextureMap;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;


import gvclib.mod_GVCLib;
import gvclib.entity.EntityT_GrenadeT;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderItem;
import net.minecraft.client.renderer.block.model.ItemCameraTransforms;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.texture.TextureMap;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
public class RenderT_GrenadeT<T extends EntityT_GrenadeT> extends Render<T>
{
    private final RenderItem itemRenderer;
    //private final RenderManager rendermanager;

    public RenderT_GrenadeT(RenderManager renderManagerIn, RenderItem itemRendererIn)
    {
        super(renderManagerIn);
        this.itemRenderer = itemRendererIn;
        //this.rendermanager = renderManagerIn;
    }

    /**
     * Renders the desired {@code T} type Entity.
     */
    public void func_76986_a(T entity, double x, double y, double z, float entityYaw, float partialTicks)
    {
    	Minecraft mc = Minecraft.func_71410_x();
    	RenderManager rendermanager = new RenderManager(mc.field_71446_o, mc.func_175599_af());
    	float playerViewY1 = mc.field_71439_g.field_70126_B + (mc.field_71439_g.field_70177_z - mc.field_71439_g.field_70126_B) * partialTicks;
        float playerViewX1 = mc.field_71439_g.field_70127_C + (mc.field_71439_g.field_70125_A - mc.field_71439_g.field_70127_C) * partialTicks;
    	
        GlStateManager.func_179094_E();
        GlStateManager.func_179109_b((float)x, (float)y, (float)z);
        GlStateManager.func_179091_B();
        GlStateManager.func_179114_b(-playerViewY1, 0.0F, 1.0F, 0.0F);
        GlStateManager.func_179114_b((float)(mc.field_71474_y.field_74320_O == 2 ? -1 : 1) * playerViewX1, 1.0F, 0.0F, 0.0F);
        GlStateManager.func_179114_b(180.0F, 0.0F, 1.0F, 0.0F);
        GL11.glScalef(1.2F, 1.2F, 1.2F);
        
        this.func_110776_a(TextureMap.field_110575_b);

        if (this.field_188301_f)
        {
            GlStateManager.func_179142_g();
            GlStateManager.func_187431_e(this.func_188298_c(entity));
        }

        this.itemRenderer.func_181564_a(this.getStackToRender(entity), ItemCameraTransforms.TransformType.GROUND);

        if (this.field_188301_f)
        {
            GlStateManager.func_187417_n();
            GlStateManager.func_179119_h();
        }

        GlStateManager.func_179101_C();
        GlStateManager.func_179121_F();
        super.func_76986_a(entity, x, y, z, entityYaw, partialTicks);
    	
    }

    public ItemStack getStackToRender(T entityIn)
    {
    		return new ItemStack(mod_GVCLib.e_grenadet);
    }

    /**
     * Returns the location of an entity's texture. Doesn't seem to be called unless you call Render.bindEntityTexture.
     */
    protected ResourceLocation func_110775_a(T entity)
    {
        return TextureMap.field_110575_b;
    }
}
