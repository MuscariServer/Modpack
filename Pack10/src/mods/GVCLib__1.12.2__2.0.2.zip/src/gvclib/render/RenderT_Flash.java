package gvclib.render;

import java.io.IOException;
import gvclib.entity.EntityT_Flash;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.resources.IResource;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import objmodel.AdvancedModelLoader;
import objmodel.IModelCustom;
import org.lwjgl.opengl.GL11;


import org.lwjgl.opengl.GL11;

import gvclib.entity.EntityT_Flash;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.resources.IResource;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import objmodel.AdvancedModelLoader;
import objmodel.IModelCustom;

@SideOnly(Side.CLIENT)
public class RenderT_Flash<T extends EntityT_Flash> extends Render<T>
{
    private static final IModelCustom tankk = AdvancedModelLoader.loadModel(new ResourceLocation("gvclib:textures/entity/mflash.mqo"));
    private static final ResourceLocation boatTextures0 = new ResourceLocation("gvclib:textures/entity/mflash.png");

    public RenderT_Flash(RenderManager renderManagerIn)
    {
        super(renderManagerIn);
        //this.rendermanager = renderManagerIn;
    }

   // public  int moi = 0;
	//public  String[] modelt = new String[64];
	//public  IModelCustom[] model = new IModelCustom[64];
    /**
     * Renders the desired {@code T} type Entity.
     */
    public void func_76986_a(T entity, double x, double y, double z, float entityYaw, float partialTicks)
    {
    	
    	Minecraft minecraft = Minecraft.func_71410_x();
        //this.bindEntityTexture(new ResourceLocation(entity.getModel()));
        GlStateManager.func_179094_E();
        //GlStateManager.disableLighting();
        GlStateManager.func_179109_b((float)x, (float)y, (float)z);
        GlStateManager.func_179114_b(entity.field_70126_B + (entity.field_70177_z - entity.field_70126_B) * partialTicks, 0.0F, 1.0F, 0.0F);
        //GlStateManager.rotate(entity.prevRotationPitch + (entity.rotationPitch - entity.prevRotationPitch) * partialTicks, 1.0F, 0.0F, 0.0F);
        GlStateManager.func_179114_b(-entity.field_70125_A, 1.0F, 0.0F, 0.0F);
        
        
        if(entity.model == null && entity.getModel() != null){
        	boolean mo = false;
        	ResourceLocation resource = new ResourceLocation(entity.getModel());
        	try {
        		IResource res = Minecraft.func_71410_x().func_110442_L().func_110536_a(resource);
				if(res != null) {
        		entity.model = AdvancedModelLoader.loadModel(resource);
				}
        		
        	} catch (IOException e) {
				//e.printStackTrace();
				System.out.println(String.format("warning! not exist model!::::" + entity.getModel()));
			}
			
		}
        
        
        if(entity.model != null){
        	
			GL11.glEnable(GL11.GL_BLEND);
			GL11.glDisable(GL11.GL_CULL_FACE);
			GL11.glDepthMask(false);
			GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
			//GL11.glCullFace(GL11.GL_BACK);
			//GL11.glDisable(GL11.GL_DEPTH_TEST);
        	GL11.glColor4f(1F, 1F, 1F, 0.6F);
            minecraft.func_110434_K().func_110577_a(new ResourceLocation(entity.getTex()));
            {
            	GlStateManager.func_179140_f();
            	String tu1 = String.valueOf(entity.time);
            	entity.model.renderPart("mat_" + tu1);
            	
            	float size = partialTicks * 0.4F + 1;
            	GlStateManager.func_179152_a(size, size, size);
            	entity.model.renderPart("mat1");
    			entity.model.renderPart("bullet");
            	 GlStateManager.func_179145_e();
            }
            //GL11.glColor4f(1F, 1F, 1F, 1F);
            //GL11.glEnable(GL11.GL_DEPTH_TEST);
            GL11.glDepthMask(true);
            GL11.glEnable(GL11.GL_CULL_FACE);
            GL11.glDisable(GL11.GL_BLEND);
        }
        GlStateManager.func_179109_b((float)-x, (float)-y, (float)-z);
        GlStateManager.func_179121_F();
        
        
        
        super.func_76986_a(entity, x, y, z, entityYaw, partialTicks);
    }

	@Override
	protected ResourceLocation func_110775_a(T entity) {
		// TODO �����������ꂽ���\�b�h�E�X�^�u
		return boatTextures0;
	}
}
