package gvclib.entity;

import java.io.IOException;
import java.io.NotSerializableException;
import java.util.List;
import java.util.UUID;
import com.google.common.base.Predicate;
import com.google.common.base.Predicates;
import gvclib.event.GVCSoundEvent;
import gvclib.mod_GVCLib;
import gvclib.network.GVCLClientMessageKeyPressed;
import gvclib.network.GVCLPacketHandler;
import gvclib.world.GVCExplosionBase;
import io.netty.buffer.ByteBuf;
import javax.annotation.Nullable;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.IProjectile;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.datasync.DataParameter;
import net.minecraft.network.datasync.DataSerializers;
import net.minecraft.network.datasync.EntityDataManager;
import net.minecraft.util.EntitySelectors;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.datafix.DataFixer;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;
import net.minecraft.world.chunk.Chunk;
import net.minecraftforge.fml.common.registry.IEntityAdditionalSpawnData;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import objmodel.IModelCustom;


import javax.annotation.Nullable;

import com.google.common.base.Predicate;
import com.google.common.base.Predicates;
import com.google.common.io.ByteArrayDataInput;
import com.google.common.io.ByteArrayDataOutput;

import gvclib.mod_GVCLib;
import gvclib.event.GVCSoundEvent;
import gvclib.network.GVCLClientMessageKeyPressed;
import gvclib.network.GVCLPacketHandler;
import gvclib.util.SendEntitydata;
import gvclib.world.GVCExplosionBase;
import io.netty.buffer.ByteBuf;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.IProjectile;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.datasync.DataParameter;
import net.minecraft.network.datasync.DataSerializers;
import net.minecraft.network.datasync.EntityDataManager;
import net.minecraft.util.EntitySelectors;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.datafix.DataFixer;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;
import net.minecraft.world.chunk.Chunk;
import net.minecraftforge.fml.common.registry.IEntityAdditionalSpawnData;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import objmodel.IModelCustom;

public abstract class EntityBBase extends Entity implements IProjectile, IEntityAdditionalSpawnData
{
	private static final Predicate<Entity> ARROW_TARGETS = Predicates.and(EntitySelectors.field_180132_d, EntitySelectors.field_94557_a, new Predicate<Entity>()
    {
        public boolean apply(@Nullable Entity p_apply_1_)
        {
            return p_apply_1_.func_70067_L();
        }
    });
	
	protected static final DataParameter<String> Model = 
    		EntityDataManager.<String>func_187226_a(EntityBBase.class, DataSerializers.field_187194_d);
    protected static final DataParameter<String> Tex = 
    		EntityDataManager.<String>func_187226_a(EntityBBase.class, DataSerializers.field_187194_d);
    public IModelCustom model = null;
    
    public String entity_model = null;
    //public ResourceLocation entity_tex = null;
    public String entity_tex = null;
    
    protected static final DataParameter<String> ModelF = 
    		EntityDataManager.<String>func_187226_a(EntityBBase.class, DataSerializers.field_187194_d);
    protected static final DataParameter<String> TexF = 
    		EntityDataManager.<String>func_187226_a(EntityBBase.class, DataSerializers.field_187194_d);
    public IModelCustom modelf = null;
    
    protected int xTile;
    protected int yTile;
    protected int zTile;
    protected Block inTile;
    protected int inData;
    public boolean inGround;
    public int throwableShake;
    /** The entity that threw this throwable item. */
    private EntityLivingBase thrower;
    private String throwerName;
    protected int ticksInGround;
    protected int ticksInAir;
    public Entity ignoreEntity;
    protected int ignoreTime;
    
    public EntityLivingBase friend = null;
    public double gra = 0.029;//
    public int Bdamege = 5;
    public boolean muteki = false;
    
    public int time;
    public int timemax = 200;
    public boolean smoke = false;
    public boolean ex =false;
    public boolean exfire =false;
    public boolean exsmoke =false;
    public boolean exflash =false;
    public boolean exgas =false;
    public float exlevel = 0.0F;
    
    public int extime = 80;
    public boolean exinground = false;
    
    public int bulletDameID = 0;
    public int P_ID = 0;
    public int P_LEVEL = 5;
    public int P_TIME = 200;
    
    public double startposX = 0;
    public double startposY = 0;
    public double startposZ = 0;
    
    //0916
    public EntityLivingBase mitarget = null;
    public int mitargetid = -1;
	private int timeInGround;
	private int arrowShake;
	
	//10/19
	public boolean fly_sound = true;
	
	//12/01
	public boolean spg_fly_sound = false;
	
    public EntityBBase(World worldIn)
    {
        super(worldIn);
        this.xTile = -1;
        this.yTile = -1;
        this.zTile = -1;
        
        this.func_70105_a(0.15F, 0.15F);
    }

    public EntityBBase(World worldIn, double x, double y, double z)
    {
        this(worldIn);
        this.func_70107_b(x, y, z);
    }

    public EntityBBase(World worldIn, EntityLivingBase throwerIn)
    {
        this(worldIn, throwerIn.field_70165_t, throwerIn.field_70163_u + (double)throwerIn.func_70047_e() - 0.10000000149011612D, throwerIn.field_70161_v);
        this.thrower = throwerIn;
        
        float f1 = 0.4F;
		field_70159_w = -MathHelper.func_76126_a((field_70177_z / 180F) * 3.141593F) * MathHelper.func_76134_b((field_70125_A / 180F) * 3.141593F) * f1;
		field_70179_y = MathHelper.func_76134_b((field_70177_z / 180F) * 3.141593F) * MathHelper.func_76134_b((field_70125_A / 180F) * 3.141593F) * f1;
//		motionY = -MathHelper.sin(((rotationPitch + func_70183_g()) / 180F) * 3.141593F) * f1;
    }

    protected void func_70088_a()
    {
    	this.field_70180_af.func_187214_a(Model, new String("gvclib:textures/entity/bulletnormal.obj"));
        this.field_70180_af.func_187214_a(Tex, new String("gvclib:textures/entity/bulletnormal.png"));
        this.field_70180_af.func_187214_a(ModelF, new String("gvclib:textures/entity/mflash.mqo"));
        this.field_70180_af.func_187214_a(TexF, new String("gvclib:textures/entity/mflash.png"));
        if (field_70170_p != null) {
			field_70178_ae = !field_70170_p.field_72995_K;
		}
    }

    /**
     * Checks if the entity is in range to render.
     */
    @SideOnly(Side.CLIENT)
    public boolean func_70112_a(double distance)
    {
        double d0 = this.func_174813_aQ().func_72320_b();

        if (Double.isNaN(d0))
        {
            d0 = 1.0D;
        }

        d0 = d0 * 64.0D * mod_GVCLib.cfg_entity_render_range;
        return distance < d0 * d0;
    }
    
    /**
     * Checks if the entity is in range to render.
     */
    /*@SideOnly(Side.CLIENT)
    public boolean isInRangeToRenderDist(double distance)
    {
        double d0 = this.getEntityBoundingBox().getAverageEdgeLength() * 4.0D;

        if (Double.isNaN(d0))
        {
            d0 = 4.0D;
        }

        d0 = d0 * 64.0D;
        return distance < d0 * d0;
    }*/

    /**
     * Sets throwable heading based on an entity that's throwing it
     */
    public void setHeadingFromThrower(Entity entityThrower, float rotationPitchIn, float rotationYawIn, float pitchOffset, float velocity, float inaccuracy)
    {
        float f = -MathHelper.func_76126_a(rotationYawIn * 0.017453292F) * MathHelper.func_76134_b(rotationPitchIn * 0.017453292F);
        float f1 = -MathHelper.func_76126_a((rotationPitchIn + pitchOffset) * 0.017453292F);
        float f2 = MathHelper.func_76134_b(rotationYawIn * 0.017453292F) * MathHelper.func_76134_b(rotationPitchIn * 0.017453292F);
        this.setThrowableHeading((double)f, (double)f1, (double)f2, velocity, inaccuracy);
        this.field_70159_w += entityThrower.field_70159_w;
        this.field_70179_y += entityThrower.field_70179_y;

        if (!entityThrower.field_70122_E)
        {
            this.field_70181_x += entityThrower.field_70181_x;
        }
        if(!this.field_70170_p.field_72995_K)if(time < 20)GVCLPacketHandler.INSTANCE2.sendToAll(new GVCLClientMessageKeyPressed(321, this.func_145782_y(), this));
    }

    /**
     * Similar to setArrowHeading, it's point the throwable entity to a x, y, z direction.
     */
    public void setThrowableHeading(double x, double y, double z, float velocity, float inaccuracy)
    {
        float f = MathHelper.func_76133_a(x * x + y * y + z * z);
        x = x / (double)f;
        y = y / (double)f;
        z = z / (double)f;
        //x = x + this.rand.nextGaussian() * 0.007499999832361937D * (double)inaccuracy;
        //y = y + this.rand.nextGaussian() * 0.007499999832361937D * (double)inaccuracy;
        //z = z + this.rand.nextGaussian() * 0.007499999832361937D * (double)inaccuracy;
        x += this.field_70146_Z.nextGaussian() * (double)(this.field_70146_Z.nextBoolean() ? -1 : 1) * 0.01 * (double)inaccuracy;
        y += this.field_70146_Z.nextGaussian() * (double)(this.field_70146_Z.nextBoolean() ? -1 : 1) * 0.01 * (double)inaccuracy;
        z += this.field_70146_Z.nextGaussian() * (double)(this.field_70146_Z.nextBoolean() ? -1 : 1) * 0.01 * (double)inaccuracy;
        x = x * (double)velocity;
        y = y * (double)velocity;
        z = z * (double)velocity;
        this.field_70159_w = x;
        this.field_70181_x = y;
        this.field_70179_y = z;
        float f1 = MathHelper.func_76133_a(x * x + z * z);
        this.field_70177_z = (float)(MathHelper.func_181159_b(x, z) * (180D / Math.PI));
        this.field_70125_A = (float)(MathHelper.func_181159_b(y, (double)f1) * (180D / Math.PI));
        this.field_70126_B = this.field_70177_z;
        this.field_70127_C = this.field_70125_A;
        this.ticksInGround = 0;
        
        if(!this.field_70170_p.field_72995_K)if(time < 20)GVCLPacketHandler.INSTANCE2.sendToAll(new GVCLClientMessageKeyPressed(321, this.func_145782_y(), this));
    }

    /**
    * Set the position and rotation values directly without any clamping.
    */
   @SideOnly(Side.CLIENT)
   public void func_180426_a(double x, double y, double z, float yaw, float pitch, int posRotationIncrements, boolean teleport)
   {
	   if (!inGround) 
	   {
		   this.func_70107_b(x, y, z);
	       this.func_70101_b(yaw, pitch);
	   }
   }
    
   /*
   @Override
	public void setPositionAndRotation2(double par1, double par3, double par5,
			float par7, float par8, int par9) {
		// 着弾後に変な移動が起こるのを抑制
		if (!inGround) {
			setPosition(par1, par3, par5);
			setRotation(par7, par8);
		}
	}
   */
    /**
     * Updates the velocity of the entity to a new value.
     */
    @SideOnly(Side.CLIENT)
    public void func_70016_h(double x, double y, double z)
    {
        this.field_70159_w = x;
        this.field_70181_x = y;
        this.field_70179_y = z;

        if (this.field_70127_C == 0.0F && this.field_70126_B == 0.0F)
        {
            float f = MathHelper.func_76133_a(x * x + z * z);
            this.field_70177_z = (float)(MathHelper.func_181159_b(x, z) * (180D / Math.PI));
            this.field_70125_A = (float)(MathHelper.func_181159_b(y, (double)f) * (180D / Math.PI));
           // this.prevRotationYaw = this.rotationYaw;
           // this.prevRotationPitch = this.rotationPitch;
            this.func_70012_b(this.field_70165_t, this.field_70163_u, this.field_70161_v, this.field_70177_z, this.field_70125_A);
			this.ticksInGround = 0;
        }
    }

    /*
    @SideOnly(Side.CLIENT)
    public int getBrightnessForRender(float partialTicks)
    {
        return 15728880;
    }
    */

    /**
     * Gets how bright this entity is.
     */
    /*public float getBrightness(float partialTicks)
    {
        return 1.0F;
    }*/
    /**
     * Checks to make sure the light is not too bright where the mob is spawning
     */
   /* protected boolean isValidLightLevel()
    {
        return true;
    }*/
    
    @SideOnly(Side.CLIENT)
    public int func_70070_b()
    {
        return 15728880;
    }

    /**
     * Gets how bright this entity is.
     */
    public float func_70013_c()
    {
        return 1.0F;
    }
    
    /**
     * Checks to make sure the light is not too bright where the mob is spawning
     */
    protected boolean isValidLightLevel()
    {
        return true;
    }
    
    /**
     * Sets throwable heading based on an entity that's throwing it
     */
    public void shoot(Entity entityThrower, float rotationPitchIn, float rotationYawIn, float pitchOffset, float velocity, float inaccuracy)
    {
        float f = -MathHelper.func_76126_a(rotationYawIn * 0.017453292F) * MathHelper.func_76134_b(rotationPitchIn * 0.017453292F);
        float f1 = -MathHelper.func_76126_a((rotationPitchIn + pitchOffset) * 0.017453292F);
        float f2 = MathHelper.func_76134_b(rotationYawIn * 0.017453292F) * MathHelper.func_76134_b(rotationPitchIn * 0.017453292F);
        this.func_70186_c((double)f, (double)f1, (double)f2, velocity, inaccuracy);
        this.field_70159_w += entityThrower.field_70159_w;
        this.field_70179_y += entityThrower.field_70179_y;

        if (!entityThrower.field_70122_E)
        {
            this.field_70181_x += entityThrower.field_70181_x;
        }
    }

    /**
     * Similar to setArrowHeading, it's point the throwable entity to a x, y, z direction.
     */
    public void func_70186_c(double x, double y, double z, float velocity, float inaccuracy)
    {
        float f = MathHelper.func_76133_a(x * x + y * y + z * z);
        x = x / (double)f;
        y = y / (double)f;
        z = z / (double)f;
        x = x + this.field_70146_Z.nextGaussian() * 0.007499999832361937D * (double)inaccuracy;
        y = y + this.field_70146_Z.nextGaussian() * 0.007499999832361937D * (double)inaccuracy;
        z = z + this.field_70146_Z.nextGaussian() * 0.007499999832361937D * (double)inaccuracy;
        x = x * (double)velocity;
        y = y * (double)velocity;
        z = z * (double)velocity;
        this.field_70159_w = x;
        this.field_70181_x = y;
        this.field_70179_y = z;
        float f1 = MathHelper.func_76133_a(x * x + z * z);
        this.field_70177_z = (float)(MathHelper.func_181159_b(x, z) * (180D / Math.PI));
        this.field_70125_A = (float)(MathHelper.func_181159_b(y, (double)f1) * (180D / Math.PI));
        this.field_70126_B = this.field_70177_z;
        this.field_70127_C = this.field_70125_A;
        this.ticksInGround = 0;
        
        if(!this.field_70170_p.field_72995_K)if(time < 20)GVCLPacketHandler.INSTANCE2.sendToAll(new GVCLClientMessageKeyPressed(321, this.func_145782_y(), this));
    }
    
    /**
     * Called to update the entity's position/logic.
     */
    public void func_70071_h_()
    {
    	int fps = mod_GVCLib.proxy.getFPS();
		if(fps < 15)return;
		Chunk chunk = this.field_70170_p.func_175726_f(new BlockPos(this.field_70165_t, this.field_70163_u, this.field_70161_v));
		if (chunk.func_76621_g())return;
		
		//試作
		if(!this.field_70170_p.field_72995_K)if(time < 20)GVCLPacketHandler.INSTANCE2.sendToAll(new GVCLClientMessageKeyPressed(321, this.func_145782_y(), this));
		
    	if (this.field_70127_C == 0.0F && this.field_70126_B == 0.0F)
        {
            float f = MathHelper.func_76133_a(this.field_70159_w * this.field_70159_w + this.field_70179_y * this.field_70179_y);
            this.field_70177_z = (float)(MathHelper.func_181159_b(this.field_70159_w, this.field_70179_y) * (180D / Math.PI));
            this.field_70125_A = (float)(MathHelper.func_181159_b(this.field_70181_x, (double)f) * (180D / Math.PI));
            this.field_70126_B = this.field_70177_z;
            this.field_70127_C = this.field_70125_A;
        }

        BlockPos blockpos = new BlockPos(this.xTile, this.yTile, this.zTile);
        IBlockState iblockstate = this.field_70170_p.func_180495_p(blockpos);
        Block block = iblockstate.func_177230_c();
        
        if (iblockstate.func_185904_a() != Material.field_151579_a)
        {
            AxisAlignedBB axisalignedbb = iblockstate.func_185890_d(this.field_70170_p, blockpos);

            if (axisalignedbb != Block.field_185506_k && axisalignedbb.func_186670_a(blockpos).func_72318_a(new Vec3d(this.field_70165_t, this.field_70163_u, this.field_70161_v)))
            {
                this.inGround = true;
            }
        }

        if (this.arrowShake > 0)
        {
            --this.arrowShake;
        }

        if (this.inGround)
        {
            int j = block.func_176201_c(iblockstate);

            if ((block != this.inTile || j != this.inData) && !this.field_70170_p.func_184143_b(this.func_174813_aQ().func_186662_g(0.05D)))
            {
                this.inGround = false;
                this.field_70159_w *= (double)(this.field_70146_Z.nextFloat() * 0.002F);
                this.field_70181_x *= (double)(this.field_70146_Z.nextFloat() * 0.002F);
                this.field_70179_y *= (double)(this.field_70146_Z.nextFloat() * 0.002F);
                this.ticksInGround = 0;
                this.ticksInAir = 0;
            }
            else
            {
                ++this.ticksInGround;

                if (this.ticksInGround >= timemax/2)
                {
                    this.func_70106_y();
                }
            }

            ++this.timeInGround;
        }
        else
        {
            this.timeInGround = 0;
            ++this.ticksInAir;
            Vec3d vec3d1 = new Vec3d(this.field_70165_t, this.field_70163_u, this.field_70161_v);
            Vec3d vec3d = new Vec3d(this.field_70165_t + this.field_70159_w, this.field_70163_u + this.field_70181_x, this.field_70161_v + this.field_70179_y);
            RayTraceResult raytraceresult = this.field_70170_p.func_147447_a(vec3d1, vec3d, false, true, false);
            vec3d1 = new Vec3d(this.field_70165_t, this.field_70163_u, this.field_70161_v);
            vec3d = new Vec3d(this.field_70165_t + this.field_70159_w, this.field_70163_u + this.field_70181_x, this.field_70161_v + this.field_70179_y);

            if (raytraceresult != null)
            {
                vec3d = new Vec3d(raytraceresult.field_72307_f.field_72450_a, raytraceresult.field_72307_f.field_72448_b, raytraceresult.field_72307_f.field_72449_c);
            }

            Entity entity = this.findEntityOnPath(vec3d1, vec3d);

           // if (entity != null && entity != this.friend)
            if (entity != null)
            {
                raytraceresult = new RayTraceResult(entity);
            }

            if (raytraceresult != null && raytraceresult.field_72308_g instanceof EntityPlayer)
            {
                EntityPlayer entityplayer = (EntityPlayer)raytraceresult.field_72308_g;

                if (this.getThrower() instanceof EntityPlayer && !((EntityPlayer)this.getThrower()).func_96122_a(entityplayer))
                {
                    raytraceresult = null;
                }
            }
            if (raytraceresult != null && raytraceresult.field_72308_g instanceof EntityLivingBase)
            {
            	EntityLivingBase en = (EntityLivingBase) raytraceresult.field_72308_g;
            	if(this.getThrower() != null && en.func_184179_bs() == this.getThrower()) {
            		raytraceresult = null;
            	}
            	for(int m = 0; m < en.func_184188_bt().size(); ++m) {
            		if(this.getThrower() != null && en.func_184188_bt().get(m) == this.getThrower()) {
                		raytraceresult = null;
                	}
            	}
            	
            }
            

            if (raytraceresult != null)
            {
            	this.onImpact(raytraceresult);
            }

            

            this.field_70165_t += this.field_70159_w;
            this.field_70163_u += this.field_70181_x;
            this.field_70161_v += this.field_70179_y;
            
            //試作
            if(!this.field_70170_p.field_72995_K)if(time < 20)GVCLPacketHandler.INSTANCE2.sendToAll(new GVCLClientMessageKeyPressed(321, this.func_145782_y(), this));
            
            float f4 = MathHelper.func_76133_a(this.field_70159_w * this.field_70159_w + this.field_70179_y * this.field_70179_y);
            this.field_70177_z = (float)(MathHelper.func_181159_b(this.field_70159_w, this.field_70179_y) * (180D / Math.PI));

            for (this.field_70125_A = (float)(MathHelper.func_181159_b(this.field_70181_x, (double)f4) * (180D / Math.PI)); this.field_70125_A - this.field_70127_C < -180.0F; this.field_70127_C -= 360.0F)
            {
                ;
            }

            while (this.field_70125_A - this.field_70127_C >= 180.0F)
            {
                this.field_70127_C += 360.0F;
            }

            while (this.field_70177_z - this.field_70126_B < -180.0F)
            {
                this.field_70126_B -= 360.0F;
            }

            while (this.field_70177_z - this.field_70126_B >= 180.0F)
            {
                this.field_70126_B += 360.0F;
            }

            this.field_70125_A = this.field_70127_C + (this.field_70125_A - this.field_70127_C) * 0.2F;
            this.field_70177_z = this.field_70126_B + (this.field_70177_z - this.field_70126_B) * 0.2F;
            float f1 = 0.999F;
            float f2 = this.getGravityVelocity();

            if (this.func_70090_H())
            {
                for (int i = 0; i < 4; ++i)
                {
                    float f3 = 0.25F;
                    this.field_70170_p.func_175688_a(EnumParticleTypes.WATER_BUBBLE, this.field_70165_t - this.field_70159_w * 0.25D, this.field_70163_u - this.field_70181_x * 0.25D, this.field_70161_v - this.field_70179_y * 0.25D, this.field_70159_w, this.field_70181_x, this.field_70179_y);
                }

                f1 = 0.6F;
            }

            if (this.func_70026_G())
            {
                this.func_70066_B();
            }

            this.field_70159_w *= (double)f1;
            this.field_70181_x *= (double)f1;
            this.field_70179_y *= (double)f1;

            if (!this.func_189652_ae())
            {
               // this.motionY -= 0.05000000074505806D;
            	this.field_70181_x -= (double)f2 - this.gra;
            }

            this.func_70107_b(this.field_70165_t, this.field_70163_u, this.field_70161_v);
            this.func_145775_I();
            //試作
            if(!this.field_70170_p.field_72995_K)if(time < 20)GVCLPacketHandler.INSTANCE2.sendToAll(new GVCLClientMessageKeyPressed(321, this.func_145782_y(), this));
        }
        ++time;
        if(time > timemax){
        	if(!this.field_70170_p.field_72995_K){
        		//System.out.println(String.format("dead"));
        	this.func_70106_y();
        	}
        }
 //       double ddx = Math.abs(motionX);
 //       double ddz = Math.abs(motionZ);
        /*if(ddx < 0.2 && ddz < 0.2){
        	if(!this.world.isRemote){
        	this.setDead();
        	}
        }*/
        if(this.field_70170_p.func_72820_D() %10 == 0 && time > 8 && this.field_70181_x < 0 && spg_fly_sound) {
   		 this.func_184185_a(GVCSoundEvent.sound_fall_shell, 6F, 1.0F);
   	 }
    }

    /**
     * Gets the amount of gravity to apply to the thrown entity with each tick.
     */
    protected float getGravityVelocity()
    {
        return 0.03F;
    }

    @Nullable
    protected Entity findEntityOnPath(Vec3d start, Vec3d end)
    {
        Entity entity = null;
        List<Entity> list = this.field_70170_p.func_175674_a(this, this.func_174813_aQ().func_72321_a(this.field_70159_w, this.field_70181_x, this.field_70179_y).func_186662_g(1.0D), ARROW_TARGETS);
        //List<Entity> list = this.world.getEntitiesWithinAABBExcludingEntity(this, this.getEntityBoundingBox().expand(this.motionX, this.motionY, this.motionZ).grow(1.0D));
        double d0 = 0.0D;

        for (int i = 0; i < list.size(); ++i)
        {
            Entity entity1 = list.get(i);

            if (entity1 != this.getThrower() || this.ticksInAir >= 5)
            {
                AxisAlignedBB axisalignedbb = entity1.func_174813_aQ().func_186662_g(0.30000001192092896D);
                RayTraceResult raytraceresult = axisalignedbb.func_72327_a(start, end);

                if (raytraceresult != null)
                {
                    double d1 = start.func_72436_e(raytraceresult.field_72307_f);

                    if (d1 < d0 || d0 == 0.0D)
                    {
                        entity = entity1;
                        d0 = d1;
                    }
                }
            }
        }

        return entity;
    }
    
    /**
     * Called when this EntityThrowable hits a block or entity.
     */
    protected abstract void onImpact(RayTraceResult result);
    
    
    public void hitbullet() {
    	{
    		double x = this.field_70165_t;
			double y = this.field_70163_u;
			double z = this.field_70161_v;
			double han = 0.3;
			AxisAlignedBB aabb = (new AxisAlignedBB((double) (x - han), (double) (y - han),
					(double) (z - han),
					(double) (x + han), (double) (y + han), (double) (z + han)))
							.func_186662_g(han);
	        List llist2 = this.field_70170_p.func_72872_a(Entity.class, aabb);
	        if(llist2!=null){
	            for (int lj = 0; lj < llist2.size(); lj++) {
	            	Entity entity1 = (Entity)llist2.get(lj);
	                {
	            		if ((entity1 instanceof IProjectile) && entity1 != null && entity1 != this && !(entity1 instanceof EntityTNTBase))
	                    {
	            			if(entity1 instanceof EntityBBase) {
	            				EntityBBase bullet = (EntityBBase) entity1;
	            				if(bullet.getThrower() != this.getThrower()) {
	            					if (!entity1.field_70170_p.field_72995_K) 
									{
			            				GVCExplosionBase.ExplosionKai(this.getThrower(), this, this.field_70165_t + 0, this.field_70163_u + 0, this.field_70161_v + 0, this.exlevel, false,  this.ex);
			            				this.func_70106_y();
										entity1.func_70106_y();
									}
	            				}
	            			}else {
	            				if (!entity1.field_70170_p.field_72995_K && this.getThrower() != null) 
								{
		            				GVCExplosionBase.ExplosionKai(this.getThrower(), this, this.field_70165_t + 0, this.field_70163_u + 0, this.field_70161_v + 0, this.exlevel, false,  this.ex);
		            				this.func_70106_y();
									entity1.func_70106_y();
								}
	            			}
	                    }
	                }
	            }
	        }
    	}
    }

    public static void func_189661_a(DataFixer fixer, String name)
    {
    }

    
 // Forge用
    //1.6.2より移植
 	@Override
 	public void writeSpawnData(ByteBuf data) {
 		// 通常の方法では速度が足りないので特別仕様
 		data.writeInt(thrower == null ? func_145782_y() : thrower.func_145782_y());
 		data.writeInt(Float.floatToIntBits((float)field_70159_w));
 		data.writeInt(Float.floatToIntBits((float)field_70181_x));
 		data.writeInt(Float.floatToIntBits((float)field_70179_y));
 		/*PacketBuffer lpbuf = new PacketBuffer(data);
 		SendEntitydata dataentity = new SendEntitydata(this);
        try {
            lpbuf.writeInt(fromObject(dataentity).length);
            lpbuf.writeBytes(fromObject(dataentity));
        } catch (NotSerializableException e){
            e.printStackTrace();
        } catch (IOException e){
            e.printStackTrace();
        }*/
 		/*System.out.println(String.format("%1$.3f", motionX));
 		System.out.println(String.format("%1$.3f", motionY));
 		System.out.println(String.format("%1$.3f", motionZ));*/
 //		System.out.println(String.format("write"));
 	}

 	@Override
 	public void readSpawnData(ByteBuf data) {
 		// 通常の方法では速度が足りないので特別仕様
 		int lthrower = data.readInt();
 		if (lthrower != 0) {
 			Entity lentity = field_70170_p.func_73045_a(lthrower);
 			if (lentity instanceof EntityLivingBase) {
 				thrower = (EntityLivingBase)lentity;
 			}
 		}
 		field_70159_w = (double)Float.intBitsToFloat(data.readInt());
 		field_70181_x = (double)Float.intBitsToFloat(data.readInt());
 		field_70179_y = (double)Float.intBitsToFloat(data.readInt());
 		/*System.out.println(String.format("%1$.3f", motionX));
 		System.out.println(String.format("%1$.3f", motionY));
 		System.out.println(String.format("%1$.3f", motionZ));*/
// 		setVelocity(motionX, motionY, motionZ);
// 		System.out.println(String.format("read"));
 	}
    
    /**
     * (abstract) Protected helper method to write subclass entity data to NBT.
     */
    public void func_70014_b(NBTTagCompound compound)
    {
        compound.func_74768_a("xTile", this.xTile);
        compound.func_74768_a("yTile", this.yTile);
        compound.func_74768_a("zTile", this.zTile);
        ResourceLocation resourcelocation = (ResourceLocation)Block.field_149771_c.func_177774_c(this.inTile);
        compound.func_74778_a("inTile", resourcelocation == null ? "" : resourcelocation.toString());
        compound.func_74774_a("shake", (byte)this.throwableShake);
        compound.func_74774_a("inGround", (byte)(this.inGround ? 1 : 0));

        if ((this.throwerName == null || this.throwerName.isEmpty()) && this.thrower instanceof EntityPlayer)
        {
            this.throwerName = this.thrower.func_70005_c_();
        }

        compound.func_74778_a("ownerName", this.throwerName == null ? "" : this.throwerName);
        
        compound.func_74778_a("Model", this.getModel());
        compound.func_74778_a("Tex", this.getTex());
        compound.func_74778_a("ModelF", this.getModelF());
        compound.func_74778_a("TexF", this.getTexF());
        
    }

    /**
     * (abstract) Protected helper method to read subclass entity data from NBT.
     */
    public void func_70037_a(NBTTagCompound compound)
    {
        this.xTile = compound.func_74762_e("xTile");
        this.yTile = compound.func_74762_e("yTile");
        this.zTile = compound.func_74762_e("zTile");

        if (compound.func_150297_b("inTile", 8))
        {
            this.inTile = Block.func_149684_b(compound.func_74779_i("inTile"));
        }
        else
        {
            this.inTile = Block.func_149729_e(compound.func_74771_c("inTile") & 255);
        }

        this.throwableShake = compound.func_74771_c("shake") & 255;
        this.inGround = compound.func_74771_c("inGround") == 1;
        this.thrower = null;
        this.throwerName = compound.func_74779_i("ownerName");

        if (this.throwerName != null && this.throwerName.isEmpty())
        {
            this.throwerName = null;
        }

        this.thrower = this.getThrower();
        
        {
        	this.setModel(compound.func_74779_i("Model"));
        }
        {
        	this.setTex(compound.func_74779_i("Tex"));
        }
        {
        	this.setModelF(compound.func_74779_i("ModelF"));
        }
        {
        	this.setTexF(compound.func_74779_i("TexF"));
        }
    }

   
    public String getModel() {
		return ((this.field_70180_af.func_187225_a(Model)));
	}
	public void setModel(String s) {
		this.field_70180_af.func_187227_b(Model, String.valueOf(new String(s)));
	}
	public String getTex() {
		return ((this.field_70180_af.func_187225_a(Tex)));
	}
	public void setTex(String s) {
		this.field_70180_af.func_187227_b(Tex, String.valueOf(new String(s)));
	}
	
	public String getModelF() {
		return ((this.field_70180_af.func_187225_a(ModelF)));
	}
	public void setModelF(String s) {
		this.field_70180_af.func_187227_b(ModelF, String.valueOf(new String(s)));
	}
	public String getTexF() {
		return ((this.field_70180_af.func_187225_a(TexF)));
	}
	public void setTexF(String s) {
		this.field_70180_af.func_187227_b(TexF, String.valueOf(new String(s)));
	}
    
    /*public String getModel() {
		return "";
	}
	public void setModel(String s) {
		
	}
	public String getTex() {
		return "";
	}
	public void setTex(String s) {
		
	}
	
	public String getModelF() {
		return "";
	}
	public void setModelF(String s) {
		
	}
	public String getTexF() {
		return "";
	}
	public void setTexF(String s) {
		
	}*/
    
    @Nullable
    public EntityLivingBase getThrower()
    {
        if (this.thrower == null && this.throwerName != null && !this.throwerName.isEmpty())
        {
            this.thrower = this.field_70170_p.func_72924_a(this.throwerName);

            if (this.thrower == null && this.field_70170_p instanceof WorldServer)
            {
                try
                {
                    Entity entity = ((WorldServer)this.field_70170_p).func_175733_a(UUID.fromString(this.throwerName));

                    if (entity instanceof EntityLivingBase)
                    {
                        this.thrower = (EntityLivingBase)entity;
                    }
                }
                catch (Throwable var2)
                {
                    this.thrower = null;
                }
            }
        }

        return this.thrower;
    }
    
    /** 指定した座礁のブロックをChunkLoaderとして起動する */
    /*public static boolean setBlockTicket(World world, int x, int y, int z) {
        return false;
    }
    
    /**
     * ChunkLoaderに実装するinterface<br>
     * worldがロードされた時に呼ばれる。trueを返すとChunkLoaderが始まる。
     * */
    /*public interface IChunkLoaderBlock {

        public boolean canLoad(World world, int x, int y, int z);

    }*/
}
