package gvclib.entity;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.MoverType;
import net.minecraft.util.datafix.DataFixer;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.world.World;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public class EntityT_Flash extends EntityTNTBase {
	public EntityT_Flash(World worldIn) {
		super(worldIn);
	}

	public EntityT_Flash(World worldIn, EntityLivingBase throwerIn) {
		super(worldIn, throwerIn);
	}

	public EntityT_Flash(World worldIn, double x, double y, double z) {
		super(worldIn, x, y, z);
	}

	public static void func_189662_a(DataFixer p_189662_0_) {
		EntityBBase.func_189661_a(p_189662_0_, "Snowball");
	}
	
	@SideOnly(Side.CLIENT)
    public int func_70070_b()
    {
        return 15728880;
    }

    /**
     * Gets how bright this entity is.
     */
    public float func_70013_c()
    {
        return 1.0F;
    }
    
    /**
     * Checks to make sure the light is not too bright where the mob is spawning
     */
    protected boolean isValidLightLevel()
    {
        return true;
    }

	public void func_70071_h_()
    {
        super.func_70071_h_();
        this.field_70169_q = this.field_70165_t;
        this.field_70167_r = this.field_70163_u;
        this.field_70166_s = this.field_70161_v;
        //this.motionY -= 0.03999999910593033D;
        this.func_70091_d(MoverType.SELF, this.field_70159_w, this.field_70181_x, this.field_70179_y);
        this.field_70159_w *= 0.9800000190734863D;
        //this.motionY *= 0.9800000190734863D;
        this.field_70179_y *= 0.9800000190734863D;
        
        ++time;
        if(time > timemax){
        	if(!this.field_70170_p.field_72995_K){
        	this.func_70106_y();
        	}
        }
        /*else
        {
            this.handleWaterMovement();
        }*/
    }
	
	private void explode()
    {
        float f = 4.0F;
        this.field_70170_p.func_72876_a(this, this.field_70165_t, this.field_70163_u + (double)(this.field_70131_O / 16.0F), this.field_70161_v, exlevel, ex);
    }
	
	/**
	 * Called when this EntityThrowable hits a block or entity.
	 */
	protected void onImpact(RayTraceResult result) {
	}

	@Override
	public void func_70186_c(double x, double y, double z, float velocity, float inaccuracy) {
		// TODO 自動生成されたメソッド・スタブ
		
	}
}
