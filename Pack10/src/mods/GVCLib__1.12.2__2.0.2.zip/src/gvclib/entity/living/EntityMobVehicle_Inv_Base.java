package gvclib.entity.living;

import java.util.List;
import gvclib.entity.trader.ContainerInventoryBox;
import gvclib.event.GVCSoundEvent;
import gvclib.mod_GVCLib;
import gvclib.network.GVCLClientMessageKeyPressed;
import gvclib.network.GVCLMessageKeyPressed;
import gvclib.network.GVCLPacketHandler;
import net.minecraft.block.Block;
import net.minecraft.block.BlockLilyPad;
import net.minecraft.block.BlockLog;
import net.minecraft.block.BlockNewLeaf;
import net.minecraft.block.BlockOldLeaf;
import net.minecraft.block.BlockOldLog;
import net.minecraft.block.BlockPane;
import net.minecraft.block.BlockPlanks;
import net.minecraft.block.BlockStone;
import net.minecraft.block.BlockStoneBrick;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.monster.IMob;
import net.minecraft.entity.passive.IAnimals;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.SoundEvents;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.IInventoryChangedListener;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.EnumDifficulty;
import net.minecraft.world.World;


import gvclib.mod_GVCLib;
import gvclib.entity.trader.ContainerInventoryBox;
import gvclib.event.GVCSoundEvent;
import gvclib.network.GVCLClientMessageKeyPressed;
import gvclib.network.GVCLMessageKeyPressed;
import gvclib.network.GVCLPacketHandler;
import net.minecraft.block.Block;
import net.minecraft.block.BlockLilyPad;
import net.minecraft.block.BlockLog;
import net.minecraft.block.BlockNewLeaf;
import net.minecraft.block.BlockOldLeaf;
import net.minecraft.block.BlockOldLog;
import net.minecraft.block.BlockPane;
import net.minecraft.block.BlockPlanks;
import net.minecraft.block.BlockStone;
import net.minecraft.block.BlockStoneBrick;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
//import mcdungeons.mod_MCDungeons;
//import mcdungeons.entity.MCDContainerInventoryBox;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.monster.IMob;
import net.minecraft.entity.passive.IAnimals;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.SoundEvents;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.IInventoryChangedListener;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.EnumDifficulty;
import net.minecraft.world.World;

public class EntityMobVehicle_Inv_Base extends EntityMobVehicleBase implements IAnimals,IInventoryChangedListener
{
	
	public ContainerInventoryBox horseChest;
	
	public int slot_max = 27;
	
	/**乗り物のタイプ
	 * 0=普通の戦車
	 * 1=対空戦車
	 * 2=自走砲系
	 * */
	public int vehicle_type = 0;
	
	public boolean can_fuel = false;
	public int fuel = 0;
	public int fuel_max = 1200;
	public Item fuel_item = null;
	
	public boolean can_weapon1 = false;
	public Item weapon1_item = null;
	public boolean can_weapon2 = false;
	public Item weapon2_item = null;
	
	
    public EntityMobVehicle_Inv_Base(World worldIn)
    {
        super(worldIn);
        this.initHorseChest();
        
    }

    
	public boolean func_184645_a(EntityPlayer player, EnumHand hand) {
		//cooltime = 0;
		if (player.func_70093_af()) {
			NBTTagCompound nbt = player.getEntityData();
			nbt.func_74768_a("vi", this.func_145782_y());
			player.openGui(mod_GVCLib.INSTANCE, 4,
					player.field_70170_p, (int) player.field_70165_t, (int) player.field_70163_u, (int) player.field_70161_v);
			{
				this.field_70170_p.func_184148_a((EntityPlayer)null, this.field_70165_t, this.field_70163_u, this.field_70161_v, 
		    			SoundEvents.field_187657_V, SoundCategory.NEUTRAL, 0.5F, 1.0F);
			}
		}else {
			super.func_184645_a(player, hand);
		}
		return true;
	}
    
	public boolean rogin = false;
    public void func_70636_d() {
		super.func_70636_d();
		if(!this.field_70170_p.field_72995_K && !rogin){
			ItemStack fuel_stack = this.horseChest.func_70301_a(63);
			if(!fuel_stack.func_190926_b()) {
				Item item = this.horseChest.func_70301_a(63).func_77973_b();
				GVCLPacketHandler.INSTANCE2.sendToAll(new GVCLClientMessageKeyPressed(3063, 
						this.func_145782_y(), 63, item.func_150891_b(item), fuel_stack.func_190916_E()));
			}
			for (int i = 0; i < 5; ++i) {
				ItemStack soi1 = (ItemStack) this.horseChest.func_70301_a(40 + i);
				ItemStack soi2 = (ItemStack) this.horseChest.func_70301_a(50 + i);
				if(!soi1.func_190926_b()) {
					Item item = this.horseChest.func_70301_a(40 + i).func_77973_b();
					GVCLPacketHandler.INSTANCE2.sendToAll(new GVCLClientMessageKeyPressed(3063, 
							this.func_145782_y(), 40 + i, item.func_150891_b(item), soi1.func_190916_E()));
				}
				if(!soi2.func_190926_b()) {
					Item item = this.horseChest.func_70301_a(50 + i).func_77973_b();
					GVCLPacketHandler.INSTANCE2.sendToAll(new GVCLClientMessageKeyPressed(3063, 
							this.func_145782_y(), 50 + i, item.func_150891_b(item), soi2.func_190916_E()));
				}
			}
			//rogin = true;
		}
		{
			if(can_fuel && this.throttle != 0) {
				if(fuel > 0) {
					--fuel;
				}
				ItemStack fuel_stack = this.horseChest.func_70301_a(63);
				if(!fuel_stack.func_190926_b() && fuel_stack.func_77973_b() == this.fuel_item) {
					if(fuel == 0) {
						fuel = fuel_max;
						fuel_stack.func_190918_g(1);
						
					}
				}
			}
		}
		{
			if(this.getRemain_L() <= 0 && !weapon1_auto_reload){
				ItemStack shell_stack = this.horseChest.func_70301_a(40);
				if(!shell_stack.func_190926_b() && shell_stack.func_77973_b() == this.weapon1_item) {
					++reload1;
					if(reload1 == reload_time1 - reloadsoundset1){
						this.field_70170_p.func_184148_a((EntityPlayer)null, this.field_70165_t, this.field_70163_u, this.field_70161_v, reloadsound1, SoundCategory.WEATHER, 1.0F, 1.0F);
					}
					if(reload1 >= reload_time1){
						this.setRemain_L(this.magazine);
						reload1 = 0;
						shell_stack.func_190918_g(1);
					}
				}
			}
			{
				for (int i = 0; i < 4; ++i) {
					ItemStack soi = (ItemStack) this.horseChest.func_70301_a(40 + i);
					ItemStack soi2 = (ItemStack) this.horseChest.func_70301_a(41 + i);
					if (!soi2.func_190926_b() && soi2.func_77973_b() == this.weapon1_item) {
						if (soi.func_190926_b()) {
							this.horseChest.func_70299_a(40 + i, soi2);
							this.horseChest.func_70299_a(41 + i, soi2.field_190927_a);
						} else {
							if (soi.func_190916_E() < 64 && soi2.func_190916_E() >= 1) {
								soi.func_190920_e(soi.func_190916_E() + 1);
								this.horseChest.func_70299_a(40 + i, soi);
								soi2.func_190918_g(1);
								if (soi2.func_190916_E() <= 0) {
									this.horseChest.func_70299_a(41 + i, soi2.field_190927_a);
								}
							}
						}
					}
				}
			}
			
			if(this.getRemain_R() <= 0 && !weapon2_auto_reload){
				ItemStack shell_stack = this.horseChest.func_70301_a(50);
				if(!shell_stack.func_190926_b() && shell_stack.func_77973_b() == this.weapon2_item) {
					++reload2;
					if(reload2 == reload_time2 - reloadsoundset2){
						this.field_70170_p.func_184148_a((EntityPlayer)null, this.field_70165_t, this.field_70163_u, this.field_70161_v, reloadsound2, SoundCategory.WEATHER, 1.0F, 1.0F);
					}
					if(reload2 >= reload_time2){
						this.setRemain_R(this.magazine2);
						reload2 = 0;
						shell_stack.func_190918_g(1);
					}
				}
			}
			{
				for (int i = 0; i < 4; ++i) {
					ItemStack soi = (ItemStack) this.horseChest.func_70301_a(50 + i);
					ItemStack soi2 = (ItemStack) this.horseChest.func_70301_a(51 + i);
					if (!soi2.func_190926_b() && soi2.func_77973_b() == this.weapon2_item) {
						if (soi.func_190926_b()) {
							this.horseChest.func_70299_a(50 + i, soi2);
							this.horseChest.func_70299_a(51 + i, soi2.field_190927_a);
						} else {
							if (soi.func_190916_E() < 64 && soi2.func_190916_E() >= 1) {
								soi.func_190920_e(soi.func_190916_E() + 1);
								this.horseChest.func_70299_a(50 + i, soi);
								soi2.func_190918_g(1);
								if (soi2.func_190916_E() <= 0) {
									this.horseChest.func_70299_a(51 + i, soi2.field_190927_a);
								}
							}
						}
					}
				}
			}
		}
		/*if (this.canBeSteered() && this.getControllingPassenger() != null && this.getHealth() > 0.0F)
		{
			if(this.getControllingPassenger() instanceof EntityGVCLivingBase)
			{
				fuel = fuel_max;
				if(this.getRemain_L() <= 0 && !weapon1_auto_reload){
					{
						++reload1;
						if(reload1 == reload_time1 - reloadsoundset1){
							this.world.playSound((EntityPlayer)null, this.posX, this.posY, this.posZ, reloadsound1, SoundCategory.WEATHER, 1.0F, 1.0F);
						}
						if(reload1 >= reload_time1){
							this.setRemain_L(this.magazine);
							reload1 = 0;
						}
					}
				}
			}
		}*/
		
		/*{
			fuel = fuel_max;
			if(this.getRemain_L() <= 0){
					++reload1;
					if(reload1 == reload_time1 - reloadsoundset1){
						this.world.playSound((EntityPlayer)null, this.posX, this.posY, this.posZ, reloadsound1, SoundCategory.WEATHER, 1.0F, 1.0F);
					}
					if(reload1 >= reload_time1){
						this.setRemain_L(this.magazine);
						reload1 = 0;
					}
			}
			if(this.getRemain_R() <= 0 && !weapon2_auto_reload){
					++reload2;
					if(reload2 == reload_time2 - reloadsoundset2){
						this.world.playSound((EntityPlayer)null, this.posX, this.posY, this.posZ, reloadsound2, SoundCategory.WEATHER, 1.0F, 1.0F);
					}
					if(reload2 >= reload_time2){
						this.setRemain_R(this.magazine2);
						reload2 = 0;
					}
			}
		}*/
    }
    
    /**
     * (abstract) Protected helper method to write subclass entity data to NBT.
     */
    public void func_70014_b(NBTTagCompound compound)
    {
        super.func_70014_b(compound);

        {
            NBTTagList nbttaglist = new NBTTagList();

            for (int i = 0; i < this.horseChest.func_70302_i_(); ++i)
            {
                ItemStack itemstack = this.horseChest.func_70301_a(i);

                if (!itemstack.func_190926_b())
                {
                    NBTTagCompound nbttagcompound = new NBTTagCompound();
                    nbttagcompound.func_74774_a("Slot", (byte)i);
                    itemstack.func_77955_b(nbttagcompound);
                    nbttaglist.func_74742_a(nbttagcompound);
                }
            }

            compound.func_74782_a("Items", nbttaglist);
        }
    }

    /**
     * (abstract) Protected helper method to read subclass entity data from NBT.
     */
    public void func_70037_a(NBTTagCompound compound)
    {
        super.func_70037_a(compound);
        {
            NBTTagList nbttaglist = compound.func_150295_c("Items", 10);
            this.initHorseChest();

            for (int i = 0; i < nbttaglist.func_74745_c(); ++i)
            {
                NBTTagCompound nbttagcompound = nbttaglist.func_150305_b(i);
                int j = nbttagcompound.func_74771_c("Slot") & 255;

                if (j >= 0 && j < this.horseChest.func_70302_i_())
                {
                    this.horseChest.func_70299_a(j, new ItemStack(nbttagcompound));
                }
            }
        }

        this.updateHorseSlots();
    }
    
    
    
    public boolean CanAttack(Entity entity){
    	if(entity instanceof IMob && ((EntityLivingBase) entity).func_110143_aJ() > 0.0F){
    		return true;
    	}else
    	{
    		return false;
    	}
    }
    /*public boolean CanAttack(Entity entity){
    	{
    		return false;
    	}
    }*/
    
    
    
  
    
    /**
     * Determines if an entity can be despawned, used on idle far away entities
     */
    protected boolean func_70692_ba()
    {
    	if(this.getcanDespawn() == 0 && !this.getVehicleLock() && !this.getattacktask()) {
    		return true;
    	}else {
    		return false;
    	}
    }
    
    /**
     * Drop the equipment for this entity.
     */
    protected void func_82160_b(boolean wasRecentlyHit, int lootingModifier)
    {
    	ItemStack fuel_stack = this.horseChest.func_70301_a(63);
    	if(!fuel_stack.func_190926_b()) {
    		this.func_70099_a(fuel_stack, 0.0F);
    	}
    	ItemStack w1_stack = this.horseChest.func_70301_a(40);
    	if(!w1_stack.func_190926_b()) {
    		this.func_70099_a(w1_stack, 0.0F);
    	}
    	ItemStack w2_stack = this.horseChest.func_70301_a(50);
    	if(!w2_stack.func_190926_b()) {
    		this.func_70099_a(w2_stack, 0.0F);
    	}
    }
    
   
    protected int getInventorySize()
    {
        return 64;
    }

    protected void initHorseChest()
    {
    	ContainerInventoryBox containerhorsechest = this.horseChest;
        this.horseChest = new ContainerInventoryBox("HorseChest", this.getInventorySize());
        this.horseChest.func_110133_a(this.func_70005_c_());

        if (containerhorsechest != null)
        {
            containerhorsechest.func_110132_b(this);
            int i = Math.min(containerhorsechest.func_70302_i_(), this.horseChest.func_70302_i_());

            for (int j = 0; j < i; ++j)
            {
                ItemStack itemstack = containerhorsechest.func_70301_a(j);

                if (!itemstack.func_190926_b())
                {
                    this.horseChest.func_70299_a(j, itemstack.func_77946_l());
                }
            }
        }

        this.horseChest.func_110134_a(this);
        this.updateHorseSlots();
    }
    
    public void func_76316_a(IInventory invBasic)
    {
    	this.updateHorseSlots();
    }
    /**
     * Updates the items in the saddle and armor slots of the horse's inventory.
     */
    protected void updateHorseSlots()
    {
    	ContainerInventoryBox containerhorsechest = this.horseChest;
    	if (containerhorsechest != null)
        {
    		//this.horseChest.setInventorySlotContents(11, new ItemStack(Items.EMERALD));
        }
    }
    public void func_70071_h_()
    {
        super.func_70071_h_();
        this.updateHorseSlots();
        if (!this.field_70170_p.field_72995_K && this.field_70170_p.func_175659_aa() == EnumDifficulty.PEACEFUL && this.getcanDespawn() == 0)
        {
            this.func_70106_y();
        }
    }
    
    /*public int getInventoryColumns()
    {
        return 5;
    }*/
    
    public void typePCTank() {
    	float f1 = this.field_70759_as * (2 * (float) Math.PI / 360);
    	if (this.func_82171_bF() && this.func_184179_bs() != null && this.func_110143_aJ() > 0.0F)
		{
			if(this.func_184179_bs() instanceof EntityPlayer)
			{
			EntityPlayer entitylivingbase = (EntityPlayer) this.func_184179_bs();
			this.setcanDespawn(1);
			this.rotation  = entitylivingbase.field_70759_as;
			this.rotationp = this.field_70125_A = entitylivingbase.field_70125_A;
			Vec3d looked = entitylivingbase.func_70040_Z();
			PL_TankMove.move2(entitylivingbase, this, sp, turnspeed);
			
			boolean left = mod_GVCLib.proxy.leftclick();
			boolean right = mod_GVCLib.proxy.rightclick();
			boolean jump = mod_GVCLib.proxy.jumped();
			boolean kx = mod_GVCLib.proxy.keyx();
			boolean kg = mod_GVCLib.proxy.keyg();
			boolean kc = mod_GVCLib.proxy.keyc();
			if (left) {
				GVCLPacketHandler.INSTANCE.sendToServer(new GVCLMessageKeyPressed(11, this.func_145782_y()));
				this.server1 = true;
			}
			if (right) {
				GVCLPacketHandler.INSTANCE.sendToServer(new GVCLMessageKeyPressed(12, this.func_145782_y()));
			}
			if (jump) {
				GVCLPacketHandler.INSTANCE.sendToServer(new GVCLMessageKeyPressed(13, this.func_145782_y()));
			}
			if (kx) {
				GVCLPacketHandler.INSTANCE.sendToServer(new GVCLMessageKeyPressed(14, this.func_145782_y()));
			}
			if (kg) {
				GVCLPacketHandler.INSTANCE.sendToServer(new GVCLMessageKeyPressed(15, this.func_145782_y()));
			}
			if (kc) {
				GVCLPacketHandler.INSTANCE.sendToServer(new GVCLMessageKeyPressed(16, this.func_145782_y()));
			}
			
			if (serverx) {
				if (cooltime5 > 1 && this.getRemain_A() > 0) {
					if(this.getArmID_R() == 0 && this.weapon11true){
						this.setArmID_R(1);
					}else if(this.getArmID_R() == 1 && this.weapon12true){
						this.setArmID_R(2);
					}else
					{
						this.setArmID_R(0);
					}
					cooltime5 = 0;
					this.setRemain_A(this.getRemain_A() - 1);
					this.func_184185_a(GVCSoundEvent.reload_shell, 1.0F, 1.0F);
				}
				{
					this.serverx = false;
				}
			}
			
			if(this.server1)
		    {
		    	{
    				if(cooltime >= ammo1){
    					this.counter1 = true;
    		            cooltime = 0;
    				}
    				if(this.weapon1true) {
    					if(this.getArmID_R() == 1 && this.weapon11true){
    						this.weapon11active(looked, entitylivingbase);
    					}else if(this.getArmID_R() == 2 && this.weapon12true){
    						this.weapon12active(looked, entitylivingbase);
    					}else {
    						this.weapon1active(looked, entitylivingbase);
    					}
        		    }
    			}
		    	this.server1 = false;
			}
		    
		    if(this.serverspace)
		    {
		    	{
    				if(cooltime2 >= ammo2){
    					this.counter2 = true;
    		            cooltime2 = 0;
    				}
    				if(this.weapon2true) {
        		    	this.weapon2active(looked, entitylivingbase);
        		    }
    			}
		    	this.serverspace = false;
			}
			
			
			
			}//player
			else if(this.func_184179_bs() instanceof EntityGVCLivingBase) {
				EntityGVCLivingBase entitylivingbase = (EntityGVCLivingBase) this.func_184179_bs();
				this.rotation  = entitylivingbase.field_70759_as;
				this.rotationp = this.field_70125_A = entitylivingbase.field_70125_A;
				Vec3d looked = entitylivingbase.func_70040_Z();
				AI_EntityMoveTank.move(this, entitylivingbase, f1, sp, turnspeed, this.mob_min_range, this.mob_max_range);
				if(AI_EntityWeapon.getRange(entitylivingbase, this.mob_w1range, this.mob_w1range_max_y, this.mob_w1range_min_y)){
					if(cooltime >= ammo1 && this.getRemain_L() > 0){
						this.counter1 = true;
			            cooltime = 0;
					}
					if(this.weapon1true) {
	    		    	this.weapon1activeMob(looked, entitylivingbase, 0);
	    		    }
				}
				if(AI_EntityWeapon.getRange(entitylivingbase, this.mob_w2range, this.mob_w2range_max_y, this.mob_w2range_min_y)){
					if(cooltime2 >= ammo2 && this.getRemain_R() > 0){
						this.counter2 = true;
			            cooltime2 = 0;
					}
					if(this.weapon2true) {
	    		    	this.weapon2activeMob(looked, entitylivingbase, this.weapon2type);
	    		    }
				}
			}
		}
		
    	if(fuel > 0)AI_TankSet.set2(this, GVCSoundEvent.sound_tank, f1, sp, 0.1F);
		
		this.catchEntityBiped();
		
        
    }
    
    public void typePCSPG() {
    	float f1 = this.field_70759_as * (2 * (float) Math.PI / 360);
    	if (this.func_82171_bF() && this.func_184179_bs() != null && this.func_110143_aJ() > 0.0F)
		{
			if(this.func_184179_bs() instanceof EntityPlayer)
			{
			EntityPlayer entitylivingbase = (EntityPlayer) this.func_184179_bs();
			Vec3d looked = entitylivingbase.func_70040_Z();
				if (this.getFTMode() == 1) {
					spg_mode = true;
					{
						int range = 120;
						//double d5 = spg_yaw - this.posX;
						//double d7 = spg_picth - this.posZ;
						//float yawoffset = -((float) Math.atan2(d5, d7)) * 180.0F / (float) Math.PI;
						float yaw = entitylivingbase.field_70759_as * (2 * (float) Math.PI / 360);
						float xx = 0;
						float zz = 0;
						if (entitylivingbase.field_191988_bg > 0.0F && (spg_yaw < range && spg_picth < range)) {
							xx = xx + (this.turnspeed * 0.2F);
						}
						if (entitylivingbase.field_191988_bg < 0.0F && (spg_yaw > -range && spg_picth > -range)) {
							xx = xx - (this.turnspeed * 0.2F);
						}
						if (entitylivingbase.field_70702_br > 0.0F && (spg_yaw < range && spg_picth < range)) {
							zz = zz + (this.turnspeed * 0.2F);
						}
						if (entitylivingbase.field_70702_br < 0.0F && (spg_yaw > -range && spg_picth > -range)) {
							zz = zz - (this.turnspeed * 0.2F);
						}
						spg_yaw -= MathHelper.func_76126_a(yaw) * xx;
						spg_picth += MathHelper.func_76134_b(yaw) * xx;
						spg_yaw -= MathHelper.func_76126_a(yaw - 1.57F) * zz;
						spg_picth += MathHelper.func_76134_b(yaw - 1.57F) * zz;
						double d5 = this.spg_yaw;
						double d7 = this.spg_picth;
						float yawoffset = -((float) Math.atan2(d5, d7)) * 180.0F / (float) Math.PI;
						this.rotation = this.field_70177_z = yawoffset;
						this.rotationp = -40;
						BlockPos bp = field_70170_p.func_175645_m(new BlockPos(spg_yaw + this.field_70165_t, this.field_70163_u, spg_picth + this.field_70161_v));
						spg_y = bp.func_177956_o();
					}
				} else {
					spg_mode = false;
					spg_yaw = 0;
					spg_picth = 0;
					this.rotation = entitylivingbase.field_70759_as;
					this.rotationp = entitylivingbase.field_70125_A;
					PL_TankMove.move2(entitylivingbase, this, sp, turnspeed);
				}
			
			boolean left = mod_GVCLib.proxy.leftclick();
			boolean right = mod_GVCLib.proxy.rightclick();
			boolean jump = mod_GVCLib.proxy.jumped();
			boolean kx = mod_GVCLib.proxy.keyx();
			boolean kg = mod_GVCLib.proxy.keyg();
			boolean kc = mod_GVCLib.proxy.keyc();
			if (left) {
				GVCLPacketHandler.INSTANCE.sendToServer(new GVCLMessageKeyPressed(11, this.func_145782_y()));
				this.server1 = true;
			}
			if (right) {
				GVCLPacketHandler.INSTANCE.sendToServer(new GVCLMessageKeyPressed(12, this.func_145782_y()));
			}
			if (jump) {
				GVCLPacketHandler.INSTANCE.sendToServer(new GVCLMessageKeyPressed(13, this.func_145782_y()));
			}
			if (kx) {
				GVCLPacketHandler.INSTANCE.sendToServer(new GVCLMessageKeyPressed(14, this.func_145782_y()));
			}
			if (kg) {
				this.serverg = true;
				GVCLPacketHandler.INSTANCE.sendToServer(new GVCLMessageKeyPressed(15, this.func_145782_y()));
			}
			if (kc) {
				GVCLPacketHandler.INSTANCE.sendToServer(new GVCLMessageKeyPressed(16, this.func_145782_y()));
			}
			
			if (serverx) {
				if (cooltime5 > 1 && this.getRemain_A() > 0) {
					if(this.getArmID_R() == 0 && this.weapon11true){
						this.setArmID_R(1);
					}else if(this.getArmID_R() == 1 && this.weapon12true){
						this.setArmID_R(2);
					}else
					{
						this.setArmID_R(0);
					}
					cooltime5 = 0;
					this.setRemain_A(this.getRemain_A() - 1);
					this.func_184185_a(GVCSoundEvent.reload_shell, 1.0F, 1.0F);
				}
				{
					this.serverx = false;
				}
			}
			
			if(this.server1)
		    {
		    	{
    				if(cooltime >= ammo1){
    					this.counter1 = true;
    		            cooltime = 0;
    				}
    				if(this.weapon1true) {
    					if(this.getArmID_R() == 1 && this.weapon11true){
    						this.weapon11active(looked, entitylivingbase);
    					}else if(this.getArmID_R() == 2 && this.weapon12true){
    						this.weapon12active(looked, entitylivingbase);
    					}else {
    						this.weapon1active(looked, entitylivingbase);
    					}
        		    }
    			}
		    	this.server1 = false;
			}
		    
		    if(this.serverspace)
		    {
		    	{
    				if(cooltime2 >= ammo2){
    					this.counter2 = true;
    		            cooltime2 = 0;
    				}
    				if(this.weapon2true) {
        		    	this.weapon2active(looked, entitylivingbase);
        		    }
    			}
		    	this.serverspace = false;
			}
		    if (this.serverg) {
				if (cooltime6 > 1 && this.getWeaponChange() > 0) {
					if(this.getFTMode() >= 1){
						this.setFTMode(0);
					}else
					{
						this.setFTMode(1);
						float yaw = this.field_70177_z * (2 * (float) Math.PI / 360);
						//spg_yaw = 0;
						//spg_picth = 0;
						spg_yaw -= MathHelper.func_76126_a(yaw) * 40;
						spg_picth += MathHelper.func_76134_b(yaw) * 40;
					}
					cooltime6 = 0;
					this.setWeaponChange(this.getWeaponChange() - 1);
				}
				{
					this.serverg = false;
				}
			}
			
			
			}//player
			else if(this.func_184179_bs() instanceof EntityGVCLivingBase) {
				EntityGVCLivingBase entitylivingbase = (EntityGVCLivingBase) this.func_184179_bs();
				this.rotation  = entitylivingbase.field_70759_as;
				this.rotationp =  -40;
				Vec3d looked = entitylivingbase.func_70040_Z();
				AI_EntityMoveTank.move(this, entitylivingbase, f1, sp, turnspeed, this.mob_min_range, this.mob_max_range);
				if(AI_EntityWeapon.getRange(entitylivingbase, this.mob_w1range, this.mob_w1range_max_y, this.mob_w1range_min_y)){
					if(cooltime >= ammo1 && this.getRemain_L() > 0){
						this.counter1 = true;
			            cooltime = 0;
					}
					if(this.weapon1true) {
	    		    	this.weapon1activeMob(looked, entitylivingbase, 0);
	    		    }
				}
				this.rotationp =  -40;
			}
		}
		
    	if(fuel > 0)AI_TankSet.set2(this, GVCSoundEvent.sound_tank, f1, sp, 0.1F);
		
		this.catchEntityBiped();
		
        
    }
    
    
    public void roadattackPC(int level) {
    	double dx = Math.abs(this.field_70165_t - this.field_70169_q);
		double dz = Math.abs(this.field_70161_v - this.field_70166_s);
		float dd = (float)Math.sqrt((dx * dx) + (dz * dz)) * 20;
    	if(dd != 0){
			this.func_184609_a(EnumHand.MAIN_HAND);
			AxisAlignedBB axisalignedbb2 = new AxisAlignedBB(
					this.field_70165_t - this.field_70130_N, this.field_70163_u, this.field_70161_v - this.field_70130_N, 
					this.field_70165_t + this.field_70130_N, this.field_70163_u + this.field_70131_O, this.field_70161_v + this.field_70130_N)
	        		.func_72321_a(this.field_70130_N, this.field_70131_O, this.field_70130_N);
			List<Entity> llist = this.field_70170_p.func_72839_b(this,axisalignedbb2);
			if (llist != null) {
				for (int lj = 0; lj < llist.size(); lj++) {
					Entity entity1 = (Entity) llist.get(lj);
					if (entity1.func_70067_L() && entity1 instanceof EntityLivingBase && entity1 != null) {
						if(entity1 != this && entity1 != this.func_184179_bs() && entity1 instanceof IMob && !entity1.func_184218_aH()){
							entity1.func_70097_a(DamageSource.func_76358_a(this), 10);
						}
					}
				}
			}
		}
    	if(!this.field_70170_p.field_72995_K && roodbreak){
    		AxisAlignedBB axisalignedbb = this.func_174813_aQ();
    		double xx = field_70130_N;
        		for(double x = 0; x < field_70130_N*2; ++x) {
        			for(double y = -1; y < field_70131_O*1.2; ++y) {
        				for(double z = 0; z < field_70130_N*2; ++z) {
        					BlockPos pos = new BlockPos(this.field_70165_t -xx + x, this.field_70163_u + y, this.field_70161_v - xx + z);
        					if(canbreak(level, pos)) 
        					{
        						IBlockState iblockstate = this.field_70170_p.func_180495_p(pos);
        		                Block block = iblockstate.func_177230_c();
        		                if (iblockstate.func_185904_a() != Material.field_151579_a)
        		                {
        		                    block.func_180653_a(this.field_70170_p, pos, this.field_70170_p.func_180495_p(pos), 1.0F, 0);
        		                    field_70170_p.func_175698_g(pos);
        		                }
        					}
        				}
        			}
        		}
    	}
    }
    
    public boolean canbreak(int level, BlockPos pos) {
    	boolean re = false;
    	if(level == 0) {
    		if(this.field_70170_p.func_180495_p(pos).func_177230_c() instanceof BlockOldLeaf	
					|| this.field_70170_p.func_180495_p(pos).func_177230_c() instanceof BlockPane	
					|| this.field_70170_p.func_180495_p(pos).func_177230_c() instanceof BlockNewLeaf) 
				{
    			re = true;
				}
    	}
    	if(level == 1) {
    		if(this.field_70170_p.func_180495_p(pos).func_177230_c() instanceof BlockOldLog
					|| this.field_70170_p.func_180495_p(pos).func_177230_c() instanceof BlockOldLeaf	
					|| this.field_70170_p.func_180495_p(pos).func_177230_c() instanceof BlockPane	
					|| this.field_70170_p.func_180495_p(pos).func_177230_c() instanceof BlockLog
					|| this.field_70170_p.func_180495_p(pos).func_177230_c() instanceof BlockNewLeaf	
					|| this.field_70170_p.func_180495_p(pos).func_177230_c() instanceof BlockPlanks	
					|| this.field_70170_p.func_180495_p(pos).func_177230_c() instanceof BlockLilyPad	
						) 
				{
    			re = true;
				}
    	}
    	if(level == 2) {
    		if(this.field_70170_p.func_180495_p(pos).func_177230_c() instanceof BlockOldLog
					|| this.field_70170_p.func_180495_p(pos).func_177230_c() instanceof BlockOldLeaf	
					|| this.field_70170_p.func_180495_p(pos).func_177230_c() instanceof BlockPane	
					|| this.field_70170_p.func_180495_p(pos).func_177230_c() instanceof BlockLog
					|| this.field_70170_p.func_180495_p(pos).func_177230_c() instanceof BlockNewLeaf	
					|| this.field_70170_p.func_180495_p(pos).func_177230_c() instanceof BlockPlanks	
					|| this.field_70170_p.func_180495_p(pos).func_177230_c() instanceof BlockLilyPad	
					|| this.field_70170_p.func_180495_p(pos).func_177230_c() instanceof BlockStoneBrick
					|| this.field_70170_p.func_180495_p(pos).func_177230_c() == Blocks.field_150347_e
					|| (this.field_70170_p.func_180495_p(pos).func_177230_c() instanceof BlockStone && this.field_70170_p.func_180495_p(pos).func_177230_c() != Blocks.field_150348_b)
						) 
				{
    			re = true;
				}
    	}
    	return re;
    }
    
}
