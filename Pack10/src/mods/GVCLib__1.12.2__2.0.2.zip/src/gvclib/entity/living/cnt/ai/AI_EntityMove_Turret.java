package gvclib.entity.living.cnt.ai;

import java.util.List;
import gvclib.entity.living.EntityGVCLivingBase;
import gvclib.entity.living.EntityVehicleBase;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.chunk.Chunk;


import gvclib.entity.living.EntityGVCLivingBase;
import gvclib.entity.living.EntityVehicleBase;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.ai.RandomPositionGenerator;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.chunk.Chunk;

public class AI_EntityMove_Turret {
	public static void move(EntityVehicleBase vehicle, EntityGVCLivingBase ridding, float f1, float sp, float turnspeed, double max, double range, boolean antiair) {
		{// 1
			Chunk chunk = vehicle.field_70170_p.func_175726_f(new BlockPos(vehicle.field_70165_t, vehicle.field_70163_u, vehicle.field_70161_v));
			if (chunk.func_76621_g())return;
			if(ridding.field_70759_as > 360F || ridding.field_70759_as < -360F){
				ridding.field_70759_as = 0;
				ridding.field_70177_z = 0;
				ridding.field_70126_B = 0;
				ridding.field_70758_at = 0;
				ridding.field_70761_aq = 0;
			}
			if(ridding.field_70759_as > 180F){
				ridding.field_70759_as = -179F;
				ridding.field_70177_z = -179F;
				ridding.field_70126_B = -179F;
				ridding.field_70758_at = -179F;
				ridding.field_70761_aq = -179F;
			}
			if(ridding.field_70759_as < -180F){
				ridding.field_70759_as = 179F;
				ridding.field_70177_z = 179F;
				ridding.field_70126_B = 179F;
				ridding.field_70758_at = 179F;
				ridding.field_70761_aq = 179F;
			}
			if(vehicle.field_70759_as > 360F || vehicle.field_70759_as < -360F){
				vehicle.field_70759_as = 0;
				vehicle.field_70177_z = 0;
				vehicle.field_70126_B = 0;
				vehicle.field_70758_at = 0;
				vehicle.field_70761_aq = 0;
			}
			if(vehicle.field_70759_as > 180F){
				vehicle.field_70759_as = -179F;
				vehicle.field_70177_z = -179F;
				vehicle.field_70126_B = -179F;
				vehicle.field_70758_at = -179F;
				vehicle.field_70761_aq = -179F;
			}
			if(vehicle.field_70759_as < -180F){
				vehicle.field_70759_as = 179F;
				vehicle.field_70177_z = 179F;
				vehicle.field_70126_B = 179F;
				vehicle.field_70758_at = 179F;
				vehicle.field_70761_aq = 179F;
			}
			boolean ta = false;
			
			Entity target = null;
			Entity[] targetlist = new Entity[1024];
			int targetplus = 0;
			
			List<Entity> llist = vehicle.field_70170_p.func_72839_b(vehicle,
					vehicle.func_174813_aQ().func_72321_a(vehicle.field_70159_w, vehicle.field_70181_x, vehicle.field_70179_y).func_186662_g(range));
			if (llist != null) {
				for (int lj = 0; lj < llist.size(); lj++) {
					Entity entity1 = (Entity) llist.get(lj);
					if (entity1.func_70067_L() && entity1 != null && vehicle.func_110143_aJ() > 0.0F) {
						boolean flag = vehicle.func_70635_at().func_75522_a(entity1);
						if (ridding.CanAttack(entity1) && entity1 != null && flag) {
							double d5 = entity1.field_70165_t - vehicle.field_70165_t;
							double d7 = entity1.field_70161_v - vehicle.field_70161_v;
							double d6 = entity1.field_70163_u - vehicle.field_70163_u;
							double d1 = vehicle.field_70163_u - (entity1.field_70163_u);
				            double d3 = (double)MathHelper.func_76133_a(d5 * d5 + d7 * d7);
				            float f11 = (float)(-(Math.atan2(d1, d3) * 180.0D / Math.PI));
				            float rotep_offset = -f11 + 10;
				            if(rotep_offset <= vehicle.rotationp_min && rotep_offset >= vehicle.rotationp_max) {
				            	targetlist[targetplus] = entity1;
								++targetplus;
				            }
						}

					}
				}
			}
			for(int xs = 0; xs < targetlist.length; ++xs) {
				if(targetlist[xs] != null) {
					if(antiair) {
						if(target != null) {
							if(targetlist[xs].field_70163_u > target.field_70163_u) {
								target = targetlist[xs];
							}
						}else {
							target = targetlist[xs];
						}
					}else {
						target = targetlist[xs];
						break;
					}
				}
			}
			
			
			
			if(target != null) {
				boolean flag = vehicle.func_70635_at().func_75522_a(target);
				{
					double d5 = target.field_70165_t - vehicle.field_70165_t;
					double d7 = target.field_70161_v - vehicle.field_70161_v;
					double d6 = target.field_70163_u - vehicle.field_70163_u;
					double d1 = vehicle.field_70163_u - (target.field_70163_u);
		            double d3 = (double)MathHelper.func_76133_a(d5 * d5 + d7 * d7);
		            float f11 = (float)(-(Math.atan2(d1, d3) * 180.0D / Math.PI));
		            ridding.rotation = ridding.field_70177_z = ridding.field_70759_as = ridding.field_70761_aq
		            		=  vehicle.rotation = vehicle.rote =  -((float) Math.atan2(d5, d7)) * 180.0F / (float) Math.PI;
		            ridding.rotationp = ridding.field_70127_C = vehicle.rotationp = vehicle.field_70125_A = -f11 + 10;
		            
					Vec3d look = vehicle.func_70040_Z();
					float f3 = (float) (vehicle.field_70759_as - vehicle.rote);
					if(flag){
						ridding.targetentity = (EntityLivingBase) target;
					}
					ta = true;
				}
			}
			
			if(ta) {
				float f3 = (float) (vehicle.field_70177_z - vehicle.rote);
				 if(vehicle.field_70177_z != vehicle.rote){
	         		if(f3 > 1){
	 					if(f3 > 180F){
	 						vehicle.field_70177_z = vehicle.field_70177_z + vehicle.turnspeed;
	 					}else{
	 						vehicle.field_70177_z = vehicle.field_70177_z - vehicle.turnspeed;
	 					}
	 				}
	 				else if(f3 < -1){
	 					if(f3 < -180F){
	 						vehicle.field_70177_z = vehicle.field_70177_z - vehicle.turnspeed;
	 					}else{
	 						vehicle.field_70177_z = vehicle.field_70177_z + vehicle.turnspeed;
	 					}
	 				}
		            }
			}
			
			/*if(!ta){
				double xPosition = 0;
			    double yPosition = 0;
			    double zPosition = 0;
				if (vehicle.getIdleTime() >= 100)
		        {
		        }
		        else if (vehicle.getRNG().nextInt(120) != 0)
		        {
		        }
		        else
		        {
		            Vec3d vec3 = RandomPositionGenerator.findRandomTarget(vehicle, 10, 7);

		            if (vec3 == null)
		            {
		            }
		            else
		            {
		                xPosition = vec3.x;
		                yPosition = vec3.y;
		                zPosition = vec3.z;
		            }
		            vehicle.rotation = vehicle.getRNG().nextInt(120) - 60;
		        }
				vehicle.getNavigator().tryMoveToXYZ(xPosition, yPosition, zPosition, 1D);
			}*/
		} // 1
}
}
