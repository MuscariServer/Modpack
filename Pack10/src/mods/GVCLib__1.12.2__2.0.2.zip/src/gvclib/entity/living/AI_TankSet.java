package gvclib.entity.living;

import net.minecraft.entity.MoverType;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.math.MathHelper;

public class AI_TankSet {

public static void set2(EntityGVCLivingBase entity, SoundEvent sound, float f1, float sp, float brake){
		
		if ((entity.func_82171_bF() && entity.func_184179_bs() != null) || (entity.getMobMode() == 0) && entity.func_110143_aJ() > 0.0F)
		{
			if(entity.ontick % 5 == 0 && (entity.field_70165_t != entity.field_70169_q || entity.field_70161_v != entity.field_70166_s)){
				//entity.playSound(sound, 4.0F, 1.0F);
				if(sound != null && !entity.field_70170_p.field_72995_K)entity.field_70170_p.func_184148_a((EntityPlayer)null, entity.field_70165_t, entity.field_70163_u, entity.field_70161_v, sound, SoundCategory.WEATHER, 4.0F, 1.0F);
			}
		}
		double x = 0;
		double y = 0;
		double z = 0;
		//if(entity.throttle >= 0.1F) 
		if(entity.throttle > 0.5F | entity.throttle < -0.2F){
			if(entity.getMoveT() == 1) {
				sp = sp * 0.25F;
			}
			
			/*if (entity.onGround) {
				x -= MathHelper.sin(f1) * sp * entity.throttle;
				z += MathHelper.cos(f1) * sp * entity.throttle;
			} else {
				x -= MathHelper.sin(f1) * sp * entity.throttle;
				z += MathHelper.cos(f1) * sp * entity.throttle;
			}*/
			x -= MathHelper.func_76126_a(f1) * sp * entity.throttle;
			z += MathHelper.func_76134_b(f1) * sp * entity.throttle;
		}
		//if(!entity.world.isRemote) 
		{
			entity.field_70159_w = x;
			entity.field_70179_y = z;
			//entity.motionY = y;
			entity.func_70091_d(MoverType.PLAYER, entity.field_70159_w, entity.field_70181_x, entity.field_70179_y);
		}
		/*if(!entity.world.isRemote) {
			entity.move(MoverType.PLAYER, entity.motionX, entity.motionY, entity.motionZ);
		}*/
		if(entity.throttle != 0){
			if(entity.throttle < 0.09 && entity.throttle > -0.09) {
				entity.throttle = 0;
			}
			if(entity.throttle > 0){
				entity.throttle = entity.throttle - brake;
				rotecrawler(entity, 0, true,1);
				rotecrawler(entity, 1, true,1);
			}
			if(entity.throttle < 0){
				entity.throttle = entity.throttle + brake;
				rotecrawler(entity, 0, false,1);
				rotecrawler(entity, 1, false,1);
			}
			
		}
		/*if(entity.thpower != 0){
			if(entity.thpower > 0){
				entity.thpower = entity.thpower - brake;
			}
			if(entity.thpower < 0){
				entity.thpower = entity.thpower + brake;
			}
		}*/
		
		
		float speed = MathHelper.func_76133_a(entity.field_70159_w * entity.field_70159_w + entity.field_70179_y * entity.field_70179_y);
		//if(speed != 0)
		{
			if(entity.throttle > 0){
				if(entity.thpera < 360){
					entity.thpera = entity.thpera + (speed*40);
				}else{
					entity.thpera = 0;
				}
			}else {
				if(entity.thpera < 0){
					entity.thpera = 360;
				}else{
					entity.thpera = entity.thpera - (speed*40);
				}
			}
		}
		
		if(entity.field_70759_as > 360F || entity.field_70759_as < -360F){
        	entity.rotation = 0;
			entity.rotationp = 0;
			entity.field_70759_as = 0;
			entity.field_70177_z = 0;
			//entity.prevRotationYaw = 0;
			//entity.prevRotationYawHead = 0;
			entity.field_70761_aq = 0;
		}
		if(entity.field_70759_as > 180F){
			entity.rotation = -179F;
			entity.rotationp = -179F;
			entity.field_70759_as = -179F;
			entity.field_70177_z = -179F;
			//entity.prevRotationYaw = -179F;
			//entity.prevRotationYawHead = -179F;
			entity.field_70761_aq = -179F;
		}
		if(entity.field_70759_as < -180F){
			entity.rotation = 179F;
			entity.rotationp = 179F;
			entity.field_70759_as = 179F;
			entity.field_70177_z = 179F;
			//entity.prevRotationYaw = 179F;
			//entity.prevRotationYawHead = 179F;
			entity.field_70761_aq = 179F;
		}
		if(entity.field_70177_z > entity.field_70126_B){
			if(entity.throttle > 0){
				rotecrawler(entity, 1, true,1);
				rotecrawler(entity, 0, false,1);
			}else {
				rotecrawler(entity, 0, true,1);
				rotecrawler(entity, 1, false,1);
			}
		}
		if(entity.field_70177_z < entity.field_70126_B){
			if(entity.throttle > 0){
				rotecrawler(entity, 0, true,1);
				rotecrawler(entity, 1, false,1);
			}else {
				rotecrawler(entity, 1, true,1);
				rotecrawler(entity, 0, false,1);
			}
		}
		
		
		/*double x1 = 0;
		double z1 = 0;
		x1 -= MathHelper.sin(entity.rotationYawHead * 0.01745329252F -0.3F) * 3.0;
		z1 += MathHelper.cos(entity.rotationYawHead * 0.01745329252F -0.3F) * 3.0;
		double x2 = 0;
		double z2 = 0;
		x2 -= MathHelper.sin(entity.rotationYawHead * 0.01745329252F +0.3F) * 3.0;
		z2 += MathHelper.cos(entity.rotationYawHead * 0.01745329252F +0.3F) * 3.0;
		entity.world.spawnParticle(EnumParticleTypes.CLOUD, entity.posX-x1, entity.posY + 1.6D, entity.posZ-z1, 0.0D, 0.0D, 0.0D, new int[0]);
		entity.world.spawnParticle(EnumParticleTypes.CLOUD, entity.posX-x2, entity.posY + 1.6D, entity.posZ-z2, 0.0D, 0.0D, 0.0D, new int[0]);
		*/
		if(entity.func_110143_aJ() <= entity.func_110138_aP()/2){
			if(entity.func_110143_aJ() <= entity.func_110138_aP()/4){
				entity.field_70170_p.func_175688_a(EnumParticleTypes.SMOKE_LARGE, entity.field_70165_t-2, entity.field_70163_u + 2D, entity.field_70161_v+2, 0.0D, 0.0D, 0.0D, new int[0]);
				entity.field_70170_p.func_175688_a(EnumParticleTypes.SMOKE_LARGE, entity.field_70165_t+2, entity.field_70163_u + 2D, entity.field_70161_v-1, 0.0D, 0.0D, 0.0D, new int[0]);
				int rx = entity.field_70170_p.field_73012_v.nextInt(5);
				int rz = entity.field_70170_p.field_73012_v.nextInt(5);
				entity.field_70170_p.func_175688_a(EnumParticleTypes.FLAME, entity.field_70165_t-2+rx, entity.field_70163_u + 2D, entity.field_70161_v-2+rz, 0.0D, 0.0D, 0.0D, new int[0]);
				entity.field_70170_p.func_175688_a(EnumParticleTypes.SMOKE_LARGE, entity.field_70165_t-2+rx, entity.field_70163_u + 2D, entity.field_70161_v-2+rz, 0.0D, 0.0D, 0.0D, new int[0]);
			}else{
				entity.field_70170_p.func_175688_a(EnumParticleTypes.SMOKE_LARGE, entity.field_70165_t-2, entity.field_70163_u + 2D, entity.field_70161_v+2, 0.0D, 0.0D, 0.0D, new int[0]);
				entity.field_70170_p.func_175688_a(EnumParticleTypes.SMOKE_LARGE, entity.field_70165_t+2, entity.field_70163_u + 2D, entity.field_70161_v-1, 0.0D, 0.0D, 0.0D, new int[0]);
				int rx = entity.field_70170_p.field_73012_v.nextInt(5);
				int rz = entity.field_70170_p.field_73012_v.nextInt(5);
				entity.field_70170_p.func_175688_a(EnumParticleTypes.SMOKE_LARGE, entity.field_70165_t-2+rx, entity.field_70163_u + 2D, entity.field_70161_v-2+rz, 0.0D, 0.0D, 0.0D, new int[0]);
			}
		}
	}
	
	public static void rotecrawler(EntityGVCLivingBase entity, int id, boolean on, int r) {
		if (id == 0) {
			if (!on) {
				if (entity.throttle_r <= 8) {
					entity.throttle_r = entity.throttle_r + (r);
				} else {
					entity.throttle_r = 0;
				}
			} else {
				if (entity.throttle_r > 0) {
					entity.throttle_r = entity.throttle_r - (r);
				} else {
					entity.throttle_r = 8;
				}
			}
		}
		if (id == 1) {
			if (!on) {
				if (entity.throttle_l <= 8) {
					entity.throttle_l = entity.throttle_l + (r);
				} else {
					entity.throttle_l = 0;
				}
			} else {
				if (entity.throttle_l > 0) {
					entity.throttle_l = entity.throttle_l - (r);
				} else {
					entity.throttle_l = 8;
				}
			}
		}
	}

	public static void set(EntityGVCLivingBase entity, SoundEvent sound){
		
		if ((entity.func_82171_bF() && entity.func_184179_bs() != null) || (entity.getMobMode() == 0) && entity.func_110143_aJ() > 0.0F)
		{
			if(entity.ontick % 5 == 0 && (entity.field_70165_t != entity.field_70169_q || entity.field_70161_v != entity.field_70166_s)){
				entity.field_70170_p.func_184148_a((EntityPlayer)null, entity.field_70165_t, entity.field_70163_u, entity.field_70161_v, sound, SoundCategory.WEATHER, 4.0F, 1.0F);
			}
		}
		
		if(entity.field_70759_as > 360F || entity.field_70759_as < -360F){
        	entity.rotation = 0;
			entity.rotationp = 0;
			entity.field_70759_as = 0;
			entity.field_70177_z = 0;
			entity.field_70126_B = 0;
			entity.field_70758_at = 0;
			entity.field_70761_aq = 0;
		}
		if(entity.field_70759_as > 180F){
			entity.rotation = -179F;
			entity.rotationp = -179F;
			entity.field_70759_as = -179F;
			entity.field_70177_z = -179F;
			entity.field_70126_B = -179F;
			entity.field_70758_at = -179F;
			entity.field_70761_aq = -179F;
		}
		if(entity.field_70759_as < -180F){
			entity.rotation = 179F;
			entity.rotationp = 179F;
			entity.field_70759_as = 179F;
			entity.field_70177_z = 179F;
			entity.field_70126_B = 179F;
			entity.field_70758_at = 179F;
			entity.field_70761_aq = 179F;
		}
		
		/*double x1 = 0;
		double z1 = 0;
		x1 -= MathHelper.sin(entity.rotationYawHead * 0.01745329252F -0.3F) * 3.0;
		z1 += MathHelper.cos(entity.rotationYawHead * 0.01745329252F -0.3F) * 3.0;
		double x2 = 0;
		double z2 = 0;
		x2 -= MathHelper.sin(entity.rotationYawHead * 0.01745329252F +0.3F) * 3.0;
		z2 += MathHelper.cos(entity.rotationYawHead * 0.01745329252F +0.3F) * 3.0;
		entity.world.spawnParticle(EnumParticleTypes.CLOUD, entity.posX-x1, entity.posY + 1.6D, entity.posZ-z1, 0.0D, 0.0D, 0.0D, new int[0]);
		entity.world.spawnParticle(EnumParticleTypes.CLOUD, entity.posX-x2, entity.posY + 1.6D, entity.posZ-z2, 0.0D, 0.0D, 0.0D, new int[0]);
		*/
		if(entity.func_110143_aJ() <= entity.func_110138_aP()/2){
			if(entity.func_110143_aJ() <= entity.func_110138_aP()/4){
				entity.field_70170_p.func_175688_a(EnumParticleTypes.SMOKE_LARGE, entity.field_70165_t-2, entity.field_70163_u + 2D, entity.field_70161_v+2, 0.0D, 0.0D, 0.0D, new int[0]);
				entity.field_70170_p.func_175688_a(EnumParticleTypes.SMOKE_LARGE, entity.field_70165_t+2, entity.field_70163_u + 2D, entity.field_70161_v-1, 0.0D, 0.0D, 0.0D, new int[0]);
				int rx = entity.field_70170_p.field_73012_v.nextInt(5);
				int rz = entity.field_70170_p.field_73012_v.nextInt(5);
				entity.field_70170_p.func_175688_a(EnumParticleTypes.FLAME, entity.field_70165_t-2+rx, entity.field_70163_u + 2D, entity.field_70161_v-2+rz, 0.0D, 0.0D, 0.0D, new int[0]);
				entity.field_70170_p.func_175688_a(EnumParticleTypes.SMOKE_LARGE, entity.field_70165_t-2+rx, entity.field_70163_u + 2D, entity.field_70161_v-2+rz, 0.0D, 0.0D, 0.0D, new int[0]);
			}else{
				entity.field_70170_p.func_175688_a(EnumParticleTypes.SMOKE_LARGE, entity.field_70165_t-2, entity.field_70163_u + 2D, entity.field_70161_v+2, 0.0D, 0.0D, 0.0D, new int[0]);
				entity.field_70170_p.func_175688_a(EnumParticleTypes.SMOKE_LARGE, entity.field_70165_t+2, entity.field_70163_u + 2D, entity.field_70161_v-1, 0.0D, 0.0D, 0.0D, new int[0]);
				int rx = entity.field_70170_p.field_73012_v.nextInt(5);
				int rz = entity.field_70170_p.field_73012_v.nextInt(5);
				entity.field_70170_p.func_175688_a(EnumParticleTypes.SMOKE_LARGE, entity.field_70165_t-2+rx, entity.field_70163_u + 2D, entity.field_70161_v-2+rz, 0.0D, 0.0D, 0.0D, new int[0]);
			}
		}
	}
}
