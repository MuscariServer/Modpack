package gvclib.entity.living.cnt.ai;

import java.util.List;
import net.minecraft.entity.EntityLivingBase;


import gvclib.entity.living.EntityGVCLivingBase;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;

public class VehicleAI_RotationYawOffset {
	public static void offset(EntityLivingBase entity, EntityLivingBase ridding) {
		if (ridding.field_70759_as > 360F || ridding.field_70759_as < -360F) {
			ridding.field_70759_as = 0;
			ridding.field_70177_z = 0;
			ridding.field_70126_B = 0;
			ridding.field_70758_at = 0;
			ridding.field_70761_aq = 0;
		}
		if (ridding.field_70759_as > 180F) {
			ridding.field_70759_as = -179F;
			ridding.field_70177_z = -179F;
			ridding.field_70126_B = -179F;
			ridding.field_70758_at = -179F;
			ridding.field_70761_aq = -179F;
		}
		if (ridding.field_70759_as < -180F) {
			ridding.field_70759_as = 179F;
			ridding.field_70177_z = 179F;
			ridding.field_70126_B = 179F;
			ridding.field_70758_at = 179F;
			ridding.field_70761_aq = 179F;
		}
		if (entity.field_70759_as > 360F || entity.field_70759_as < -360F) {
			entity.field_70759_as = 0;
			entity.field_70177_z = 0;
			entity.field_70126_B = 0;
			entity.field_70758_at = 0;
			entity.field_70761_aq = 0;
		}
		if (entity.field_70759_as > 180F) {
			entity.field_70759_as = -179F;
			entity.field_70177_z = -179F;
			entity.field_70126_B = -179F;
			entity.field_70758_at = -179F;
			entity.field_70761_aq = -179F;
		}
		if (entity.field_70759_as < -180F) {
			entity.field_70759_as = 179F;
			entity.field_70177_z = 179F;
			entity.field_70126_B = 179F;
			entity.field_70758_at = 179F;
			entity.field_70761_aq = 179F;
		}
	}
}
