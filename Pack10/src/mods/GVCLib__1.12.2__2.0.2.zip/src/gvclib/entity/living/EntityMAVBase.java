package gvclib.entity.living;

import java.util.List;
import java.util.UUID;
import gvclib.item.ItemWrench;
import gvclib.mod_GVCLib;
import gvclib.network.GVCLClientMessageKeyPressed;
import gvclib.network.GVCLMessageKeyPressed;
import gvclib.network.GVCLPacketHandler;
import gvclib.world.GVCExplosionBase;
import javax.annotation.Nullable;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.MoverType;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.monster.IMob;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.Blocks;
import net.minecraft.init.MobEffects;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.EnumHand;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.text.TextComponentTranslation;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;
import net.minecraftforge.fml.common.FMLCommonHandler;


import javax.annotation.Nullable;

import gvclib.mod_GVCLib;
import gvclib.entity.living.AI_TankSet;
import gvclib.entity.living.EntityGVCLivingBase;
import gvclib.entity.living.EntityMobVehicleBase;
import gvclib.entity.living.ISoldier;
import gvclib.entity.living.PL_TankMove;
import gvclib.event.GVCSoundEvent;
import gvclib.item.ItemWrench;
import gvclib.network.GVCLClientMessageKeyPressed;
import gvclib.network.GVCLMessageKeyPressed;
import gvclib.network.GVCLPacketHandler;
import gvclib.world.GVCExplosionBase;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.MoverType;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.monster.IMob;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.Blocks;
import net.minecraft.init.MobEffects;
import net.minecraft.init.SoundEvents;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.EnumHand;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.text.TextComponentTranslation;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;
import net.minecraftforge.fml.common.FMLCommonHandler;

public class EntityMAVBase extends EntityMobVehicleBase
{

	private EntityLivingBase thrower;
    private String throwerName;
    
    public boolean return_basepoint = false;
	
    public EntityMAVBase(World worldIn)
    {
        super(worldIn);
        this.func_70105_a(0.8F, 0.8F);
        this.setcanDespawn(1);
        this.setVehicleLock(true);
        
        this.ridding_invisible = true;
        this.ridding_sneakdismount = true;
        this.render_hud_information_1 = "Z-KEY:Get off";
        
    }

    protected void func_110147_ax()
    {
        super.func_110147_ax();
        this.func_110148_a(SharedMonsterAttributes.field_111267_a).func_111128_a(50D);
        this.func_110148_a(SharedMonsterAttributes.field_111266_c).func_111128_a(20D);
    }
    
    public boolean func_184645_a(EntityPlayer player, EnumHand hand)
    {
    	ItemStack itemstack = player.func_184586_b(hand);
        boolean flag = !itemstack.func_190926_b();
        if(!player.func_184218_aH() && !player.func_70093_af() && (!(itemstack.func_77973_b() instanceof ItemWrench))) {
        	if(!this.field_70170_p.field_72995_K) {
        		EntityGVC_PlayerDummy ent = new EntityGVC_PlayerDummy(field_70170_p);
    			ent.func_70012_b(player.field_70165_t + 0, player.field_70163_u + 0, player.field_70161_v + 0, 0, 0.0F);
    			ent.setcanDespawn(1);
    			ent.setTamedBy(player);
    			
    			if(!player.func_184614_ca().func_190926_b())ent.func_184201_a(EntityEquipmentSlot.MAINHAND, player.func_184614_ca());
    			if(!player.func_184592_cb().func_190926_b())ent.func_184201_a(EntityEquipmentSlot.OFFHAND, player.func_184592_cb());
    			if(!player.func_184582_a(EntityEquipmentSlot.HEAD).func_190926_b())ent.func_184201_a(EntityEquipmentSlot.HEAD, player.func_184582_a(EntityEquipmentSlot.HEAD));
    			if(!player.func_184582_a(EntityEquipmentSlot.CHEST).func_190926_b())ent.func_184201_a(EntityEquipmentSlot.CHEST, player.func_184582_a(EntityEquipmentSlot.CHEST));
    			if(!player.func_184582_a(EntityEquipmentSlot.LEGS).func_190926_b())ent.func_184201_a(EntityEquipmentSlot.LEGS, player.func_184582_a(EntityEquipmentSlot.LEGS));
    			if(!player.func_184582_a(EntityEquipmentSlot.FEET).func_190926_b())ent.func_184201_a(EntityEquipmentSlot.FEET, player.func_184582_a(EntityEquipmentSlot.FEET));
    			
    			field_70170_p.func_72838_d(ent);
    			this.thrower = ent;
        	}
        	super.func_184645_a(player, hand);
        	this.setMoveX((int)player.field_70165_t);
        	this.setMoveY((int)player.field_70163_u);
        	this.setMoveZ((int)player.field_70161_v);
        	return true;
        }else {
        	return true;
        }
    }
    
    /**
     * Dismounts this entity from the entity it is riding.
     */
    public void func_184210_p()
    {
        Entity entity = this.func_184187_bx();
        super.func_184210_p();

        if (entity != null && entity != this.func_184187_bx() && !this.field_70170_p.field_72995_K)
        {
        	//if(!this.getRidingEntity().shouldDismountInWater(this))
            this.func_110145_l(entity);
        }
        if(!this.field_70170_p.field_72995_K && getThrower() != null) {
			getThrower().func_70106_y();
		}
    }
    
    protected void func_70609_aI() {
		++this.deathTicks;
		int x = this.field_70170_p.field_73012_v.nextInt(4);
		int y = this.field_70170_p.field_73012_v.nextInt(5);
		int z = this.field_70170_p.field_73012_v.nextInt(4);
		
		if(this.func_184179_bs() != null) {
			if(this.func_184179_bs()  instanceof EntityPlayer) {
				EntityPlayer player = (EntityPlayer) this.func_184179_bs();
				if(this.field_70170_p.field_72995_K)
					player.func_145747_a(new TextComponentTranslation("Break Vehicle!", new Object[0]));
			}
			if(FMLCommonHandler.instance().getMinecraftServerInstance() != null) {
				for (EntityPlayerMP player : FMLCommonHandler.instance().getMinecraftServerInstance().func_184103_al().func_181057_v())
	            {
					GVCLPacketHandler.INSTANCE2.sendTo((new GVCLClientMessageKeyPressed(444, this.func_145782_y())), player);
					GVCLPacketHandler.INSTANCE.sendToServer((new GVCLMessageKeyPressed(444, this.func_145782_y())));
	            }
			}else {
				if(this.func_184179_bs() != null) {
					this.func_184179_bs().func_70634_a(this.getMoveX(), this.getMoveY(), this.getMoveZ());
					this.func_184179_bs().func_184210_p();
				}
			}
		}
		
		if (this.deathTicks == 1 && !this.field_70170_p.field_72995_K) {
			GVCExplosionBase.ExplosionKai(this, this, this.field_70165_t + 0, this.field_70163_u + 0, this.field_70161_v + 0, 3, false,  false);
		}
		//if(this.getControllingPassenger() != null && this.getControllingPassenger() instanceof EntityLivingBase) {
		/*if(this.getControllingPassenger() != null) {
			//EntityLivingBase entity = (EntityLivingBase) this.getControllingPassenger();
			this.getControllingPassenger().setPositionAndUpdate(this.getMoveX(), this.getMoveY(), this.getMoveZ());
			this.getControllingPassenger().dismountRidingEntity();
			
		}*/
		
		if(!this.field_70170_p.field_72995_K && getThrower() != null) {
			getThrower().func_70106_y();
		}
		if (this.deathTicks >= 20 && !this.field_70170_p.field_72995_K && this.field_70122_E) {
			GVCExplosionBase.ExplosionKai(this, this, this.field_70165_t + 0, this.field_70163_u + 0, this.field_70161_v + 0, 3, false,  false);
			this.func_70106_y();
		}
		if (this.deathTicks == 20 && !this.field_70170_p.field_72995_K) {
			this.func_70106_y();
		}
	}
    
    
    @Nullable
    public EntityLivingBase getThrower()
    {
        if (this.thrower == null && this.throwerName != null && !this.throwerName.isEmpty())
        {
            this.thrower = this.field_70170_p.func_72924_a(this.throwerName);

            if (this.thrower == null && this.field_70170_p instanceof WorldServer)
            {
                try
                {
                    Entity entity = ((WorldServer)this.field_70170_p).func_175733_a(UUID.fromString(this.throwerName));

                    if (entity instanceof EntityLivingBase)
                    {
                        this.thrower = (EntityLivingBase)entity;
                    }
                }
                catch (Throwable var2)
                {
                    this.thrower = null;
                }
            }
        }

        return this.thrower;
    }
    
    
    public void func_70071_h_() {
		super.func_70071_h_();
    }

   
    
    public void move_mav() {
    	float f1 = this.field_70759_as * (2 * (float) Math.PI / 360);
    	if (this.func_82171_bF() && this.func_184179_bs() != null && this.func_110143_aJ() > 0.0F)
		{
			if(this.func_184179_bs() instanceof EntityPlayer)
			{
				EntityPlayer entitylivingbase = (EntityPlayer) this.func_184179_bs();
				
				//entitylivingbase.height = 0.8F;
				{
					double x = this.field_70165_t;
					double y = this.field_70163_u;
					double z = this.field_70161_v;
			  //      if (this.isAddedToWorld() && !this.world.isRemote) this.world.updateEntityWithOptionalForce(this, false); // Forge - Process chunk registration after moving.
			        float f = this.field_70130_N / 2.0F;
			        float f12 = this.field_70131_O;
			        entitylivingbase.func_174826_a(new AxisAlignedBB(x - (double)f, y, z - (double)f, x + (double)f, y + (double)f12, z + (double)f));
				}
				
				this.setcanDespawn(1);
				//entitylivingbase.rotationYawHead = this.rotationYaw;
				this.rotation = this.field_70177_z = this.field_70761_aq = entitylivingbase.field_70759_as;
				this.rotationp = this.field_70125_A = entitylivingbase.field_70125_A;
				Vec3d looked = entitylivingbase.func_70040_Z();
				//PL_TankMove.movecar(entitylivingbase, this, sp, turnspeed);

				double xmove = 0;
				double zmove = 0;
				if (entitylivingbase.field_191988_bg > 0.0F) {
					xmove -= MathHelper.func_76126_a(f1) * 0.05;
					zmove += MathHelper.func_76134_b(f1) * 0.05;
				}
				if (entitylivingbase.field_191988_bg < 0.0F) {
					xmove -= MathHelper.func_76126_a(f1) * -0.05;
					zmove += MathHelper.func_76134_b(f1) * -0.05;
				}
				
				if (entitylivingbase.field_70702_br > 0.0F) {
					xmove -= MathHelper.func_76126_a(f1 - 1.57F) * 0.05;
					zmove += MathHelper.func_76134_b(f1 - 1.57F) * 0.05;
				}
				if (entitylivingbase.field_70702_br < 0.0F) {
					xmove -= MathHelper.func_76126_a(f1 - 1.57F) * -0.05;
					zmove += MathHelper.func_76134_b(f1 - 1.57F) * -0.05;
				}
				
				{
					this.field_70159_w = xmove;
					this.field_70179_y = zmove;
					//entity.motionY = y;
					this.func_70091_d(MoverType.PLAYER, this.field_70159_w, this.field_70181_x, this.field_70179_y);
				}
				boolean left = mod_GVCLib.proxy.leftclick();
				boolean right = mod_GVCLib.proxy.rightclick();
				boolean jump = mod_GVCLib.proxy.jumped();
				boolean kx = mod_GVCLib.proxy.keyx();
				boolean kg = mod_GVCLib.proxy.keyg();
				boolean kc = mod_GVCLib.proxy.keyc();
				boolean kz = mod_GVCLib.proxy.keyz();
				if (left) {
					GVCLPacketHandler.INSTANCE.sendToServer(new GVCLMessageKeyPressed(11, this.func_145782_y()));
					this.server1 = true;
				}
				if (right) {
					GVCLPacketHandler.INSTANCE.sendToServer(new GVCLMessageKeyPressed(12, this.func_145782_y()));
				}
				if (jump) {
					this.serverspace = true;
					GVCLPacketHandler.INSTANCE.sendToServer(new GVCLMessageKeyPressed(13, this.func_145782_y()));
					GVCLPacketHandler.INSTANCE2.sendToAll(new GVCLClientMessageKeyPressed(13, this.func_145782_y()));
				}
				if (kx) {
					GVCLPacketHandler.INSTANCE.sendToServer(new GVCLMessageKeyPressed(14, this.func_145782_y()));
				}
				if (kg) {
					GVCLPacketHandler.INSTANCE.sendToServer(new GVCLMessageKeyPressed(15, this.func_145782_y()));
				}
				if (kc) {
					GVCLPacketHandler.INSTANCE.sendToServer(new GVCLMessageKeyPressed(16, this.func_145782_y()));
				}
				if (kz) {
					this.serverz = true;
					GVCLPacketHandler.INSTANCE.sendToServer(new GVCLMessageKeyPressed(17, this.func_145782_y()));
					GVCLPacketHandler.INSTANCE2.sendToAll(new GVCLClientMessageKeyPressed(17, this.func_145782_y()));
				}
				double ymove = 0.0265;
				if (this.serverspace) {
					ymove = 0.10;
					this.serverspace = false;
				}
				/*if(this.serverz) {
					ymove = -0.1;
					this.serverz = false;
				}*/
				if(entitylivingbase.func_70093_af()) {
					ymove = -0.1;
				}
				{
					this.field_70181_x = ymove;
					this.func_70091_d(MoverType.PLAYER, this.field_70159_w, this.field_70181_x, this.field_70179_y);
				}
				
				
				if (this.server1) {
					
					{
		    			Vec3d lock = Vec3d.func_189986_a(entitylivingbase.field_70125_A, entitylivingbase.field_70177_z);
						int ix = 0;
						int iy = 0;
						int iz = 0;
						for(int x = 0; x < 120; ++x) {
							if (entitylivingbase.field_70170_p
									.func_180495_p(new BlockPos(entitylivingbase.field_70165_t + lock.field_72450_a * x,
											entitylivingbase.field_70163_u + 1.5 + lock.field_72448_b * x,
											entitylivingbase.field_70161_v + lock.field_72449_c * x))
									.func_177230_c() != Blocks.field_150350_a) {
								ix = (int) (entitylivingbase.field_70165_t + lock.field_72450_a * x);
								iy = (int) (entitylivingbase.field_70163_u + 1.5 + lock.field_72448_b * x);
								iz = (int) (entitylivingbase.field_70161_v + lock.field_72449_c * x);
								entitylivingbase.field_70170_p.func_175688_a(EnumParticleTypes.EXPLOSION_NORMAL, 
										entitylivingbase.field_70165_t +lock.field_72450_a * x,  entitylivingbase.field_70163_u + 1.5 +lock.field_72448_b * x, entitylivingbase.field_70161_v +lock.field_72449_c * x, 0, 0, 0);
								break;
							}
						}
						if(ix != 0 && iz != 0 && iy != 0) {
							EntityLivingBase target = null;
							{
								int han = 1;
				            	AxisAlignedBB axisalignedbb2 = (new AxisAlignedBB((double)(ix-han), (double)(iy-han), (double)(iz-han), 
				            			(double)(ix + han), (double)(iy + han), (double)(iz+ han)))
				                		.func_186662_g(3);
				                List llist2 = entitylivingbase.field_70170_p.func_72839_b(entitylivingbase, axisalignedbb2);
				                if(llist2!=null){
				                    for (int lj = 0; lj < llist2.size(); lj++) {
				                    	
				                    	Entity entity1 = (Entity)llist2.get(lj);
				                    	if (entity1.func_70067_L())
				                        {
				                    		if (entity1 instanceof IMob && entity1 != null)
				                            {
				                    			EntityLivingBase mob = (EntityLivingBase) entity1;
				                    			mob.func_70690_d(new PotionEffect(MobEffects.field_188423_x, 400, 200));
				                    			target = mob;
				                            }
				                        }
				                    }
				                }
							}
			                /*if(target != null){
			                	int han = 80;
			                	double x = player.posX;
			                	double y = player.posY;
			                	double z = player.posZ;
			                	AxisAlignedBB axisalignedbb2 = (new AxisAlignedBB((double)(x-han), (double)(y-han), (double)(z-han), 
				            			(double)(x + han), (double)(y + han), (double)(z+ han)))
				                		.grow(1);
				                List llist2 = player.world.getEntitiesWithinAABBExcludingEntity(player, axisalignedbb2);
				                if(llist2!=null){
				                    for (int lj = 0; lj < llist2.size(); lj++) {
				                    	
				                    	Entity entity1 = (Entity)llist2.get(lj);
				                    	if (entity1.canBeCollidedWith())
				                        {
				                    		if (entity1 instanceof ISoldier && entity1 != null)
				                            {
				                    			EntityGVCLivingBase mob = (EntityGVCLivingBase) entity1;
				                    			mob.targetentity = target;
				                    			mob.setMobMode(1);
				                    			mob.sneak = true;
				                    			mob.setattacktask(true);
				                    			{
				                    				mob.world.spawnParticle(EnumParticleTypes.NOTE, 
				                    						mob.posX,  mob.posY + mob.height + 1, mob.posZ, 0, 0, 0);
				                    			}
				                            }
				                        }
				                    }
				                }
			                }*/
			                
						}
		        		
		    		}
					
					
					this.server1 = false;
				}
				
				
			}//player
			else if(this.func_184179_bs() instanceof EntityGVCLivingBase) {
				
			}
		}
    }
    
}
