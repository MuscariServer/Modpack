package gvclib.entity.living;

import java.util.List;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;


import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public abstract class AI_EntityMoveAirCraft {
	public static void moveheli(EntityGVCLivingBase entity, EntityGVCLivingBase ridding, float f1, float sp,
			float turnspeed, double max, double range, int gy) {
		entity.target = false;
		BlockPos bp = entity.field_70170_p.func_175645_m(new BlockPos(entity.field_70165_t, entity.field_70163_u, entity.field_70161_v));
		int genY = bp.func_177956_o() + gy;
		if (entity.field_70163_u <= genY) {
			if (entity.throttle < entity.thmax) {
				++entity.throttle;
			}
			entity.thpower = entity.thpower + entity.thmaxa;
		}
		if (entity.field_70163_u > genY) {
			if (entity.thpower > entity.thmax / 2) {
				entity.thpower = entity.thpower + entity.thmina;
			}
			if (entity.throttle > entity.thmax / 2) {
				--entity.throttle;
			}
		}
		if (ridding.field_70759_as > 360F || ridding.field_70759_as < -360F) {
			ridding.field_70759_as = 0;
			ridding.field_70177_z = 0;
			ridding.field_70126_B = 0;
			ridding.field_70758_at = 0;
			ridding.field_70761_aq = 0;
		}
		if (ridding.field_70759_as > 180F) {
			ridding.field_70759_as = -179F;
			ridding.field_70177_z = -179F;
			ridding.field_70126_B = -179F;
			ridding.field_70758_at = -179F;
			ridding.field_70761_aq = -179F;
		}
		if (ridding.field_70759_as < -180F) {
			ridding.field_70759_as = 179F;
			ridding.field_70177_z = 179F;
			ridding.field_70126_B = 179F;
			ridding.field_70758_at = 179F;
			ridding.field_70761_aq = 179F;
		}
		if (entity.field_70759_as > 360F || entity.field_70759_as < -360F) {
			entity.field_70759_as = 0;
			entity.field_70177_z = 0;
			entity.field_70126_B = 0;
			entity.field_70758_at = 0;
			entity.field_70761_aq = 0;
		}
		if (entity.field_70759_as > 180F) {
			entity.field_70759_as = -179F;
			entity.field_70177_z = -179F;
			entity.field_70126_B = -179F;
			entity.field_70758_at = -179F;
			entity.field_70761_aq = -179F;
		}
		if (entity.field_70759_as < -180F) {
			entity.field_70759_as = 179F;
			entity.field_70177_z = 179F;
			entity.field_70126_B = 179F;
			entity.field_70758_at = 179F;
			entity.field_70761_aq = 179F;
		}
		/*if( entity.throttle >= 0){
			if(entity.thpower < entity.throttle){
				if( entity.throttle > entity.thmax-5){
					entity.thpower = entity.thpower + entity.thmaxa;
				}else{
					entity.thpower = entity.thpower + entity.thmaxa*0.5;
				}
			}else{
				entity.thpower = entity.thpower + entity.thmina;
			}
			if(entity.throttle <= 0 && entity.throttle > 0){
				entity.thpower = entity.thpower + entity.thmina * 2;
			}
		}*/
		if (ridding.getMoveT() == 1) {
			double d5 = ridding.getMoveX() - entity.field_70165_t;
			double d7 = ridding.getMoveZ() - entity.field_70161_v;
			double d6 = ridding.getMoveY() - entity.field_70163_u;
			double d1 = entity.field_70163_u - (ridding.getMoveY());
			double d3 = (double) MathHelper.func_76133_a(d5 * d5 + d7 * d7);
			float f11 = (float) (-(Math.atan2(d1, d3) * 180.0D / Math.PI));
			entity.rote = -((float) Math.atan2(d5, d7)) * 180.0F / (float) Math.PI;

			if (entity.rote > 180F) {
				entity.rote = -179F;
			}
			if (entity.rote < -180F) {
				entity.rote = 179F;
			}
			if (entity.getAIType3() != 1) {
				if (entity.field_70759_as != entity.rote) {
					if (entity.field_70759_as < entity.rote) {
						entity.field_70759_as = entity.field_70759_as + turnspeed;
						entity.field_70177_z = entity.field_70177_z + turnspeed;
						entity.field_70126_B = entity.field_70126_B + turnspeed;
						entity.field_70758_at = entity.field_70758_at + turnspeed;
					} else if (entity.field_70759_as > entity.rote) {
						entity.field_70759_as = entity.field_70759_as - turnspeed;
						entity.field_70177_z = entity.field_70177_z - turnspeed;
						entity.field_70126_B = entity.field_70126_B - turnspeed;
						entity.field_70758_at = entity.field_70758_at - turnspeed;
					}
				}
			}

			double ddx = Math.abs(d5);
			double ddz = Math.abs(d7);
			if ((ddx > max || ddz > max)) {
				if (entity.getAIType3() != 1) {
					ridding.field_70125_A = entity.field_70125_A = entity.rotationp = -f11 + 10;
					entity.setAIType3(0);
				}
			} else {
				if (entity.getAIType3() == 0) {
					entity.setAIType3(1);
					entity.aitypetime3 = 0;
				}
			}
		} else {
			List<Entity> llist = entity.field_70170_p.func_72839_b(entity,
					entity.func_174813_aQ().func_72321_a(entity.field_70159_w, entity.field_70181_x, entity.field_70179_y).func_186662_g(range));
			if (llist != null) {
				for (int lj = 0; lj < llist.size(); lj++) {
					Entity entity1 = (Entity) llist.get(lj);
					if (entity1.func_70067_L()) {
						boolean flag = entity.func_70635_at().func_75522_a(entity1);
						if (ridding.targetentity == entity1 && ridding.CanAttack(entity1)) {
							double d5 = entity1.field_70165_t - entity.field_70165_t;
							double d7 = entity1.field_70161_v - entity.field_70161_v;
							double d6 = entity1.field_70163_u - entity.field_70163_u;
							double d1 = entity.field_70163_u - (entity1.field_70163_u);
							double d3 = (double) MathHelper.func_76133_a(d5 * d5 + d7 * d7);
							float f11 = (float) (-(Math.atan2(d1, d3) * 180.0D / Math.PI));
							entity.rote = -((float) Math.atan2(d5, d7)) * 180.0F / (float) Math.PI;

							if (entity.rote > 180F) {
								entity.rote = -179F;
							}
							if (entity.rote < -180F) {
								entity.rote = 179F;
							}
							if (entity.getAIType3() != 1) {
								if (entity.field_70759_as != entity.rote) {
									if (entity.field_70759_as < entity.rote) {
										entity.field_70759_as = entity.field_70759_as + turnspeed;
										entity.field_70177_z = entity.field_70177_z + turnspeed;
										entity.field_70126_B = entity.field_70126_B + turnspeed;
										entity.field_70758_at = entity.field_70758_at + turnspeed;
									} else if (entity.field_70759_as > entity.rote) {
										entity.field_70759_as = entity.field_70759_as - turnspeed;
										entity.field_70177_z = entity.field_70177_z - turnspeed;
										entity.field_70126_B = entity.field_70126_B - turnspeed;
										entity.field_70758_at = entity.field_70758_at - turnspeed;
									}
								}
							}

							double ddx = Math.abs(d5);
							double ddz = Math.abs(d7);
							if ((ddx > max || ddz > max)) {
								if (entity.getAIType3() != 1) {
									ridding.field_70125_A = entity.field_70125_A = entity.rotationp = -f11 + 10;
									entity.setAIType3(0);
								}
							} else {
								if (entity.getAIType3() == 0) {
									entity.setAIType3(1);
									entity.aitypetime3 = 0;
								}
							}

							if (flag) {
								ridding.targetentity = (EntityLivingBase) entity1;
							}
							ridding.target = true;
							break;
						} else
						//if(ridding.targetentity == null)
						if (ridding.CanAttack(entity1) && flag) {
							//if (ridding.CanAttack(entity1) && flag) 
							{
								ridding.targetentity = (EntityLivingBase) entity1;
								ridding.target = true;
								break;
							}
						}
					}
				}
			}
			if (!ridding.target && entity.func_110143_aJ() > 0.0F) {
				if (entity.getMoveT() == 2) {
					ridding.field_70125_A = entity.field_70125_A = entity.rotationp = 10;
					double d5 = entity.getMoveX() - entity.field_70165_t;
					double d7 = entity.getMoveZ() - entity.field_70161_v;

					entity.rotation = entity.rote = -((float) Math.atan2(d5, d7)) * 180.0F / (float) Math.PI;
					if (entity.rote > 180F) {
						entity.rote = -179F;
					}
					if (entity.rote < -180F) {
						entity.rote = 179F;
					}
					if (entity.getAIType3() != 1) {
						if (entity.field_70759_as != entity.rote) {
							if (entity.field_70759_as < entity.rote) {
								entity.field_70759_as = entity.field_70759_as + turnspeed;
								entity.field_70177_z = entity.field_70177_z + turnspeed;
								entity.field_70126_B = entity.field_70126_B + turnspeed;
								entity.field_70758_at = entity.field_70758_at + turnspeed;
							} else if (entity.field_70759_as > entity.rote) {
								entity.field_70759_as = entity.field_70759_as - turnspeed;
								entity.field_70177_z = entity.field_70177_z - turnspeed;
								entity.field_70126_B = entity.field_70126_B - turnspeed;
								entity.field_70758_at = entity.field_70758_at - turnspeed;
							}
						}
					}

					double ddx = Math.abs(d5);
					double ddz = Math.abs(d7);
					if ((ddx > max || ddz > max)) {
						if (entity.getAIType3() != 1) {
							entity.setAIType3(0);
						}
					} else {
						if (entity.getAIType3() == 0) {
							entity.setAIType3(1);
							entity.aitypetime3 = 0;
						}
					}
				} else {
					if (!entity.field_70170_p.field_72995_K) {
						entity.field_70759_as = entity.field_70759_as + 1;
						entity.field_70177_z = entity.field_70177_z + 1;
						entity.field_70126_B = entity.field_70126_B + 1;
						entity.field_70758_at = entity.field_70758_at + 1;
					}
					ridding.field_70125_A = entity.field_70125_A = entity.rotationp = 10;
				}
			}
		}
		if (entity.getAIType3() == 1) {
			ridding.field_70125_A = entity.field_70125_A = entity.rotationp = 40;
			if (entity.aitypetime3 > 80) {
				entity.setAIType3(0);
				entity.aitypetime3 = 0;
			}
		}
	}

	public static void movefighter(EntityGVCLivingBase entity, EntityGVCLivingBase ridding, float f1, float sp,
			float turnspeed,
			double max, double range, int minheight) {
		Vec3d look = entity.func_70040_Z();
		//entity.rotationp = entity.rotationPitch= entity.prevRotationPitch = -30;
		//ridding.rotationp = ridding.rotationPitch= ridding.prevRotationPitch = -30;

		float rop = 0;
		if (ridding.field_70759_as > 360F || ridding.field_70759_as < -360F) {
			ridding.field_70759_as = 0;
			ridding.field_70177_z = 0;
			ridding.field_70126_B = 0;
			ridding.field_70758_at = 0;
			ridding.field_70761_aq = 0;
		}
		if (ridding.field_70759_as > 180F) {
			ridding.field_70759_as = -179F;
			ridding.field_70177_z = -179F;
			ridding.field_70126_B = -179F;
			ridding.field_70758_at = -179F;
			ridding.field_70761_aq = -179F;
		}
		if (ridding.field_70759_as < -180F) {
			ridding.field_70759_as = 179F;
			ridding.field_70177_z = 179F;
			ridding.field_70126_B = 179F;
			ridding.field_70758_at = 179F;
			ridding.field_70761_aq = 179F;
		}
		if (entity.field_70759_as > 360F || entity.field_70759_as < -360F) {
			entity.field_70759_as = 0;
			entity.field_70177_z = 0;
			entity.field_70126_B = 0;
			entity.field_70758_at = 0;
			entity.field_70761_aq = 0;
		}
		if (entity.field_70759_as > 180F) {
			entity.field_70759_as = -179F;
			entity.field_70177_z = -179F;
			entity.field_70126_B = -179F;
			entity.field_70758_at = -179F;
			entity.field_70761_aq = -179F;
		}
		if (entity.field_70759_as < -180F) {
			entity.field_70759_as = 179F;
			entity.field_70177_z = 179F;
			entity.field_70126_B = 179F;
			entity.field_70758_at = 179F;
			entity.field_70761_aq = 179F;
		}
		if (ridding.getMoveT() == 1) {
			double d5 = ridding.getMoveX() - entity.field_70165_t;
			double d7 = ridding.getMoveZ() - entity.field_70161_v;
			double d6 = ridding.getMoveY() - entity.field_70163_u;
			double d1 = entity.field_70163_u - (ridding.getMoveY());
			double d3 = (double) MathHelper.func_76133_a(d5 * d5 + d7 * d7);
			float f11 = (float) (-(Math.atan2(d1, d3) * 180.0D / Math.PI));
			entity.rotation = entity.rote = -((float) Math.atan2(d5, d7)) * 180.0F / (float) Math.PI;

			double ddx = Math.abs(d5);
			double ddz = Math.abs(d7);
			entity.rote = -((float) Math.atan2(d5, d7)) * 180.0F / (float) Math.PI;
			rop = -f11;
			if (entity.rote > 180F) {
				entity.rote = -179F;
			}
			if (entity.rote < -180F) {
				entity.rote = 179F;
			}
			float f3 = (float) (entity.field_70759_as - entity.rote);
			//if(!entity.world.isRemote)
			if (entity.getAIType() != 3) {
				if (entity.field_70759_as != entity.rote) {
					if (f3 > turnspeed) {
						if (f3 > 180F) {
							PL_RoteModel.rotemodel(entity, +turnspeed);
							if (entity.throte < 50) {
								entity.throte = entity.throte + 2;
							}
						} else {
							PL_RoteModel.rotemodel(entity, -turnspeed);
							if (entity.throte > -50) {
								entity.throte = entity.throte - 2;
							}
						}
					} else if (f3 < -turnspeed) {
						if (f3 < -180F) {
							PL_RoteModel.rotemodel(entity, -turnspeed);
							if (entity.throte > -50) {
								entity.throte = entity.throte - 2;
							}
						} else {
							PL_RoteModel.rotemodel(entity, +turnspeed);
							if (entity.throte < 50) {
								entity.throte = entity.throte + 2;
							}
						}
					}
				}
			}
			ridding.target = true;
		} else {
			List<Entity> llist = entity.field_70170_p.func_72839_b(entity, entity
					.func_174813_aQ().func_72321_a(entity.field_70159_w, entity.field_70181_x, entity.field_70179_y).func_186662_g(range));
			if (llist != null) {
				for (int lj = 0; lj < llist.size(); lj++) {
					Entity entity1 = (Entity) llist.get(lj);
					if (entity1.func_70067_L()) {
						boolean flag = entity.func_70635_at().func_75522_a(entity1);
						if (ridding.CanAttack(entity1) && entity1 != null) {
							if(ridding.targetentity == entity1 && ((EntityLivingBase) entity1).func_110143_aJ() > 0.0F)
							{
								double d5 = entity1.field_70165_t - entity.field_70165_t;
								double d7 = entity1.field_70161_v - entity.field_70161_v;
								double d6 = entity1.field_70163_u - entity.field_70163_u;
								double d1 = entity.field_70163_u - (entity1.field_70163_u);
								double d3 = (double) MathHelper.func_76133_a(d5 * d5 + d7 * d7);
								float f11 = (float) (-(Math.atan2(d1, d3) * 180.0D / Math.PI));
								entity.rotation = entity.rote = -((float) Math.atan2(d5, d7)) * 180.0F
										/ (float) Math.PI;

								double ddx = Math.abs(d5);
								double ddz = Math.abs(d7);
								entity.rote = -((float) Math.atan2(d5, d7)) * 180.0F / (float) Math.PI;
								rop = -f11;
								if (entity.rote > 180F) {
									entity.rote = -179F;
								}
								if (entity.rote < -180F) {
									entity.rote = 179F;
								}
								float f3 = (float) (entity.field_70759_as - entity.rote);
								//if(!entity.world.isRemote)
								if (entity.getAIType() != 3) {
									if (entity.field_70759_as != entity.rote) {
										if (f3 > turnspeed) {
											if (f3 > 180F) {
												PL_RoteModel.rotemodel(entity, +turnspeed);
												if (entity.throte < 50) {
													entity.throte = entity.throte + 2;
												}
											} else {
												PL_RoteModel.rotemodel(entity, -turnspeed);
												if (entity.throte > -50) {
													entity.throte = entity.throte - 2;
												}
											}
										} else if (f3 < -turnspeed) {
											if (f3 < -180F) {
												PL_RoteModel.rotemodel(entity, -turnspeed);
												if (entity.throte > -50) {
													entity.throte = entity.throte - 2;
												}
											} else {
												PL_RoteModel.rotemodel(entity, +turnspeed);
												if (entity.throte < 50) {
													entity.throte = entity.throte + 2;
												}
											}
										}
									}
								}
								if (flag) {
									ridding.targetentity = (EntityLivingBase) entity1;
								}
								ridding.target = true;
								//System.out.println(String.format("0"));
								break;
							}else {
								if(ridding.targetentity == null)
								{
									if (ridding.CanAttack(entity1) && flag) 
									{
										ridding.targetentity = (EntityLivingBase) entity1;
										//System.out.println(String.format("1"));
										break;
									}
									ridding.target = false;
								}
								break;
							}
							
						} else {
							ridding.target = false;
						}
					}
				}
			}
			if (!ridding.target && entity.func_110143_aJ() > 0.0F) {
				movestay(entity, ridding, turnspeed, turnspeed, turnspeed, max, range);
			}
		}
		if (entity != null) {
			BlockPos bp = entity.field_70170_p.func_175645_m(new BlockPos(entity.field_70165_t, entity.field_70163_u, entity.field_70161_v));
			int genY = bp.func_177956_o() + minheight;
			if (entity.field_70163_u < genY) {
				entity.rotationp = entity.field_70125_A = entity.field_70127_C = entity.field_70125_A - 1;
				ridding.rotationp = ridding.field_70125_A = ridding.field_70127_C = entity.field_70125_A - 1;
			} else {

				entity.rotationp = entity.field_70125_A = entity.field_70127_C = rop;
				ridding.rotationp = ridding.field_70125_A = ridding.field_70127_C = rop;
			}
			//entity.setVelocity(look.x * sp*20, MathHelper.sin(-entity.rotationp * 0.017453292F), look.z * sp*20);
			{
				entity.field_70159_w = look.field_72450_a * sp * 20;
				entity.field_70181_x = MathHelper.func_76126_a(-entity.rotationp * 0.017453292F);
				entity.field_70179_y = look.field_72449_c * sp * 20;
			}
			if (entity.throttle < entity.thmax * 0.5) {
				++entity.throttle;
				//entity.thpower = entity.thpower + 0.6D;
				entity.thpower = entity.thmax * 0.5;
			}
		}

		//if( entity.throttle >= 1)
		{
			if (entity.thpera < 360) {
				entity.thpera = entity.thpera + (entity.throttle * 2);
			} else {
				entity.thpera = 0;
			}
		}
	}

	public static void movestay(EntityGVCLivingBase entity, EntityGVCLivingBase ridding, float f1, float sp,
			float turnspeed, double max, double range) {
		Vec3d look = entity.func_70040_Z();
		/*if(!entity.world.isRemote){
			entity.rotationYawHead = entity.rotationYawHead + 1;
		entity.rotationYaw = entity.rotationYaw + 1;
		entity.prevRotationYaw = entity.prevRotationYaw + 1;
		entity.prevRotationYawHead = entity.prevRotationYawHead + 1;
		}*/
		{
			BlockPos bp = entity.field_70170_p.func_175645_m(new BlockPos(entity.field_70165_t, entity.field_70163_u, entity.field_70161_v));
			int genY = bp.func_177956_o();

			if (entity.field_70163_u < genY + 15 + (entity.getAIType2() * 4)) {
				entity.rotationp = entity.field_70125_A = entity.field_70127_C = -4;
				ridding.rotationp = ridding.field_70125_A = ridding.field_70127_C = -4;
			} else if (entity.field_70163_u > genY + 15 + (entity.getAIType2() * 4)) {
				entity.rotationp = entity.field_70125_A = entity.field_70127_C = 4;
				ridding.rotationp = ridding.field_70125_A = ridding.field_70127_C = 4;
			} else {
				entity.rotationp = entity.field_70125_A = entity.field_70127_C = -0;
				ridding.rotationp = ridding.field_70125_A = ridding.field_70127_C = -0;
			}
			//entity.setVelocity(look.x * sp, MathHelper.sin(-entity.rotationp * 0.017453292F), look.z * sp);
		}

		if (entity.getMoveX() != 0) {
			double d5 = entity.getMoveX() - entity.field_70165_t;
			double d7 = entity.getMoveZ() - entity.field_70161_v;

			entity.rotation = entity.rote = -((float) Math.atan2(d5, d7)) * 180.0F / (float) Math.PI;

			double ddx = Math.abs(d5);
			double ddz = Math.abs(d7);
			entity.rote = -((float) Math.atan2(d5, d7)) * 180.0F / (float) Math.PI;
			if (entity.rote > 180F) {
				entity.rote = -179F;
			}
			if (entity.rote < -180F) {
				entity.rote = 179F;
			}
			float f3 = (float) (entity.field_70759_as - entity.rote);

			{
				if (entity.field_70759_as != entity.rote) {
					if (f3 > turnspeed) {
						if (f3 > 180F) {
							PL_RoteModel.rotemodel(entity, +turnspeed);
							if (entity.throte < 50) {
								entity.throte = entity.throte + 2;
							}
						} else {
							PL_RoteModel.rotemodel(entity, -turnspeed);
							if (entity.throte > -50) {
								entity.throte = entity.throte - 2;
							}
						}
					} else if (f3 < -turnspeed) {
						if (f3 < -180F) {
							PL_RoteModel.rotemodel(entity, -turnspeed);
							if (entity.throte > -50) {
								entity.throte = entity.throte - 2;
							}
						} else {
							PL_RoteModel.rotemodel(entity, +turnspeed);
							if (entity.throte < 50) {
								entity.throte = entity.throte + 2;
							}
						}
					}
				}
			}
		} else {
			if (!entity.field_70170_p.field_72995_K) {
				entity.field_70759_as = entity.field_70759_as + 1;
				entity.field_70177_z = entity.field_70177_z + 1;
				entity.field_70126_B = entity.field_70126_B + 1;
				entity.field_70758_at = entity.field_70758_at + 1;
			}
		}

		if (entity.throttle < entity.thmax * 0.25) {
			++entity.throttle;
			//entity.thpower = entity.thpower + 0.6D;
			entity.thpower = 1;
		}

	}

	
	
	
	public static void moveheli_new(EntityGVCLivingBase entity, EntityGVCLivingBase ridding, float f1, float sp,
			float turnspeed, double max, double range, int gy) {
		entity.target = false;
		BlockPos bp = entity.field_70170_p.func_175645_m(new BlockPos(entity.field_70165_t, entity.field_70163_u, entity.field_70161_v));
		int genY = bp.func_177956_o() + gy;
		if (entity.field_70163_u <= genY) {
			if (entity.throttle < entity.thmax) {
				++entity.throttle;
			}
			entity.thpower = entity.thpower + entity.thmaxa;
			entity.throttle_up = 1;
		}
		if (entity.field_70163_u > genY) {
			if (entity.thpower > entity.thmax / 2) {
				entity.thpower = entity.thpower + entity.thmina;
			}
			if (entity.throttle > entity.thmax / 2) {
				--entity.throttle;
			}
			entity.throttle_up = -1;
		}
		if (ridding.field_70759_as > 360F || ridding.field_70759_as < -360F) {
			ridding.field_70759_as = 0;
			ridding.field_70177_z = 0;
			ridding.field_70126_B = 0;
			ridding.field_70758_at = 0;
			ridding.field_70761_aq = 0;
		}
		if (ridding.field_70759_as > 180F) {
			ridding.field_70759_as = -179F;
			ridding.field_70177_z = -179F;
			ridding.field_70126_B = -179F;
			ridding.field_70758_at = -179F;
			ridding.field_70761_aq = -179F;
		}
		if (ridding.field_70759_as < -180F) {
			ridding.field_70759_as = 179F;
			ridding.field_70177_z = 179F;
			ridding.field_70126_B = 179F;
			ridding.field_70758_at = 179F;
			ridding.field_70761_aq = 179F;
		}
		if (entity.field_70759_as > 360F || entity.field_70759_as < -360F) {
			entity.field_70759_as = 0;
			entity.field_70177_z = 0;
			entity.field_70126_B = 0;
			entity.field_70758_at = 0;
			entity.field_70761_aq = 0;
		}
		if (entity.field_70759_as > 180F) {
			entity.field_70759_as = -179F;
			entity.field_70177_z = -179F;
			entity.field_70126_B = -179F;
			entity.field_70758_at = -179F;
			entity.field_70761_aq = -179F;
		}
		if (entity.field_70759_as < -180F) {
			entity.field_70759_as = 179F;
			entity.field_70177_z = 179F;
			entity.field_70126_B = 179F;
			entity.field_70758_at = 179F;
			entity.field_70761_aq = 179F;
		}
		if (ridding.getMoveT() == 1) {
			double d5 = ridding.getMoveX() - entity.field_70165_t;
			double d7 = ridding.getMoveZ() - entity.field_70161_v;
			double d6 = ridding.getMoveY() - entity.field_70163_u;
			double d1 = entity.field_70163_u - (ridding.getMoveY());
			double d3 = (double) MathHelper.func_76133_a(d5 * d5 + d7 * d7);
			float f11 = (float) (-(Math.atan2(d1, d3) * 180.0D / Math.PI));
			entity.rote = -((float) Math.atan2(d5, d7)) * 180.0F / (float) Math.PI;

			if (entity.rote > 180F) {
				entity.rote = -179F;
			}
			if (entity.rote < -180F) {
				entity.rote = 179F;
			}
			if (entity.getAIType3() != 1) {
				if (entity.field_70759_as != entity.rote) {
					if (entity.field_70759_as < entity.rote) {
						entity.field_70759_as = entity.field_70759_as + turnspeed;
						entity.field_70177_z = entity.field_70177_z + turnspeed;
						entity.field_70126_B = entity.field_70126_B + turnspeed;
						entity.field_70758_at = entity.field_70758_at + turnspeed;
					} else if (entity.field_70759_as > entity.rote) {
						entity.field_70759_as = entity.field_70759_as - turnspeed;
						entity.field_70177_z = entity.field_70177_z - turnspeed;
						entity.field_70126_B = entity.field_70126_B - turnspeed;
						entity.field_70758_at = entity.field_70758_at - turnspeed;
					}
				}
			}

			double ddx = Math.abs(d5);
			double ddz = Math.abs(d7);
			if ((ddx > max || ddz > max)) {
				if (entity.getAIType3() != 1) {
					ridding.field_70125_A = entity.field_70125_A = entity.rotationp = -f11 + 10;
					entity.setAIType3(0);
				}
			} else {
				if (entity.getAIType3() == 0) {
					entity.setAIType3(1);
					entity.aitypetime3 = 0;
				}
			}
		} else {
			List<Entity> llist = entity.field_70170_p.func_72839_b(entity,
					entity.func_174813_aQ().func_72321_a(entity.field_70159_w, entity.field_70181_x, entity.field_70179_y).func_186662_g(range));
			if (llist != null) {
				for (int lj = 0; lj < llist.size(); lj++) {
					Entity entity1 = (Entity) llist.get(lj);
					if (entity1.func_70067_L()) {
						boolean flag = entity.func_70635_at().func_75522_a(entity1);
						if (ridding.targetentity == entity1 && ridding.CanAttack(entity1)) {
							double d5 = entity1.field_70165_t - entity.field_70165_t;
							double d7 = entity1.field_70161_v - entity.field_70161_v;
							double d6 = entity1.field_70163_u - entity.field_70163_u;
							double d1 = entity.field_70163_u - (entity1.field_70163_u);
							double d3 = (double) MathHelper.func_76133_a(d5 * d5 + d7 * d7);
							float f11 = (float) (-(Math.atan2(d1, d3) * 180.0D / Math.PI));
							entity.rote = -((float) Math.atan2(d5, d7)) * 180.0F / (float) Math.PI;

							if (entity.rote > 180F) {
								entity.rote = -179F;
							}
							if (entity.rote < -180F) {
								entity.rote = 179F;
							}
							if (entity.getAIType3() != 1) {
								if (entity.field_70759_as != entity.rote) {
									if (entity.field_70759_as < entity.rote) {
										entity.field_70759_as = entity.field_70759_as + turnspeed;
										entity.field_70177_z = entity.field_70177_z + turnspeed;
										entity.field_70126_B = entity.field_70126_B + turnspeed;
										entity.field_70758_at = entity.field_70758_at + turnspeed;
									} else if (entity.field_70759_as > entity.rote) {
										entity.field_70759_as = entity.field_70759_as - turnspeed;
										entity.field_70177_z = entity.field_70177_z - turnspeed;
										entity.field_70126_B = entity.field_70126_B - turnspeed;
										entity.field_70758_at = entity.field_70758_at - turnspeed;
									}
								}
							}

							double ddx = Math.abs(d5);
							double ddz = Math.abs(d7);
							if ((ddx > max || ddz > max)) {
								if (entity.getAIType3() != 1) {
									ridding.field_70125_A = entity.field_70125_A = entity.rotationp = -f11 + 10;
									entity.setAIType3(0);
								}
							} else {
								if (entity.getAIType3() == 0) {
									entity.setAIType3(1);
									entity.aitypetime3 = 0;
								}
							}

							if (flag) {
								ridding.targetentity = (EntityLivingBase) entity1;
							}
							ridding.target = true;
							break;
						} else
						//if(ridding.targetentity == null)
						if (ridding.CanAttack(entity1) && flag) {
							//if (ridding.CanAttack(entity1) && flag) 
							{
								ridding.targetentity = (EntityLivingBase) entity1;
								ridding.target = true;
								break;
							}
						}
					}
				}
			}
			if (!ridding.target && entity.func_110143_aJ() > 0.0F) {
				if (entity.getMoveT() == 2) {
					ridding.field_70125_A = entity.field_70125_A = entity.rotationp = 10;
					double d5 = entity.getMoveX() - entity.field_70165_t;
					double d7 = entity.getMoveZ() - entity.field_70161_v;

					entity.rotation = entity.rote = -((float) Math.atan2(d5, d7)) * 180.0F / (float) Math.PI;
					if (entity.rote > 180F) {
						entity.rote = -179F;
					}
					if (entity.rote < -180F) {
						entity.rote = 179F;
					}
					if (entity.getAIType3() != 1) {
						if (entity.field_70759_as != entity.rote) {
							if (entity.field_70759_as < entity.rote) {
								entity.field_70759_as = entity.field_70759_as + turnspeed;
								entity.field_70177_z = entity.field_70177_z + turnspeed;
								entity.field_70126_B = entity.field_70126_B + turnspeed;
								entity.field_70758_at = entity.field_70758_at + turnspeed;
							} else if (entity.field_70759_as > entity.rote) {
								entity.field_70759_as = entity.field_70759_as - turnspeed;
								entity.field_70177_z = entity.field_70177_z - turnspeed;
								entity.field_70126_B = entity.field_70126_B - turnspeed;
								entity.field_70758_at = entity.field_70758_at - turnspeed;
							}
						}
					}

					double ddx = Math.abs(d5);
					double ddz = Math.abs(d7);
					if ((ddx > max || ddz > max)) {
						if (entity.getAIType3() != 1) {
							entity.setAIType3(0);
						}
					} else {
						if (entity.getAIType3() == 0) {
							entity.setAIType3(1);
							entity.aitypetime3 = 0;
						}
					}
				} else {
					if (!entity.field_70170_p.field_72995_K) {
						entity.field_70759_as = entity.field_70759_as + 1;
						entity.field_70177_z = entity.field_70177_z + 1;
						entity.field_70126_B = entity.field_70126_B + 1;
						entity.field_70758_at = entity.field_70758_at + 1;
					}
					ridding.field_70125_A = entity.field_70125_A = entity.rotationp = 10;
				}
			}
		}
		if (entity.getAIType3() == 1) {
			ridding.field_70125_A = entity.field_70125_A = entity.rotationp = 40;
			if (entity.aitypetime3 > 80) {
				entity.setAIType3(0);
				entity.aitypetime3 = 0;
			}
		}
	}
	
	
}
