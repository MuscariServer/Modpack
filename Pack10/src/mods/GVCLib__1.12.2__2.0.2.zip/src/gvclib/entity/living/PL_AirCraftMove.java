package gvclib.entity.living;

import gvclib.mod_GVCLib;
import gvclib.entity.living.cnt.ai.VehicleAI_RotationYawOffset;
import gvclib.network.GVCLClientMessageKeyPressed;
import gvclib.network.GVCLMessageKeyPressed;
import gvclib.network.GVCLPacketHandler;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public class PL_AirCraftMove {
	public static void moveheli(EntityLivingBase player, EntityVehicleBase entity, float sp, float turnspeed){
		if(player.field_70759_as > 360F || player.field_70759_as < -360F){
			player.field_70759_as = 0;
			player.field_70177_z = 0;
			player.field_70126_B = 0;
			player.field_70758_at = 0;
			player.field_70761_aq = 0;
		}
		if(player.field_70759_as > 180F){
			player.field_70759_as = -179F;
			player.field_70177_z = -179F;
			player.field_70126_B = -179F;
			player.field_70758_at = -179F;
			player.field_70761_aq = -179F;
		}
		if(player.field_70759_as < -180F){
			player.field_70759_as = 179F;
			player.field_70177_z = 179F;
			player.field_70126_B = 179F;
			player.field_70758_at = 179F;
			player.field_70761_aq = 179F;
		}
		float f = Math.abs(entity.field_70759_as - player.field_70759_as);
		float f2 = entity.field_70759_as - player.field_70759_as;
		entity.rotation = player.field_70758_at;
		entity.rotationp = player.field_70127_C;
		if(entity.field_70122_E)
		{
			if(entity.thpower > 1){
			if(f <= turnspeed && f >= -turnspeed){
				entity.field_70759_as = player.field_70177_z;
				entity.field_70177_z = player.field_70759_as;
				entity.field_70126_B = player.field_70758_at;
				entity.field_70758_at = player.field_70758_at;
				entity.field_70761_aq = player.field_70758_at;
			}
			else if(f2 > 0.1F){
				if(f2 > 180F){
					PL_RoteModel.rotemodel(entity, + turnspeed/5);
				}else{
					PL_RoteModel.rotemodel(entity,- turnspeed/5);
				}
			}
			else if(f2 < -0.1F){
				if(f2 < -180F){
					PL_RoteModel.rotemodel(entity,- turnspeed/5);
				}else{
					PL_RoteModel.rotemodel(entity,+ turnspeed/5);
				}
			}
			entity.field_70125_A = player.field_70125_A;
			entity.field_70127_C = player.field_70127_C;
			}
		}else{
			if(f <= turnspeed*2 && f >= -turnspeed*2){
				entity.field_70759_as = player.field_70177_z;
				entity.field_70177_z = player.field_70759_as;
				entity.field_70126_B = player.field_70758_at;
				entity.field_70758_at = player.field_70758_at;
				entity.field_70761_aq = player.field_70758_at;
			}else
			if(f2 > 0.1F){
				if(f2 > 180F){
					PL_RoteModel.rotemodel(entity,+ turnspeed);
					if(entity.throte < 50){
						entity.throte = entity.throte + 2;
					}
				}else{
					PL_RoteModel.rotemodel(entity,- turnspeed);
					if(entity.throte > -50){
						entity.throte = entity.throte - 2;
					}
				}
			}
			else if(f2 < -0.1F){
				if(f2 < -180F){
					PL_RoteModel.rotemodel(entity,- turnspeed);
					if(entity.throte > -50){
						entity.throte = entity.throte - 2;
					}
				}else{
					PL_RoteModel.rotemodel(entity,+ turnspeed);
					if(entity.throte < 50){
						entity.throte = entity.throte + 2;
					}
				}
			}
			//entity.rotationPitch = player.rotationPitch;
			//entity.prevRotationPitch = player.prevRotationPitch;
			if(player.field_70125_A > entity.angle_max) {
				entity.field_70125_A = entity.angle_max;
				entity.field_70127_C = entity.angle_max;
			}else if(player.field_70125_A < entity.angle_min) {
				entity.field_70125_A = entity.angle_min;
				entity.field_70127_C = entity.angle_min;
			}else {
				entity.field_70125_A = player.field_70125_A;
				entity.field_70127_C = player.field_70127_C;
			}
		}
		

		if (player.field_191988_bg > 0.0F) {
			if(entity.throttle < entity.thmax){
				++entity.throttle;
			}
		}
		if (player.field_191988_bg < 0.0F) {
			if(entity.throttle >= 1){
				--entity.throttle;
			}
		}
		if( entity.throttle >= 0){
			if(entity.thpower < entity.throttle){
				if( entity.throttle > entity.thmax-5){
					entity.thpower = entity.thpower + entity.thmaxa;
				}else{
					entity.thpower = entity.thpower + entity.thmaxa*0.5;
				}
			}else{
				entity.thpower = entity.thpower + entity.thmina;
			}
			if(entity.throttle <= 0 && entity.throttle > 0){
				entity.thpower = entity.thpower + entity.thmina * 2;
			}
		}
		if (player.field_70702_br < 0.0F && entity.thpower >= 1) {
			entity.moveangle = 3;
		}
		if (player.field_70702_br > 0.0F && entity.thpower >= 1) {
			entity.moveangle = 4;
		}
		
		
		
	}
	
	public static void moveheligunner(EntityLivingBase player, EntityGVCLivingBase entity, float sp, float turnspeed){
		if(player.field_70759_as > 360F || player.field_70759_as < -360F){
			player.field_70759_as = 0;
			player.field_70177_z = 0;
			player.field_70126_B = 0;
			player.field_70758_at = 0;
			player.field_70761_aq = 0;
		}
		if(player.field_70759_as > 180F){
			player.field_70759_as = -179F;
			player.field_70177_z = -179F;
			player.field_70126_B = -179F;
			player.field_70758_at = -179F;
			player.field_70761_aq = -179F;
		}
		if(player.field_70759_as < -180F){
			player.field_70759_as = 179F;
			player.field_70177_z = 179F;
			player.field_70126_B = 179F;
			player.field_70758_at = 179F;
			player.field_70761_aq = 179F;
		}
		float f = Math.abs(entity.field_70759_as - player.field_70759_as);
		float f2 = entity.field_70759_as - player.field_70759_as;
		entity.rotation = player.field_70758_at;
		entity.rotationp = player.field_70127_C;
		Vec3d look = entity.func_70040_Z();
		if (player.field_191988_bg > 0.0F) {
			entity.moveangle = 1;
		}
		if (player.field_191988_bg < 0.0F) {
			entity.moveangle = 2;
		}
		
		if (player.field_70702_br < 0.0F) {
			entity.field_70759_as = entity.field_70759_as + turnspeed;
			entity.field_70177_z = entity.field_70177_z + turnspeed;
			entity.field_70126_B = entity.field_70126_B + turnspeed;
			entity.field_70758_at = entity.field_70758_at + turnspeed;
		}
		if (player.field_70702_br > 0.0F) {
			entity.field_70759_as = entity.field_70759_as - turnspeed;
			entity.field_70177_z = entity.field_70177_z - turnspeed;
			entity.field_70126_B = entity.field_70126_B - turnspeed;
			entity.field_70758_at = entity.field_70758_at - turnspeed;
		}
//		entity.rotationPitch = 0;
	}
	
	public static void movefighter(EntityLivingBase player, EntityGVCLivingBase entity, float sp, float turnspeed){
		if(player.field_70759_as > 360F || player.field_70759_as < -360F){
			player.field_70759_as = 0;
			player.field_70177_z = 0;
			player.field_70126_B = 0;
			player.field_70758_at = 0;
			player.field_70761_aq = 0;
		}
		if(player.field_70759_as > 180F){
			player.field_70759_as = -179F;
			player.field_70177_z = -179F;
			player.field_70126_B = -179F;
			player.field_70758_at = -179F;
			player.field_70761_aq = -179F;
		}
		if(player.field_70759_as < -180F){
			player.field_70759_as = 179F;
			player.field_70177_z = 179F;
			player.field_70126_B = 179F;
			player.field_70758_at = 179F;
			player.field_70761_aq = 179F;
		}
		float f = Math.abs(entity.field_70758_at - player.field_70759_as);
		float f2 = entity.field_70759_as - player.field_70759_as;
		if(entity.func_110143_aJ() > 0.0F) {
			if(entity.field_70122_E)
			{
				if(entity.thpower > 1){
				if(f <= turnspeed && f >= -turnspeed){
					entity.rotation = player.field_70758_at;
//					entity.rotationp = player.prevRotationPitch;
					entity.field_70759_as = player.field_70177_z;
					entity.field_70177_z = player.field_70759_as;
					entity.field_70126_B = player.field_70758_at;
					entity.field_70758_at = player.field_70758_at;
					entity.field_70761_aq = player.field_70758_at;
				}
				else if(f2 > 0.1F){
					if(f2 > 180F){
						PL_RoteModel.rotemodel(entity,+ turnspeed/5);
					}else{
						PL_RoteModel.rotemodel(entity,- turnspeed/5);
					}
				}
				else if(f2 < -0.1F){
					if(f2 < -180F){
						PL_RoteModel.rotemodel(entity,- turnspeed/5);
					}else{
						PL_RoteModel.rotemodel(entity,+ turnspeed/5);
					}
				}
				//entity.rotationPitch = player.rotationPitch;
				//entity.prevRotationPitch = player.prevRotationPitch;
				}
			}else{
				if(f2 > turnspeed){
					if(f2 > 180F){
						PL_RoteModel.rotemodel(entity,+ turnspeed);
						if(entity.throte < 50){
							entity.throte = entity.throte + 2;
						}
					}else{
						PL_RoteModel.rotemodel(entity,- turnspeed);
						if(entity.throte > -50){
							entity.throte = entity.throte - 2;
						}
					}
				}
				else if(f2 < -turnspeed){
					if(f2 < -180F){
						PL_RoteModel.rotemodel(entity,- turnspeed);
						if(entity.throte > -50){
							entity.throte = entity.throte - 2;
						}
					}else{
						PL_RoteModel.rotemodel(entity,+ turnspeed);
						if(entity.throte < 50){
							entity.throte = entity.throte + 2;
						}
					}
				}else {
					entity.rotation = player.field_70758_at;
//					entity.rotationp = player.prevRotationPitch;
					entity.field_70759_as = player.field_70177_z;
					entity.field_70177_z = player.field_70759_as;
					entity.field_70126_B = player.field_70758_at;
					entity.field_70758_at = player.field_70758_at;
					entity.field_70761_aq = player.field_70758_at;
				}
				//entity.rotationPitch = player.rotationPitch;
				//entity.prevRotationPitch = player.prevRotationPitch;
			}
			if(!entity.field_70122_E) {
				entity.rotep = player.field_70127_C;
				if ((entity.field_70125_A > (entity.rotep + turnspeed)) || (entity.field_70125_A < entity.rotep - turnspeed)) {
					if (entity.field_70125_A < entity.rotep) {
						entity.rotationp = entity.rotationp + turnspeed*1;
						entity.field_70125_A = entity.field_70125_A + turnspeed*1;
						entity.field_70127_C = entity.field_70127_C + turnspeed*1;
					} else if (entity.field_70125_A > entity.rotep) {
						entity.rotationp = entity.rotationp - turnspeed*1;
						entity.field_70125_A = entity.field_70125_A - turnspeed*1;
						entity.field_70127_C = entity.field_70127_C - turnspeed*1;
					}
				}
				if(entity.field_70170_p.field_72995_K)GVCLPacketHandler.INSTANCE.sendToServer(new GVCLMessageKeyPressed(421, entity.func_145782_y(), entity.field_70177_z, entity.field_70125_A));
			}
			
//			System.out.println(String.format("%1$.2f", entity.rotationPitch));
			
			//entity.rotationPitch = player.rotationPitch;
			//entity.prevRotationPitch = player.prevRotationPitch;
		}
		
		
		
		
		
		
		
		float ix1 = 0;
		float iz1 = 0;
		float f111 = entity.field_70177_z * (2 * (float) Math.PI / 360);
		ix1 -= MathHelper.func_76126_a(f111) * 2;
		iz1 += MathHelper.func_76134_b(f111) * 2;
		if( entity.throttle >= 1){
//		entity.world.spawnParticle(EnumParticleTypes.CLOUD, entity.posX - ix1, entity.posY + 1D, entity.posZ - iz1, 0.0D, 0.0D, 0.0D, new int[0]);//20/4/4用途不明
		}
		//Vec3d looked = player.getLookVec();
		Vec3d look = entity.func_70040_Z();
		//Vec3 looke = player.getLookVec();
		

		/*if(entity.onGround)
		{
			if( entity.thpower > entity.thmax-10  && entity.getHealth() > 0.0F){
			entity.motionY = look.y * sp * (entity.thpower/2);
			}
		}else{
			if( entity.thpower > entity.thmax-30  && entity.getHealth() > 0.0F){
				entity.motionY = look.y * sp * (entity.thpower/2);
			}else
			if (!entity.onGround)
	        {
				entity.motionY *= 0.9D;
	        }
		}*/
		
		if (player.field_191988_bg > 0.0F) {
			if(entity.throttle < entity.thmax){
				++entity.throttle;
			}
		}
		if (player.field_191988_bg < 0.0F) {
			if(entity.throttle >= 1){
				--entity.throttle;
			}
		}
		if (player.field_70702_br < 0.0F) {
			if(entity.throte < 50){
				entity.throte = entity.throte + 2;
			}
		}
		if (player.field_70702_br > 0.0F) {
			if(entity.throte > -50){
				entity.throte = entity.throte - 2;
			}
		}
		if( entity.throttle >= 0){
			if(entity.thpower < entity.throttle){
				if( entity.throttle > entity.thmax-5){
					entity.thpower = entity.thpower + entity.thmaxa;
				}else{
					entity.thpower = entity.thpower + entity.thmaxa*0.5;
				}
			}else{
				entity.thpower = entity.thpower + entity.thmina;
			}
			if(entity.throttle <= 0 && entity.throttle > 0){
				entity.thpower = entity.thpower + entity.thmina * 2;
			}
		}
	}
	
	
	public static void moveheli_NEW(EntityLivingBase player, EntityGVCLivingBase entity, float sp, float turnspeed){
		/*if(player.rotationYawHead > 360F || player.rotationYawHead < -360F){
			player.rotationYawHead = 0;
			player.rotationYaw = 0;
			player.prevRotationYaw = 0;
			player.prevRotationYawHead = 0;
			player.renderYawOffset = 0;
		}
		if(player.rotationYawHead > 180F){
			player.rotationYawHead = -179F;
			player.rotationYaw = -179F;
			player.prevRotationYaw = -179F;
			player.prevRotationYawHead = -179F;
			player.renderYawOffset = -179F;
		}
		if(player.rotationYawHead < -180F){
			player.rotationYawHead = 179F;
			player.rotationYaw = 179F;
			player.prevRotationYaw = 179F;
			player.prevRotationYawHead = 179F;
			player.renderYawOffset = 179F;
		}*/
		VehicleAI_RotationYawOffset.offset(entity, player);
		float f = Math.abs(entity.field_70759_as - player.field_70759_as);
		float f2 = entity.field_70759_as - player.field_70759_as;
//		entity.rotation = player.prevRotationYawHead;
//		entity.rotationp = player.prevRotationPitch;
		if(entity.field_70122_E)
		{
			if(entity.thpower > 1){
			if(f <= turnspeed && f >= -turnspeed){
				entity.field_70759_as = player.field_70177_z;
				entity.field_70177_z = player.field_70759_as;
				entity.field_70126_B = player.field_70758_at;
				entity.field_70758_at = player.field_70758_at;
				entity.field_70761_aq = player.field_70758_at;
			}
			else if(f2 > 0.1F){
				if(f2 > 180F){
					PL_RoteModel.rotemodel(entity, + turnspeed/5);
				}else{
					PL_RoteModel.rotemodel(entity,- turnspeed/5);
				}
			}
			else if(f2 < -0.1F){
				if(f2 < -180F){
					PL_RoteModel.rotemodel(entity,- turnspeed/5);
				}else{
					PL_RoteModel.rotemodel(entity,+ turnspeed/5);
				}
			}
			}
		}else{
			/*if(f < turnspeed && f > -turnspeed){
				entity.rotationYawHead = player.rotationYaw;
				entity.rotationYaw = player.rotationYawHead;
				entity.prevRotationYaw = player.prevRotationYawHead;
				entity.prevRotationYawHead = player.prevRotationYawHead;
				entity.renderYawOffset = player.prevRotationYawHead;
			}else*/
			if(f2 > (turnspeed+0.1F)){
				if(f2 > 180F){
					PL_RoteModel.rotemodel(entity,+ turnspeed);
					if(entity.throte < 50){
						entity.throte = entity.throte + 2;
					}
				}else{
					PL_RoteModel.rotemodel(entity,- turnspeed);
					if(entity.throte > -50){
						entity.throte = entity.throte - 2;
					}
				}
			}
			else if(f2 < -(turnspeed+0.1F)){
				if(f2 < -180F){
					PL_RoteModel.rotemodel(entity,- turnspeed);
					if(entity.throte > -50){
						entity.throte = entity.throte - 2;
					}
				}else{
					PL_RoteModel.rotemodel(entity,+ turnspeed);
					if(entity.throte < 50){
						entity.throte = entity.throte + 2;
					}
				}
			}else {
				entity.field_70759_as = player.field_70177_z;
				entity.field_70177_z = player.field_70759_as;
				entity.field_70126_B = player.field_70758_at;
				entity.field_70758_at = player.field_70758_at;
				entity.field_70761_aq = player.field_70758_at;
			}
			/*
			if(player.rotationPitch > 30) {
				entity.rotationPitch = 30;
				entity.prevRotationPitch = 30;
			}else if(player.rotationPitch < -20) {
				entity.rotationPitch = -20;
				entity.prevRotationPitch = -20;
			}
			else {
				entity.rotationPitch = player.rotationPitch;
				entity.prevRotationPitch = player.prevRotationPitch;
			}*/
			/*
			float fz = player.rotationPitch;
	        float f11 = MathHelper.clamp(fz, entity.rotationp_max, entity.rotationp_min);
	        player.prevRotationPitch += f11 - fz;
	        player.rotationPitch += f11 - fz;
	        entity.prevRotationPitch += f11 - fz;
	        entity.rotationPitch += f11 - fz;
	        */
			/*entity.rotep = player.rotationPitch;
			if ((entity.rotationPitch > (entity.rotep + turnspeed)) || (entity.rotationPitch < entity.rotep - turnspeed)) {
				if (entity.rotationPitch < entity.rotep) {
					entity.rotationp = entity.rotationp + turnspeed*1;
					entity.rotationPitch = entity.rotationPitch + turnspeed*1;
					entity.prevRotationPitch = entity.prevRotationPitch + turnspeed*1;
				} else if (entity.rotationPitch > entity.rotep) {
					entity.rotationp = entity.rotationp - turnspeed*1;
					entity.rotationPitch = entity.rotationPitch - turnspeed*1;
					entity.prevRotationPitch = entity.prevRotationPitch - turnspeed*1;
				}
			}*/
			if(!entity.field_70122_E) {
				entity.rotep = player.field_70127_C;
				if ((entity.field_70125_A > (entity.rotep + turnspeed)) || (entity.field_70125_A < entity.rotep - turnspeed)) {
					if (entity.field_70125_A < entity.rotep) {
						entity.rotationp = entity.rotationp + turnspeed*1;
						entity.field_70125_A = entity.field_70125_A + turnspeed*1;
						entity.field_70127_C = entity.field_70127_C + turnspeed*1;
					} else if (entity.field_70125_A > entity.rotep) {
						entity.rotationp = entity.rotationp - turnspeed*1;
						entity.field_70125_A = entity.field_70125_A - turnspeed*1;
						entity.field_70127_C = entity.field_70127_C - turnspeed*1;
					}
				}
				if(entity.field_70170_p.field_72995_K)GVCLPacketHandler.INSTANCE.sendToServer(new GVCLMessageKeyPressed(421, entity.func_145782_y(), entity.field_70177_z, entity.field_70125_A));
			}
		}
		

		if (player.field_191988_bg > 0.0F) {
			if(entity.throttle < entity.thmax){
				++entity.throttle;
			}
		}
		if (player.field_191988_bg < 0.0F) {
			if(entity.throttle >= 1){
				--entity.throttle;
			}
		}
		if( entity.throttle >= 0){
			if(entity.thpower < entity.throttle){
				if( entity.throttle > entity.thmax-5){
					entity.thpower = entity.thpower + entity.thmaxa;
				}else{
					entity.thpower = entity.thpower + entity.thmaxa*0.5;
				}
			}else{
				entity.thpower = entity.thpower + entity.thmina;
			}
			if(entity.throttle <= 0 && entity.throttle > 0){
				entity.thpower = entity.thpower + entity.thmina * 2;
			}
		}
		if (player.field_70702_br < 0.0F && entity.thpower >= 1) {
			//entity.moveangle = 3;
			if(entity.throte < 50)entity.throte = entity.throte + 2;
		}
		if (player.field_70702_br > 0.0F && entity.thpower >= 1) {
			//entity.moveangle = 4;
			if(entity.throte > -50)entity.throte = entity.throte - 2;
		}
		boolean jump = mod_GVCLib.proxy.jumped();
		if (jump) {
			entity.serverspace = true;
			GVCLPacketHandler.INSTANCE.sendToServer(new GVCLMessageKeyPressed(13, entity.func_145782_y()));
			GVCLPacketHandler.INSTANCE2.sendToAll(new GVCLClientMessageKeyPressed(13, entity.func_145782_y()));
		}
		if (entity.serverspace) {
			entity.throttle_up = 1;
			entity.serverspace = false;
		}else if(player.func_70093_af()) {
			entity.throttle_up = -1;
		}else {
			entity.throttle_up = 0;
		}
		
	}
}
