package gvclib.entity.living;

import java.util.List;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.MoverType;
import net.minecraft.entity.ai.RandomPositionGenerator;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;


import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.MoverType;
import net.minecraft.entity.ai.RandomPositionGenerator;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public abstract class AI_EntityMoveS_Squad
{
	public static void newmove(EntityGVCLivingBase entity, int id, float sp, float turnspeed, double max, double range1, double range2, double followrange) {
		entity.sneak = false;
		boolean ta = false;
		double range = range1;
		if(entity.getMobMode() == 1){
			range = range2;
		}
		
		/*{
			List<Entity> llist2 = entity.world.getEntitiesWithinAABBExcludingEntity(entity, entity
					.getEntityBoundingBox().expand(entity.motionX, entity.motionY, entity.motionZ).grow(range));
			if (llist2 != null) {
				for (int lj = 0; lj < llist2.size(); lj++) {
					Entity entity1 = (Entity) llist2.get(lj);
					if (entity1.canBeCollidedWith()) {
						boolean flag = entity.getEntitySenses().canSee(entity1);
						if(!(entity.getMoveT() == 3)) {
							
						}
					}
				}
			}
		}*/
		{
			double x = entity.field_70165_t;
			double y = entity.field_70163_u;
			double z = entity.field_70161_v;
			double han = range;
			AxisAlignedBB axisalignedbb2 = (new AxisAlignedBB((double) (x - han), (double) (y - han),
					(double) (z - han), (double) (x + han), (double) (y + han), (double) (z + han)))
							.func_186662_g(han);
			List<Entity> llist = entity.field_70170_p.func_72839_b(entity, axisalignedbb2);
			if (llist != null) {
				//player
				for (int lj = 0; lj < llist.size(); lj++) {
					Entity entity1 = (Entity) llist.get(lj);
					if (entity1.func_70067_L()) {
						if (entity.getMoveT() == 0)//follow
						{
							if (entity1 != null && entity1 instanceof EntityPlayerMP) {
								EntityPlayer player = (EntityPlayer) entity1;
								//System.out.println(String.format("m"));
								if (entity.isOwner(player) && !entity.func_184218_aH()) {
									double d5 = entity1.field_70165_t - entity.field_70165_t;
									double d7 = entity1.field_70161_v - entity.field_70161_v;
									double d6 = entity1.field_70163_u - entity.field_70163_u;
									double d1 = entity.field_70163_u - (entity1.field_70163_u);
									double d3 = (double) MathHelper.func_76133_a(d5 * d5 + d7 * d7);
									float f11 = (float) (-(Math.atan2(d1, d3) * 180.0D / Math.PI));
									if (!entity.getattacktask()) {
										entity.field_70759_as = entity.field_70177_z = entity.field_70761_aq = entity.rotation = entity.rote = -((float) Math
												.atan2(d5, d7)) * 180.0F / (float) Math.PI;
										entity.rotationp = entity.field_70125_A = -f11 + 0;
									}
									double ddx = Math.abs(d5);
									double ddz = Math.abs(d7);
									if ((ddx > followrange || ddz > followrange)) {
										entity.func_70634_a(player.field_70165_t, player.field_70163_u, player.field_70161_v);
									} else {
										if ((ddx > entity.squad_followrange || ddz > entity.squad_followrange)) {
											if (ta) {
												MoveS(entity, sp, 1, player.field_70165_t, player.field_70163_u, player.field_70161_v, 1);
											} else {
												MoveS(entity, sp, 1, player.field_70165_t, player.field_70163_u, player.field_70161_v, 0);
											}
											
										}
									}
									//System.out.println(String.format("move"));
								}
							}
						}
						if (entity1 != null && entity1 instanceof ISoldier && entity.getMoveT() != 3) {
							//System.out.println(String.format("en"));
							double d5 = entity1.field_70165_t - entity.field_70165_t;
							double d7 = entity1.field_70161_v - entity.field_70161_v;
							double d6 = entity1.field_70163_u - entity.field_70163_u;
							double d1 = entity.field_70163_u - (entity1.field_70163_u);
							double d3 = (double) MathHelper.func_76133_a(d5 * d5 + d7 * d7);
							double ddx = Math.abs(d5);
							double ddz = Math.abs(d7);
							if ((ddx < 2 && ddz < 2)) {
								MoveS(entity, -sp, 1, entity1.field_70165_t, entity1.field_70163_u, entity1.field_70161_v, 0);
							}
							//break;
						}
					}
				}
				//player
			}
		}
		{
			double x = entity.field_70165_t;
			double y = entity.field_70163_u;
			double z = entity.field_70161_v;
			double han = range;
			AxisAlignedBB axisalignedbb2 = 
					(new AxisAlignedBB((double)(x-han), (double)(y-han), (double)(z-han), (double)(x + han), (double)(y + han), (double)(z+ han)))
            		.func_186662_g(han);
			//List<Entity> llist = entity.world.getEntitiesWithinAABBExcludingEntity(entity, entity
			//		.getEntityBoundingBox().expand(entity.motionX, entity.motionY, entity.motionZ).grow(range));
			List<Entity> llist = entity.field_70170_p.func_72839_b(entity, axisalignedbb2);
			if (llist != null) {
				//mob
				for (int lj = 0; lj < llist.size(); lj++) {
					Entity entity1 = (Entity) llist.get(lj);
					if (entity1.func_70067_L()) {
						boolean flag = entity.func_70635_at().func_75522_a(entity1);
						if(entity.targetentity == entity1 && entity1 != null && entity1 instanceof EntityLivingBase) {
							EntityLivingBase en = (EntityLivingBase) entity1;
							if(en.field_70725_aQ > 0) {
								entity.targetentity = null;
							}
						}
						if(entity.getMoveT() == 3) {//wait
							if(entity.targetentity == entity1 && entity1 != null) {
								double d5 = entity.targetentity.field_70165_t - entity.field_70165_t;
								double d7 = entity.targetentity.field_70161_v - entity.field_70161_v;
								double d6 = entity.targetentity.field_70163_u - entity.field_70163_u;
								double d1 = entity.field_70163_u - (entity.targetentity.field_70163_u);
								double d3 = (double) MathHelper.func_76133_a(d5 * d5 + d7 * d7);
								float f11 = (float) (-(Math.atan2(d1, d3) * 180.0D / Math.PI));
								entity.field_70177_z = entity.field_70761_aq = entity.field_70759_as = entity.rotation = entity.rote
										= -((float) Math.atan2(d5, d7)) * 180.0F / (float) Math.PI;
								entity.rotationp = entity.field_70125_A = -f11 + 0;
								ta = true;
								break;
							}
						}
						else if(entity.getMoveT() == 5) {//pointfire
							{
								double d5 = entity.getMoveX() - entity.field_70165_t;
								double d7 = entity.getMoveZ()- entity.field_70161_v;
								double d6 = entity.getMoveY() - entity.field_70163_u;
								double d1 = entity.field_70163_u - (entity.getMoveY());
								double d3 = (double) MathHelper.func_76133_a(d5 * d5 + d7 * d7);
								float f11 = (float) (-(Math.atan2(d1, d3) * 180.0D / Math.PI));
								 
								{
									entity.field_70759_as = entity.field_70177_z = entity.field_70761_aq = entity.rotation = entity.rote
											= -((float) Math.atan2(d5, d7)) * 180.0F / (float) Math.PI;
									entity.rotationp = entity.field_70125_A = -f11 + 0;
									double ddx = Math.abs(d5);
									double ddz = Math.abs(d7);
									ta = true;
								}
								ta = true;
								break;
							} 
						}
						else if(entity.getMoveT() == 0) {//follow
							if(entity.targetentity == entity1 && entity1 != null) {
								double d5 = entity.targetentity.field_70165_t - entity.field_70165_t;
								double d7 = entity.targetentity.field_70161_v - entity.field_70161_v;
								double d6 = entity.targetentity.field_70163_u - entity.field_70163_u;
								double d1 = entity.field_70163_u - (entity.targetentity.field_70163_u);
								double d3 = (double) MathHelper.func_76133_a(d5 * d5 + d7 * d7);
								float f11 = (float) (-(Math.atan2(d1, d3) * 180.0D / Math.PI));
								entity.field_70177_z = entity.field_70761_aq = entity.field_70759_as = entity.rotation = entity.rote
										= -((float) Math.atan2(d5, d7)) * 180.0F / (float) Math.PI;
								entity.rotationp = entity.field_70125_A = -f11 + 0;
								if (flag) {
									entity.targetentity = (EntityLivingBase) entity1;
								}
								ta = true;
							}
							
						}
						else if(entity.getMoveT() == 1) {//free
							if (entity1 != null && entity1 instanceof EntityVehicleBase && flag && entity.biped && entity.targetentity == null) {
								EntityVehicleBase ve = (EntityVehicleBase) entity1;
								if(ve.func_184188_bt().size() < ve.riddng_maximum  && !ve.getVehicleLock() && ve.func_110143_aJ() > 0.0F)
								{
									MoveS(entity, sp, 1, entity1.field_70165_t, entity1.field_70163_u, entity1.field_70161_v, 0);
								}
							}else
							if (entity.CanAttack(entity1) && entity1 != null) {//target
								
								if (entity.targetentity == entity1
										&& ((EntityLivingBase) entity1).func_110143_aJ() > 0.0F) {
									double d5 = entity1.field_70165_t - entity.field_70165_t;
									double d7 = entity1.field_70161_v - entity.field_70161_v;
									double d6 = entity1.field_70163_u - entity.field_70163_u;
									double d1 = entity.field_70163_u - (entity1.field_70163_u);
									double d3 = (double) MathHelper.func_76133_a(d5 * d5 + d7 * d7);
									float f11 = (float) (-(Math.atan2(d1, d3) * 180.0D / Math.PI));
									
									if (flag) {
										entity.field_70759_as = entity.field_70177_z = entity.field_70761_aq = entity.rotation = entity.rote
												= -((float) Math.atan2(d5, d7)) * 180.0F / (float) Math.PI;
										entity.rotationp = entity.field_70125_A = -f11 + 0;
										double ddx = Math.abs(d5);
										double ddz = Math.abs(d7);
										if ((ddx > max || ddz > max)) {
											MoveS(entity, sp, 1, entity1.field_70165_t, entity1.field_70163_u, entity1.field_70161_v, 0);
										}
										entity.noflag = 0;
										ta = true;
									} else {
										++entity.noflag;
										if(entity.noflag > 100) {
											{
												MoveS(entity, sp, 1, entity1.field_70165_t, entity1.field_70163_u, entity1.field_70161_v, 0);
											}
										}else {
											ta = true;
										}
									}
									if (flag) {
										entity.targetentity = (EntityLivingBase) entity1;
									}
									ta = true;
									break;
								} 
							}//target
						}
						else if(entity.getMoveT() == 2) {//pointattack
							{//target
								{
									double d5 = entity.getMoveX() - entity.field_70165_t;
									double d7 = entity.getMoveZ()- entity.field_70161_v;
									double d6 = entity.getMoveY() - entity.field_70163_u;
									double d1 = entity.field_70163_u - (entity.getMoveY());
									double d3 = (double) MathHelper.func_76133_a(d5 * d5 + d7 * d7);
									float f11 = (float) (-(Math.atan2(d1, d3) * 180.0D / Math.PI));
									 
									{
										entity.field_70759_as = entity.field_70177_z = entity.field_70761_aq = entity.rotation = entity.rote
												= -((float) Math.atan2(d5, d7)) * 180.0F / (float) Math.PI;
										entity.rotationp = entity.field_70125_A = -f11 + 0;
										double ddx = Math.abs(d5);
										double ddz = Math.abs(d7);
										if ((ddx > 1 || ddz > 1)){
											MoveS(entity, sp, 1, entity.getMoveX(), entity.getMoveY(), entity.getMoveZ(), 0);
										}else {
											entity.setMoveT(3);
										}
										ta = true;
									}
									ta = true;
									break;
								} 
							}//target
						}
						
						
						
						
					}
				}
				//mob
			}
		}
		if(!entity.getattacktask()){
			boolean item = false;
			{
				double x = entity.field_70165_t;
				double y = entity.field_70163_u;
				double z = entity.field_70161_v;
				double han = range;
				AxisAlignedBB axisalignedbb2 = (new AxisAlignedBB((double) (x - han), (double) (y - han),
						(double) (z - han), (double) (x + han), (double) (y + han), (double) (z + han)))
								.func_186662_g(han);
				List<Entity> llist = entity.field_70170_p.func_72839_b(entity, axisalignedbb2);
				if (llist != null) {
					//player
					for (int lj = 0; lj < llist.size(); lj++) {
						Entity entity1 = (Entity) llist.get(lj);
						if (entity1.func_70067_L()) {
							if (entity.getMoveT() == 3)//follow
							{
								if (entity1 != null && entity1 instanceof EntityPlayer) {
									EntityPlayer player = (EntityPlayer) entity1;
									if (entity.isOwner(player) && !entity.func_184218_aH()) {
										double d5 = entity1.field_70165_t - entity.field_70165_t;
										double d7 = entity1.field_70161_v - entity.field_70161_v;
										double d6 = entity1.field_70163_u - entity.field_70163_u;
										double d1 = entity.field_70163_u - (entity1.field_70163_u);
										double d3 = (double) MathHelper.func_76133_a(d5 * d5 + d7 * d7);
										float f11 = (float) (-(Math.atan2(d1, d3) * 180.0D / Math.PI));
										ItemStack itemstack = player.func_184614_ca();
										//if (!itemstack.isEmpty() && itemstack.getItem() == Item.getItemFromBlock(Blocks.RED_FLOWER))
										if (!itemstack.func_190926_b() && itemstack.func_77973_b() == Items.field_151045_i)
										{
											entity.field_70759_as = entity.field_70177_z = entity.field_70761_aq = entity.rotation = entity.rote = -((float) Math
													.atan2(d5, d7)) * 180.0F / (float) Math.PI;
											entity.rotationp = entity.field_70125_A = -f11 + 0;
											item = true;
										}
									}
								}
							}
						}
					}
					//player
				}
			}
			
			if(!item)stay(entity, id);
			//entity.setattacktask(false);
		}else{
			//entity.sneak = true;
			//entity.setattacktask(true);
		}
		if(entity.targetentity != null) {
			//entity.setattacktask(true);
		}else {
			//entity.setattacktask(false);
		}
	}
	
	public static void MoveS(EntityGVCLivingBase entity, double speed, double han, double ex, double ey, double ez, int id){
		{// 1
			//if(!entity.world.isRemote)
			{
				double d5 = ex - entity.field_70165_t;
				double d7 = ez - entity.field_70161_v;
				double root = Math.sqrt(d5 * d5 + d7 * d7);
				//entity.rotationYaw = entity.renderYawOffset = -((float) Math.atan2(d5, d7)) * 180.0F / (float) Math.PI;
				float yawset = -((float) Math.atan2(d5, d7)) * 180.0F / (float) Math.PI;
				float yaw = yawset * (2 * (float) Math.PI / 360);
				double mox = 0;
				double moy = entity.field_70181_x;
				double moz = 0;
				mox -= MathHelper.func_76126_a(yaw) * speed * 1.5;
				moz += MathHelper.func_76134_b(yaw) * speed * 1.5;
				if (entity.field_70122_E) {
					
				}
				entity.field_70138_W = entity.field_70131_O * 0.8F;
				//if(entity.world.rand.nextInt(4) == 0) 
				{
					//entity.getNavigator().tryMoveToXYZ(ex, ey, ez, speed * 10);
					if(id == 0 || !(entity.func_110143_aJ() > 0)){
						entity.field_70159_w = mox;
						entity.field_70179_y = moz;
						//entity.motionY = y;
						entity.func_70091_d(MoverType.PLAYER, entity.field_70159_w, entity.field_70181_x, entity.field_70179_y);
					}else 
					{
						if(entity.cooltime3 > 20) {
							entity.func_70661_as().func_75492_a(ex, ey, ez, speed * 15);
							entity.cooltime3 = 0;
						}
						
					}
				}
			}
		} // 1
	}
	
	public static void stay(EntityGVCLivingBase entity, int id) {
		entity.setMobMode(0);
		double xPosition = 0;
	    double yPosition = 0;
	    double zPosition = 0;
		if (entity.func_70654_ax() >= 100)
        {
        }
        else if (entity.func_70681_au().nextInt(120) != 0)
        {
        }
        else
        {
            Vec3d vec3 = RandomPositionGenerator.func_75463_a(entity, 10, 7);

            if (vec3 == null)
            {
            }
            else
            {
                xPosition = vec3.field_72450_a;
                yPosition = vec3.field_72448_b;
                zPosition = vec3.field_72449_c;
            }
            entity.rotation = entity.field_70759_as = entity.func_70681_au().nextInt(120) - 60;
        }
		{
			if(entity.rote > 180F){
				entity.rote = -179F;
			}
			if(entity.rote < -180F){
				entity.rote = 179F;
			}
			float f3 = (float) (entity.field_70759_as - entity.rote);
			 if(entity.field_70759_as != entity.rote){
         		if(f3 > 1){
 					if(f3 > 180F){
 						entity.field_70177_z = entity.field_70177_z + 1;
 					}else{
 						entity.field_70177_z = entity.field_70177_z - 1;
 					}
 				}
 				else if(f3 < -1){
 					if(f3 < -180F){
 						entity.field_70177_z = entity.field_70177_z - 1;
 					}else{
 						entity.field_70177_z = entity.field_70177_z + 1;
 					}
 				}
	            }
		}
		if(id != 0 && entity.getMoveT() != 3) {
			entity.func_70661_as().func_75492_a(xPosition, yPosition, zPosition, 1D);
		}
		if(entity.func_184218_aH()) {
			/*if(entity.getAIType() == 3) 
			{
				if(entity.ontick <= 5) {
					entity.rotationPitch = entity.rotationPitch - 4;
				}else if(entity.ontick >= 5 && entity.ontick <= 15) {
					entity.rotationPitch = entity.rotationPitch + 4;
				}else {
					entity.rotationPitch = entity.rotationPitch - 4;
				}
			}*/
		}
	}
	
}

