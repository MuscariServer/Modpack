package gvclib.entity.living;

public class PL_RoteModel {
	
	public static void rotemodel(EntityGVCLivingBase entity, float f){
		entity.field_70759_as = entity.field_70177_z + f;
		entity.field_70177_z = entity.field_70759_as + f;
	//	entity.prevRotationYaw = entity.prevRotationYawHead + f;
	//	entity.prevRotationYawHead = entity.prevRotationYawHead + f;
		entity.field_70761_aq = entity.field_70758_at + f;
    	//entity.rotation =entity.prevRotationYawHead + f;
	}
}
