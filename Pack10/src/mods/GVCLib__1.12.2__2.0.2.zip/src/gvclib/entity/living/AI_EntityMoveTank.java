package gvclib.entity.living;

import java.util.List;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.MoverType;
import net.minecraft.entity.ai.RandomPositionGenerator;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.chunk.Chunk;


import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.MoverType;
import net.minecraft.entity.ai.RandomPositionGenerator;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.chunk.Chunk;

public abstract class AI_EntityMoveTank
{
	public static void move(EntityGVCLivingBase vehicle, EntityGVCLivingBase ridding, float f1, float sp, float turnspeed, double max, double range) {
		{// 1
			Chunk chunk = vehicle.field_70170_p.func_175726_f(new BlockPos(vehicle.field_70165_t, vehicle.field_70163_u, vehicle.field_70161_v));
			if (chunk.func_76621_g())return;
			if(ridding.field_70759_as > 360F || ridding.field_70759_as < -360F){
				ridding.field_70759_as = 0;
				ridding.field_70177_z = 0;
				ridding.field_70126_B = 0;
				ridding.field_70758_at = 0;
				ridding.field_70761_aq = 0;
			}
			if(ridding.field_70759_as > 180F){
				ridding.field_70759_as = -179F;
				ridding.field_70177_z = -179F;
				ridding.field_70126_B = -179F;
				ridding.field_70758_at = -179F;
				ridding.field_70761_aq = -179F;
			}
			if(ridding.field_70759_as < -180F){
				ridding.field_70759_as = 179F;
				ridding.field_70177_z = 179F;
				ridding.field_70126_B = 179F;
				ridding.field_70758_at = 179F;
				ridding.field_70761_aq = 179F;
			}
			if(vehicle.field_70759_as > 360F || vehicle.field_70759_as < -360F){
				vehicle.field_70759_as = 0;
				vehicle.field_70177_z = 0;
				vehicle.field_70126_B = 0;
				vehicle.field_70758_at = 0;
				vehicle.field_70761_aq = 0;
			}
			if(vehicle.field_70759_as > 180F){
				vehicle.field_70759_as = -179F;
				vehicle.field_70177_z = -179F;
				vehicle.field_70126_B = -179F;
				vehicle.field_70758_at = -179F;
				vehicle.field_70761_aq = -179F;
			}
			if(vehicle.field_70759_as < -180F){
				vehicle.field_70759_as = 179F;
				vehicle.field_70177_z = 179F;
				vehicle.field_70126_B = 179F;
				vehicle.field_70758_at = 179F;
				vehicle.field_70761_aq = 179F;
			}
			boolean ta = false;
			if(ridding.getMoveT() == 1)
			{
				{
					double d5 = ridding.getMoveX() - vehicle.field_70165_t;
					double d7 = ridding.getMoveZ() - vehicle.field_70161_v;
					double d6 = ridding.getMoveY() - vehicle.field_70163_u;
					double d1 = vehicle.field_70163_u - (vehicle.getMoveY());
		            double d3 = (double)MathHelper.func_76133_a(d5 * d5 + d7 * d7);
		            float f11 = (float)(-(Math.atan2(d1, d3) * 180.0D / Math.PI));
		            ridding.rotation = ridding.field_70177_z = ridding.field_70759_as = ridding.field_70761_aq
		            		=  vehicle.rotation = vehicle.rote =  -((float) Math.atan2(d5, d7)) * 180.0F / (float) Math.PI;
		            ridding.rotationp = ridding.field_70127_C = vehicle.rotationp = vehicle.field_70125_A = -f11 + 10+ vehicle.angle_offset;
					double ddx = Math.abs(d5);
					double ddz = Math.abs(d7);
					if(vehicle.rote > 180F){
						vehicle.rote = -179F;
					}
					if(vehicle.rote < -180F){
						vehicle.rote = 179F;
					}
					//System.out.println(String.format("input"));
					Vec3d look = vehicle.func_70040_Z();
					float f3 = (float) (vehicle.field_70759_as - vehicle.rote);
					
					if ((ddx > max || ddz > max)) {
						if(vehicle.throttle < vehicle.thmax * 0.75f){
							 vehicle.throttle = vehicle.throttle + vehicle.thmaxa;
							}
						/*vehicle.throttle = vehicle.thmax;
						 if(vehicle.thpower < vehicle.thmax){
							 vehicle.thpower = vehicle.thpower + vehicle.thmaxa;
							}*/
						 if(vehicle.field_70759_as != vehicle.rote){
							 //System.out.println(String.format("input"));
			            		if(f3 > turnspeed){
			    					if(f3 > 180F){
			    						PL_RoteModel.rotemodel(vehicle,+ turnspeed);
			    					}else{
			    						PL_RoteModel.rotemodel(vehicle,- turnspeed);
			    					}
			    				}
			    				else if(f3 < -turnspeed){
			    					if(f3 < -180F){
			    						PL_RoteModel.rotemodel(vehicle,- turnspeed);
			    					}else{
			    						PL_RoteModel.rotemodel(vehicle,+ turnspeed);
			    					}
			    				}
				            }
						 vehicle.field_70177_z  = vehicle.field_70759_as;
					}
					{
						List<Entity> llist = vehicle.field_70170_p.func_72839_b(vehicle,
								vehicle.func_174813_aQ().func_72321_a(vehicle.field_70159_w, vehicle.field_70181_x, vehicle.field_70179_y)
										.func_186662_g(range));
						if (llist != null) {
							for (int lj = 0; lj < llist.size(); lj++) {
								Entity entity1 = (Entity) llist.get(lj);
								if (entity1.func_70067_L() && entity1 != null && vehicle.func_110143_aJ() > 0.0F) {
									boolean flag = vehicle.func_70635_at().func_75522_a(entity1);
									if (vehicle.CanAttack(entity1) && entity1 != null) {
										if (vehicle.targetentity == entity1) {
											{
												double d51 = entity1.field_70165_t - vehicle.field_70165_t;
												double d71 = entity1.field_70161_v - vehicle.field_70161_v;
												double d61 = entity1.field_70163_u - vehicle.field_70163_u;
												double d11 = vehicle.field_70163_u - (entity1.field_70163_u);
												double d31 = (double) MathHelper.func_76133_a(d51 * d51 + d71 * d71);
												float f111 = (float) (-(Math.atan2(d11, d31) * 180.0D / Math.PI));
												vehicle.rotation = -((float) Math.atan2(d51, d71)) * 180.0F
														/ (float) Math.PI;
												vehicle.rotationp = vehicle.field_70127_C = vehicle.rotationp = vehicle.field_70125_A = -f11
														+ 10 + vehicle.angle_offset;
												ridding.rotation = ridding.field_70177_z = ridding.field_70759_as = ridding.field_70761_aq 
														= -((float) Math.atan2(d51, d71)) * 180.0F / (float) Math.PI;
												ridding.rotationp = ridding.field_70127_C = ridding.rotationp = ridding.field_70125_A = -f11
														+ 10 + vehicle.angle_offset;
												if (flag) {
													vehicle.targetentity = (EntityLivingBase) entity1;
												}
												ta = true;
											}
											break;
										} else if (vehicle.targetentity == null) {
											if (vehicle.CanAttack(entity1) && flag) {
												vehicle.targetentity = (EntityLivingBase) entity1;
												ta = true;
												break;
											}
										}
									}
								}
							}
						}
					}
					ta = true;
				}
				/*if((vehicle.motionX <= 0.1 && vehicle.motionX >= - 0.1) && (vehicle.motionZ <= 0.1 && vehicle.motionZ >= - 0.1) && vehicle.motionY <= 0){
					++ridding.stoptime;
				}else{
					ridding.stoptime = 0;
				}
				if(ridding.stoptime > 1200){
					if (!ridding.world.isRemote) {
						ridding.setDead();
					}
				}*/
				
			}///MoveT == 1
			
			List<Entity> llist = vehicle.field_70170_p.func_72839_b(vehicle,
					vehicle.func_174813_aQ().func_72321_a(vehicle.field_70159_w, vehicle.field_70181_x, vehicle.field_70179_y).func_186662_g(range));
			if (llist != null) {
				for (int lj = 0; lj < llist.size(); lj++) {
					Entity entity1 = (Entity) llist.get(lj);
					if (entity1.func_70067_L() && entity1 != null && vehicle.func_110143_aJ() > 0.0F) {
						boolean flag = vehicle.func_70635_at().func_75522_a(entity1);
						if (ridding.CanAttack(entity1) && entity1 != null ) {
							
							if(ridding.targetentity == entity1)
							 {
								{
									double d5 = entity1.field_70165_t - vehicle.field_70165_t;
									double d7 = entity1.field_70161_v - vehicle.field_70161_v;
									double d6 = entity1.field_70163_u - vehicle.field_70163_u;
									double d1 = vehicle.field_70163_u - (entity1.field_70163_u);
						            double d3 = (double)MathHelper.func_76133_a(d5 * d5 + d7 * d7);
						            float f11 = (float)(-(Math.atan2(d1, d3) * 180.0D / Math.PI));
						            //ridding.rotationYawHead = vehicle.rote =  -((float) Math.atan2(d5, d7)) * 180.0F / (float) Math.PI;
						            vehicle.rote =  -((float) Math.atan2(d5, d7)) * 180.0F / (float) Math.PI;
						            if(vehicle.ridding_rotation_lock) {
						            	vehicle.rotation = ridding.field_70177_z;
						            }else {
						            	ridding.rotation = ridding.field_70177_z = ridding.field_70761_aq =  -((float) Math.atan2(d5, d7)) * 180.0F / (float) Math.PI;
						            	 vehicle.rotation =  -((float) Math.atan2(d5, d7)) * 180.0F / (float) Math.PI;
						            }
						            float angle = -f11 + 10 + vehicle.angle_offset;
						            if(angle < vehicle.rotationp_max) {
						            	angle = vehicle.rotationp_max;
						            }
						            if(angle > vehicle.rotationp_min) {
						            	angle = vehicle.rotationp_min;
						            }
						            ridding.rotationp = ridding.field_70127_C = vehicle.rotationp = vehicle.field_70125_A = angle;
						            
									double ddx = Math.abs(d5);
									double ddz = Math.abs(d7);
									if(vehicle.rote > 180F){
										vehicle.rote = -179F;
									}
									if(vehicle.rote < -180F){
										vehicle.rote = 179F;
									}
									//System.out.println(String.format("input"));
									Vec3d look = vehicle.func_70040_Z();
									float f3 = (float) (vehicle.field_70759_as - vehicle.rote);
									
									if ((ddx > max || ddz > max)) {
										if(vehicle.throttle < vehicle.thmax * 0.75f){
											 vehicle.throttle = vehicle.throttle + vehicle.thmaxa;
											}
										/*vehicle.throttle = vehicle.thmax;
										 if(vehicle.thpower < vehicle.thmax){
											 vehicle.thpower = vehicle.thpower + vehicle.thmaxa;
											}*/
										 if(vehicle.field_70759_as != vehicle.rote){
											 //System.out.println(String.format("input"));
							            		if(f3 > turnspeed){
							    					if(f3 > 180F){
							    						PL_RoteModel.rotemodel(vehicle,+ turnspeed);
							    					}else{
							    						PL_RoteModel.rotemodel(vehicle,- turnspeed);
							    					}
							    				}
							    				else if(f3 < -turnspeed){
							    					if(f3 < -180F){
							    						PL_RoteModel.rotemodel(vehicle,- turnspeed);
							    					}else{
							    						PL_RoteModel.rotemodel(vehicle,+ turnspeed);
							    					}
							    				}
								            }
										 vehicle.field_70177_z  = vehicle.field_70759_as;
									}
									if(flag){
										ridding.targetentity = (EntityLivingBase) entity1;
									}
									ta = true;
								}
								break;
							}
							else 
							if(ridding.targetentity == null){
								if (ridding.CanAttack(entity1) && flag) 
								{
									ridding.targetentity = (EntityLivingBase) entity1;
									ta = true;
									break;
								}
							}
							
						}

					}
				}
			}
			if(!ta){
				double xPosition = 0;
			    double yPosition = 0;
			    double zPosition = 0;
				if (vehicle.func_70654_ax() >= 100)
		        {
		        }
		        else if (vehicle.func_70681_au().nextInt(120) != 0)
		        {
		        }
		        else
		        {
		            Vec3d vec3 = RandomPositionGenerator.func_75463_a(vehicle, 10, 7);

		            if (vec3 == null)
		            {
		            }
		            else
		            {
		                xPosition = vec3.field_72450_a;
		                yPosition = vec3.field_72448_b;
		                zPosition = vec3.field_72449_c;
		            }
		            vehicle.rotation = vehicle.func_70681_au().nextInt(120) - 60;
		        }
				vehicle.func_70661_as().func_75492_a(xPosition, yPosition, zPosition, 1D);
			}
		} // 1
}
	
	public static void movespg(EntityGVCLivingBase vehicle, EntityGVCLivingBase ridding, float f1, float sp, float turnspeed, double max, double range) {
		{// 1
			boolean ta = false;
			if(ridding.getMoveT() == 1)
			{
				{
					double d5 = vehicle.getMoveX() - vehicle.field_70165_t;
					double d7 = vehicle.getMoveZ() - vehicle.field_70161_v;
					double d6 = vehicle.getMoveY() - vehicle.field_70163_u;
					double d1 = vehicle.field_70163_u - (vehicle.getMoveY());
		            double d3 = (double)MathHelper.func_76133_a(d5 * d5 + d7 * d7);
		            float f11 = (float)(-(Math.atan2(d1, d3) * 180.0D / Math.PI));
		            ridding.rotation = ridding.field_70177_z = ridding.field_70759_as = ridding.field_70761_aq
		            		=  vehicle.rotation = vehicle.rote =  -((float) Math.atan2(d5, d7)) * 180.0F / (float) Math.PI;
		            ridding.rotationp = ridding.field_70127_C = vehicle.rotationp = vehicle.field_70125_A = -f11 + 10;
					double ddx = Math.abs(d5);
					double ddz = Math.abs(d7);
					if(vehicle.rote > 180F){
						vehicle.rote = -179F;
					}
					if(vehicle.rote < -180F){
						vehicle.rote = 179F;
					}
					//System.out.println(String.format("input"));
					Vec3d look = vehicle.func_70040_Z();
					float f3 = (float) (vehicle.field_70759_as - vehicle.rote);
					
					if ((ddx > max || ddz > max)) {
						 /*if(vehicle.throttle < vehicle.thmax * 0.75f){
							 vehicle.throttle = vehicle.throttle + vehicle.thmaxa;
							}*/
						/*vehicle.throttle = vehicle.thmax;
						 if(vehicle.thpower < vehicle.thmax){
							 vehicle.thpower = vehicle.thpower + vehicle.thmaxa;
							}*/
						 if(vehicle.field_70759_as != vehicle.rote){
							 //System.out.println(String.format("input"));
			            		if(f3 > turnspeed){
			    					if(f3 > 180F){
			    						PL_RoteModel.rotemodel(vehicle,+ turnspeed);
			    					}else{
			    						PL_RoteModel.rotemodel(vehicle,- turnspeed);
			    					}
			    				}
			    				else if(f3 < -turnspeed){
			    					if(f3 < -180F){
			    						PL_RoteModel.rotemodel(vehicle,- turnspeed);
			    					}else{
			    						PL_RoteModel.rotemodel(vehicle,+ turnspeed);
			    					}
			    				}
				            }
						 vehicle.field_70177_z  = vehicle.field_70759_as;
					}
					ta = true;
				}
			}
			
			List<Entity> llist = vehicle.field_70170_p.func_72839_b(vehicle,
					vehicle.func_174813_aQ().func_72321_a(vehicle.field_70159_w, vehicle.field_70181_x, vehicle.field_70179_y).func_186662_g(range));
			if (llist != null) {
				for (int lj = 0; lj < llist.size(); lj++) {
					Entity entity1 = (Entity) llist.get(lj);
					if (entity1.func_70067_L() && entity1 != null && vehicle.func_110143_aJ() > 0.0F) {
						boolean flag = vehicle.func_70635_at().func_75522_a(entity1);
						if(vehicle.getMoveT() == 1)
						{
							if(vehicle.targetentity == entity1){
								double d5 = entity1.field_70165_t - vehicle.field_70165_t;
								double d7 = entity1.field_70161_v - vehicle.field_70161_v;
								double d51 = vehicle.getMoveX() - vehicle.field_70165_t;
								double d71 = vehicle.getMoveZ() - vehicle.field_70161_v;
								
								double d6 = entity1.field_70163_u - vehicle.field_70163_u;
								double d1 = vehicle.field_70163_u - (entity1.field_70163_u);
					            double d3 = (double)MathHelper.func_76133_a(d5 * d5 + d7 * d7);
					            float f11 = (float)(-(Math.atan2(d1, d3) * 180.0D / Math.PI));
					            vehicle.rotation =  -((float) Math.atan2(d5, d7)) * 180.0F / (float) Math.PI;
					            vehicle.rote =  -((float) Math.atan2(d51, d71)) * 180.0F / (float) Math.PI;
					            vehicle.rotationp = vehicle.field_70125_A = -f11 + 10;
								double ddx = Math.abs(d51);
								double ddz = Math.abs(d71);
								if ((ddx > 10 || ddz > 10)) {
									if (!vehicle.field_70170_p.field_72995_K) {
										if (vehicle.field_70759_as != vehicle.rote) {
											if (vehicle.field_70759_as < vehicle.rote) {
												vehicle.field_70759_as = vehicle.field_70759_as + turnspeed;
												vehicle.field_70177_z = vehicle.field_70177_z + turnspeed;
												vehicle.field_70126_B = vehicle.field_70126_B + turnspeed;
												vehicle.field_70758_at = vehicle.field_70758_at + turnspeed;
											} else if (vehicle.field_70759_as > vehicle.rote) {
												vehicle.field_70759_as = vehicle.field_70759_as - turnspeed;
												vehicle.field_70177_z = vehicle.field_70177_z - turnspeed;
												vehicle.field_70126_B = vehicle.field_70126_B - turnspeed;
												vehicle.field_70758_at = vehicle.field_70758_at - turnspeed;
											}
										}
									}
									if(!vehicle.field_70170_p.field_72995_K)
									{
										vehicle.field_70159_w -= MathHelper.func_76126_a(f1) * sp;
										vehicle.field_70179_y += MathHelper.func_76134_b(f1) * sp;
										vehicle.func_70091_d(MoverType.SELF,vehicle.field_70159_w, vehicle.field_70181_x, vehicle.field_70179_y);
									}
								}
								if(flag){
									ridding.targetentity = (EntityLivingBase) entity1;
								}
								ta = true;
							}
							else if(ridding.targetentity == null){
								if (ridding.CanAttack(entity1) && flag) 
								{
									ridding.targetentity = (EntityLivingBase) entity1;
									ta = true;
									break;
								}
							}
						}else
						if(ridding.targetentity == entity1){
							{
								double d5 = entity1.field_70165_t - vehicle.field_70165_t;
								double d7 = entity1.field_70161_v - vehicle.field_70161_v;
								double d6 = entity1.field_70163_u - vehicle.field_70163_u;
								double d1 = vehicle.field_70163_u - (entity1.field_70163_u);
					            double d3 = (double)MathHelper.func_76133_a(d5 * d5 + d7 * d7);
					            float f11 = (float)(-(Math.atan2(d1, d3) * 180.0D / Math.PI));
					            vehicle.rotation = vehicle.rote =  -((float) Math.atan2(d5, d7)) * 180.0F / (float) Math.PI;
					            vehicle.rotationp = vehicle.field_70125_A = -f11 + 10;
								double ddx = Math.abs(d5);
								double ddz = Math.abs(d7);
								if ((ddx > max || ddz > max)) {
									if (!vehicle.field_70170_p.field_72995_K) {
										if (vehicle.field_70759_as != vehicle.rote) {
											if (vehicle.field_70759_as < vehicle.rote) {
												vehicle.field_70759_as = vehicle.field_70759_as + turnspeed;
												vehicle.field_70177_z = vehicle.field_70177_z + turnspeed;
												vehicle.field_70126_B = vehicle.field_70126_B + turnspeed;
												vehicle.field_70758_at = vehicle.field_70758_at + turnspeed;
											} else if (vehicle.field_70759_as > vehicle.rote) {
												vehicle.field_70759_as = vehicle.field_70759_as - turnspeed;
												vehicle.field_70177_z = vehicle.field_70177_z - turnspeed;
												vehicle.field_70126_B = vehicle.field_70126_B - turnspeed;
												vehicle.field_70758_at = vehicle.field_70758_at - turnspeed;
											}
										}
									}
									if(!vehicle.field_70170_p.field_72995_K)
									{
										vehicle.field_70159_w -= MathHelper.func_76126_a(f1) * sp;
										vehicle.field_70179_y += MathHelper.func_76134_b(f1) * sp;
										vehicle.func_70091_d(MoverType.SELF,vehicle.field_70159_w, vehicle.field_70181_x, vehicle.field_70179_y);
									}
								}
								if(flag){
									ridding.targetentity = (EntityLivingBase) entity1;
								}
								ta = true;
							}
							break;
						}
						else if(ridding.targetentity == null){
							if (ridding.CanAttack(entity1) && flag) 
							{
								ridding.targetentity = (EntityLivingBase) entity1;
								ta = true;
								break;
							}
						}
						
					}
				}
			}
			if(!ta){
				double xPosition = 0;
			    double yPosition = 0;
			    double zPosition = 0;
				if (vehicle.func_70654_ax() >= 100)
		        {
		        }
		        else if (vehicle.func_70681_au().nextInt(120) != 0)
		        {
		        }
		        else
		        {
		            Vec3d vec3 = RandomPositionGenerator.func_75463_a(vehicle, 10, 7);

		            if (vec3 == null)
		            {
		            }
		            else
		            {
		                xPosition = vec3.field_72450_a;
		                yPosition = vec3.field_72448_b;
		                zPosition = vec3.field_72449_c;
		            }
		            vehicle.rotation = vehicle.func_70681_au().nextInt(120) - 60;
		        }
				vehicle.func_70661_as().func_75492_a(xPosition, yPosition, zPosition, 1D);
			}
		} // 1
}
}
