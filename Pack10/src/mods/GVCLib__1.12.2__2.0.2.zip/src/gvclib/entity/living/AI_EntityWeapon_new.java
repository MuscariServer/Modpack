package gvclib.entity.living;

import java.util.List;
import gvclib.entity.EntityBBase;
import gvclib.entity.EntityB_Bullet;
import gvclib.entity.EntityB_BulletAA;
import gvclib.entity.EntityB_BulletFire;
import gvclib.entity.EntityB_GrenadeB;
import gvclib.entity.EntityB_Missile;
import gvclib.entity.EntityB_Shell;
import gvclib.entity.EntityT_Flash;
import gvclib.entity.EntityT_Grenade;
import gvclib.entity.Entity_Flare;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.monster.IMob;
import net.minecraft.entity.projectile.EntityTippedArrow;
import net.minecraft.init.MobEffects;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.DamageSource;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;


import gvclib.entity.EntityBBase;
import gvclib.entity.EntityB_Bullet;
import gvclib.entity.EntityB_BulletAA;
import gvclib.entity.EntityB_BulletFire;
import gvclib.entity.EntityB_GrenadeB;
import gvclib.entity.EntityB_Missile;
import gvclib.entity.EntityB_Shell;
import gvclib.entity.EntityT_Flash;
import gvclib.entity.EntityT_Grenade;
import gvclib.entity.Entity_Flare;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.monster.IMob;
import net.minecraft.entity.projectile.EntityTippedArrow;
import net.minecraft.init.MobEffects;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.DamageSource;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public class AI_EntityWeapon_new {
	
	public EntityGVCLivingBase player;
	public EntityGVCLivingBase vehicle;
	public EntityLivingBase target;
	
	public int id;
	public String model;
	public String tex;
	public String modelf;
	public String texf;
	
	public int ftime;
	public SoundEvent sound;
	public float f;
	public double w;
	public double h;
	public double z;
	public double xoffset;
	public double yoffset;
	public double px;
	public double py;
	public double pz;
	public double bx;
	public double by;
	public double bz;
	public Vec3d lock;
	public float rote;
	/**モブが向いている方向(rotationYawHead or rotation)に撃つ
	 * false時はrotationYaw方向*/
	public boolean follow_rote = true;
	
	public double maxy;
	public double miny;
	
	public int power;
	public float speed;
	public float bure;
	public float ex;
	public boolean exfire;
	public boolean exsmoke;
	public boolean exflash;
	public boolean extrue;
	public int P_ID = 0;
    public int P_LEVEL = 5;
    public int P_TIME = 200;
	
	public boolean damegetime = false;
	
	public int kazu;
	public double gra;
	public int maxtime;
	public int dameid;
	
	//10/19
		public boolean fly_sound = true;
	
		public int mob_min_range = 0;
		
		
	public AI_EntityWeapon_new(EntityGVCLivingBase v, EntityGVCLivingBase p) {
		this.player  = p;
		this.vehicle = v;
	}
	
	public void Attacktask(EntityGVCLivingBase entity, EntityGVCLivingBase onride, double range){
		double k = entity.field_70165_t;
		double l = entity.field_70163_u;
		double i = entity.field_70161_v;
		double han = range;
		AxisAlignedBB axisalignedbb = (new AxisAlignedBB((double) (k - han), (double) (l - miny),(double) (i - han), 
				(double) (k + han), (double) (l + maxy), (double) (i + han)))
						.func_186662_g(1);
		List<Entity> llist = entity.field_70170_p.func_72839_b(entity,axisalignedbb);
    		if(entity.getMoveT() == 5) {
    			double x1 = entity.getMoveX();
    			double y1 = entity.getMoveY();
    			double z1 = entity.getMoveZ();
    			double dyp = onride.field_70163_u + maxy;
				double dym = onride.field_70163_u - miny;
				if (dyp > y1 && dym < y1) {
					double d5 = x1 - onride.field_70165_t;
					double d7 = z1 - onride.field_70161_v;
					double ddx = Math.abs(d5);
					double ddz = Math.abs(d7);
					if ((ddx < 50 && ddz < 50)) {
						WeaponAttack();
					}
				}
    		}else 
			if (llist != null) {
				for (int lj = 0; lj < llist.size(); lj++) {
					Entity entity1 = (Entity) llist.get(lj);
					if (entity1.func_70067_L()) {
						if (entity.targetentity == entity1 && entity.CanAttack(entity1) && entity1 != null && ((EntityLivingBase) entity1).func_110143_aJ() > 0.0F && entity.func_110143_aJ() > 0.0F) 
						{
							boolean flag = onride.func_70635_at().func_75522_a(entity1);
							double ddy = Math.abs(entity1.field_70163_u - onride.field_70163_u);
							double dyp = onride.field_70163_u + maxy;
							double dym = onride.field_70163_u - miny;
							if (dyp > entity1.field_70163_u && dym < entity1.field_70163_u) {
								double d5 = entity1.field_70165_t - onride.field_70165_t;
								double d7 = entity1.field_70161_v - onride.field_70161_v;
								double d11 = entity.field_70163_u - (entity1.field_70163_u);
								double d31 = (double) MathHelper.func_76133_a(d5 * d5 + d7 * d7);
								float f111 = (float) (-(Math.atan2(d11, d31) * 180.0D / Math.PI));
								float angle = -f111+ 10;
								entity.rotation_1 = -((float) Math.atan2(d5, d7)) * 180.0F / (float) Math.PI;
								if(angle >= entity.rotationp_max && angle <= entity.rotationp_min) {
									if(entity1.func_184218_aH() && entity1.func_184187_bx() != null && entity1.func_184187_bx() instanceof EntityLivingBase) {
										EntityLivingBase en = (EntityLivingBase) entity1.func_184187_bx();
										target = (EntityLivingBase)en;
										WeaponAttack();
									}else {
										target = (EntityLivingBase)entity1;
										WeaponAttack();
									}
								}
								break;
							}
							
						}
					}
				}
			}
    }
	
	public void AttacktaskAngle(EntityGVCLivingBase entity, EntityGVCLivingBase onride, double range){
		double k = entity.field_70165_t;
		double l = entity.field_70163_u;
		double i = entity.field_70161_v;
		double han = range;
		AxisAlignedBB axisalignedbb = (new AxisAlignedBB((double) (k - han), (double) (l - han),(double) (i - han), 
				(double) (k + han), (double) (l + han), (double) (i + han)))
						.func_186662_g(1);
		List<Entity> llist = entity.field_70170_p.func_72839_b(entity,axisalignedbb);
    		if(entity.getMoveT() == 5) {
    			double x1 = entity.getMoveX();
    			double y1 = entity.getMoveY();
    			double z1 = entity.getMoveZ();
    			double dyp = onride.field_70163_u + maxy;
				double dym = onride.field_70163_u - miny;
				if (dyp > y1 && dym < y1) {
					double d5 = x1 - onride.field_70165_t;
					double d7 = z1 - onride.field_70161_v;
					double ddx = Math.abs(d5);
					double ddz = Math.abs(d7);
					if ((ddx < 50 && ddz < 50)) {
						WeaponAttack();
					}
				}
    		}else 
			if (llist != null) {
				for (int lj = 0; lj < llist.size(); lj++) {
					Entity entity1 = (Entity) llist.get(lj);
					if (entity1.func_70067_L()) {
						if (entity.targetentity == entity1 && entity.CanAttack(entity1) && entity1 != null && ((EntityLivingBase) entity1).func_110143_aJ() > 0.0F && entity.func_110143_aJ() > 0.0F) 
						{
							boolean flag = onride.func_70635_at().func_75522_a(entity1);
							double d5 = entity1.field_70165_t - vehicle.field_70165_t;
							double d7 = entity1.field_70161_v - vehicle.field_70161_v;
							double d6 = entity1.field_70163_u - vehicle.field_70163_u;
							double d1 = vehicle.field_70163_u - (entity1.field_70163_u);
				            double d3 = (double)MathHelper.func_76133_a(d5 * d5 + d7 * d7);
				            float f11 = (float)(-(Math.atan2(d1, d3) * 180.0D / Math.PI));
				            float rotep_offset = -f11 + 10;
				            if(rotep_offset <= vehicle.rotationp_min && rotep_offset >= vehicle.rotationp_max) {
								entity.rotation_1 = -((float) Math.atan2(d5, d7)) * 180.0F / (float) Math.PI;
								if(entity1.func_184218_aH() && entity1.func_184187_bx() != null && entity1.func_184187_bx() instanceof EntityLivingBase) {
									EntityLivingBase en = (EntityLivingBase) entity1.func_184187_bx();
									target = (EntityLivingBase)en;
									WeaponAttack();
								}else {
									target = (EntityLivingBase)entity1;
									WeaponAttack();
								}
								break;
							}
							
						}
					}
				}
			}
    }
	
	public void AttacktaskAir(EntityGVCLivingBase entity, EntityGVCLivingBase onride, double range){
		boolean ta = false;
		double ix = 0;
		double iy = 0;
		double iz = 0;
		double yy = 0;
		
		double k = entity.field_70165_t;
		double l = entity.field_70163_u;
		double i = entity.field_70161_v;
		double han = range;
		AxisAlignedBB axisalignedbb = (new AxisAlignedBB((double) (k - han), (double) (l - miny),(double) (i - han), 
				(double) (k + han), (double) (l + maxy), (double) (i + han)))
						.func_186662_g(1);
		List<Entity> llist = entity.field_70170_p.func_72839_b(entity,axisalignedbb);
		if (llist != null) {
			for (int lj = 0; lj < llist.size(); lj++) {
				Entity entity1 = (Entity) llist.get(lj);
				if (entity1.func_70067_L()) {
					if (entity.targetentity == entity1 && entity1 != null && ((EntityLivingBase) entity1).func_110143_aJ() > 0.0F && entity.func_110143_aJ() > 0.0F) 
					{
						double d5 = entity1.field_70165_t - onride.field_70165_t;
						double d7 = entity1.field_70161_v - onride.field_70161_v;
			            double ro =  -((float) Math.atan2(d5, d7)) * 180.0F / (float) Math.PI;
			            double ro2 = Math.abs(ro);
			            if(ro > 180F){
			            	ro = -179F;
						}
						if(ro < -180F){
							ro = 179F;
						}
			            float f3 = (float) (onride.field_70759_as - ro);
			            double dd = Math.abs(f3);
			            float dx = (float)Math.tan((onride.field_70165_t * onride.field_70165_t) + (onride.field_70161_v * onride.field_70161_v));
			    		float dy = (float) (dx * Math.tan(onride.field_70127_C)) + (float)onride.field_70163_u;
			    		double dyp = onride.field_70163_u + maxy;
						double dym = onride.field_70163_u - miny;
						if (dyp > entity1.field_70163_u && dym < entity1.field_70163_u && dd < 5) {
							if(entity1.func_184218_aH() && entity1.func_184187_bx() != null && entity1.func_184187_bx() instanceof EntityLivingBase) {
								EntityLivingBase en = (EntityLivingBase) entity1.func_184187_bx();
								target = (EntityLivingBase)en;
								WeaponAttack();
							}else {
								target = (EntityLivingBase)entity1;
								WeaponAttack();
							}
							break;
						}
						
					}
				}
			}
		}
	}
	
	public void AttacktaskB(EntityGVCLivingBase entity, EntityGVCLivingBase onride, double range){
		double k = entity.field_70165_t;
		double l = entity.field_70163_u;
		double i = entity.field_70161_v;
		double han = range;
		AxisAlignedBB axisalignedbb = (new AxisAlignedBB((double) (k - han), (double) (l - miny),(double) (i - han), 
				(double) (k + han), (double) (l + maxy), (double) (i + han)))
						.func_186662_g(1);
		List<Entity> llist = entity.field_70170_p.func_72839_b(entity,axisalignedbb);
			if (llist != null) {
				for (int lj = 0; lj < llist.size(); lj++) {
					Entity entity1 = (Entity) llist.get(lj);
					if (entity1.func_70067_L()) {
						if (entity.targetentity == entity1 && entity1 != null && ((EntityLivingBase) entity1).func_110143_aJ() > 0.0F && entity.func_110143_aJ() > 0.0F) 
						{
							double d5 = entity1.field_70165_t - onride.field_70165_t;
							double d7 = entity1.field_70161_v - onride.field_70161_v;
				            double ro =  -((float) Math.atan2(d5, d7)) * 180.0F / (float) Math.PI;
				            if(ro > 180F){
				            	ro = -179F;
							}
							if(ro < -180F){
								ro = 179F;
							}
				            float f3 = (float) (onride.field_70759_as - ro);
				            double dd = Math.abs(f3);
				            BlockPos bp = entity.field_70170_p.func_175645_m(new BlockPos(entity.field_70165_t, entity.field_70163_u, entity.field_70161_v));
							int genY = bp.func_177956_o();
							if (entity1.field_70163_u < genY + 5 && dd < 10) {
								if(entity1.func_184218_aH() && entity1.func_184187_bx() != null && entity1.func_184187_bx() instanceof EntityLivingBase) {
									EntityLivingBase en = (EntityLivingBase) entity1.func_184187_bx();
									target = (EntityLivingBase)en;
									WeaponAttack();
								}else {
									target = (EntityLivingBase)entity1;
									WeaponAttack();
								}
								break;
							}
							
						}
					}
				}
			}
    }
	
	
	public void WeaponAttack()
	{
		double xxz = target.field_70165_t - px;
		double zzx = target.field_70161_v - pz;
		double ddx = Math.abs(xxz);
		double ddz = Math.abs(zzx);
		if ((ddx < mob_min_range && ddz < mob_min_range) && !follow_rote) {
			return;
		}
		
		int ra = player.field_70170_p.field_73012_v.nextInt(10) + 1;
    	float val = ra * 0.02F;
    	//if(sound != null && !player.world.isRemote) 
    	if(sound != null) 
    	{
    		player.func_184185_a(sound, 5.0F, 0.9F + val);
    	}
		player.firetrue = true;
		double xx11 = 0;
		double zz11 = 0;
		xx11 -= MathHelper.func_76126_a(rote * 0.01745329252F) * z;
		zz11 += MathHelper.func_76134_b(rote * 0.01745329252F) * z;
		xx11 -= MathHelper.func_76126_a(rote * 0.01745329252F + f) * w;
		zz11 += MathHelper.func_76134_b(rote * 0.01745329252F + f) * w;
		double offx = 0;
		double offz = 0;
		offx -= MathHelper.func_76126_a(rote * 0.01745329252F + 1.57F) * xoffset;
		offz += MathHelper.func_76134_b(rote * 0.01745329252F + 1.57F) * xoffset;
		double kaku = 0;
		//kaku += lock.y * 2;
		kaku = MathHelper.func_76133_a((z - bz)* (z - bz) + (w - bx)*(w - bx)) * Math.tan(Math.toRadians(-vehicle.field_70125_A)) * 0.4D;
		
		Vec3d locked = player.func_70040_Z();
		if(id < 10){
			for (int ka = 0; ka < kazu; ++ka) {
				
				EntityBBase var3;
				if (id == 1) {
					var3 = new EntityB_BulletAA(player.field_70170_p, player);
				} else if (id == 2) {
					var3 = new EntityB_GrenadeB(player.field_70170_p, player);
				} else if (id == 3) {
					var3 = new EntityB_Shell(player.field_70170_p, player);
				} else if (id == 4) {
					var3 = new EntityB_Missile(player.field_70170_p, player);
					EntityB_Missile mi = (EntityB_Missile) var3;
					mi.speedd = speed;
				} else if (id == 6) {
					var3 = new EntityB_BulletFire(player.field_70170_p, player);
				} else if (id == 7) {
					var3 = new EntityB_BulletAA(player.field_70170_p, player);
					EntityB_BulletAA aa = (EntityB_BulletAA) var3;
					aa.exnear = true;
				} else if (id == 8) {
					var3 = new EntityB_Missile(player.field_70170_p, player);
					EntityB_Missile mi = (EntityB_Missile) var3;
					mi.speedd = speed;
					mi.autoaim = false;
				} else if (id == 9) {
					var3 = new EntityT_Grenade(player.field_70170_p, player);
				} else {
					var3 = new EntityB_Bullet(player.field_70170_p, player);
				}
				var3.Bdamege = power;
				var3.gra = gra;// 0.025
				//var3.friend = entity;
				var3.friend = vehicle;
				var3.ex = extrue;
				var3.exfire = exfire;
				var3.exsmoke = exsmoke;
				var3.exflash = exflash;
				var3.exlevel = ex;
				var3.setModel(model);
				var3.setTex(tex);
				var3.timemax = maxtime;
				var3.bulletDameID = dameid;
				var3.muteki = damegetime;
				 var3.mitarget = target;
				 var3.P_ID = P_ID;
				 var3.P_TIME = P_TIME;
				 var3.P_LEVEL = P_LEVEL;
				 
				 var3.fly_sound = fly_sound;
				 
				var3.func_70012_b(px + xx11, py + h + kaku, pz + zz11, player.field_70177_z,
						player.field_70125_A);
				
				Vec3d elock = target.func_70040_Z();
				double d5 = target.field_70165_t - px;
				double d7 = target.field_70161_v - pz;
	            double d3 = (double)MathHelper.func_76133_a(d5 * d5 + d7 * d7) * 1;
				//double xx = elock.x * d3;
				//double zz = elock.z * d3;
				//double xx = (entity1.posX - entity1.prevPosX) * 1;
			    //double zz = (entity1.posZ - entity1.prevPosZ) * 1;
	            double xx = target.field_70159_w * d3;
				double zz = target.field_70179_y * d3;
				double var4 = (target.field_70165_t + xx) - px - xx11 - offx;
				double var6 = target.field_70163_u + (double) target.func_70047_e()
						+ 0.200000023841858D - var3.field_70163_u - (h / 2);
				double var8 = (target.field_70161_v + zz) - pz - zz11 - offz;
				float var10 = MathHelper.func_76133_a(var4 * var4 + var8 * var8) * 0.01F;
				float var11 = var10 * 100;
				if(speed > 4F)speed = 4F;
				float t = var11 / speed;
				float hg = (float) (((0.03 - gra)* t*t) / 2);
				if (player.func_70644_a(MobEffects.field_76440_q))
		        {
					bure = bure * 10F;
		        }
				if(follow_rote) {
					var3.setThrowableHeading(var4, (var6 + (double) var10) * 1 + kaku + hg, var8, speed, bure);
				}else {
					if(player == vehicle) {
						//var3.setThrowableHeading(var4, (var6 + (double) var10) * 1 + kaku, var8, speed, bure);
						var3.setHeadingFromThrower(player, (float)player.field_70125_A + (float)yoffset, player.field_70177_z + (float)xoffset, 0.0F,
								speed, bure);
					}else {
						var3.setHeadingFromThrower(vehicle, (float)vehicle.field_70125_A + (float)yoffset, vehicle.field_70177_z + (float)xoffset, 0.0F,
								speed, bure);
					}
					
				}
				
				if (!player.field_70170_p.field_72995_K) {
					player.field_70170_p.func_72838_d(var3);
				}
				EntityT_Flash flash = new EntityT_Flash(player.field_70170_p, player);
				flash.gra = 0.03;
				flash.timemax = ftime;
				flash.setModel(modelf);
				flash.setTex(texf);
				flash.func_70012_b(px + xx11, py + h, pz + zz11, player.field_70177_z,
						player.field_70125_A);
				flash.setThrowableHeading(var4, (var6 + (double) var10) * 1 + kaku, var8, 0.3F, 0);
				if (!player.field_70170_p.field_72995_K) {
					player.field_70170_p.func_72838_d(flash);
				}
			}
		}else if(id >= 10 && id < 20){
			/*EntityTNTBase var3;
			if(id == 0){
				var3 = new EntityT_TNT(player.world, player);
			}else{
				var3 = new EntityT_TNT(player.world, player);
			}
			var3.Bdamege = power;
			var3.friend = vehicle;
			var3.exlevel = ex;
			var3.ex = extrue;
			var3.muteki = true;
			var3.exinground = true;
		//	var3.exnear = true;
			var3.extime = 200;
			var3.setLocationAndAngles(px + xx11, py + h + kaku, pz + zz11,
					player.rotationYaw, player.rotationPitch);
			var3.setThrowableHeading(lock.x, locked.y + 0.03, lock.z, speed, bure);
			if (!player.world.isRemote) {
				player.world.spawnEntity(var3);
			}*/
			EntityB_GrenadeB var3 = new EntityB_GrenadeB(player.field_70170_p, player);
			
			var3.Bdamege = power;
			var3.gra = 0.0F;// 0.025
			//var3.friend = entity;
			var3.friend = vehicle;
			var3.ex = extrue;
			var3.exfire = exfire;
			var3.exsmoke = exsmoke;
			var3.exflash = exflash;
			var3.exlevel = ex;
			var3.setModel(model);
			var3.setTex(tex);
			var3.timemax = 8000;
			var3.bulletDameID = dameid;
			var3.muteki = damegetime;
			 var3.mitarget = target;
			var3.func_70012_b(px + xx11, py + h + kaku, pz + zz11, player.field_70177_z,
					player.field_70125_A);
			var3.spg_fly_sound = true;
			
			Vec3d elock = target.func_70040_Z();
			double d5 = target.field_70165_t - px;
			double d7 = target.field_70161_v - pz;
            double d3 = (double)MathHelper.func_76133_a(d5 * d5 + d7 * d7) * 1;
			//double xx = elock.x * d3;
			//double zz = elock.z * d3;
			//double xx = (entity1.posX - entity1.prevPosX) * 1;
		    //double zz = (entity1.posZ - entity1.prevPosZ) * 1;
            double xx = target.field_70159_w * d3;
			double zz = target.field_70179_y * d3;
			double var4 = (target.field_70165_t + xx) - px - xx11 - offx;
			double var6 = target.field_70163_u + (double) target.func_70047_e()
					+ 0.200000023841858D - var3.field_70163_u - (h / 2);
			double var8 = (target.field_70161_v + zz) - pz - zz11 - offz;
			float var10 = MathHelper.func_76133_a(var4 * var4 + var8 * var8) * 0.01F;
			
			double xrange = Math.abs(target.field_70165_t) -Math.abs(px);
			double zrange = Math.abs(target.field_70161_v) -Math.abs(pz);
			double range = (double)MathHelper.func_76133_a(xrange * xrange + zrange * zrange) * 1;
			
			double rangespeed = (double)MathHelper.func_76133_a((0.022 * range) / (2 * Math.sin(60) * Math.cos(60)));
			float yawaa = -((float) Math.atan2(var4, var8)) * 180.0F / (float) Math.PI;
			float yaw = yawaa * (2 * (float) Math.PI / 360);
			{
				//var3.setThrowableHeading(var4, (var6 + (double) var10) * 1 + kaku, var8, speed, bure);
				//var3.setHeadingFromThrower(player, -60, yaw, 0.0F,(float)rangespeed, bure);
				float rotationPitchIn = -60;
				float rotationYawIn = yawaa;
				float f = -MathHelper.func_76126_a(rotationYawIn * 0.017453292F)
						* MathHelper.func_76134_b(rotationPitchIn * 0.017453292F);
				float f1 = -MathHelper.func_76126_a((rotationPitchIn + 0) * 0.017453292F);
				float f2 = MathHelper.func_76134_b(rotationYawIn * 0.017453292F)
						* MathHelper.func_76134_b(rotationPitchIn * 0.017453292F);
				 var3.setThrowableHeading((double)f, (double)f1, (double)f2, (float)rangespeed, bure);
				//var3.setThrowableHeading(var4, f1, var8, (float)rangespeed, bure);
			}
			
			if (!player.field_70170_p.field_72995_K) {
				player.field_70170_p.func_72838_d(var3);
			}
		}
		else if(id == 21){
			for (int ka = 0; ka < kazu; ++ka) {
				int xx = player.field_70170_p.field_73012_v.nextInt(6);
				int zz = player.field_70170_p.field_73012_v.nextInt(6);
				Entity_Flare var8 = new Entity_Flare(player.field_70170_p);
				var8.field_70181_x = speed;
				var8.func_70012_b(px - 3 + xx, py, pz - 3 + zz,
						var8.field_70759_as, var8.field_70125_A);
				if (!player.field_70170_p.field_72995_K) {
					player.field_70170_p.func_72838_d(var8);
				}
			}
		}
		else if(id == 51){
			for (int ka = 0; ka < kazu; ++ka) {
				int xx = player.field_70170_p.field_73012_v.nextInt(6);
				int zz = player.field_70170_p.field_73012_v.nextInt(6);
				EntityTippedArrow var3 = new EntityTippedArrow(player.field_70170_p);
				var3.func_70012_b(px + xx11, py + h + kaku, pz + zz11,
						player.field_70177_z, player.field_70125_A);
				var3.func_70186_c(lock.field_72450_a, locked.field_72448_b + 0.03, lock.field_72449_c, speed, bure);
				if (!player.field_70170_p.field_72995_K) {
					player.field_70170_p.func_72838_d(var3);
				}
			}
		}
		else if(id == 30){
			double x2 = 0;
			double z2 = 0;
			x2 -= MathHelper.func_76126_a(vehicle.rotation * 0.01745329252F) * 2.0;
			z2 += MathHelper.func_76134_b(vehicle.rotation * 0.01745329252F) * 2.0;
			AxisAlignedBB axisalignedbb2 = new AxisAlignedBB(
					player.field_70165_t + x2, player.field_70163_u, player.field_70161_v + z2, 
					player.field_70165_t + x2, player.field_70163_u, player.field_70161_v + z2)
	        		.func_72321_a(3, 5, 3);
			List<Entity> llist = player.field_70170_p.func_72839_b(player,axisalignedbb2);
			if (llist != null) {
				for (int lj = 0; lj < llist.size(); lj++) {
					Entity entity1 = (Entity) llist.get(lj);
					if (entity1.func_70067_L() && entity1 instanceof EntityLivingBase && entity1 != null) {
						if(entity1 != player && entity1 != player.func_184179_bs()){
							entity1.func_70097_a(DamageSource.func_76358_a(player), power);
							
						}
					}
				}
			}
		}
	}

	public void EntityLock(boolean aam) {
		{
			Vec3d looken = player.func_70040_Z();
			Vec3d locken = player.func_70040_Z();
			float d = 100;
			boolean lock = false;
			//if (vehicle.ontick % 2 == 0)
			{
				//List llist = vehicle.world.getEntitiesWithinAABBExcludingEntity(entity, axisalignedbb);
				List<Entity> llist = player.field_70170_p.func_72839_b(player,
						player.func_174813_aQ()
								.func_72321_a(locken.field_72450_a * d, locken.field_72448_b * d, locken.field_72449_c * d)
								.func_186662_g(0.25D));
				if (llist != null) {
					for (int lj = 0; lj < llist.size(); lj++) {

						Entity entity1 = (Entity) llist.get(lj);
						if (entity1.func_70067_L()) {
							boolean flag = vehicle.func_70635_at().func_75522_a(entity1);
							if (entity1 instanceof IMob && entity1 != null && entity1 != player
									&& entity1 != vehicle && flag) {
								BlockPos bp = entity1.field_70170_p.func_175645_m(new BlockPos(entity1.field_70165_t, entity1.field_70163_u, entity1.field_70161_v));
								if(aam && entity1.field_70163_u > bp.func_177956_o() + 5){
									vehicle.mitarget = (EntityLivingBase) entity1;
									lock = true;
									break;
								}else if(entity1.field_70163_u < bp.func_177956_o() + 5){
									vehicle.mitarget = (EntityLivingBase) entity1;
									lock = true;
									break;
								}
							}
						}
					}
				}
			}
			if(lock && vehicle.mitarget !=null){
				if (vehicle.ontick % 3 == 0) {
					//NBTTagCompound nbt = vehicle.mitarget.getEntityData();
					//nbt.setInteger("LockOnTime", 200);
					vehicle.mitarget.func_70690_d(new PotionEffect(MobEffects.field_188423_x, 10, 10));
				}
				if (vehicle.ontick % 10 == 0) {
		//			vehicle.playSound(GVCSoundEvent.sound_lock, 0.4F, 1.0F);
				}
			}
		}
		
	}
}
