package gvclib.entity;

import java.util.List;
import java.util.UUID;
import com.google.common.base.Optional;
import javax.annotation.Nullable;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.SoundEvents;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.network.datasync.DataParameter;
import net.minecraft.network.datasync.DataSerializers;
import net.minecraft.network.datasync.EntityDataManager;
import net.minecraft.server.management.PreYggdrasilConverter;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.datafix.DataFixer;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;


import javax.annotation.Nullable;

import com.google.common.base.Optional;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.SoundEvents;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.network.datasync.DataParameter;
import net.minecraft.network.datasync.DataSerializers;
import net.minecraft.network.datasync.EntityDataManager;
import net.minecraft.server.management.PreYggdrasilConverter;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.datafix.DataFixer;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

public class EntityB_Grapple extends EntityTNTBase {
	
	public EntityPlayer angler;
	protected static final DataParameter<Optional<UUID>> OWNER_UNIQUE_ID 
	= EntityDataManager.<Optional<UUID>>func_187226_a(EntityB_Grapple.class, DataSerializers.field_187203_m);
	
	public EntityB_Grapple(World worldIn) {
		super(worldIn);
	}

	public EntityB_Grapple(World worldIn, EntityLivingBase throwerIn) {
		super(worldIn, throwerIn);
	}

	public EntityB_Grapple(World worldIn, double x, double y, double z) {
		super(worldIn, x, y, z);
	}
	
	public static void func_189662_a(DataFixer p_189662_0_) {
		EntityBBase.func_189661_a(p_189662_0_, "Snowball");
	}
	
	public void setTamedBy(EntityPlayer player)
    {
        this.setOwnerId(player.func_110124_au());
    }
	@Nullable
    public UUID getOwnerId()
    {
        return (UUID)((Optional)this.field_70180_af.func_187225_a(OWNER_UNIQUE_ID)).orNull();
    }

    public void setOwnerId(@Nullable UUID p_184754_1_)
    {
        this.field_70180_af.func_187227_b(OWNER_UNIQUE_ID, Optional.fromNullable(p_184754_1_));
    }
	
	@Nullable
    public EntityLivingBase getOwner()
    {
        try
        {
            UUID uuid = this.getOwnerId();
            return uuid == null ? null : this.field_70170_p.func_152378_a(uuid);
        }
        catch (IllegalArgumentException var2)
        {
            return null;
        }
    }

    public boolean isOwner(EntityLivingBase entityIn)
    {
        return entityIn == this.getOwner();
    }
	
	protected void func_70088_a()
    {
    	//this.dataManager.register(Model, new String("gvclib:textures/entity/ATGrenade.obj"));
        //this.dataManager.register(Tex, new String("gvclib:textures/entity/ATGrenade.png"));
		this.field_70180_af.func_187214_a(Model, new String("hmggvc:textures/entity/grapple.mqo"));
        this.field_70180_af.func_187214_a(Tex, new String("hmggvc:textures/entity/grapple.png"));
        
        this.field_70180_af.func_187214_a(OWNER_UNIQUE_ID, Optional.absent());
    }
	public void func_70014_b(NBTTagCompound compound)
    {
        super.func_70014_b(compound);
        NBTTagList nbttaglist = new NBTTagList();
        if (this.getOwnerId() == null)
        {
            compound.func_74778_a("OwnerUUID", "");
        }
        else
        {
            compound.func_74778_a("OwnerUUID", this.getOwnerId().toString());
        }
    }
	public void func_70037_a(NBTTagCompound compound)
    {
        super.func_70037_a(compound);
        String s;
        if (compound.func_150297_b("OwnerUUID", 8))
        {
            s = compound.func_74779_i("OwnerUUID");
        }
        else
        {
            String s1 = compound.func_74779_i("Owner");
            s = PreYggdrasilConverter.func_187473_a(this.func_184102_h(), s1);
        }

        if (!s.isEmpty())
        {
            try
            {
                this.setOwnerId(UUID.fromString(s));
            }
            catch (Throwable var4)
            {
            }
        }
    }
	
	public boolean hit = false;
	 private int xTile;
	    private int yTile;
	    private int zTile;
	    private Block inTile;
	    private int inData;
	    private Entity targeten;
	    
	    public int playerid;
	    
	    public boolean canmove = false;
	
	    public void func_70071_h_()
	    {
	    	this.field_70142_S = this.field_70165_t;
	        this.field_70137_T = this.field_70163_u;
	        this.field_70136_U = this.field_70161_v;
	        super.func_70071_h_();

	        //this.worldObj.spawnParticle(EnumParticleTypes.CLOUD, this.posX, this.posY + 0D, this.posZ, 0.0D, 0.0D, 0.0D, new int[0]);
	        
	        /*if(this.getThrower() == null || this.angler == null){
	        	//if(!this.world.isRemote)
	        	{
	        	this.setDead();
	        	}
	        }*/
	        //
	        if (this.throwableShake > 0)
	        {
	            --this.throwableShake;
	        }

	        if (this.inGround)
	        {
	            if (this.field_70170_p.func_180495_p(new BlockPos(this.xTile, this.yTile, this.zTile)).func_177230_c() == this.inTile)
	            {
	                ++this.ticksInGround;

	                if (this.ticksInGround == 1200)
	                {
	                    this.func_70106_y();
	                }

	                return;
	            }
	            this.field_70122_E = true;
	            this.inGround = false;
	            this.field_70159_w *= (double)(this.field_70146_Z.nextFloat() * 0.2F);
	            this.field_70181_x *= (double)(this.field_70146_Z.nextFloat() * 0.2F);
	            this.field_70179_y *= (double)(this.field_70146_Z.nextFloat() * 0.2F);
	            this.ticksInGround = 0;
	            this.ticksInAir = 0;
	        }
	        else
	        {
	        	if(hit){
	            	List llist = this.field_70170_p.func_72839_b(this, this.func_174813_aQ()
	                		.func_72321_a(this.field_70159_w, this.field_70181_x, this.field_70179_y).func_186662_g(100.0D));
	                EntityLivingBase entitylivingbase = this.getThrower();
	                if(llist!=null){
	                    for (int lj = 0; lj < llist.size(); lj++) {
	                    	
	                    	Entity entity1 = (Entity)llist.get(lj);
	                    	if (entity1.func_70067_L() && (entity1 != entitylivingbase))
	                        {
	                    		if (entity1 != null)
	                            {
	                    			if (entity1 instanceof EntityLivingBase && entity1 == this.targeten && entity1.func_145782_y() == this.inData)
	                                {
	                    				double var4 = entity1.field_70165_t - this.field_70165_t;
	    								double var6 = (entity1.field_70163_u + (double) entity1.func_70047_e())- this.field_70163_u;
	    								double var8 = entity1.field_70161_v - this.field_70161_v;
	    								this.field_70159_w = (var4) * 0.03D * (time/10);
	                                    this.field_70181_x = (var6) * 0.03D * (time/10);
	                                    this.field_70179_y = (var8) * 0.03D * (time/10);
	                                    break;
	                                }
	                            }
	                        }
	                    }
	                }
	            }
	            ++this.ticksInAir;
	        }

	        Vec3d vec3d = new Vec3d(this.field_70165_t, this.field_70163_u, this.field_70161_v);
	        Vec3d vec3d1 = new Vec3d(this.field_70165_t + this.field_70159_w, this.field_70163_u + this.field_70181_x, this.field_70161_v + this.field_70179_y);
	        RayTraceResult raytraceresult = this.field_70170_p.func_72933_a(vec3d, vec3d1);
	        vec3d = new Vec3d(this.field_70165_t, this.field_70163_u, this.field_70161_v);
	        vec3d1 = new Vec3d(this.field_70165_t + this.field_70159_w, this.field_70163_u + this.field_70181_x, this.field_70161_v + this.field_70179_y);

	        if (raytraceresult != null)
	        {
	            vec3d1 = new Vec3d(raytraceresult.field_72307_f.field_72450_a, raytraceresult.field_72307_f.field_72448_b, raytraceresult.field_72307_f.field_72449_c);
	        }

	        Entity entity = null;
	        List<Entity> list = this.field_70170_p.func_72839_b(this, this.func_174813_aQ().func_72321_a(this.field_70159_w, this.field_70181_x, this.field_70179_y).func_186662_g(1.0D));
	        double d0 = 0.0D;
	        boolean flag = false;

	        for (int i = 0; i < list.size(); ++i)
	        {
	            Entity entity1 = (Entity)list.get(i);

	            if (entity1.func_70067_L())
	            {
	                if (entity1 == this.ignoreEntity)
	                {
	                    flag = true;
	                }
	                else if (this.field_70173_aa < 2 && this.ignoreEntity == null)
	                {
	                    this.ignoreEntity = entity1;
	                    flag = true;
	                }
	                else
	                {
	                    flag = false;
	                    AxisAlignedBB axisalignedbb = entity1.func_174813_aQ().func_186662_g(0.30000001192092896D);
	                    RayTraceResult raytraceresult1 = axisalignedbb.func_72327_a(vec3d, vec3d1);

	                    if (raytraceresult1 != null)
	                    {
	                        double d1 = vec3d.func_72436_e(raytraceresult1.field_72307_f);

	                        if (d1 < d0 || d0 == 0.0D)
	                        {
	                            entity = entity1;
	                            d0 = d1;
	                        }
	                    }
	                }
	            }
	        }

	        if (this.ignoreEntity != null)
	        {
	            if (flag)
	            {
	                this.ignoreTime = 2;
	            }
	            else if (this.ignoreTime-- <= 0)
	            {
	                this.ignoreEntity = null;
	            }
	        }

	        if (entity != null)
	        {
	            raytraceresult = new RayTraceResult(entity);
	        }
	        if (raytraceresult != null && raytraceresult.field_72308_g instanceof EntityPlayer)
            {
                EntityPlayer entityplayer = (EntityPlayer)raytraceresult.field_72308_g;

                if (this.getThrower() instanceof EntityPlayer && !((EntityPlayer)this.getThrower()).func_96122_a(entityplayer))
                {
                    raytraceresult = null;
                }
            }
            if (raytraceresult != null && raytraceresult.field_72308_g instanceof EntityLivingBase)
            {
            	EntityLivingBase en = (EntityLivingBase) raytraceresult.field_72308_g;
            	if(this.getThrower() != null && en.func_184179_bs() == this.getThrower()) {
            		raytraceresult = null;
            	}
            	for(int m = 0; m < en.func_184188_bt().size(); ++m) {
            		if(this.getThrower() != null && en.func_184188_bt().get(m) == this.getThrower()) {
                		raytraceresult = null;
                	}
            	}
            	
            }
	        if (raytraceresult != null)
	        {
	            if (raytraceresult.field_72313_a == RayTraceResult.Type.BLOCK && this.field_70170_p.func_180495_p(raytraceresult.func_178782_a()).func_177230_c() == Blocks.field_150427_aO)
	            {
	                this.func_181015_d(raytraceresult.func_178782_a());
	            }
	            //else if(raytraceresult.entityHit != this.friend && raytraceresult.entityHit != this.getThrower())
	            else
	            {
	              //  if(!net.minecraftforge.common.ForgeHooks.onThrowableImpact(this, raytraceresult))
	                this.onImpact(raytraceresult);
	            }
	        }

	        this.field_70165_t += this.field_70159_w;
	        this.field_70163_u += this.field_70181_x;
	        this.field_70161_v += this.field_70179_y;
	        float f = MathHelper.func_76133_a(this.field_70159_w * this.field_70159_w + this.field_70179_y * this.field_70179_y);
	        this.field_70177_z = (float)(MathHelper.func_181159_b(this.field_70159_w, this.field_70179_y) * (180D / Math.PI));

	        for (this.field_70125_A = (float)(MathHelper.func_181159_b(this.field_70181_x, (double)f) * (180D / Math.PI)); this.field_70125_A - this.field_70127_C < -180.0F; this.field_70127_C -= 360.0F)
	        {
	            ;
	        }

	        while (this.field_70125_A - this.field_70127_C >= 180.0F)
	        {
	            this.field_70127_C += 360.0F;
	        }

	        while (this.field_70177_z - this.field_70126_B < -180.0F)
	        {
	            this.field_70126_B -= 360.0F;
	        }

	        while (this.field_70177_z - this.field_70126_B >= 180.0F)
	        {
	            this.field_70126_B += 360.0F;
	        }

	        this.field_70125_A = this.field_70127_C + (this.field_70125_A - this.field_70127_C) * 0.2F;
	        this.field_70177_z = this.field_70126_B + (this.field_70177_z - this.field_70126_B) * 0.2F;
	        float f1 = 0.99F;
	        float f2 = this.getGravityVelocity();

	        if (this.func_70090_H())
	        {
	            for (int j = 0; j < 4; ++j)
	            {
	                float f3 = 0.25F;
	                this.field_70170_p.func_175688_a(EnumParticleTypes.WATER_BUBBLE, this.field_70165_t - this.field_70159_w * 0.25D, this.field_70163_u - this.field_70181_x * 0.25D, this.field_70161_v - this.field_70179_y * 0.25D, this.field_70159_w, this.field_70181_x, this.field_70179_y, new int[0]);
	            }

	            f1 = 0.8F;
	        }

	        this.field_70159_w *= (double)f1;
	        this.field_70181_x *= (double)f1;
	        this.field_70179_y *= (double)f1;

	        if (!this.func_189652_ae())
	        {
	            this.field_70181_x -= (double)f2 - this.gra;
	        }

	        this.func_70107_b(this.field_70165_t, this.field_70163_u, this.field_70161_v);
	        
	        ++time;
	        if(time > 2400){
	        	if(!this.field_70170_p.field_72995_K){
	        	this.func_70106_y();
	        	}
	        }/**/
	        if(time > 100 && !canmove){
	        	if(!this.field_70170_p.field_72995_K){
	        	this.func_70106_y();
	        	}
	        }
	    }
		/**
		 * Called when this EntityThrowable hits a block or entity.
		 */
		protected void onImpact(RayTraceResult result) {
			canmove = true;
			Entity entity = result.field_72308_g;
			{
				this.func_184185_a(SoundEvents.field_187731_t, 1.0F, 1.2F / (this.field_70146_Z.nextFloat() * 0.2F + 0.9F));
				if (result.field_72308_g != null) {
					this.targeten = result.field_72308_g;
	    			this.inData = result.field_72308_g.func_145782_y();
	    			this.hit = true;
				}else{
					BlockPos blockpos = result.func_178782_a();
	    			if(blockpos != null)
	    			{
	    				this.xTile = blockpos.func_177958_n();
	                    this.yTile = blockpos.func_177956_o();
	                    this.zTile = blockpos.func_177952_p();
	                    IBlockState iblockstate = this.field_70170_p.func_180495_p(blockpos);
	                    this.inTile = iblockstate.func_177230_c();
	                    this.inData = this.inTile.func_176201_c(iblockstate);
	                    this.field_70159_w = (double)((float)(result.field_72307_f.field_72450_a - this.field_70165_t));
	                    this.field_70181_x = (double)((float)(result.field_72307_f.field_72448_b - this.field_70163_u));
	                    this.field_70179_y = (double)((float)(result.field_72307_f.field_72449_c - this.field_70161_v));
	                    float f2 = MathHelper.func_76133_a(this.field_70159_w * this.field_70159_w + this.field_70181_x * this.field_70181_x + this.field_70179_y * this.field_70179_y);
	                    this.field_70165_t -= this.field_70159_w / (double)f2 * 0.05000000074505806D;
	                    this.field_70163_u -= this.field_70181_x / (double)f2 * 0.05000000074505806D;
	                    this.field_70161_v -= this.field_70179_y / (double)f2 * 0.05000000074505806D;
	                    //this.playSound(SoundEvents.ENTITY_ARROW_HIT, 1.0F, 1.2F / (this.rand.nextFloat() * 0.2F + 0.9F));
	                    this.inGround = true;

	                    if (iblockstate.func_185904_a() != Material.field_151579_a)
	                    {
	                        this.inTile.func_180634_a(this.field_70170_p, blockpos, iblockstate, this);
	                    }
	        	        
	    			}
				}
			
			}
		}

		@Override
		public void func_70186_c(double x, double y, double z, float velocity, float inaccuracy) {
			// TODO 自動生成されたメソッド・スタブ
			
		}
	
}
