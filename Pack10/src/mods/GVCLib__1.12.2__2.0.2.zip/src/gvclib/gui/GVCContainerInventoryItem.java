package gvclib.gui;
 

import gvclib.item.ItemGunBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.Slot;
import net.minecraft.item.ItemStack;
 
public class GVCContainerInventoryItem extends Container
{
    private GVCInventoryItem inventory;
 
    private IInventory holderInventory;
    
    public GVCContainerInventoryItem(InventoryPlayer inventoryPlayer, ItemStack itemstack)
    {
    	inventory = new GVCInventoryItem(inventoryPlayer, itemstack);
        inventory.func_174889_b(inventoryPlayer.field_70458_d);
        if(itemstack.func_77973_b() instanceof  ItemGunBase){
        	ItemGunBase gun = (ItemGunBase) itemstack.func_77973_b();
            {
                //this.addSlotToContainer(new Slot(inventory, k + j * 9, 8 + k * 18, 18 + j * 18));
            	if(gun.canuse_sight)this.func_75146_a(new SlotGun(inventory, 1, 8 + 5 * 18, 18 + 1 * 18, itemstack));
            	if(gun.canuse_light)this.func_75146_a(new SlotGun(inventory, 2, 8 + 2 * 18, 18 + 1 * 18, itemstack));
            	if(gun.canuse_muss)this.func_75146_a(new SlotGun(inventory, 3, 8 + 0 * 18, 18 + 4 * 18, itemstack));
            	if(gun.canuse_grip)this.func_75146_a(new SlotGun(inventory, 4, 8 + 2 * 18, 18 + 5 * 18, itemstack));
            	
            	this.func_75146_a(new SlotGun(inventory, 5, 8 + 7 * 18, 18 + 5 * 18, itemstack));
            }
        }
 
        int i = 2 * 18 + 1;
        for (int j = 0; j < 3; ++j)
        {
            for (int k = 0; k < 9; ++k)
            {
                this.func_75146_a(new GVCSlotInventoryItem(inventoryPlayer, k + j * 9 + 9, 8 + k * 18, 103 + j * 18 + i));
            }
        }
 
        for (int j = 0; j < 9; ++j)
        {
            this.func_75146_a(new GVCSlotInventoryItem(inventoryPlayer, j, 8 + j * 18, 161 + i));
        }

        //System.out.println(String.format("open"));
    }
 

    /**
     * Determines whether supplied player can use this container
     */
    public boolean func_75145_c(EntityPlayer playerIn)
    {
        return this.inventory.func_70300_a(playerIn);
    }
 
    @Override
    public ItemStack func_82846_b(EntityPlayer p_82846_1_, int p_82846_2_)
    {
    	 ItemStack itemstack = ItemStack.field_190927_a;
        Slot slot = (Slot)this.field_75151_b.get(p_82846_2_);
 
        if (slot != null && slot.func_75216_d())
        {
            ItemStack itemstack1 = slot.func_75211_c();
            itemstack = itemstack1.func_77946_l();
 
            if (p_82846_2_ < this.inventory.func_70302_i_())
            {
                if (!this.func_75135_a(itemstack1, this.inventory.func_70302_i_(), this.field_75151_b.size(), true))
                {
                	return ItemStack.field_190927_a;
                }
            }
            //シフトクリック時に、このアイテムだったら動かさない。
            else if(slot.func_75211_c() != ItemStack.field_190927_a && slot.func_75211_c().func_77973_b()instanceof ItemGunBase)
            {
            	return ItemStack.field_190927_a;
            }
            else if (!this.func_75135_a(itemstack1, 0, this.inventory.func_70302_i_(), false))
            {
            	return ItemStack.field_190927_a;
            }
            if (itemstack1.func_190916_E() == 0)
            {
                slot.func_75215_d(ItemStack.field_190927_a);
            }
            else
            {
                slot.func_75218_e();
            }
        }
 
        return itemstack;
    }
 
    /*
        Containerを閉じるときに呼ばれる
     */
    @Override
    public void func_75134_a(EntityPlayer p_75134_1_)
    {
        super.func_75134_a(p_75134_1_);
        this.inventory.func_174886_c(p_75134_1_);
    }
    
    /**
     * Return this chest container's lower chest inventory.
     */
    public IInventory getLowerChestInventory()
    {
        return this.inventory;
    }
}
