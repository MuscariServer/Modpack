package gvclib.gui;

import java.io.IOException;
import gvclib.entity.trader.EntityNPCBase;
import gvclib.network.GVCLMessageKeyPressed;
import gvclib.network.GVCLPacketHandler;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderItem;
import net.minecraft.client.renderer.texture.TextureMap;
import net.minecraft.client.resources.I18n;
import net.minecraft.inventory.IInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import org.lwjgl.opengl.GL11;


import org.lwjgl.opengl.GL11;

import gvclib.entity.trader.EntityNPCBase;
import gvclib.network.GVCLMessageKeyPressed;
import gvclib.network.GVCLPacketHandler;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderItem;
import net.minecraft.client.renderer.texture.TextureMap;
import net.minecraft.client.resources.I18n;
import net.minecraft.inventory.IInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
public class TraderGuiInventoryItem extends GuiContainer
{
    private static final ResourceLocation HORSE_GUI_TEXTURES = new ResourceLocation("gvclib:textures/gui/trader.png");
    /** The player inventory bound to this GUI. */
    private final IInventory playerInventory;
    /** The horse inventory bound to this GUI. */
    private final IInventory horseInventory;
    /** The EntityHorse whose inventory is currently being accessed. */
    private final EntityNPCBase trader;
    /** The mouse x-position recorded during the last rendered frame. */
    private float mousePosx;
    /** The mouse y-position recorded during the last renderered frame. */
    private float mousePosY;

    private GuiButton next;
    private GuiButton back;
    
    private GuiButton next2;
    private GuiButton back2;
    
    public TraderGuiInventoryItem(IInventory playerInv, IInventory horseInv, EntityNPCBase horse)
    {
        super(new TraderContainerInventoryItem(playerInv, horseInv, horse, Minecraft.func_71410_x().field_71439_g));
        this.playerInventory = playerInv;
        this.horseInventory = horseInv;
        this.trader = horse;
        this.field_146291_p = false;
    }

    public void func_73866_w_()
    {
    	super.func_73866_w_();
    	this.next = this.func_189646_b(new GuiButton(0, this.field_146294_l / 2 + 30, this.field_146295_m / 2 - 10, 20, 10, I18n.func_135052_a("next")));
    	this.back = this.func_189646_b(new GuiButton(1, this.field_146294_l / 2 - 30, this.field_146295_m / 2 - 10, 20, 10, I18n.func_135052_a("back")));
    	this.next2 = this.func_189646_b(new GuiButton(2, this.field_146294_l / 2 + 90, this.field_146295_m / 2 - 80, 20, 10, I18n.func_135052_a("next")));
    	this.back2 = this.func_189646_b(new GuiButton(3, this.field_146294_l / 2 + 90, this.field_146295_m / 2 - 70, 20, 10, I18n.func_135052_a("back")));
    }
    
    /**
     * Draw the foreground layer for the GuiContainer (everything in front of the items)
     */
    protected void func_146979_b(int mouseX, int mouseY)
    {
        this.field_146289_q.func_78276_b(trader.func_95999_t(), 8, 6, 4210752);
        this.field_146289_q.func_78276_b("page:"+String.format("%1$3d", trader.sell_now_id), 85, 75, 4210752);
        //this.fontRenderer.drawString(this.playerInventory.getDisplayName().getUnformattedText(), 8, this.ySize - 96 + 2, 4210752);
    }

	protected void func_146284_a(GuiButton button) throws IOException {
		if (button.field_146127_k == 0) {
			//GVCLPacketHandler.INSTANCE2.sendToAll(new GVCLClientMessageKeyPressed(1500, trader.getEntityId()));
			if (trader.sell_now_id < trader.sell_page - 1) {
				++trader.sell_now_id;
			}
			int page = 10 * trader.sell_now_id;
			for (int x = 0; x < 9; ++x) {
				trader.hand[0 + x + page] = false;
			}
			GVCLPacketHandler.INSTANCE.sendToServer(new GVCLMessageKeyPressed(1500, trader.func_145782_y()));
		}
		if (button.field_146127_k == 1) {
			//GVCLPacketHandler.INSTANCE2.sendToAll(new GVCLClientMessageKeyPressed(1501, trader.getEntityId()));
			if (trader.sell_now_id > 0) {
				--trader.sell_now_id;
			}
			int page = 10 * trader.sell_now_id;
			for (int x = 0; x < 9; ++x) {
				trader.hand[0 + x + page] = false;
			}
			GVCLPacketHandler.INSTANCE.sendToServer(new GVCLMessageKeyPressed(1501, trader.func_145782_y()));
		}
		if (button.field_146127_k == 2) {
			//GVCLPacketHandler.INSTANCE2.sendToAll(new GVCLClientMessageKeyPressed(1502, trader.getEntityId()));
			if (trader.buy_now_id < trader.buy_page - 1) {
				++trader.buy_now_id;
			}
			GVCLPacketHandler.INSTANCE.sendToServer(new GVCLMessageKeyPressed(1502, trader.func_145782_y()));
		}
		if (button.field_146127_k == 3) {
			//GVCLPacketHandler.INSTANCE2.sendToAll(new GVCLClientMessageKeyPressed(1503, trader.getEntityId()));
			if (trader.buy_now_id > 0) {
				--trader.buy_now_id;
			}
			GVCLPacketHandler.INSTANCE.sendToServer(new GVCLMessageKeyPressed(1503, trader.func_145782_y()));
		}
	}
    
    /**
     * Draws the background layer of this container (behind the items).
     */
    protected void func_146976_a(float partialTicks, int mouseX, int mouseY)
    {
        GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
        this.field_146297_k.func_110434_K().func_110577_a(HORSE_GUI_TEXTURES);
        int i = (this.field_146294_l - this.field_146999_f) / 2;
        int j = (this.field_146295_m - this.field_147000_g) / 2;
        //this.drawTexturedModalRect(i, j, 0, 0, this.xSize, this.ySize);
        this.func_73729_b(i, j, 0, 0, 220, 212);

        FontRenderer fontReader = field_146297_k.field_71466_p;
		field_146297_k.field_71466_p.func_78264_a(field_146297_k.func_152349_b());
        GL11.glPushMatrix();
		GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
		GlStateManager.func_187428_a(GlStateManager.SourceFactor.SRC_ALPHA,
				GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE,
				GlStateManager.DestFactor.ZERO);
		field_146297_k.field_71446_o.func_110577_a(TextureMap.field_110575_b);
		{
			RenderItem renderitem = field_146297_k.func_175599_af();
			int page = 10 * trader.sell_now_id;
			for(int ii = 0; ii < 9; ++ii) {
				ItemStack item = new ItemStack(trader.sell[ii + page], trader.sell_size[ii + page], trader.sell_id[ii + page]);
				int x = 0;
				int y = 0;
				if(ii < 3) {
					x = 0;
					y = ii;
				}
				else if(ii >= 3 && ii < 6) {
					x = 1;
					y = ii - 3;
				}else {
					x = 2;
					y = ii - 6;
				}
				if (!item.func_190926_b()) {
					GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.4F);
					renderitem.func_175042_a(item, i + 80 + (x * 36), j + 17 + (y * 18));//62/18
					GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
				}
				{
					int s = trader.sell_size[ii + page];
					String d2 = String.format("%1$3d", s);
					if(s > 0)
					fontReader.func_78276_b(d2,  i + 74 + (x * 36), j + 30 + (y * 18), 0xFFFFFF);
				}
				{
					int s = trader.sellm[ii + page];
					String d2 = String.format("%1$3d", s);
					if(s > 0)
					fontReader.func_78276_b(d2,  i + 82 + (x * 36), j + 30 + (y * 18), 0X00FF00);
				}
				
			}
			/*for (int x = 0; x < 3; ++x) {
				for (int y = 0; y < 3; ++y) {
					ItemStack item = new ItemStack(trader.sell[x + y]);
					if (!item.isEmpty()) {
						GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.4F);
						renderitem.renderItemIntoGUI(item, i + 62 + (x * 36), j + 18 + (y * 18));
						GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
					}
				}
			}
			for (int x = 0; x < 3; ++x) {
				for (int y = 0; y < 3; ++y) {
					int s = trader.sellm[x + y];
					String d2 = String.format("%1$3d", s);
					fontReader.drawString(d2,  i + 80 + (x * 36), j + 26 + (y * 18), 0xFFFFFF);
				}
			}*/
			
		}
		{
			GL11.glPushMatrix();
			GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
			GlStateManager.func_187428_a(GlStateManager.SourceFactor.SRC_ALPHA,
					GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE,
					GlStateManager.DestFactor.ZERO);
			field_146297_k.field_71446_o.func_110577_a(TextureMap.field_110575_b);
			RenderItem renderitem = field_146297_k.func_175599_af();
			int x = (this.field_146294_l - this.field_146999_f) / 2;
			int y = (this.field_146295_m - this.field_147000_g) / 2;
			int page = 10 * trader.buy_now_id;
			for(int ite = 0; ite < 9; ++ite) {
				ItemStack items = new ItemStack(trader.buy[0 + ite + page]);
				if(!items.func_190926_b()) {
					renderitem.func_175042_a(items, x + 180, y + 25 + (20 * ite));
					fontReader.func_78276_b(String.format("%1$3d", trader.buy_size[0 + ite + page]), x + 195, y + 35  + (20 * ite), 0X00FF00);
					fontReader.func_78276_b(String.format("%1$3d", trader.buym[0 + ite + page]), x + 187, y + 35  + (20 * ite), 0xFFFFFF);
				}
			}
			GL11.glPopMatrix();
		}
		GL11.glPopMatrix();
    }
    
    /**
     * Draws the screen and all the components in it.
     */
    public void func_73863_a(int mouseX, int mouseY, float partialTicks)
    {
        this.func_146276_q_();
        this.mousePosx = (float)mouseX;
        this.mousePosY = (float)mouseY;
        super.func_73863_a(mouseX, mouseY, partialTicks);
        this.func_191948_b(mouseX, mouseY);
    }
}
