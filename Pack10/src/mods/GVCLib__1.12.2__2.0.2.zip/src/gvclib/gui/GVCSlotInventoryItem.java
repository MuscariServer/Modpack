package gvclib.gui;
 
import gvclib.item.ItemAttachment;
import gvclib.item.ItemGunBase;
import gvclib.item.ItemGun_AR;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.Slot;
 
public class GVCSlotInventoryItem extends Slot
{
    public GVCSlotInventoryItem(IInventory p_i1824_1_, int p_i1824_2_, int p_i1824_3_, int p_i1824_4_)
    {
        super(p_i1824_1_, p_i1824_2_, p_i1824_3_, p_i1824_4_);
    }
 
    /*
        このアイテムは動かせない、つかめないようにする。
     */
    @Override
    public boolean func_82869_a(EntityPlayer entityplayer)
    {
    	/*if(!(getHasStack() && getStack().getItem()instanceof HMGItemGun_SG)){
    		return !(getHasStack() && getStack().getItem()instanceof HMGItemGunBase);
    	}else if(!(getHasStack() && getStack().getItem()instanceof HMGItemGun_SG)){
    		return !(getHasStack() && getStack().getItem()instanceof HMGItemGunBase);
    	}else{
    		return !(getHasStack() && getStack().getItem()instanceof HMGItemGunBase);
    	}*/
    	
    	//return !(getHasStack() && getStack().getItem()instanceof ItemGun_AR);
        boolean flag = false;
        if(func_75216_d() && func_75211_c().func_77973_b() instanceof ItemGunBase) {
        	ItemGunBase gun = (ItemGunBase) func_75211_c().func_77973_b();
        	if(gun.gun_can_set_underbarrel && entityplayer.func_184614_ca() != func_75211_c()) {
        		flag = true;
        	}
        }
        if(func_75216_d() && func_75211_c().func_77973_b() instanceof ItemAttachment) {
        	flag = true;
        }
    	
    	return flag;
    }
 
}
