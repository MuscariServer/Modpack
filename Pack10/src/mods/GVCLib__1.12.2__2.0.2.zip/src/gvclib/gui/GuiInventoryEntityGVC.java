package gvclib.gui;

import org.lwjgl.opengl.GL11;
import gvclib.block.tile.TileEntityInvasion;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.inventory.IInventory;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;


import gvclib.block.tile.TileEntityInvasion;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.inventory.IInventory;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
public class GuiInventoryEntityGVC extends GuiContainer
{
	//private static final ResourceLocation field_147017_u = new ResourceLocation("textures/gui/container/generic_54.png");
	private static final ResourceLocation texture = new ResourceLocation("gvclib:textures/gui/inv.png");
	//private static final ResourceLocation texturepara = new ResourceLocation("gvcrbattlemachine:textures/gui/robogui_para.png");
	 private final InventoryPlayer playerInventory;
	 private final IInventory tileFurnace;
    private TileEntityInvasion tile;
    private int inventoryRows;
    private static final String __OBFID = "CL_00000760";
    private boolean tex = false;
    
    /** The old x position of the mouse pointer */
    private float oldMouseX;
    /** The old y position of the mouse pointer */
    private float oldMouseY;

    public GuiInventoryEntityGVC(InventoryPlayer player, IInventory furnaceInv, TileEntityInvasion t)
    {
        super(new ContainerInventoryEntityGVC(player, t));
        this.playerInventory = player;
        this.tileFurnace = furnaceInv;
        this.tile = t;
    }
    
    /**
     * Draws the screen and all the components in it.
     */
    public void func_73863_a(int mouseX, int mouseY, float partialTicks)
    {
        this.func_146276_q_();
        super.func_73863_a(mouseX, mouseY, partialTicks);
        this.func_191948_b(mouseX, mouseY);
    }

    /**
     * Draw the foreground layer for the GuiContainer (everything in front of the items)
     */
    protected void func_146979_b(int mouseX, int mouseY)
    {
        String s = this.tileFurnace.func_145748_c_().func_150260_c();
        this.field_146289_q.func_78276_b(s, this.field_146999_f / 2 - this.field_146289_q.func_78256_a(s) / 2, 6, 4210752);
        this.field_146289_q.func_78276_b(this.playerInventory.func_145748_c_().func_150260_c(), 8, this.field_147000_g - 96 + 2, 4210752);
    }

    protected void func_146976_a(float p_146976_1_, int p_146976_2_, int p_146976_3_)
    {
    	GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
        this.field_146297_k.func_110434_K().func_110577_a(texture);
        int i = this.field_147003_i;
        int j = this.field_147009_r;
        int x = (this.field_146294_l - this.field_146999_f) / 2;
        int y = (this.field_146295_m - this.field_147000_g) / 2;
        int k = x + (this.field_146999_f / 2);
        int l = y + (this.field_147000_g / 2);
        this.func_73729_b(x, y, 0, 0, this.field_146999_f, this.field_147000_g);
        {
        	//String c = String.valueOf(TileEntityInvasion.getClientRange(tile));
        	String c = String.valueOf(TileEntityInvasion.getClientRange(tile));
        	this.field_146289_q.func_78276_b("SpwanRange : " + c, x + 80, y + 20, 4210752);
        	String d = String.valueOf(TileEntityInvasion.getClientLevel(tile));
        	this.field_146289_q.func_78276_b("Wave : " + d, x + 80, y + 30, 4210752);
        	String hp = String.valueOf(100 - TileEntityInvasion.getClientHP(tile));
        	this.field_146289_q.func_78276_b("HP : " + hp, x + 80, y + 40, 4210752);
        	
        	String time = String.valueOf((this.tile.spawntime - TileEntityInvasion.getClientTick(tile)) / 20);
        	this.field_146289_q.func_78276_b("Time : " + time, x + 80, y + 50, 4210752);
        }
        
        
        GL11.glPushMatrix();//glstart
        GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
        GlStateManager.func_179152_a(0.75F, 0.75F, 0.75F);
        //drawEntityOnScreen(i + 110, j + 170, 30, (float)(i + 51) - this.oldMouseX, (float)(j + 75 - 50) - this.oldMouseY, field_147034_x);
        GL11.glPopMatrix();//glend
    }
    
    
    @Override
    protected void func_146284_a(GuiButton button) {
    	
    }
    
    /**
     * Draws an entity on the screen looking toward the cursor.
     */
    public static void drawEntityOnScreen(int posX, int posY, int scale, float mouseX, float mouseY, EntityLivingBase ent)
    {
        GlStateManager.func_179142_g();
        GlStateManager.func_179094_E();
        GlStateManager.func_179109_b((float)posX, (float)posY, 50.0F);
        GlStateManager.func_179152_a((float)(-scale), (float)scale, (float)scale);
        GlStateManager.func_179114_b(180.0F, 0.0F, 0.0F, 1.0F);
        float f = ent.field_70761_aq;
        float f1 = ent.field_70177_z;
        float f2 = ent.field_70125_A;
        float f3 = ent.field_70758_at;
        float f4 = ent.field_70759_as;
        GlStateManager.func_179114_b(135.0F, 0.0F, 1.0F, 0.0F);
        RenderHelper.func_74519_b();
        GlStateManager.func_179114_b(-135.0F, 0.0F, 1.0F, 0.0F);
        GlStateManager.func_179114_b(-((float)Math.atan((double)(mouseY / 40.0F))) * 20.0F, 1.0F, 0.0F, 0.0F);
        ent.field_70761_aq = (float)Math.atan((double)(mouseX / 40.0F)) * 20.0F;
        ent.field_70177_z = (float)Math.atan((double)(mouseX / 40.0F)) * 40.0F;
        ent.field_70125_A = -((float)Math.atan((double)(mouseY / 40.0F))) * 20.0F;
        ent.field_70759_as = ent.field_70177_z;
        ent.field_70758_at = ent.field_70177_z;
        GlStateManager.func_179109_b(0.0F, 0.0F, 0.0F);
        RenderManager rendermanager = Minecraft.func_71410_x().func_175598_ae();
        rendermanager.func_178631_a(180.0F);
        rendermanager.func_178633_a(false);
        rendermanager.func_188391_a(ent, 0.0D, 0.0D, 0.0D, 0.0F, 1.0F, false);
        rendermanager.func_178633_a(true);
        ent.field_70761_aq = f;
        ent.field_70177_z = f1;
        ent.field_70125_A = f2;
        ent.field_70758_at = f3;
        ent.field_70759_as = f4;
        GlStateManager.func_179121_F();
        RenderHelper.func_74518_a();
        GlStateManager.func_179101_C();
        GlStateManager.func_179138_g(OpenGlHelper.field_77476_b);
        GlStateManager.func_179090_x();
        GlStateManager.func_179138_g(OpenGlHelper.field_77478_a);
    }
}
