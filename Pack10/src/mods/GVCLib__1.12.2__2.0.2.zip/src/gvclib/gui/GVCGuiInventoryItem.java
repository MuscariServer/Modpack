package gvclib.gui;
 
import org.lwjgl.opengl.GL11;
import gvclib.event.gun.Layermat;
import gvclib.item.ItemGunBase;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ResourceLocation;


import gvclib.event.gun.Layermat;
import gvclib.item.ItemGunBase;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ResourceLocation;
 
public class GVCGuiInventoryItem extends GuiContainer
{
    //private static final ResourceLocation texture = new ResourceLocation("textures/gui/container/generic_54.png");
    private static final ResourceLocation texture = new ResourceLocation("gvclib:textures/gui/ar.png");
    private static EntityPlayer player;
    /** The mouse x-position recorded during the last rendered frame. */
    private float mousePosx;
    /** The mouse y-position recorded during the last renderered frame. */
    private float mousePosY;
 
    public GVCGuiInventoryItem(InventoryPlayer inventoryPlayer, ItemStack itemstack)
    {
        super(new GVCContainerInventoryItem(inventoryPlayer, itemstack));
        this.field_147000_g = 222;
        player = inventoryPlayer.field_70458_d;
    }

    /*public void initGui() {
    	super.initGui();
    	int i = width  - xSize >> 1;
		int j = height - ySize >> 1;
        this.buttonList.add(new GuiButton(0, i + 175, j + 0, 50, 20 , "Parameters"));
		//this.buttonList.add(new GuiButton(0, i + 175, j + 0, 50, 20 , "battlemachine:bm.parameters"));
        //this.buttonList.add(new GuiButton(1, i + 210, j + 10, 30, 20 , "Button 1"));
    }
    
    @Override
    protected void actionPerformed(GuiButton button) {
    	if (button.id == 0) {
    		//GVCLPacketHandler.INSTANCE2.sendToServer(new GVCLMessageKeyPressed(1110));
    		//mod_GVCLib.proxy.dropItem(0, player);
    		/*if(player != null && !player.world.isRemote) {
    			player.entityDropItem(new ItemStack(Items.APPLE), 1);
        	}//
    	}
    }*/
    
	/*
        ChestとかInventoryとか文字を描画する
     */
    @Override
    protected void func_146979_b(int x, int p_146979_2_)
    {
    	
        //描画する文字, X, Y, 色
        this.field_146289_q.func_78276_b("AR Attachment", 8, 6, 4210752);
        this.field_146289_q.func_78276_b("Inventory", 8, this.field_147000_g - 96 + 2, 4210752);
    }
 
    /*
        背景の描画
     */
    @Override
    protected void func_146976_a(float p_146976_1_, int p_146976_2_, int p_146976_3_)
    {
        GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
        this.field_146297_k.func_110434_K().func_110577_a(texture);
        int k = (this.field_146294_l - this.field_146999_f) / 2;
        int l = (this.field_146295_m - this.field_147000_g) / 2;
        this.func_73729_b(k, l, 0, 0, this.field_146999_f, this.field_147000_g);
        
        GL11.glPushMatrix();
		//GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
		if(this.player != null){
			ItemStack itemstack = player.func_184614_ca();
			if (!itemstack.func_190926_b() && itemstack.func_77973_b() instanceof ItemGunBase) {//item
				ItemGunBase gun = (ItemGunBase) itemstack.func_77973_b();
				if(!gun.render_sight)this.func_73729_b(k + 98, l + 36, 176, 0, 16, 16);
				if(!gun.render_light)this.func_73729_b(k + 44, l + 36, 176, 0, 16, 16);
				if(!gun.render_muss)this.func_73729_b(k + 8, l + 90, 176, 0, 16, 16);
				if(!gun.render_grip)this.func_73729_b(k + 44, l + 108, 176, 0, 16, 16);
				//if(!gun.rightmode)this.drawTexturedModalRect(k + 98, l + 36, 176, 0, 15, 15);
			}
		}
		GL11.glPopMatrix();
        
        GL11.glPushMatrix();
		//GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
		if(this.player != null){
			ItemStack itemstack = player.func_184614_ca();
			if (!itemstack.func_190926_b() && itemstack.func_77973_b() instanceof ItemGunBase) {//item
				ItemGunBase gun = (ItemGunBase) itemstack.func_77973_b();
				Minecraft.func_71410_x().field_71446_o.func_110577_a(new ResourceLocation(gun.obj_tex));
				ScaledResolution scaledresolution = new ScaledResolution(field_146297_k);
				//GL11.glScalef(-1F, 1F, 1F);
				GL11.glDisable(GL11.GL_CULL_FACE);
				GlStateManager.func_179109_b(scaledresolution.func_78326_a()/2 + 20, scaledresolution.func_78328_b()/2 - 20, 5);
				GL11.glScalef(15F, 15F, 15F);
				//GlStateManager.translate(15, 7, 5);
				GlStateManager.func_179114_b(-180, 0.0F, 0.0F, 1.0F);
				GlStateManager.func_179114_b(90, 0.0F, 1.0F, 0.0F);
				//GlStateManager.rotate(this.mousePosx, 0.0F, 1.0F, 0.0F);
				//System.out.println(String.format("getScaledWidth-" + scaledresolution.getScaledWidth()/2));//213
				//System.out.println(String.format("getScaledHeight-" + scaledresolution.getScaledHeight()/2));//120
			gun.obj_model.renderPart("mat1");
			gun.obj_model.renderPart("mat100");
			gun.obj_model.renderPart("mat2");
			gun.obj_model.renderPart("mat3");
			Layermat.rendersight( player,  itemstack,  gun);
			//this.rendersight(player, itemstack, gun);
			Layermat.renderattachment( player,  itemstack,  gun);
			gun.obj_model.renderPart("mat25");
			gun.obj_model.renderPart("mat31");
			gun.obj_model.renderPart("mat32");/**/
		}
		}
		GL11.glPopMatrix();
    }
    
    /*public void rendersight(EntityPlayer player, ItemStack stack, ItemGunBase gun) {
    	InventoryPlayer playerInv = player.inventory;
		GVCInventoryItem inventory = new GVCInventoryItem(playerInv, stack);
		inventory.openInventory();
		for (int i1 = 0; i1 < inventory.getSizeInventory(); ++i1) {
			ItemStack itemstacki = inventory.getStackInSlot(i1);

			if (i1 == 1) {
				if (!itemstacki.isEmpty() && itemstacki.getItem() instanceof ItemAttachment) {
					ItemAttachment am = (ItemAttachment) itemstacki.getItem();
					if(am.objtrue && am.id == 101){
						gun.am_sight = true;
						gun.scopezoom = am.zoom;
						gun.am_model = am.obj_model;
						gun.am_tex = am.obj_tex;
						gun.am_zoomrender = am.zoomrender;
						gun.am_ads_tex = am.ads_tex;
						gun.model_x_ads =  (gun.am_sight_x + am.x);
						gun.model_y_ads = - (gun.am_sight_y + am.y);
						gun.model_z_ads = - (-gun.model_z_ads + gun.am_sight_z + am.z);
						GL11.glPushMatrix();//glstart11
						GL11.glTranslatef(gun.am_sight_x, gun.am_sight_y, gun.am_sight_z);
						Minecraft.getMinecraft().renderEngine.bindTexture(new ResourceLocation(gun.am_tex));
						gun.am_model.renderPart("sight");
						GL11.glTranslatef( - gun.am_sight_x,  - gun.am_sight_y,  - gun.am_sight_z);
						Minecraft.getMinecraft().renderEngine.bindTexture(new ResourceLocation(gun.obj_tex));
						GL11.glPopMatrix();//glend11
						gun.obj_model.renderPart("mat41");
					}
				}
			}
		}
    }*/
    
    /**
     * Draws the screen and all the components in it.
     */
    public void func_73863_a(int mouseX, int mouseY, float partialTicks)
    {
        this.func_146276_q_();
        this.mousePosx = (float)mouseX;
        this.mousePosY = (float)mouseY;
        super.func_73863_a(mouseX, mouseY, partialTicks);
        //this.renderHoveredToolTip(mouseX, mouseY);
        this.func_191948_b(mouseX, mouseY);
        //player.inventoryContainer.renderTooltip(this.guiLeft, this.guiTop, mouseX, mouseY);
    }
}
