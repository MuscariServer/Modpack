package gvclib.gui;
 
import java.util.Map;
import gvclib.item.ItemGunBase;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.inventory.IInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.util.NonNullList;
import net.minecraft.util.text.ITextComponent;


import gvclib.item.ItemGunBase;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.inventory.IInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.util.NonNullList;
import net.minecraft.util.text.ITextComponent;
 
public class GVCInventoryItem implements IInventory
{
    private InventoryPlayer inventoryPlayer;
    private ItemStack currentItem;
    //private ItemStack[] items;
    private NonNullList<ItemStack> stackList = NonNullList.<ItemStack>func_191197_a(54, ItemStack.field_190927_a);
 
    public GVCInventoryItem(InventoryPlayer inventory, ItemStack stack)
    {
        inventoryPlayer = inventory;
        EntityPlayer entityplayer = inventory.field_70458_d;
        //currentItem = inventoryPlayer.getCurrentItem();
        if(!entityplayer.func_184614_ca().func_190926_b() && entityplayer.func_184614_ca().func_77973_b() instanceof ItemGunBase){
        	currentItem = ((EntityPlayer)(entityplayer)).func_184614_ca();
        }else if(!entityplayer.func_184592_cb().func_190926_b() && entityplayer.func_184592_cb().func_77973_b() instanceof ItemGunBase){
        	currentItem = ((EntityPlayer)(entityplayer)).func_184592_cb();
        }
        //currentItem = ((EntityPlayer)(entityplayer)).getHeldItemMainhand();
        //currentItem = stack;
 
        //InventorySize
    }
 
    @Override
    public int func_70302_i_()
    {
        return this.stackList.size();
    }
 
    @Override
    public ItemStack func_70301_a(int index)
    {
        return this.stackList.get(index);
    }
 @Override
    public ItemStack func_70298_a(int index, int p_70298_2_)
    {
        if (this.stackList.get(index) != ItemStack.field_190927_a)
        {
            ItemStack itemstack;
 
            if (this.stackList.get(index).func_190916_E() <= p_70298_2_)
            {
                itemstack = this.stackList.get(index);
                this.stackList.set(index, ItemStack.field_190927_a);
                this.func_70296_d();
                return itemstack;
            }
            else
            {
                itemstack = this.stackList.get(index).func_77979_a(p_70298_2_);
 
                if (this.stackList.get(index).func_190916_E() == 0)
                {
                	this.stackList.set(index, ItemStack.field_190927_a);
                }
 
                this.func_70296_d();
                return itemstack;
            }
        }
        return ItemStack.field_190927_a;
    }
 
 public ItemStack decrStackDamege(int index, int p_70298_2_, EntityLivingBase en)
 {
     if (this.stackList.get(index) != ItemStack.field_190927_a)
     {
         ItemStack itemstack;
         this.stackList.get(index).func_77972_a(p_70298_2_, en);

         if (this.stackList.get(index).func_77952_i() >= this.stackList.get(index).func_77958_k())
         {
             itemstack = this.stackList.get(index);
             this.stackList.set(index, ItemStack.field_190927_a);
             this.func_70296_d();
             return itemstack;
         }
         else
         {
             itemstack = this.stackList.get(index).func_77979_a(p_70298_2_);

             if (this.stackList.get(index).func_190916_E() == 0)
             {
             	this.stackList.set(index, ItemStack.field_190927_a);
             }

             this.func_70296_d();
             return itemstack;
         }
     }
     return ItemStack.field_190927_a;
 }
 
   // @Override
    public ItemStack getStackInSlotOnClosing(int index)
    {
        if (this.stackList.get(index)!= ItemStack.field_190927_a)
        {
            ItemStack itemstack = this.stackList.get(index);
            this.stackList.set(index, ItemStack.field_190927_a);
            return itemstack;
        }
        return null;
    }
 
    @Override
    public void func_70299_a(int index, ItemStack p_70299_2_)
    {
    	this.stackList.set(index,p_70299_2_);
 
        if (p_70299_2_ != ItemStack.field_190927_a && p_70299_2_.func_190916_E() > this.func_70297_j_())
        {
           // p_70299_2_ = this.getInventoryStackLimit();
        	p_70299_2_.func_190920_e( this.func_70297_j_());
        }
 
        this.func_70296_d();
    }
 
    //@Override
    public String getInventoryName()
    {
        return "InventoryItem";
    }
 
    //@Override
    public boolean hasCustomInventoryName()
    {
        return false;
    }
 
    @Override
    public int func_70297_j_()
    {
        return 64;
    }
 
    @Override
    public void func_70296_d() {}
 
    @Override
    public boolean func_70300_a(EntityPlayer p_70300_1_)
    {
        return true;
    }
 
    /*
        Containerが開かれたタイミングでItemStackの持っているNBTからアイテムを読み込んでいる
     */
  //  @Override
   /* public void openInventory()
    {
    	//System.out.println(String.format("1"));
        if(!currentItem.hasTagCompound())
        {
            currentItem.setTagCompound(new NBTTagCompound());
            currentItem.getTagCompound().setTag("Items", new NBTTagList());
        }
        if(currentItem.getTagCompound().getTag("Items") == null)
        {
            currentItem.setTagCompound(new NBTTagCompound());
            currentItem.getTagCompound().setTag("Items", new NBTTagList());
        }
        NBTTagList tags = (NBTTagList)currentItem.getTagCompound().getTag("Items");
 
        for(int i = 0; i < tags.tagCount(); i++)//133
        {
            NBTTagCompound tagCompound = tags.getCompoundTagAt(i);
            int slot = tagCompound.getByte("Slot");
            if(slot >= 0 && slot < stackList.size())
            {
               // items[slot] = new ItemStack((NBTTagCompound)tagCompound);
                stackList.set(slot, new ItemStack((NBTTagCompound)tagCompound));
            }
        }
        //System.out.println(String.format("2"));
    }*/
 
    /*
        Containerを閉じるときに保存
     */
  //  @Override
   /* public void closeInventory()
    {
        NBTTagList tagList = new NBTTagList();
        for(int i = 0; i < stackList.size(); i++)
        {
        	ItemStack itemstack = this.getStackInSlot(i);

            if (!itemstack.isEmpty())
            {
                NBTTagCompound compound = new NBTTagCompound();
                compound.setByte("Slot", (byte)i);
                itemstack.writeToNBT(compound);
                tagList.appendTag(compound);
            }
        }
        ItemStack result = new ItemStack(currentItem.getItem(), 1);
        result.setTagCompound(new NBTTagCompound());
        result.getTagCompound().setTag("Items", tagList);
 
        //ItemStackをセットする。NBTは右クリック等のタイミングでしか保存されないため再セットで保存している。
        //inventoryPlayer.mainInventory.get(inventoryPlayer.currentItem) = result;
        inventoryPlayer.mainInventory.set(inventoryPlayer.currentItem, result);
       // inventoryPlayer.mainInventory[inventoryPlayer.currentItem] = result;
        System.out.println(String.format("close"));
    }*/
 
    @Override
	public void func_174889_b(EntityPlayer player) {
		// TODO 自動生成されたメソッド・スタブ
    	//System.out.println(String.format("1"));
        if(!currentItem.func_77942_o())
        {
            currentItem.func_77982_d(new NBTTagCompound());
            currentItem.func_77978_p().func_74782_a("Items", new NBTTagList());
        }
        if(currentItem.func_77978_p().func_74781_a("Items") == null)
        {
            //currentItem.setTagCompound(new NBTTagCompound());
            currentItem.func_77978_p().func_74782_a("Items", new NBTTagList());
        }
        NBTTagList tags = (NBTTagList)currentItem.func_77978_p().func_74781_a("Items");
 
        for(int i = 0; i < tags.func_74745_c(); i++)//133
        {
            NBTTagCompound tagCompound = tags.func_150305_b(i);
            int slot = tagCompound.func_74771_c("Slot");
            if(slot >= 0 && slot < stackList.size())
            {
               // items[slot] = new ItemStack((NBTTagCompound)tagCompound);
                stackList.set(slot, new ItemStack((NBTTagCompound)tagCompound));
            }
        }
        Map<Enchantment, Integer> map1 = EnchantmentHelper.func_82781_a(currentItem);
        for (Enchantment enchantment1 : map1.keySet())
        {
            if (enchantment1 != null)
            {
            	EnchantmentHelper.func_82782_a(map1, currentItem);
            	//System.out.println(String.format("en"));
            }
        }
        currentItem.func_77964_b(currentItem.func_77952_i());
        //System.out.println(String.format("open"));
	}

	@Override
	public void func_174886_c(EntityPlayer player) {
		// TODO 自動生成されたメソッド・スタブ
		NBTTagList nbttaglist = new NBTTagList();
		for (int i = 0; i < this.stackList.size(); i++) {
		      if (!this.stackList.get(i).func_190926_b())
		      {
		        NBTTagCompound nbttagcompound = new NBTTagCompound();
                nbttagcompound.func_74774_a("Slot", (byte)i);
                this.stackList.get(i).func_77955_b(nbttagcompound);
                nbttaglist.func_74742_a(nbttagcompound);
		      }
		    }
        ItemStack result = new ItemStack(currentItem.func_77973_b(), 1);
        result.func_77982_d(new NBTTagCompound());
        result.func_77978_p().func_74782_a("Items", nbttaglist);
        Map<Enchantment, Integer> map1 = EnchantmentHelper.func_82781_a(currentItem);
        for (Enchantment enchantment1 : map1.keySet())
        {
            if (enchantment1 != null)
            {
            	EnchantmentHelper.func_82782_a(map1, result);
            	//System.out.println(String.format("enset"));
            }
        }
        //ItemStackをセットする。NBTは右クリック等のタイミングでしか保存されないため再セットで保存している。
        //inventoryPlayer.mainInventory.get(inventoryPlayer.currentItem) = result;
        result.func_77964_b(currentItem.func_77952_i());
        inventoryPlayer.field_70462_a.set(inventoryPlayer.field_70461_c, result);
       // inventoryPlayer.mainInventory[inventoryPlayer.currentItem] = result;
       // System.out.println(String.format("close"));
	}
    
    @Override
    public boolean func_94041_b(int p_94041_1_, ItemStack p_94041_2_)
    {
        return true;
    }

	@Override
	public String func_70005_c_() {
		// TODO 自動生成されたメソッド・スタブ
		return null;
	}

	@Override
	public boolean func_145818_k_() {
		// TODO 自動生成されたメソッド・スタブ
		return false;
	}

	@Override
	public ITextComponent func_145748_c_() {
		// TODO 自動生成されたメソッド・スタブ
		return null;
	}

	@Override
	public ItemStack func_70304_b(int index) {
		// TODO 自動生成されたメソッド・スタブ
		return null;
	}

	

	@Override
	public int func_174887_a_(int id) {
		// TODO 自動生成されたメソッド・スタブ
		return 0;
	}

	@Override
	public void func_174885_b(int id, int value) {
		// TODO 自動生成されたメソッド・スタブ
		
	}

	@Override
	public int func_174890_g() {
		// TODO 自動生成されたメソッド・スタブ
		return 0;
	}

	@Override
	public void func_174888_l() {
		// TODO 自動生成されたメソッド・スタブ
		
	}

	@Override
	public boolean func_191420_l() {
		// TODO 自動生成されたメソッド・スタブ
		return false;
	}
 
}
