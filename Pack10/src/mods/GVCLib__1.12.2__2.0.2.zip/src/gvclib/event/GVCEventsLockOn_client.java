package gvclib.event;

import java.util.List;
import gvclib.entity.living.EntityGVCLivingBase;
import gvclib.item.ItemGunBase;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.monster.IMob;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraftforge.client.event.RenderLivingEvent;
import net.minecraftforge.fml.client.FMLClientHandler;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import objmodel.AdvancedModelLoader;
import objmodel.IModelCustom;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL12;


import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL12;

import gvclib.entity.living.EntityGVCLivingBase;
import gvclib.item.ItemGunBase;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.shader.Framebuffer;
import net.minecraft.client.shader.ShaderGroup;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.monster.IMob;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraftforge.client.event.RenderLivingEvent;
import net.minecraftforge.fml.client.FMLClientHandler;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import objmodel.AdvancedModelLoader;
import objmodel.IModelCustom;

public class GVCEventsLockOn_client {
	
	
	private static final ResourceLocation lockon = new ResourceLocation("gvclib:textures/marker/lockon.png");
	private static final ResourceLocation lock = new ResourceLocation("gvclib:textures/marker/lock.png");
    private static final IModelCustom doll_class = AdvancedModelLoader.loadModel(new ResourceLocation("gvclib:textures/marker/class.mqo"));
    
    
	@SideOnly(Side.CLIENT)
    @SubscribeEvent
	  public void renderLockOn(RenderLivingEvent.Post event)
	  {
		Minecraft minecraft = FMLClientHandler.instance().getClient();
		EntityPlayer entityplayer = minecraft.field_71439_g;
		ItemStack itemstack = ((EntityPlayer) (entityplayer)).func_184614_ca();
		Entity target = event.getEntity();
		if(target != null && target instanceof EntityLivingBase) {
			NBTTagCompound target_nbt = target.getEntityData();
			if(target_nbt != null && target_nbt.func_74762_e("lockon") > 0){
				if (entityplayer.func_184187_bx() instanceof EntityGVCLivingBase && entityplayer.func_184187_bx() != null) {// 1
					EntityGVCLivingBase vehicle = (EntityGVCLivingBase) entityplayer.func_184187_bx();
					if(vehicle.mitarget == target) {
						render(event, minecraft, target, entityplayer, lockon);
					}
				}
				if(!itemstack.func_190926_b() && itemstack.func_77973_b() instanceof ItemGunBase) {
					ItemGunBase gun = (ItemGunBase) itemstack.func_77973_b();
					if(gun.mitarget == target) {
						render(event, minecraft, target, entityplayer, lockon);
					}
				}
			}
		}
	  }
	
	@SideOnly(Side.CLIENT)
    @SubscribeEvent
	  public void renderVehicle_Rader(RenderLivingEvent.Post event)
	  {
		Minecraft minecraft = FMLClientHandler.instance().getClient();
		EntityPlayer entityplayer = minecraft.field_71439_g;
		ItemStack itemstack = ((EntityPlayer) (entityplayer)).func_184614_ca();
		Entity target = event.getEntity();
		if(target != null && target instanceof EntityLivingBase) {
			if (entityplayer.func_184187_bx() instanceof EntityGVCLivingBase && entityplayer.func_184187_bx() != null) {// 1
				EntityGVCLivingBase vehicle = (EntityGVCLivingBase) entityplayer.func_184187_bx();
				if(vehicle != target && vehicle.aarader && target instanceof IMob) {
					BlockPos bp = target.field_70170_p.func_175645_m(new BlockPos(target.field_70165_t, target.field_70163_u, target.field_70161_v));
					if(target.field_70163_u > bp.func_177956_o() + 10 && !target.field_70122_E)
					{
						render(event, minecraft, target, entityplayer, lock);
					}
				}
			}
		}
			/*if (entityplayer.getRidingEntity() instanceof EntityGVCLivingBase && entityplayer.getRidingEntity() != null) {// 1
				EntityGVCLivingBase vehicle = (EntityGVCLivingBase) entityplayer.getRidingEntity();
				//if(vehicle.mitarget != null) 
				if(vehicle.aarader){
					List<Entity> llist = vehicle.world.getEntitiesWithinAABBExcludingEntity(vehicle,
							vehicle.getEntityBoundingBox().expand(vehicle.motionX, vehicle.motionY, vehicle.motionZ).grow(120));
					if (llist != null) {
						for (int lj = 0; lj < llist.size(); lj++) {
							Entity entity1 = (Entity) llist.get(lj);
							if (entity1.canBeCollidedWith()) {
								if(entity1 == target  && vehicle != target){
									if (entity1 instanceof IMob && entity1 != null && ((EntityLivingBase) entity1).getHealth() > 0.0F && vehicle.getHealth() > 0.0F) 
									{
										BlockPos bp = entity1.world.getHeight(new BlockPos(entity1.posX, entity1.posY, entity1.posZ));
										if(entity1.posY > bp.getY() + 10 && !entity1.onGround)
										{
											render(event, minecraft, entity1, entityplayer, lock);
										}
									}
								}
							}
						}
					}
				}
			}
		}*/
	  }
	
	private void render(RenderLivingEvent.Post event, Minecraft minecraft, Entity entity, EntityPlayer entityplayer, ResourceLocation resource) {
//			 System.out.println("3");
			GL11.glPushMatrix();
			GL11.glEnable(GL11.GL_BLEND);
			// GL11.glPushAttrib(GL11.GL_ALL_ATTRIB_BITS);
			GL11.glTranslatef((float) event.getX(), (float) event.getY(), (float) event.getZ());
			RenderManager manager = minecraft.func_175598_ae();
			GlStateManager.func_179114_b(-manager.field_78735_i, 0.0F, 1.0F, 0.0F);
			GlStateManager.func_179114_b((float)(manager.field_78733_k.field_74320_O == 2 ? -1 : 1) * manager.field_78732_j, 1.0F, 0.0F, 0.0F);
			GL11.glEnable(GL12.GL_RESCALE_NORMAL);
			{
				GlStateManager.func_179143_c(519);
				GlStateManager.func_179106_n();
				// this.entityOutlineFramebuffer.bindFramebuffer(false);
				RenderHelper.func_74518_a();
				event.getRenderer().func_177068_d().func_178632_c(true);
				// GL11.glutInitDisplayMode(GL11.GLUT_SINGLE | GL11.GLUT_RGBA |
				// GL11.GLUT_DEPTH);
				// GL11.glClear(GL11.GL_COLOR_BUFFER_BIT | GL11.GL_DEPTH_BUFFER_BIT);
				// GL11.glEnable(GL11.GL_DEPTH_TEST);

				GL11.glTranslatef(0, entity.field_70131_O / 2, 0);
				GL11.glScalef(2.0f * entity.field_70131_O, 2.0f * entity.field_70131_O, 2.0f * entity.field_70131_O);
				double d5 = entity.field_70165_t - entityplayer.field_70165_t;
				double d7 = entity.field_70161_v - entityplayer.field_70161_v;
				double d6 = entity.field_70163_u - entityplayer.field_70163_u;
				double ddx = Math.abs(d5);
				double ddz = Math.abs(d7);
				double dxz = MathHelper.func_76133_a(d5 * d5 + d7 * d7);
				double dxzy = MathHelper.func_76133_a(dxz * dxz + d6 * d6);
				GL11.glScalef(1.0F + ((float) dxzy * 0.05F), 1.0F + ((float) dxzy * 0.05F),
						1.0F + ((float) dxzy * 0.05F));
				GlStateManager.func_179140_f();
				Minecraft.func_71410_x().field_71446_o.func_110577_a(resource);
				doll_class.renderPart("mat1");
				GlStateManager.func_179145_e();

				// GL11.glDisable(GL11.GL_DEPTH_TEST);
				event.getRenderer().func_177068_d().func_178632_c(false);
				RenderHelper.func_74519_b();
				GlStateManager.func_179132_a(false);
				// this.entityOutlineShader.render(event.getPartialRenderTick());
				GlStateManager.func_179145_e();
				GlStateManager.func_179132_a(true);
				GlStateManager.func_179127_m();
				GlStateManager.func_179147_l();
				GlStateManager.func_179142_g();
				GlStateManager.func_179143_c(515);
				GlStateManager.func_179126_j();
				GlStateManager.func_179141_d();
			}
			GL11.glDisable(GL12.GL_RESCALE_NORMAL);
			// GL11.glPopAttrib();
			GL11.glDisable(GL11.GL_BLEND);
			GL11.glPopMatrix();
	}
	
}
