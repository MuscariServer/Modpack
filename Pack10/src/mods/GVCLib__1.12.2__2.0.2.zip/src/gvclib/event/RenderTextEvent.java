package gvclib.event;

import org.lwjgl.opengl.GL11;
import gvclib.item.ItemGunBase;
import gvclib.item.ItemMagazine;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiIngame;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderItem;
import net.minecraft.client.renderer.texture.TextureMap;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.ResourceLocation;


import gvclib.item.ItemGunBase;
import gvclib.item.ItemMagazine;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiIngame;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderItem;
import net.minecraft.client.renderer.texture.TextureMap;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.ResourceLocation;

public class RenderTextEvent extends Gui {

	private final static ResourceLocation overlayTimerSun = new ResourceLocation(
			"hmggvc:textures/misc/ironsight_ak74.png");

	private final static int DAY_WIDTH = 34;
	private final static int DAY_HEIGHT = 34;

	private Minecraft mc;
	private int iii;

	public RenderTextEvent(Minecraft mc) {
		this.mc = mc;
	}
	
	public void rendergun_cross(ItemStack itemstack, ItemGunBase gun, int i, int j) {
		ScaledResolution scaledresolution = new ScaledResolution(mc);
		float b = gun.bure * 4;
		NBTTagCompound nbt = itemstack.func_77978_p();
		if(nbt != null) {
			boolean recoiled = nbt.func_74767_n("Recoiled");
			if(!recoiled) {
				b = b *1.5F;
			}
		}
		
		
		GuiIngame g  = mc.field_71456_v;
		{
			GL11.glPushMatrix();
			GL11.glEnable(GL11.GL_BLEND);
			GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.8F);
				mc.field_71446_o.func_110577_a(new ResourceLocation("gvclib:textures/hud/cross_h.png"));
				GL11.glTranslatef(0.5F,0F, 0F);
				GL11.glScalef(0.0625f, 0.0625f, 1);
				g.func_175174_a((scaledresolution.func_78326_a()/2 - 8 - b)*16,
						(scaledresolution.func_78328_b()/2 - 8)*16, 0,0, 256, 256);
				GL11.glEnable(GL11.GL_BLEND);
			GL11.glPopMatrix();
		}
		{
			GL11.glPushMatrix();
			GL11.glEnable(GL11.GL_BLEND);
			GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.8F);
				mc.field_71446_o.func_110577_a(new ResourceLocation("gvclib:textures/hud/cross_h.png"));
				GL11.glTranslatef(0.5F,0F, 0F);
				GL11.glScalef(0.0625f, 0.0625f, 1);
				g.func_175174_a((scaledresolution.func_78326_a()/2 - 8 + b)*16,
						(scaledresolution.func_78328_b()/2 - 8)*16, 0,0, 256, 256);
				GL11.glEnable(GL11.GL_BLEND);
			GL11.glPopMatrix();
		}
		{
			GL11.glPushMatrix();
			GL11.glEnable(GL11.GL_BLEND);
			GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.8F);
				mc.field_71446_o.func_110577_a(new ResourceLocation("gvclib:textures/hud/cross_v.png"));
				GL11.glTranslatef(0.5F,0F, 0F);
				GL11.glScalef(0.0625f, 0.0625f, 1);
				g.func_175174_a((scaledresolution.func_78326_a()/2 - 8)*16,
						(scaledresolution.func_78328_b()/2 - 8 - b)*16, 0,0, 256, 256);
				GL11.glEnable(GL11.GL_BLEND);
			GL11.glPopMatrix();
		}
		{
			GL11.glPushMatrix();
			GL11.glEnable(GL11.GL_BLEND);
			GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.8F);
				mc.field_71446_o.func_110577_a(new ResourceLocation("gvclib:textures/hud/cross_v.png"));
				GL11.glTranslatef(0.5F,0F, 0F);
				GL11.glScalef(0.0625f, 0.0625f, 1);
				g.func_175174_a((scaledresolution.func_78326_a()/2 - 8)*16,
						(scaledresolution.func_78328_b()/2 - 8 + b)*16, 0,0, 256, 256);
				GL11.glEnable(GL11.GL_BLEND);
			GL11.glPopMatrix();
		}
	}
	
	public void rendergun(ItemStack itemstack, ItemGunBase gun, int i, int j) {
		EntityPlayer player = mc.field_71439_g;
		InventoryPlayer playerInv = player.field_71071_by;
		FontRenderer fontReader = mc.field_71466_p;
		mc.field_71466_p.func_78264_a(mc.func_152349_b());
		
		GL11.glPushMatrix();//21
		GL11.glEnable(GL11.GL_BLEND);
		GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.5F);
		GlStateManager.func_187428_a(GlStateManager.SourceFactor.SRC_ALPHA,
				GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE,
				GlStateManager.DestFactor.ZERO);
		mc.field_71446_o.func_110577_a(new ResourceLocation("gvclib:textures/hud/gun_hud_back.png"));
		GL11.glScalef(0.25f, 0.125f, 1);
		func_73729_b((i -77)*4,(j-50)*8, 0,0, 256, 256);
		GL11.glPopMatrix();//22
		GL11.glPushMatrix();//21
		GL11.glEnable(GL11.GL_BLEND);
		GL11.glColor4f(1.0F, 1.0F, 1.0F, 1F);
		GlStateManager.func_187428_a(GlStateManager.SourceFactor.SRC_ALPHA,
				GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE,
				GlStateManager.DestFactor.ZERO);
		mc.field_71446_o.func_110577_a(new ResourceLocation("gvclib:textures/hud/gun_hud.png"));
		GL11.glScalef(0.25f, 0.125f, 1);
		func_73729_b((i -77)*4,(j-50)*8, 0,0, 256, 256);
		GL11.glPopMatrix();//22
		
		
		GL11.glPushMatrix();
		GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
		GlStateManager.func_187428_a(GlStateManager.SourceFactor.SRC_ALPHA,
				GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE,
				GlStateManager.DestFactor.ZERO);
		mc.field_71446_o.func_110577_a(TextureMap.field_110575_b);
		String d = String.format("%1$3d", itemstack.func_77958_k() - itemstack.func_77952_i());
		String d1 = String.format("%1$3d", itemstack.func_77958_k());
		for (int is = 0; is < 36; ++is) {
			ItemStack itemi = playerInv.func_70301_a(is);
			if (!itemi.func_190926_b()) {
				if(gun.magazine instanceof ItemMagazine) {
		    		ItemMagazine maga = (ItemMagazine) gun.magazine;
		    		if(itemi.func_77973_b() instanceof ItemMagazine) {
		    			ItemMagazine maga_item = (ItemMagazine)itemi.func_77973_b();
		    			if(maga_item.magazine_tab.equals(maga.magazine_tab)) {
		    				iii = iii + itemi.func_190916_E();
		    			}
		    		}
				}else if(itemi.func_77973_b() == gun.magazine){
					iii = iii + itemi.func_190916_E();
				}
			}

		}
		String d2 = String.format("%1$3d", iii);
		fontReader.func_78276_b(d + " /" + d1, i -70, j - 30 + 0, 0xFFFFFF);
		fontReader.func_78276_b( "x " + d2, i -50, j - 45 + 0, 0xFFFFFF);
		iii = 0;
		if(gun.magazine != null)
		{
			RenderItem renderitem = mc.func_175599_af();
			renderitem.func_175042_a(new ItemStack(gun.magazine), i -68, j-49);
		}
		GL11.glPopMatrix();
		
		if(!player.func_184614_ca().func_190926_b() && player.func_184614_ca() == itemstack 
				&& !gun.underbarrel.func_190926_b() && gun.underbarrel.func_77973_b() instanceof ItemGunBase)
			//if(!gun.underbarrel.isEmpty() && gun.underbarrel.getItem() instanceof ItemGunBase)
			{
			ItemGunBase under = (ItemGunBase) gun.underbarrel.func_77973_b();
			GL11.glPushMatrix();//21
			GL11.glEnable(GL11.GL_BLEND);
			GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.5F);
			GlStateManager.func_187428_a(GlStateManager.SourceFactor.SRC_ALPHA,
					GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE,
					GlStateManager.DestFactor.ZERO);
			mc.field_71446_o.func_110577_a(new ResourceLocation("gvclib:textures/hud/gun_hud_back.png"));
			GL11.glScalef(0.25f, 0.125f, 1);
			func_73729_b((i -77)*4,(j-80)*8, 0,0, 256, 256);
			GL11.glPopMatrix();//22
			GL11.glPushMatrix();//21
			GL11.glEnable(GL11.GL_BLEND);
			GL11.glColor4f(1.0F, 1.0F, 1.0F, 1F);
			GlStateManager.func_187428_a(GlStateManager.SourceFactor.SRC_ALPHA,
					GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE,
					GlStateManager.DestFactor.ZERO);
			mc.field_71446_o.func_110577_a(new ResourceLocation("gvclib:textures/hud/gun_hud.png"));
			GL11.glScalef(0.25f, 0.125f, 1);
			func_73729_b((i -77)*4,(j-80)*8, 0,0, 256, 256);
			GL11.glPopMatrix();//22
			GL11.glPushMatrix();
			GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
			GlStateManager.func_187428_a(GlStateManager.SourceFactor.SRC_ALPHA,
					GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE,
					GlStateManager.DestFactor.ZERO);
			mc.field_71446_o.func_110577_a(TextureMap.field_110575_b);
			String dx = String.format("%1$3d", gun.underbarrel.func_77958_k() - gun.underbarrel.func_77952_i());
			String d1x = String.format("%1$3d", gun.underbarrel.func_77958_k());
			for (int is = 0; is < 36; ++is) {
				ItemStack itemi = playerInv.func_70301_a(is);
				if (itemi != null && itemi.func_77973_b() == under.magazine) {
					iii = iii + itemi.func_190916_E();
				}
			}
			String d2x = String.format("%1$3d", iii);
			fontReader.func_78276_b(dx + " /" + d1x, i -70, j - 60 + 0, 0xFFFFFF);
			fontReader.func_78276_b( "x " + d2x, i -50, j - 75 + 0, 0xFFFFFF);
			iii = 0;
			if(under.magazine != null)
			{
				RenderItem renderitem = mc.func_175599_af();
				renderitem.func_175042_a(new ItemStack(under.magazine), i -68, j-79);
			}
			GL11.glPopMatrix();
		}

	}
	
	public void rendergunl(ItemStack itemstack, ItemGunBase gun, int i, int j) {
		EntityPlayer player = mc.field_71439_g;
		InventoryPlayer playerInv = player.field_71071_by;
		FontRenderer fontReader = mc.field_71466_p;
		mc.field_71466_p.func_78264_a(mc.func_152349_b());
		
		GL11.glPushMatrix();//21
		GL11.glEnable(GL11.GL_BLEND);
		GL11.glColor4f(1.0F, 1.0F, 1.0F, 0.5F);
		GlStateManager.func_187428_a(GlStateManager.SourceFactor.SRC_ALPHA,
				GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE,
				GlStateManager.DestFactor.ZERO);
		mc.field_71446_o.func_110577_a(new ResourceLocation("gvclib:textures/hud/gun_hud_back.png"));
		GL11.glScalef(0.25f, 0.125f, 1);
		func_73729_b((10)*4,(j-50)*8, 0,0, 256, 256);
		GL11.glPopMatrix();//22
		GL11.glPushMatrix();//21
		GL11.glEnable(GL11.GL_BLEND);
		GL11.glColor4f(1.0F, 1.0F, 1.0F, 1F);
		GlStateManager.func_187428_a(GlStateManager.SourceFactor.SRC_ALPHA,
				GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE,
				GlStateManager.DestFactor.ZERO);
		mc.field_71446_o.func_110577_a(new ResourceLocation("gvclib:textures/hud/gun_hud.png"));
		GL11.glScalef(0.25f, 0.125f, 1);
		func_73729_b((10)*4,(j-50)*8, 0,0, 256, 256);
		GL11.glPopMatrix();//22
		
		
		GL11.glPushMatrix();
		GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
		GlStateManager.func_187428_a(GlStateManager.SourceFactor.SRC_ALPHA,
				GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE,
				GlStateManager.DestFactor.ZERO);
		mc.field_71446_o.func_110577_a(TextureMap.field_110575_b);
		String d = String.format("%1$3d", itemstack.func_77958_k() - itemstack.func_77952_i());
		String d1 = String.format("%1$3d", itemstack.func_77958_k());
		for (int is = 0; is < 36; ++is) {
			ItemStack itemi = playerInv.func_70301_a(is);
			if (itemi != null && itemi.func_77973_b() == gun.magazine) {
				iii = iii + itemi.func_190916_E();

			}

		}
		String d2 = String.format("%1$3d", iii);
		fontReader.func_78276_b(d + " /" + d1, 20, j - 30 + 0, 0xFFFFFF);
		fontReader.func_78276_b( "x " + d2, 40, j - 45 + 0, 0xFFFFFF);
		iii = 0;
		if(gun.magazine != null)
		{
			RenderItem renderitem = mc.func_175599_af();
			renderitem.func_175042_a(new ItemStack(gun.magazine), 23, j-49);
		}
		GL11.glPopMatrix();

	}
}
