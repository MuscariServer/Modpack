package gvclib.event;

import gvclib.mod_GVCLib;
import gvclib.entity.living.EntityMobVehicle_Inv_Base;
import gvclib.entity.living.EntityVehicleBase;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.GuiIngame;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.client.FMLClientHandler;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public class GVCEventsRiddingVehicle {

	boolean key_true = false;
	
	@SideOnly(Side.CLIENT)
	@SubscribeEvent
	public void onEventRidding(RenderGameOverlayEvent.Text event) {
		Minecraft minecraft = FMLClientHandler.instance().getClient();
		World world = FMLClientHandler.instance().getWorldClient();
		ScaledResolution scaledresolution = new ScaledResolution(minecraft);
		int i = scaledresolution.func_78326_a();
		int j = scaledresolution.func_78328_b();
		EntityPlayer entityplayer = minecraft.field_71439_g;
		ItemStack itemstack = ((EntityPlayer) (entityplayer)).func_184614_ca();
		FontRenderer fontrenderer = minecraft.field_71466_p;
		minecraft.field_71460_t.func_78478_c();
		//OpenGlHelper.

		boolean cx = true;

		if (FMLCommonHandler.instance().getSide() == Side.CLIENT) {
			Render_HUDVehicleEvent renderevent = new Render_HUDVehicleEvent(minecraft);
			if (entityplayer.func_184187_bx() instanceof EntityMobVehicle_Inv_Base
					&& entityplayer.func_184187_bx() != null) {// 1
				EntityMobVehicle_Inv_Base balaam = (EntityMobVehicle_Inv_Base) entityplayer.func_184187_bx();
				GuiIngame g = minecraft.field_71456_v;
				renderevent.render_fuel(minecraft, balaam, entityplayer, i, j);
				if(balaam.spg_mode){
					renderevent.render_spg(minecraft, balaam, entityplayer, i, j);
				}
			} // 1

		}

	}
	
	@SideOnly(Side.CLIENT)
	@SubscribeEvent
	public void onEventRidding2(RenderGameOverlayEvent.Text event) {
		Minecraft minecraft = FMLClientHandler.instance().getClient();
		World world = FMLClientHandler.instance().getWorldClient();
		ScaledResolution scaledresolution = new ScaledResolution(minecraft);
		int i = scaledresolution.func_78326_a();
		int j = scaledresolution.func_78328_b();
		EntityPlayer entityplayer = minecraft.field_71439_g;
		ItemStack itemstack = ((EntityPlayer) (entityplayer)).func_184614_ca();
		FontRenderer fontrenderer = minecraft.field_71466_p;
		minecraft.field_71460_t.func_78478_c();
		//OpenGlHelper.

		boolean cx = true;

		if (FMLCommonHandler.instance().getSide() == Side.CLIENT) {
			Render_HUDVehicleEvent renderevent = new Render_HUDVehicleEvent(minecraft);
			if (entityplayer.func_184187_bx() instanceof EntityVehicleBase
					&& entityplayer.func_184187_bx() != null) {// 1
				EntityVehicleBase balaam = (EntityVehicleBase) entityplayer.func_184187_bx();
				GuiIngame g = minecraft.field_71456_v;
				
				{
					boolean kc = mod_GVCLib.proxy.keyc();
					if (kc) {
						if(!key_true) {
							key_true = true;
							if(minecraft.field_71474_y.field_74320_O == 0) {
								minecraft.field_71474_y.field_74320_O = 1;
							}
							else if(minecraft.field_71474_y.field_74320_O == 1) {
								minecraft.field_71474_y.field_74320_O = 0;
							}
						}
					}else{
						key_true = false;
					}
				}
				
			} // 1

		}

	}
}
