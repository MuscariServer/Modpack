package gvclib.event;

import java.util.List;
import gvclib.entity.EntityBBase;
import gvclib.entity.EntityB_Grapple;
import gvclib.item.ItemArmor_Grapple;
import gvclib.item.ItemArmor_NewObj;
import gvclib.mod_GVCLib;
import gvclib.network.GVCLMessageKeyPressed;
import gvclib.network.GVCLPacketHandler;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.MoverType;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.init.MobEffects;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.DamageSource;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.World;
import net.minecraftforge.event.entity.living.LivingEvent.LivingUpdateEvent;
import net.minecraftforge.event.entity.living.LivingFallEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;


import gvclib.mod_GVCLib;
import gvclib.entity.EntityBBase;
import gvclib.entity.EntityB_Grapple;
import gvclib.item.ItemArmor_Grapple;
import gvclib.item.ItemArmor_NewObj;
import gvclib.network.GVCLMessageKeyPressed;
import gvclib.network.GVCLPacketHandler;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.MoverType;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.init.MobEffects;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.DamageSource;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.World;
import net.minecraftforge.event.entity.living.LivingEvent.LivingUpdateEvent;
import net.minecraftforge.event.entity.living.LivingFallEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class GVCEventLivingArmor {
	
	@SubscribeEvent
	public void onUpdateEvent_Debag(LivingUpdateEvent event) {
		World worldIn = event.getEntityLiving().field_70170_p;
		EntityLivingBase target = event.getEntityLiving();
		
		//grapple
		if (target != null && target instanceof EntityPlayer) {
			EntityPlayer player = (EntityPlayer) target;
			if(player != null && mod_GVCLib.cfg_debag) {
				ItemStack head = player.func_184582_a(EntityEquipmentSlot.HEAD);
				if ((!head.func_190926_b()) && (head.func_77973_b() == Items.field_151169_ag)) {//head
					if(worldIn.func_72820_D() > 10000) {
						worldIn.func_72877_b(1000);
					}
					if(worldIn.func_72912_H().func_76059_o()) {
						//worldIn.getWorldInfo().setRainTime(0);
						//worldIn.getWorldInfo().setCleanWeatherTime(2000);
						worldIn.func_72912_H().func_176142_i(0);
						worldIn.func_72912_H().func_76080_g(0);
						worldIn.func_72912_H().func_76090_f(0);
						worldIn.func_72912_H().func_76084_b(false);
						worldIn.func_72912_H().func_76069_a(false);
					}
				}
				ItemStack body = player.func_184582_a(EntityEquipmentSlot.CHEST);
				if ((!body.func_190926_b()) && (body.func_77973_b() == Items.field_151171_ah)) {//head
					player.func_70690_d(new PotionEffect(MobEffects.field_76439_r, 2000, 2000, false, false));
				}
				player.field_70170_p.func_82736_K().func_82764_b("keepInventory", "true");
			}
			if(player != null && mod_GVCLib.cfg_debag_weather) {
				if(worldIn.func_72820_D() > 10000) {
					worldIn.func_72877_b(1000);
				}
				if(worldIn.func_72912_H().func_76059_o()) {
					//worldIn.getWorldInfo().setRainTime(0);
					//worldIn.getWorldInfo().setCleanWeatherTime(2000);
					worldIn.func_72912_H().func_176142_i(0);
					worldIn.func_72912_H().func_76080_g(0);
					worldIn.func_72912_H().func_76090_f(0);
					worldIn.func_72912_H().func_76084_b(false);
					worldIn.func_72912_H().func_76069_a(false);
				}
				player.field_70170_p.func_82736_K().func_82764_b("keepInventory", "true");
			}
		}
	}
	
	@SubscribeEvent
	public void onUpdateEvent(LivingUpdateEvent event) {
		World worldIn = event.getEntityLiving().field_70170_p;
		EntityLivingBase target = event.getEntityLiving();
		
		//grapple
		if (target != null && target instanceof EntityPlayer) {
			EntityPlayer player = (EntityPlayer) target;
			if(player != null) {
				if ((!player.func_184582_a(EntityEquipmentSlot.LEGS).func_190926_b())
						&& (player.func_184582_a(EntityEquipmentSlot.LEGS).func_77973_b() instanceof ItemArmor_Grapple)
						) {//head
					ItemArmor_Grapple grapplei = (ItemArmor_Grapple) player.func_184582_a(EntityEquipmentSlot.LEGS).func_77973_b();
					if (mod_GVCLib.proxy.keyc() 
							&& player.func_184811_cZ().func_185143_a(player.func_184582_a(EntityEquipmentSlot.LEGS).func_77973_b(), 0) == 0
							&& !player.func_184218_aH()) {
						GVCLPacketHandler.INSTANCE.sendToServer(new GVCLMessageKeyPressed(201, player.func_145782_y()));
					}
					if(grapplei.point && !player.func_184218_aH()) {
						EntityB_Grapple gra = null;
						{
							double x = target.field_70165_t;
							double y = target.field_70163_u;
							double z = target.field_70161_v;
							int han = 120;
							AxisAlignedBB aabb = (new AxisAlignedBB((double) (x - han), (double) (y - han),
									(double) (z - han),
									(double) (x + han), (double) (y + han), (double) (z + han)))
											.func_186662_g(1);
					        List llist2 = target.field_70170_p.func_72839_b(target, aabb);
					        if(llist2!=null){
					            for (int lj = 0; lj < llist2.size(); lj++) {
					            	Entity entity1 = (Entity)llist2.get(lj);
					                {
					            		if (entity1 instanceof EntityB_Grapple && entity1 != null)
					                    {
					            			EntityB_Grapple g = (EntityB_Grapple) entity1;
					            			if(g.isOwner(target)) {
					            				gra = g;
					            				break;
					            			}
					                    }
					                }
					            }
					        }
						}
						if(gra != null && gra.canmove) 
						{
							double d5 = (gra.field_70165_t) - target.field_70165_t;
							double d7 = (gra.field_70161_v) - target.field_70161_v;
							float yawset = -((float) Math.atan2(d5, d7)) * 180.0F / (float) Math.PI;
							float yaw = yawset * (2 * (float) Math.PI / 360);
							double mox = 0;
							double moy = 0;
							double moz = 0;
							mox -= MathHelper.func_76126_a(yaw) * 0.3;
							moz += MathHelper.func_76134_b(yaw) * 0.3;
							double ddx = Math.abs(d5);
							double ddz = Math.abs(d7);
							double d6 = (gra.field_70163_u) - target.field_70163_u;
							if(d6 > 0) {
								/*if (!(ddx > 3 || ddz > 3))
								{
									moy = 0.1;
								}else {
									moy = 0.1;
								}*/
								moy = 0.1;
							}else {
								//moy = -0.1;
							}
						
						target.field_70159_w = mox;
						target.field_70181_x = moy;
						target.field_70179_y = moz;
						target.func_70091_d(MoverType.PLAYER, target.field_70159_w, target.field_70181_x, target.field_70179_y);
						//if(!player.getItemStackFromSlot(EntityEquipmentSlot.LEGS).getItem()
						//.onEntitySwing(player, player.getItemStackFromSlot(EntityEquipmentSlot.LEGS)))
						//if(player.isSwingInProgress) 
						}
						if(player.func_70093_af()) 
						{
							GVCLPacketHandler.INSTANCE.sendToServer(new GVCLMessageKeyPressed(202));
							grapplei.point = false;
							{//list
								double x = player.field_70165_t;
								double y = player.field_70163_u;
								double z = player.field_70161_v;
								int han = 120;
								AxisAlignedBB aabb = (new AxisAlignedBB((double) (x - han), (double) (y - han),
										(double) (z - han),
										(double) (x + han), (double) (y + han), (double) (z + han)))
												.func_186662_g(1);
								List<EntityB_Grapple> llist = player.field_70170_p.func_72872_a(EntityB_Grapple.class,
										aabb);
								if (llist != null) {
									for (int lj = 0; lj < llist.size(); lj++) {
										EntityB_Grapple entity1 = (EntityB_Grapple) llist.get(lj);
										//if (entity1 != null && entity1.getThrower() != null && entity1.getThrower() == player) 
										if (entity1 != null) {
											entity1.func_70106_y();
										}
									}
								}
								
							}//list
						}
					}
				}
			}
		}//grapple
		
	}
	
	
	@SubscribeEvent
	public void ArmorLiving(LivingFallEvent event) {
		// if(eevent.getSide().isClient())
		{
			EntityLivingBase entityLiving = event.getEntityLiving();
			NBTTagCompound nbt = entityLiving.getEntityData();
			boolean para = nbt.func_74767_n("Para");
			if ((entityLiving.func_184582_a(EntityEquipmentSlot.HEAD) != null)
					&& (entityLiving.func_184582_a(EntityEquipmentSlot.HEAD).func_77973_b() instanceof ItemArmor_NewObj)) {
				ItemArmor_NewObj armor = (ItemArmor_NewObj) entityLiving.func_184582_a(EntityEquipmentSlot.HEAD).func_77973_b();
				if(armor.fall || para){
					event.setDistance(0.0F);
				}
			}
			if ((entityLiving.func_184582_a(EntityEquipmentSlot.CHEST) != null)
					&& (entityLiving.func_184582_a(EntityEquipmentSlot.CHEST).func_77973_b() instanceof ItemArmor_NewObj)) {
				ItemArmor_NewObj armor = (ItemArmor_NewObj) entityLiving.func_184582_a(EntityEquipmentSlot.CHEST).func_77973_b();
				if(armor.fall || para){
					event.setDistance(0.0F);
				}
			}
			if ((entityLiving.func_184582_a(EntityEquipmentSlot.LEGS) != null)
					&& (entityLiving.func_184582_a(EntityEquipmentSlot.LEGS).func_77973_b() instanceof ItemArmor_NewObj)) {
				ItemArmor_NewObj armor = (ItemArmor_NewObj) entityLiving.func_184582_a(EntityEquipmentSlot.LEGS).func_77973_b();
				if(armor.fall || para){
					event.setDistance(0.0F);
				}
			}
			if ((entityLiving.func_184582_a(EntityEquipmentSlot.FEET) != null)
					&& (entityLiving.func_184582_a(EntityEquipmentSlot.FEET).func_77973_b() instanceof ItemArmor_NewObj)) {
				ItemArmor_NewObj armor = (ItemArmor_NewObj) entityLiving.func_184582_a(EntityEquipmentSlot.FEET).func_77973_b();
				if(armor.fall || para){
					event.setDistance(0.0F);
				}
			}
		}
	}
	
	@SubscribeEvent
	public void onLivingMob(LivingUpdateEvent event) {
		EntityLivingBase target = event.getEntityLiving();
		if (target != null) {
			if ((target.func_184582_a(EntityEquipmentSlot.HEAD) != null)
					&& (target.func_184582_a(EntityEquipmentSlot.HEAD).func_77973_b() instanceof ItemArmor_NewObj)) {
				ItemArmor_NewObj armor = (ItemArmor_NewObj) target.func_184582_a(EntityEquipmentSlot.HEAD).func_77973_b();
				
			}
			else if ((target.func_184582_a(EntityEquipmentSlot.CHEST) != null)
					&& (target.func_184582_a(EntityEquipmentSlot.CHEST).func_77973_b() instanceof ItemArmor_NewObj)) {
				ItemArmor_NewObj armor = (ItemArmor_NewObj) target.func_184582_a(EntityEquipmentSlot.CHEST).func_77973_b();
				
			}
			else if ((target.func_184582_a(EntityEquipmentSlot.LEGS) != null)
					&& (target.func_184582_a(EntityEquipmentSlot.LEGS).func_77973_b() instanceof ItemArmor_NewObj)) {
				ItemArmor_NewObj armor = (ItemArmor_NewObj) target.func_184582_a(EntityEquipmentSlot.LEGS).func_77973_b();
				
			}
			else if ((target.func_184582_a(EntityEquipmentSlot.FEET) != null)
					&& (target.func_184582_a(EntityEquipmentSlot.FEET).func_77973_b() instanceof ItemArmor_NewObj)) {
				ItemArmor_NewObj armor = (ItemArmor_NewObj) target.func_184582_a(EntityEquipmentSlot.FEET).func_77973_b();
				
			}else{
				NBTTagCompound nbt = target.getEntityData();
				nbt.func_74757_a("Para", false);
			}
		}
	}
	
	@SubscribeEvent
	public void onLivingPara(LivingUpdateEvent event) {
		EntityLivingBase target = event.getEntityLiving();
		if (target != null) {
			NBTTagCompound nbt = target.getEntityData();
			boolean para = nbt.func_74767_n("Para");
			boolean b = false;
			double m = 1;
			double paraspeed = 0.75;
			//if(!(target instanceof EntityPlayer))
			{
				if ((target.func_184582_a(EntityEquipmentSlot.HEAD) != null)
						&& (target.func_184582_a(EntityEquipmentSlot.HEAD).func_77973_b() instanceof ItemArmor_NewObj)) {
					ItemArmor_NewObj armor = (ItemArmor_NewObj) target.func_184582_a(EntityEquipmentSlot.HEAD).func_77973_b();
					if(armor.booster){
						b = true;
					//	this.ArmorMove(target, armor, 4);
					}
					m = armor.motion;
					if(target.func_70093_af() && armor.para){
						para = true;
						paraspeed = armor.paraspeed;
					}
				}
				if ((target.func_184582_a(EntityEquipmentSlot.CHEST) != null)
						&& (target.func_184582_a(EntityEquipmentSlot.CHEST).func_77973_b() instanceof ItemArmor_NewObj)) {
					ItemArmor_NewObj armor = (ItemArmor_NewObj) target.func_184582_a(EntityEquipmentSlot.CHEST).func_77973_b();
					if(armor.booster){
						b = true;
					//	this.ArmorMove(target, armor, 3);
					}
					if(m < armor.motion){
						m = armor.motion;
					}
					if(target.func_70093_af() && armor.para){
						para = true;
						paraspeed = armor.paraspeed;
					}
				}
				if ((target.func_184582_a(EntityEquipmentSlot.LEGS) != null)
						&& (target.func_184582_a(EntityEquipmentSlot.LEGS).func_77973_b() instanceof ItemArmor_NewObj)) {
					ItemArmor_NewObj armor = (ItemArmor_NewObj) target.func_184582_a(EntityEquipmentSlot.LEGS).func_77973_b();
					if(armor.booster){
						b = true;
					//	this.ArmorMove(target, armor, 2);
					}
					if(m < armor.motion){
						m = armor.motion;
					}
					if(target.func_70093_af() && armor.para){
						para = true;
						paraspeed = armor.paraspeed;
					}
				}
				if ((target.func_184582_a(EntityEquipmentSlot.FEET) != null)
						&& (target.func_184582_a(EntityEquipmentSlot.FEET).func_77973_b() instanceof ItemArmor_NewObj)) {
					ItemArmor_NewObj armor = (ItemArmor_NewObj) target.func_184582_a(EntityEquipmentSlot.FEET).func_77973_b();
					if(armor.booster){
						b = true;
					//	this.ArmorMove(target, armor, 1);
					}
					if(m < armor.motion){
						m = armor.motion;
					}
					if(target.func_70093_af() && armor.para){
						para = true;
						paraspeed = armor.paraspeed;
					}
				}
				
				{
					target.field_70159_w *= m;
					target.field_70179_y *= m;
				}
				
				if(para){
					target.field_70181_x *= paraspeed;
					if(target.field_82175_bq){
						para = false;
					}
				}
				BlockPos bp = target.field_70170_p.func_175645_m(new BlockPos(target.field_70165_t, target.field_70163_u, target.field_70161_v));
				int genY = bp.func_177956_o() + 3;
				if(target != null && !(target instanceof EntityPlayer)){
					if(target.field_70163_u > genY){
						para = true;
					}
				}
				if(target.field_70122_E){
					para = false;
				}
				nbt.func_74757_a("Para", para);
			}
			
		}
	}
	
	
	
	@SubscribeEvent
	public void onHurtEvent(LivingHurtEvent event) {
		EntityLivingBase target = event.getEntityLiving();
		DamageSource source = event.getSource();
		float damage = event.getAmount();
		if (target != null) 
		{
			if(source.func_76364_f() instanceof EntityBBase)
	        {
				if (target instanceof EntityPlayer) {
					EntityPlayer player = (EntityPlayer) target;
					damage = damage / 4.0F;

			        if (damage < 1.0F)
			        {
			            damage = 1.0F;
			        }
					ItemStack head = player.func_184582_a(EntityEquipmentSlot.HEAD);
					if(!head.func_190926_b() && head.func_77973_b() instanceof ItemArmor) {
						head.func_77972_a(-(int)damage, player);
						//System.out.println(String.format("0"));
					}
					ItemStack chest = player.func_184582_a(EntityEquipmentSlot.CHEST);
					if(!chest.func_190926_b() && chest.func_77973_b() instanceof ItemArmor) {
						chest.func_77972_a(-(int)damage, player);
					}
					ItemStack legs = player.func_184582_a(EntityEquipmentSlot.LEGS);
					if(!legs.func_190926_b() && legs.func_77973_b() instanceof ItemArmor) {
						legs.func_77972_a(-(int)damage, player);
					}
					ItemStack feet = player.func_184582_a(EntityEquipmentSlot.FEET);
					if(!feet.func_190926_b() && feet.func_77973_b() instanceof ItemArmor) {
						feet.func_77972_a(-(int)damage, player);
					}
					/*for (int i = 0; i < 36; ++i)
			        {
			            ItemStack itemstack = player.inventory.getStackInSlot(i);

			            if (itemstack.getItem() instanceof ItemArmor)
			            {
			                itemstack.damageItem(-(int)damage, player);
			            }
			        }*/
				}
	        }
		}
	}
	
	
	
}
