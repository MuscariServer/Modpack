package gvclib.event.gun;

import org.lwjgl.opengl.GL11;
import gvclib.entity.living.EntityGVCLivingBase;
import gvclib.item.ItemGunBase;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ModelBiped;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.block.model.ItemCameraTransforms;
import net.minecraft.client.renderer.entity.RenderLivingBase;
import net.minecraft.client.renderer.entity.layers.LayerHeldItem;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumHandSide;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import objmodel.AdvancedModelLoader;
import objmodel.IModelCustom;


import gvclib.mod_GVCLib;
import gvclib.entity.living.EntityGVCLivingBase;
import gvclib.item.ItemGunBase;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ModelBiped;
import net.minecraft.client.renderer.GLAllocation;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.block.model.ItemCameraTransforms;
import net.minecraft.client.renderer.entity.RenderLivingBase;
import net.minecraft.client.renderer.entity.layers.LayerHeldItem;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumHandSide;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import objmodel.AdvancedModelLoader;
import objmodel.IModelCustom;

@SideOnly(Side.CLIENT)
public class LayerGunBase extends LayerHeldItem//implements LayerRenderer<EntityLivingBase>
{
    protected final RenderLivingBase<?> livingEntityRenderer;

    private static final ResourceLocation rightt = new ResourceLocation("gvclib:textures/model/Right.png");
	private static final IModelCustom rightm = AdvancedModelLoader.loadModel(new ResourceLocation("gvclib:textures/model/Right.mqo"));
	private static final ResourceLocation lasert = new ResourceLocation("gvclib:textures/model/RightLaser.png");
	private static final IModelCustom laserm = AdvancedModelLoader.loadModel(new ResourceLocation("gvclib:textures/model/RightLaser.mqo"));
    
    public LayerGunBase(RenderLivingBase<?> livingEntityRendererIn)
    {
    	super(livingEntityRendererIn);
        this.livingEntityRenderer = livingEntityRendererIn;
        //GL11.glScalef(5F, 5F, 5F);
    }

    public void func_177141_a(EntityLivingBase entitylivingbaseIn, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch, float scale)
    {
    	//GL11.glScalef(5F, 5F, 5F);
        boolean flag = entitylivingbaseIn.func_184591_cq() == EnumHandSide.RIGHT;
        ItemStack itemstack = flag ? entitylivingbaseIn.func_184592_cb() : entitylivingbaseIn.func_184614_ca();
        ItemStack itemstack1 = flag ? entitylivingbaseIn.func_184614_ca() : entitylivingbaseIn.func_184592_cb();

        if (!itemstack.func_190926_b() || !itemstack1.func_190926_b())
        {
            GlStateManager.func_179094_E();

            if (this.livingEntityRenderer.func_177087_b().field_78091_s)
            {
                float f = 0.5F;
                GlStateManager.func_179109_b(0.0F, 0.625F, 0.0F);
                GlStateManager.func_179114_b(-20.0F, -1.0F, 0.0F, 0.0F);
                GlStateManager.func_179152_a(0.5F, 0.5F, 0.5F);
            }
            
            this.renderHeldItem(entitylivingbaseIn, itemstack1, ItemCameraTransforms.TransformType.THIRD_PERSON_RIGHT_HAND, EnumHandSide.RIGHT);
            this.renderHeldItem(entitylivingbaseIn, itemstack, ItemCameraTransforms.TransformType.THIRD_PERSON_LEFT_HAND, EnumHandSide.LEFT);
            GlStateManager.func_179121_F();
            
        }
    }

    //public static int gllist =  GLAllocation.generateDisplayLists(1);
    
    private void renderHeldItem(EntityLivingBase p_188358_1_, ItemStack itemstack, ItemCameraTransforms.TransformType p_188358_3_, EnumHandSide handSide)
    {
        if (!itemstack.func_190926_b())
        {
            GlStateManager.func_179094_E();
            if (p_188358_1_.func_70093_af())
            {
                GlStateManager.func_179109_b(0.0F, 0.2F, 0.0F);
            }
            if (p_188358_1_ instanceof EntityGVCLivingBase && p_188358_1_ != null) {
             	EntityGVCLivingBase en = (EntityGVCLivingBase) p_188358_1_;
             	if (en.getSneak())
                {
                    GlStateManager.func_179109_b(0.0F, 0.2F, 0.0F);
                }
            }
            // Forge: moved this call down, fixes incorrect offset while sneaking.
            ModelBiped model = (ModelBiped)this.livingEntityRenderer.func_177087_b();
            model.field_178724_i.field_78807_k = false;
            model.field_178721_j.field_78807_k = false;
            ((ModelBiped)this.livingEntityRenderer.func_177087_b()).func_187073_a(0.0625F, handSide);
            GlStateManager.func_179114_b(-90.0F, 1.0F, 0.0F, 0.0F);
            
            //GlStateManager.rotate(180.0F, 0.0F, 1.0F, 0.0F);
            GL11.glScalef(0.1875F, 0.1875F, 0.1875F);
            boolean flag = handSide == EnumHandSide.LEFT;
            GlStateManager.func_179109_b((float)((flag ? -1 : 1) / 16.0F) * -5.33F, 0.125F * 1.33F, -0.625F * -4.5F);//-5.33,-3.33,-4.5
            //GlStateManager.translate((float)(flag ? -1 : 1) / 16.0F, 0.125F, -0.625F);
            //Minecraft.getMinecraft().getItemRenderer().renderItemSide(p_188358_1_, p_188358_2_, p_188358_3_, flag);
            if (!itemstack.func_190926_b() && itemstack.func_77973_b() instanceof ItemGunBase) {//item
				ItemGunBase gun = (ItemGunBase) itemstack.func_77973_b();
				if (p_188358_1_ instanceof EntityGVCLivingBase && p_188358_1_ != null) {
	             	EntityGVCLivingBase en = (EntityGVCLivingBase) p_188358_1_;
	             	if (!en.getattacktask())
	                {
	             		if (!itemstack.func_190926_b() && itemstack.func_77973_b() instanceof ItemGunBase) {//item
	             			//ItemGunBase gun = (ItemGunBase) itemstack.getItem();
	             			if(gun != null && gun.arm_l_posz > -1.0F) {
	             				GlStateManager.func_179114_b(80.0F, 0.0F, 1.0F, 0.0F);
	             				GlStateManager.func_179114_b(-50.0F, 0.0F, 0.0F, 1.0F);
	             			}
	             		}
	                }
	            }
				{
					//GL11.glNewList(gllist, GL11.GL_COMPILE);
					Minecraft.func_71410_x().field_71446_o.func_110577_a(new ResourceLocation(gun.obj_tex));
					gun.obj_model.renderPart("mat1");
					gun.obj_model.renderPart("mat100");
					gun.obj_model.renderPart("mat2");
					gun.obj_model.renderPart("mat3");
					Layermat.rendersight( p_188358_1_,  itemstack,  gun);
					Layermat.renderattachment( p_188358_1_,  itemstack,  gun);
					gun.obj_model.renderPart("mat25");
					gun.obj_model.renderPart("mat31");
					gun.obj_model.renderPart("mat32");/**/
					//GL11.glEndList();
				}
				//GL11.glCallList(gllist);
				
			//GVCEventsGunRender.rendermat(p_188358_1_, itemstack, gun);
			/*GL11.glPushMatrix();//right
			GL11.glEnable(GL11.GL_BLEND);
			GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
			if(gun.rightmode && gun.true_mat7) {
				GL11.glColor4f(1F, 1F, 1F, 0.2F);
				GL11.glTranslatef(gun.rightposx, gun.rightposy, gun.rightposz);
				Minecraft.getMinecraft().renderEngine.bindTexture(rightt);
				rightm.renderAll();
				GL11.glColor4f(1F, 1F, 1F, 1F);
			}
			if(gun.rightmode && gun.true_mat6) {
				GL11.glColor4f(1F, 1F, 1F, 0.5F);
				GL11.glTranslatef(gun.rightposx, gun.rightposy, gun.rightposz);
				Minecraft.getMinecraft().renderEngine.bindTexture(lasert);
				laserm.renderAll();
				GL11.glColor4f(1F, 1F, 1F, 1F);
			}
			GL11.glPopMatrix();//right*/
            }
            GlStateManager.func_179121_F();
        }
    }

    
    
    public boolean func_177142_b()
    {
        return false;
    }
}
