package gvclib.event.gun;

import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL12;
import gvclib.event.RenderTextEvent;
import gvclib.item.ItemGunBase;
import gvclib.item.gunbase.IGun_Shield;
import gvclib.item.gunbase.IGun_Sword;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelBiped;
import net.minecraft.client.model.ModelPlayer;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.entity.RenderPlayer;
import net.minecraft.client.renderer.texture.TextureMap;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.World;
import net.minecraftforge.client.GuiIngameForge;
import net.minecraftforge.client.event.FOVUpdateEvent;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.client.event.RenderLivingEvent;
import net.minecraftforge.client.event.RenderPlayerEvent;
import net.minecraftforge.fml.client.FMLClientHandler;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;


import gvclib.event.RenderTextEvent;
import gvclib.item.ItemGunBase;
import gvclib.item.gunbase.IGun_Shield;
import gvclib.item.gunbase.IGun_Sword;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelBiped;
import net.minecraft.client.model.ModelPlayer;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.entity.RenderPlayer;
import net.minecraft.client.renderer.texture.TextureMap;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.World;
import net.minecraftforge.client.GuiIngameForge;
import net.minecraftforge.client.event.EntityViewRenderEvent;
import net.minecraftforge.client.event.FOVUpdateEvent;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.client.event.RenderLivingEvent;
import net.minecraftforge.client.event.RenderPlayerEvent;
import net.minecraftforge.fml.client.FMLClientHandler;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
//import net.minecraftforge.fml.common.registry.LanguageRegistry;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import objmodel.AdvancedModelLoader;
import objmodel.IModelCustom;

public class GVCEventsGunZoom {

	//public String ads;

	public boolean zoomtype;
	private RenderGameOverlayEvent eventParent;
	
	@SideOnly(Side.CLIENT)
    @SubscribeEvent
	  public void renderfov(FOVUpdateEvent event)
	  {
		Minecraft minecraft = FMLClientHandler.instance().getClient();
		EntityPlayer entityplayer = minecraft.field_71439_g;
		ItemStack itemstack = ((EntityPlayer) (entityplayer)).func_184614_ca();
		if (!itemstack.func_190926_b() && itemstack.func_77973_b() instanceof ItemGunBase) {//item
			ItemGunBase gun = (ItemGunBase) itemstack.func_77973_b();
			if (entityplayer.func_70093_af()) {
				if (itemstack.func_77973_b() == gun && gun.scopezoom > 1.0) {
					NBTTagCompound nbt = itemstack.func_77978_p();
					if(!itemstack.func_77942_o())return;
					boolean am_sight = nbt.func_74767_n("am_sight");
					if(am_sight){
						event.setNewfov(event.getFov() / nbt.func_74760_g("scopezoom"));
					}else {
						event.setNewfov(event.getFov() / gun.scopezoom);
					}
				}
			}
		}//item
	  }
	
	/*
	private static final ResourceLocation defence = new ResourceLocation("gvclib:textures/marker/marker0.png");
    private static final IModelCustom doll_class = AdvancedModelLoader.loadModel(new ResourceLocation("gvclib:textures/marker/newmarker.mqo"));
	@SideOnly(Side.CLIENT)
    @SubscribeEvent
	  public void renderTest(EntityViewRenderEvent.RenderFogEvent event)
	  {
		Minecraft minecraft = FMLClientHandler.instance().getClient();
		EntityPlayer entityplayer = minecraft.player;
		ItemStack itemstack = ((EntityPlayer) (entityplayer)).getHeldItemMainhand();
		Entity entity = event.getEntity();
		if(entity != null && entity instanceof EntityLivingBase) {
			GL11.glPushMatrix();
			//GL11.glPushAttrib(GL11.GL_ALL_ATTRIB_BITS);
			GL11.glTranslatef((float) entity.posX, (float) entity.posY, (float) entity.posZ);
			RenderManager manager = minecraft.getRenderManager();
			GlStateManager.rotate(-manager.playerViewY, 0.0F, 1.0F, 0.0F);
			GL11.glEnable(GL12.GL_RESCALE_NORMAL);
			{
				GL11.glTranslatef(0, entity.height + 0.5F, 0);
				GlStateManager.disableLighting();
				Minecraft.getMinecraft().renderEngine.bindTexture(defence);
				doll_class.renderPart("mat1");
				GlStateManager.enableLighting();
			}
			GL11.glDisable(GL12.GL_RESCALE_NORMAL);
			//GL11.glPopAttrib();
			GL11.glPopMatrix();
		}
	  }*/
	
	/*@SideOnly(Side.CLIENT)
    @SubscribeEvent
	  public void renderfov(EntityViewRenderEvent.FOVModifier event)
	  {
		Minecraft minecraft = FMLClientHandler.instance().getClient();
		EntityPlayer entityplayer = minecraft.thePlayer;
		ItemStack itemstack = ((EntityPlayer) (entityplayer)).getHeldItemMainhand();
		if (!itemstack.isEmpty() && itemstack.getItem() instanceof ItemGunBase) {//item
			ItemGunBase gun = (ItemGunBase) itemstack.getItem();
			if (entityplayer.isSneaking()) {
				if (!itemstack.isEmpty() && itemstack.getItem() == gun && gun.scopezoom > 1.0) {
					event.setFOV(event.getFOV() / gun.scopezoom);
				}
			}
		}//item
	  }*/
	
	@SideOnly(Side.CLIENT)
    @SubscribeEvent
	  public void renderLiving(RenderPlayerEvent.Post event)
	  {
		ItemStack itemstack = event.getEntityPlayer().func_184614_ca();
		RenderPlayer renderplayer = event.getRenderer();
		if(!itemstack.func_190926_b() && itemstack.func_77973_b() instanceof ItemGunBase)
		{
			//ModelBiped.ArmPose modelbiped$armpose = ModelBiped.ArmPose.EMPTY;
			//modelbiped$armpose = ModelBiped.ArmPose.BOW_AND_ARROW;
			//renderplayer.getMainModel().rightArmPose =  ModelBiped.ArmPose.BOW_AND_ARROW;
			ModelPlayer modelplayer = renderplayer.func_177087_b();
		//	modelplayer.bipedRightArm.rotateAngleY = modelplayer.bipedRightArm.rotateAngleY +90;
		//	modelplayer.rightArmPose = modelplayer.rightArmPose.BOW_AND_ARROW;
		//	modelplayer.leftArmPose = ModelBiped.ArmPose.EMPTY;
			/*{
				modelplayer.bipedRightArm.rotateAngleY = -0.1F + modelplayer.bipedHead.rotateAngleY;
				modelplayer.bipedLeftArm.rotateAngleY = 0.1F + modelplayer.bipedHead.rotateAngleY + 0.4F;
				modelplayer.bipedRightArm.rotateAngleX = -((float)Math.PI / 2F) + modelplayer.bipedHead.rotateAngleX;
				modelplayer.bipedLeftArm.rotateAngleX = -((float)Math.PI / 2F) + modelplayer.bipedHead.rotateAngleX;
			}/**/
			//renderplayer.modelArmor.aimedBow = renderplayer.modelArmorChestplate.aimedBow = renderplayer.modelBipedMain.aimedBow = true;
		//	renderplayer.modelArmor.isRiding = renderplayer.modelArmorChestplate.isRiding = renderplayer.modelBipedMain.isRiding = true;
			
		}
	  }
	
	@SideOnly(Side.CLIENT)
    @SubscribeEvent
	  public void renderLiving_arm(RenderLivingEvent.Pre event)
	  {
		ModelBase mainModel = event.getRenderer().func_177087_b();
	    EntityLivingBase entity = event.getEntity();
	    if(mainModel instanceof ModelBiped) {
	    	ModelBiped biped = (ModelBiped) mainModel;
	    	ItemStack main = entity.func_184614_ca();
	    	ItemStack off = entity.func_184592_cb();
	    	if(!main.func_190926_b() && main.func_77973_b() instanceof ItemGunBase)
			{
	    		biped.field_187076_m = biped.field_187076_m.BOW_AND_ARROW;
	    		biped.field_187075_l = biped.field_187075_l.BOW_AND_ARROW;
			}
	    	if(!off.func_190926_b() && off.func_77973_b() instanceof ItemGunBase)
			{
	    		biped.field_187076_m = biped.field_187076_m.BOW_AND_ARROW;
	    		biped.field_187075_l = biped.field_187075_l.BOW_AND_ARROW;
			}
	    }
	  }
	
	@SideOnly(Side.CLIENT)
	@SubscribeEvent
	public void onEvent(RenderGameOverlayEvent.Text event) {
		Minecraft minecraft = FMLClientHandler.instance().getClient();
		World world = FMLClientHandler.instance().getWorldClient();
		ScaledResolution scaledresolution = new ScaledResolution(minecraft);
		int i = scaledresolution.func_78326_a();
		int j = scaledresolution.func_78328_b();
		EntityPlayer entityplayer = minecraft.field_71439_g;
		ItemStack itemstack = ((EntityPlayer) (entityplayer)).func_184614_ca();
		ItemStack itemstackl = ((EntityPlayer) (entityplayer)).func_184592_cb();
		FontRenderer fontrenderer = minecraft.field_71466_p;
		minecraft.field_71460_t.func_78478_c();
		// OpenGlHelper.
		
		
		// GL11.glEnable(GL11.GL_BLEND);
		if (FMLCommonHandler.instance().getSide() == Side.CLIENT) {
			RenderTextEvent renderevent = new RenderTextEvent(minecraft);
			boolean main = false;
			//cross_hair
			if (!itemstack.func_190926_b() && itemstack.func_77973_b() instanceof ItemGunBase) {
				ItemGunBase gun = (ItemGunBase) itemstack.func_77973_b();
				if(!entityplayer.func_70093_af() || gun.render_cross_sneak) {
					if(gun.render_gvc_cross && 
							(!(itemstack.func_77973_b() instanceof IGun_Sword) && !(itemstack.func_77973_b() instanceof IGun_Shield)))
						renderevent.rendergun_cross(itemstack, gun, i, j);
					main = true;
				}
			}
			if (!itemstackl.func_190926_b() && itemstackl.func_77973_b() instanceof ItemGunBase) {
				ItemGunBase gun = (ItemGunBase) itemstackl.func_77973_b();
				if(!main) {
					if(!entityplayer.func_70093_af() || gun.render_cross_sneak) {
						if(gun.render_gvc_cross && 
								(!(itemstackl.func_77973_b() instanceof IGun_Sword) && !(itemstackl.func_77973_b() instanceof IGun_Shield)))
							renderevent.rendergun_cross(itemstackl, gun, i, j);
					}
				}
			}
			
			//
			if (!itemstackl.func_190926_b() && itemstackl.func_77973_b() instanceof ItemGunBase) {
				ItemGunBase gun = (ItemGunBase) itemstackl.func_77973_b();
				
				String ads = "gvclib:textures/misc/scope.png";
				
				renderevent.rendergunl(itemstackl, gun, 0, j);
				
			}
			if (!itemstack.func_190926_b() && itemstack.func_77973_b() instanceof ItemGunBase) {
				ItemGunBase gun = (ItemGunBase) itemstack.func_77973_b();
				
				String ads = "gvclib:textures/misc/scope.png";
				
				renderevent.rendergun(itemstack, gun, i, j);
				{
					GL11.glPushMatrix();
					GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
					if(gun.mitarget != null) {
						FontRenderer fontReader = Minecraft.func_71410_x().field_71466_p;
						//fontReader.drawString("Lock", i/2, j/2 + 0, 0xFFFFFF);
					}
					GL11.glPopMatrix();
				}
				
				boolean zoomrender;
				NBTTagCompound nbt = itemstack.func_77978_p();
				if(!itemstack.func_77942_o())return;
				boolean am_sight = nbt.func_74767_n("am_sight");
				if(am_sight){
					//zoomrender = gun.am_zoomrendertex;
					zoomrender = nbt.func_74767_n("am_zoomrendertex");
				}else{
					if(gun.true_mat4){
						zoomrender = gun.zoomrert;
					}else if(gun.true_mat5){
						zoomrender = gun.zoomrest;
					}else{
						//zoomrender = gun.model_zoomrender;
						zoomrender = gun.zoomrent;
					}
				}
				
				
				if (entityplayer.func_70093_af() && minecraft.field_71474_y.field_74320_O == 0) {
					//if (!itemstack.isEmpty() && itemstack.getItem() == gun && gun.scopezoom > 1.0) {
					if (!itemstack.func_190926_b() && itemstack.func_77973_b() == gun) {
						if(am_sight){
							//ads = gun.am_ads_tex;
							ads = nbt.func_74779_i("am_ads_tex");
						}else{
							if(gun.true_mat4){
								if(gun.zoomrert){
									ads = gun.adstexturer;
								}
							}else if(gun.true_mat5){
								if(gun.zoomrest){
									ads = gun.adstextures;
								}
							}else{
								if(gun.zoomrent){
									ads = gun.adstexture;
								}
							}
						}
						
						
						
						//ads = "gvclib:textures/misc/scope.png";

						GlStateManager.func_179147_l();
						GL11.glEnable(GL11.GL_BLEND);
						// GL11.glPushAttrib(GL11.GL_ALL_ATTRIB_BITS);//11
						GL11.glPushMatrix();// 12
						GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
						minecraft.field_71446_o.func_110577_a(TextureMap.field_110575_b);
						GL11.glPushMatrix();// 13
						GlStateManager.func_187428_a(GlStateManager.SourceFactor.SRC_ALPHA,
								GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE,
								GlStateManager.DestFactor.ZERO);
						if(zoomrender){
							this.renderPumpkinBlur(minecraft, scaledresolution, ads);
						}
						GL11.glPopMatrix();// 13
						GL11.glPopMatrix();// 12
						// GL11.glPopAttrib();//11
						GlStateManager.func_179084_k();

					} else if (!itemstack.func_190926_b() && itemstack.func_77973_b() instanceof Item) {
					}
				}
				
				GuiIngameForge.renderCrosshairs = gun.rendercross;
				this.zoomtype = true;
				
				{
					NBTTagCompound nbt_entity = entityplayer.getEntityData();
					int setting = nbt_entity.func_74762_e("Gun_Setting");
					
					FontRenderer fontReader = minecraft.field_71466_p;
					GL11.glPushMatrix();
					GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
					GlStateManager.func_187428_a(GlStateManager.SourceFactor.SRC_ALPHA,
							GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE,
							GlStateManager.DestFactor.ZERO);
					minecraft.field_71446_o.func_110577_a(TextureMap.field_110575_b);
					String dx = String.valueOf(gun.model_x_ads);
					String dy = String.valueOf(gun.model_y_ads);
					String dz = String.valueOf(gun.model_z_ads);
					
					String dx7 = String.valueOf((gun.model_x_ads - 1.388F) / (-2));
					String dy7 = String.valueOf((gun.model_y_ads + 3.6796F) / (2.096F));
					String dz7 = String.valueOf((gun.model_z_ads + 1.5F) / (-1.25F));
					
					String dxr = String.valueOf(gun.model_x_adsr);
					String dyr = String.valueOf(gun.model_y_adsr);
					String dzr = String.valueOf(gun.model_z_adsr);
					
					String dxr7 = String.valueOf((gun.model_x_adsr - 1.388F) / (-2));
					String dyr7 = String.valueOf((gun.model_y_adsr + 3.6796F) / (2.096F));
					String dzr7 = String.valueOf((gun.model_z_adsr + 1.5F) / (-1.25F));
					
					String dxs = String.valueOf(gun.model_x_adss);
					String dys = String.valueOf(gun.model_y_adss);
					String dzs = String.valueOf(gun.model_z_adss);
					
					String dxs7 = String.valueOf((gun.model_x_adss - 1.388F) / (-2));
					String dys7 = String.valueOf((gun.model_y_adss + 3.6796F) / (2.096F));
					String dzs7 = String.valueOf((gun.model_z_adss + 1.5F) / (-1.25F));
					
					String dxal = String.valueOf(gun.arm_l_posx);
					String dyal = String.valueOf(gun.arm_l_posy);
					String dzal = String.valueOf(gun.arm_l_posz);
					
					String dxal7 = String.valueOf((gun.arm_l_posx));
					String dyal7 = String.valueOf((gun.arm_l_posy - 0.75F) / (-2.5F));
					String dzal7 = String.valueOf((gun.arm_l_posz + 2.5716F) / (-2.143F));
					if(setting == 1){
						fontReader.func_78276_b("ads_non", scaledresolution.func_78326_a()/2 - 80,  
								scaledresolution.func_78328_b()/2 - 10, 0xFFFFFF);
						fontReader.func_78276_b("ads_x"+ "("+ dx7 + ")" + dx, scaledresolution.func_78326_a()/2 - 80,  
								scaledresolution.func_78328_b()/2 + 00, 0xFFFFFF);
						fontReader.func_78276_b("ads_y"+ "("+ dy7 + ")" + dy, scaledresolution.func_78326_a()/2 - 80,  
								scaledresolution.func_78328_b()/2 + 10, 0xFFFFFF);
						fontReader.func_78276_b("ads_z"+ "("+ dz7 + ")" + dz, scaledresolution.func_78326_a()/2 - 80,  
								scaledresolution.func_78328_b()/2 + 20, 0xFFFFFF);
					}else if(setting == 2){
						fontReader.func_78276_b("ads_reddot", scaledresolution.func_78326_a()/2 - 80,  
								scaledresolution.func_78328_b()/2 - 10, 0xFFFFFF);
						fontReader.func_78276_b("adsr_x"+ "("+ dxr7 + ")" + dxr, scaledresolution.func_78326_a()/2 - 80,  
								scaledresolution.func_78328_b()/2 + 00, 0xFFFFFF);
						fontReader.func_78276_b("adsr_y"+ "("+ dyr7 + ")" + dyr, scaledresolution.func_78326_a()/2 - 80,  
								scaledresolution.func_78328_b()/2 + 10, 0xFFFFFF);
						fontReader.func_78276_b("adsr_z"+ "("+ dzr7 + ")" + dzr, scaledresolution.func_78326_a()/2 - 80,  
								scaledresolution.func_78328_b()/2 + 20, 0xFFFFFF);
					}else if(setting == 3){
						fontReader.func_78276_b("ads_scope", scaledresolution.func_78326_a()/2 - 80,  
								scaledresolution.func_78328_b()/2 - 10, 0xFFFFFF);
						fontReader.func_78276_b("adss_x"+ "("+ dxs7 + ")" + dxs, scaledresolution.func_78326_a()/2 - 80,  
								scaledresolution.func_78328_b()/2 + 00, 0xFFFFFF);
						fontReader.func_78276_b("adss_y"+ "("+ dys7 + ")" + dys, scaledresolution.func_78326_a()/2 - 80,  
								scaledresolution.func_78328_b()/2 + 10, 0xFFFFFF);
						fontReader.func_78276_b("adss_z"+ "("+ dzs7 + ")" + dzs, scaledresolution.func_78326_a()/2 - 80,  
								scaledresolution.func_78328_b()/2 + 20, 0xFFFFFF);
					}else if(setting == 4){
						fontReader.func_78276_b("Arm_left", scaledresolution.func_78326_a()/2 - 80,  
								scaledresolution.func_78328_b()/2 - 10, 0xFFFFFF);
						fontReader.func_78276_b("Arm_left_x"+ "("+ dxal7 + ")" + dxal, scaledresolution.func_78326_a()/2 - 80,  
								scaledresolution.func_78328_b()/2 + 00, 0xFFFFFF);
						fontReader.func_78276_b("Arm_left_y"+ "("+ dyal7 + ")" + dyal, scaledresolution.func_78326_a()/2 - 80,  
								scaledresolution.func_78328_b()/2 + 10, 0xFFFFFF);
						fontReader.func_78276_b("Arm_left_z"+ "("+ dzal7 + ")" + dzal, scaledresolution.func_78326_a()/2 - 80,  
								scaledresolution.func_78328_b()/2 + 20, 0xFFFFFF);
					}
					
					GL11.glPopMatrix();
				}
				
			} else {
				if (this.zoomtype == true) {
					this.zoomtype = false;
					GuiIngameForge.renderCrosshairs = true;
				}

			}
			
		}
	}

	@SideOnly(Side.CLIENT)
	protected void renderPumpkinBlur(Minecraft minecraft, ScaledResolution scaledRes, String adss) {
		GlStateManager.func_179097_i();
		GlStateManager.func_179132_a(false);
		GlStateManager.func_187428_a(GlStateManager.SourceFactor.SRC_ALPHA,
				GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE,
				GlStateManager.DestFactor.ZERO);
		GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
		GlStateManager.func_179118_c();
		minecraft.func_110434_K().func_110577_a(new ResourceLocation(adss));
		Tessellator tessellator = Tessellator.func_178181_a();
		BufferBuilder bufferbuilder = tessellator.func_178180_c();
        bufferbuilder.func_181668_a(7, DefaultVertexFormats.field_181707_g);
        bufferbuilder.func_181662_b(0.0D, (double)scaledRes.func_78328_b(), -90.0D).func_187315_a(0.0D, 1.0D).func_181675_d();
        bufferbuilder.func_181662_b((double)scaledRes.func_78326_a(), (double)scaledRes.func_78328_b(), -90.0D).func_187315_a(1.0D, 1.0D).func_181675_d();
        bufferbuilder.func_181662_b((double)scaledRes.func_78326_a(), 0.0D, -90.0D).func_187315_a(1.0D, 0.0D).func_181675_d();
        bufferbuilder.func_181662_b(0.0D, 0.0D, -90.0D).func_187315_a(0.0D, 0.0D).func_181675_d();
		tessellator.func_78381_a();
		GlStateManager.func_179132_a(true);
		GlStateManager.func_179126_j();
		GlStateManager.func_179141_d();
		GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
	}
}
