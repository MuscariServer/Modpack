package gvclib.event;

import gvclib.mod_GVCLib;
import gvclib.entity.EntityBBase;
import gvclib.entity.EntityB_BulletAA;
import gvclib.entity.EntityB_Shell;
import gvclib.entity.living.EntityGVCLivingBase;
import gvclib.network.GVCLClientMessageKeyPressed;
import gvclib.network.GVCLMessageKeyPressed;
import gvclib.network.GVCLPacketHandler;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.DamageSource;
import net.minecraftforge.event.entity.EntityMountEvent;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingEvent.LivingUpdateEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.living.LivingKnockBackEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class GVCEventDamege {
	
	@SubscribeEvent
	public void onKnockBackEvent(LivingKnockBackEvent event) {
		EntityLivingBase target = event.getEntityLiving();
		
		if (target instanceof EntityLivingBase && target != null) 
		{
			Entity entity = event.getAttacker();
			DamageSource source = target.func_189748_bU();
	    	//if(event.getAttacker() instanceof EntityBBase && entity != null)
			if(source != null)
	        {
	    		//EntityBBase bullet = (EntityBBase) event.getAttacker();
	    		if(source.func_76355_l().equals("thrown") || source.func_76355_l().equals("newapbullet")) {
	    			event.setStrength(0);
		    		//event.isCanceled();
	    		}
	        }
		}
	}
	
	/*@SubscribeEvent
	public void onDropEvent(PlayerDropsEvent event) {
		EntityPlayer target = event.getEntityPlayer();
		if (target instanceof EntityPlayer && target != null) 
		{
			//target.captureDrops = true;
			target.capturedDrops.add((EntityItem) event.getDrops());
			//event.isCanceled();
		}
	}*/
	
	/*@SubscribeEvent
	public void onHurtAttackEvent(LivingAttackEvent event) {
		EntityLivingBase target = event.getEntityLiving();
		DamageSource source = event.getSource();
		float damage = event.getAmount();
		boolean hitbullet = false;
    	if(source != null && source.isExplosion())
        {
    		{
    			if(target instanceof EntityPlayer){
    				float hp = target.getHealth();
    				float dame = target.getHealth() - event.getAmount();
    				System.out.println(String.format("3"));
    				if(hp >= target.getMaxHealth() * 0.75 && dame <= 0) 
    				{
    					//event.a(19);
    					target.hurtResistantTime = 50;
    					System.out.println(String.format("4"));
    					event.isCancelable();
    				}
    			}
    		}
        }
    	//if(entity instanceof EntityBBase && entity != null)
    	if(source.getImmediateSource() instanceof EntityBBase)
        {
    		{
    			if(target instanceof EntityPlayer){
    				float hp = target.getHealth();
    				float dame = target.getHealth() - event.getAmount();
    				System.out.println(String.format("1"));
    				if(hp >= target.getMaxHealth() * 0.75 && dame <= 0) {
    					//event.setAmount(19);
    					target.hurtResistantTime = 50;
    					System.out.println(String.format("2"));
    				}
    			}
    		}
        }
	}*/
	
	
	
	
	@SubscribeEvent
	public void onRiddingMountEvent(LivingUpdateEvent event) {
		Entity target = event.getEntityLiving();
		//Entity ride = event.getEntityBeingMounted();
		if (target != null && target instanceof EntityPlayer) 
		{
			EntityPlayer player = (EntityPlayer) target;
			if (player.func_184187_bx() instanceof EntityGVCLivingBase && player.func_184187_bx() != null) {// 1
				EntityGVCLivingBase vehicle = (EntityGVCLivingBase) player.func_184187_bx();
				if(!vehicle.ridding_sneakdismount) {
					boolean kz = mod_GVCLib.proxy.keyz();
					if (kz) {
						GVCLPacketHandler.INSTANCE.sendToServer(new GVCLMessageKeyPressed(17, vehicle.func_145782_y()));
					}
					if(vehicle.serverz) {
						if (player.func_184218_aH())
				        {
							player.func_184210_p();
				        }
						vehicle.serverz = false;
					}
				}
			}
		}
	}
	
	@SubscribeEvent
	public void onRiddingDisMountEvent(EntityMountEvent event) {
		Entity target = event.getEntityMounting();
		Entity ride = event.getEntityBeingMounted();
		if (target != null && target instanceof EntityPlayer) 
		{
			EntityPlayer player = (EntityPlayer) target;
			if(ride != null && ride instanceof EntityGVCLivingBase) {
				EntityGVCLivingBase vehicle = (EntityGVCLivingBase)ride;
				if(!vehicle.ridding_sneakdismount) {
					if(player.func_70093_af()) {
						event.setCanceled(true);
					}
				}
			}
		}
	}
	
	/*
	@SubscribeEvent
	public void onRiddingDisMountEvent(EntityMountEvent event) {
		Entity target = event.getEntityMounting();
		Entity ride = event.getEntityBeingMounted();
		if (target != null && target instanceof EntityPlayer) 
		{
			EntityPlayer player = (EntityPlayer) target;
			if(ride != null && ride instanceof EntityBoat) {
					if(player.isSneaking()) {
						event.setCanceled(true);
					}
			}
		}
	}*/
	
	@SubscribeEvent
	public void onDifficulty_level_adjustment(LivingHurtEvent event) {
		EntityLivingBase target = event.getEntityLiving();
		DamageSource source = event.getSource();
		float damage = event.getAmount();
		if (target instanceof EntityGVCLivingBase && target != null) 
		{
			EntityGVCLivingBase en = (EntityGVCLivingBase) target;
			if(target.func_184179_bs() != null && target.func_184179_bs() instanceof EntityPlayer) {
				if(en.difficulty_adjustment) {
    				float v = 0.5F;
    				int level = target.field_70170_p.func_175659_aa().func_151525_a();
    				if(level == 1) {
    					v = 0.2F;
    				}else if(level == 2) {
    					v = 0.5F;
    				}else if(level == 3) {
    					v = 1F;
    				}
    				event.setAmount(event.getAmount() * v);
    			}
			}
			/*if (target.getRidingEntity() instanceof EntityGVCLivingBase && target.getRidingEntity() != null) {
    			EntityGVCLivingBase en = (EntityGVCLivingBase) target.getRidingEntity();
    			if(en.difficulty_adjustment) {
    				float v = 0.5F;
    				int level = target.world.getDifficulty().getDifficultyId();
    				if(level == 1) {
    					v = 0.5F;
    				}else if(level == 2) {
    					v = 0.75F;
    				}else if(level == 3) {
    					v = 1F;
    				}
    				event.setAmount(event.getAmount() * v);
    			}
    		}*/
		}
	}
	
	
	
	@SubscribeEvent
	public void onHeadShotEvent(LivingHurtEvent event) {
		EntityLivingBase target = event.getEntityLiving();
		DamageSource source = event.getSource();
		float damage = event.getAmount();
		if (target instanceof EntityLivingBase && target != null) 
		{
			Entity entity = source.func_76346_g();
	    	if(source.func_76364_f() instanceof EntityBBase && entity != null)
	        {
	    		EntityBBase bullet = (EntityBBase) source.func_76364_f();
	    		double target_eye = target.func_70047_e() + target.field_70163_u;
	    		if(target.field_70131_O >= 1.6F && target.field_70131_O <= 2.0F && target.field_70130_N >= 0.4F && target.field_70130_N <= 0.7F) {
	    			if(bullet.field_70163_u >= target_eye - 0.25F) {
	    				event.setAmount(event.getAmount() * 1.5F);
	    				if(entity != null && entity instanceof EntityPlayer){
	    		    		EntityPlayer player = (EntityPlayer) entity;
	    		    		if(player != null){
	    		    			GVCLPacketHandler.INSTANCE2.sendToAll(new GVCLClientMessageKeyPressed(11, player.func_145782_y()));
	    		    		}
	    		    	}
	    			}
	    		}
	        }
		}
	}
	
	//試験的に付けてみる
	//ダメそうなら
	@SubscribeEvent
	public void onDeadEvent(LivingDeathEvent event) {
		EntityLivingBase target = event.getEntityLiving();
		DamageSource source = event.getSource();
		if (target instanceof EntityLivingBase && target != null) 
		{
			Entity entity = source.func_76346_g();
			if(entity != null && entity instanceof EntityPlayer){
	    		EntityPlayer player = (EntityPlayer) entity;
	    		if(player != null){
	    			GVCLPacketHandler.INSTANCE2.sendToAll(new GVCLClientMessageKeyPressed(9, player.func_145782_y()));
	    		}
	    	}
		}
	}
	
	@SubscribeEvent
	public void onHurtEvent(LivingHurtEvent event) {
		EntityLivingBase target = event.getEntityLiving();
		DamageSource source = event.getSource();
		float damage = event.getAmount();
		if (target instanceof EntityLivingBase && target != null) 
		{
			Entity entity = source.func_76346_g();
	    	if(source.func_76364_f() instanceof EntityBBase && entity != null)
	        {
	    		EntityBBase bullet = (EntityBBase) source.func_76364_f();
	    		if(bullet.getThrower() != null){
	    	//		GVCLPacketHandler.INSTANCE.sendToServer(new GVCLMessageKeyPressed(10, bullet.getThrower().getEntityId()));
	    		}
	        }
	    	
	    	if(mod_GVCLib.cfg_Instant_death_avoidance){
	    		if(source != null && source.func_94541_c())
		        {
		    		{
		    			if(target instanceof EntityPlayer){
		    				float hp = target.func_110143_aJ();
		    				float dame = target.func_110143_aJ() - event.getAmount();
		    				//System.out.println(String.format("5"));
		    				if(hp >= target.func_110138_aP() * 0.75 && dame <= 0) 
		    				{
		    					event.setAmount(target.func_110138_aP() - 1);
		    					//System.out.println(String.format("6"));
		    				}
		    			}
		    		}
		        }
		    	//if(entity instanceof EntityBBase && entity != null)
		    	if(source.func_76364_f() instanceof EntityBBase)
		        {
					if (target instanceof EntityPlayer) {
						float hp = target.func_110143_aJ();
						float dame = target.func_110143_aJ() - event.getAmount();
						//System.out.println(String.format("7"));
						if (target.func_189748_bU() != null && target.func_189748_bU().func_94541_c()) {
							event.setAmount(0);
							//System.out.println(String.format("10"));
						} else if (hp >= target.func_110138_aP() * 0.75 && dame <= 0) {
							event.setAmount(event.getAmount() * 0.25F);
							//System.out.println(String.format("8"));
						}
					}
		        }
	    	}
	    	
	    	
	    	if(entity != null && entity instanceof EntityPlayer){
	    		EntityPlayer player = (EntityPlayer) entity;
	    		if(player != null){
	    			float hp = target.func_110143_aJ() - event.getAmount();
	    			if(hp <= 0F) 
	    			{
	    				if(event.getAmount() > 0) {
	    					GVCLPacketHandler.INSTANCE2.sendToAll(new GVCLClientMessageKeyPressed(9, player.func_145782_y()));
	    				}
	    			}else 
	    			{
	    				if(event.getAmount() > 0) {
	    					GVCLPacketHandler.INSTANCE2.sendToAll(new GVCLClientMessageKeyPressed(10, player.func_145782_y()));
	    				}
	    			}
	    			
	    		}
	    	}
	    	{
	    		/*if(entity != null && entity instanceof EntityMDFBase){
	    			event.setAmount(0);
	    		}*/
	    		if (target.func_184187_bx() instanceof EntityGVCLivingBase && target.func_184187_bx() != null) {
	    			EntityGVCLivingBase en = (EntityGVCLivingBase) target.func_184187_bx();
	    			if(entity != null) {
	    				if(!en.riddng_opentop && !(source.func_76364_f() instanceof EntityB_Shell 
	    						|| source.func_76364_f() instanceof EntityB_BulletAA)) {
	    					if(source.func_76364_f() instanceof EntityBBase) {
	    						EntityBBase bullet = (EntityBBase) source.func_76364_f();
	    						if(bullet.bulletDameID == 1 || bullet.bulletDameID == 3) {
	    							event.setAmount(event.getAmount() * en.ridding_damege);
	    						}else {
	    							event.setAmount(0);
	    						}
	    					}else {
	    						event.setAmount(0);
			    				//event.isCancelable();
	    					}
		    			}else if(en.riddng_opentop){
		    				event.setAmount(event.getAmount() * en.ridding_damege);
		    			}
		    			if(!en.riddng_opentop && source.func_76364_f() instanceof EntityB_Shell 
		    					|| source.func_76364_f() instanceof EntityB_BulletAA){
		    				event.setAmount(event.getAmount() * en.ridding_damege);
		    			}
	    			}
	    			if(source != null && source.field_76373_n.equals("explosion")) {
	    				event.setAmount(event.getAmount() * en.ridding_damege);
	    			}
	    			
	    		}
	    	}
		}
		/*if (target instanceof EntityPlayer && target != null) 
		{
			if (target.ridingEntity instanceof EntityMobBases && target.ridingEntity != null) 
			{
				EntityMobBases en = (EntityMobBases) target.ridingEntity;
				if (target != null && source.getEntity() instanceof EntityLivingBase) {
					EntityLivingBase attacker = (EntityLivingBase) source.getEntity();
					if (attacker != null) {
						event.ammount = 0;
					}
				}
				if (target != null && source.isExplosion() && !en.opentop) {
					event.ammount = 0;
				}
			}
		}*/
	}

	@SubscribeEvent
	public void onLivingFromHurtEvent(LivingAttackEvent event) {
		EntityLivingBase target = event.getEntityLiving();
		DamageSource source = event.getSource();
		float damage = event.getAmount();
		if (target instanceof EntityLivingBase && target != null) 
		{
			Entity entity = source.func_76346_g();

			if (target.func_184187_bx() instanceof EntityGVCLivingBase && target.func_184187_bx() != null) {
				EntityGVCLivingBase en = (EntityGVCLivingBase) target.func_184187_bx();
				if (entity != null) {
					if (!en.riddng_opentop && !(source.func_76364_f() instanceof EntityB_Shell
							|| source.func_76364_f() instanceof EntityB_BulletAA)) {
						if (source.func_76364_f() instanceof EntityBBase) {
							EntityBBase bullet = (EntityBBase) source.func_76364_f();
							if (bullet.bulletDameID == 1 || bullet.bulletDameID == 3) {
								//event.setAmount(event.getAmount() * en.ridding_damege);
							} else {
								event.setCanceled(true);
							}
						} else {
							event.setCanceled(true);
							//event.isCancelable();
						}
					} else if (en.riddng_opentop) {
						//event.setAmount(event.getAmount() * en.ridding_damege);
					}
					if (!en.riddng_opentop && source.func_76364_f() instanceof EntityB_Shell
							|| source.func_76364_f() instanceof EntityB_BulletAA) {
						//event.setAmount(event.getAmount() * en.ridding_damege);
					}
				}
				if (source != null && source.field_76373_n.equals("explosion")) {
					//event.setAmount(event.getAmount() * en.ridding_damege);
				}

			}
		}
	}
	/*@SubscribeEvent
	public void onLivingEvent(LivingEvent event) {
		EntityLivingBase target = event.getEntityLiving();
		if (target instanceof EntityLivingBase && target != null) 
		{
			DamageSource source = target.getLastDamageSource();
			if(source !=null) {
				Entity entity = source.getImmediateSource();
				if(entity != null && entity instanceof EntityPlayer){
		    		EntityPlayer player = (EntityPlayer) entity;
		    		if(player != null){
		    			float hp = target.getHealth();
		    			if(hp < 0F) 
		    			{
		    				GVCLPacketHandler.INSTANCE.sendToServer(new GVCLMessageKeyPressed(9, player.getEntityId()));
		    			}
		    			
		    		}
		    	}
			}
	    	
		}
	}
	*/
	/*@SubscribeEvent
	public void onPEvent(PlayerEvent event) {
		EntityPlayer player = event.getEntityPlayer();
		if (player.getRidingEntity() instanceof EntityLivingBase && player.getRidingEntity() != null) {// 1
			player.setSneaking(false);
		}
		
		
	}*/
	
}
