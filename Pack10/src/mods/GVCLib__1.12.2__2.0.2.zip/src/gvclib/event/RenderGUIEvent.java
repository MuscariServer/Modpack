package gvclib.event;

import org.lwjgl.opengl.GL11;
import gvclib.entity.living.EntityGVCLivingBase;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.ResourceLocation;


import gvclib.entity.living.EntityGVCLivingBase;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.ResourceLocation;

public class RenderGUIEvent extends Gui {

	private final static ResourceLocation overlayTimerSun = new ResourceLocation(
			"hmggvc:textures/misc/ironsight_ak74.png");

	private final static int DAY_WIDTH = 34;
	private final static int DAY_HEIGHT = 34;

	private Minecraft mc;
	private int iii;

	public RenderGUIEvent(Minecraft mc) {
		this.mc = mc;
	}
	
	
	public void render(Minecraft minecraft, EntityGVCLivingBase balaam, EntityPlayer entityplayer, int i, int j, String tex) {
		FontRenderer fontrenderer = minecraft.field_71466_p;
		minecraft.field_71460_t.func_78478_c();
		ScaledResolution scaledresolution = new ScaledResolution(minecraft);

		int max = (int) balaam.func_110138_aP();
		int ima = (int) balaam.func_110143_aJ();
		GL11.glPushMatrix();//21
		GL11.glEnable(GL11.GL_BLEND);
		GL11.glColor4f(1.0F, 1.0F, 1.0F, 1F);
		GlStateManager.func_187428_a(GlStateManager.SourceFactor.SRC_ALPHA,
				GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE,
				GlStateManager.DestFactor.ZERO);
		mc.field_71446_o.func_110577_a(new ResourceLocation(tex));
		GL11.glTranslatef(0.5F,0.5F, 0F);
		float scale = 8;
		GL11.glScalef(1/scale, 1/scale, 1);//0.0625
		func_175174_a((scaledresolution.func_78326_a()/2-16)*scale,
				(scaledresolution.func_78328_b()/2-16)*scale, 0,0, 256, 256);
		GL11.glPopMatrix();//22
	}
	
	public void renderHori(Minecraft minecraft, EntityGVCLivingBase balaam, EntityPlayer entityplayer, int i, int j, String tex) {
		FontRenderer fontrenderer = minecraft.field_71466_p;
		minecraft.field_71460_t.func_78478_c();
		ScaledResolution scaledresolution = new ScaledResolution(minecraft);

		int max = (int) balaam.func_110138_aP();
		int ima = (int) balaam.func_110143_aJ();
		{
			GL11.glPushMatrix();//21
			GL11.glEnable(GL11.GL_BLEND);
			GL11.glColor4f(1.0F, 1.0F, 1.0F, 1F);
			GlStateManager.func_187428_a(GlStateManager.SourceFactor.SRC_ALPHA,
					GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE,
					GlStateManager.DestFactor.ZERO);
			mc.field_71446_o.func_110577_a(new ResourceLocation(tex));
			GL11.glTranslatef(0.5F,0.5F, 0F);
			//GL11.glTranslatef(0F,balaam.prevRotationPitch, 0F);
			float scale = 8;
			GL11.glScalef(1/scale, 1/scale, 1);//0.0625
			func_175174_a((scaledresolution.func_78326_a()/2-16)*scale,
					(scaledresolution.func_78328_b()/2-16 + balaam.field_70125_A)*scale, 0,0, 256, 256);
			GL11.glPopMatrix();//22
		}
	}
	
	public void render_bomber(Minecraft minecraft, EntityGVCLivingBase balaam, EntityPlayer entityplayer, int i, int j, String tex) {
		FontRenderer fontrenderer = minecraft.field_71466_p;
		minecraft.field_71460_t.func_78478_c();
		ScaledResolution scaledresolution = new ScaledResolution(minecraft);

		int max = (int) balaam.func_110138_aP();
		int ima = (int) balaam.func_110143_aJ();
		{
			GL11.glPushMatrix();//21
			GL11.glEnable(GL11.GL_BLEND);
			GL11.glColor4f(1.0F, 1.0F, 1.0F, 1F);
			GlStateManager.func_187428_a(GlStateManager.SourceFactor.SRC_ALPHA,
					GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE,
					GlStateManager.DestFactor.ZERO);
			mc.field_71446_o.func_110577_a(new ResourceLocation(tex));
			GL11.glTranslatef(0.5F,0.5F, 0F);
			//GL11.glTranslatef(0F,balaam.prevRotationPitch, 0F);
			float scale = 8;
			GL11.glScalef(1/scale, 1/scale, 1);//0.0625
			func_175174_a((scaledresolution.func_78326_a()/2-16)*scale,
					(scaledresolution.func_78328_b()/2-16 + 90 - balaam.field_70125_A)*scale, 0,0, 256, 256);
			GL11.glPopMatrix();//22
		}
	}
	
	public void render_Cruising_MODE(Minecraft minecraft, EntityGVCLivingBase balaam, EntityPlayer entityplayer, int i, int j) {
		FontRenderer fontrenderer = minecraft.field_71466_p;
		minecraft.field_71460_t.func_78478_c();
		ScaledResolution scaledresolution = new ScaledResolution(minecraft);

		int max = (int) balaam.func_110138_aP();
		int ima = (int) balaam.func_110143_aJ();
		{
			GL11.glPushMatrix();//21
			GL11.glEnable(GL11.GL_BLEND);
			GL11.glColor4f(1.0F, 1.0F, 1.0F, 1F);
			GlStateManager.func_187428_a(GlStateManager.SourceFactor.SRC_ALPHA,
					GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE,
					GlStateManager.DestFactor.ZERO);
			fontrenderer.func_78276_b("Cruising_MODE", i -30, j + 30 + 0, 0xFFFFFF);
			GL11.glPopMatrix();//22
		}
	}
}
