package gvclib.world;

import net.minecraft.world.EnumDifficulty;
import net.minecraft.world.World;

public class GVCEnumDifficulty_int
{
	public GVCEnumDifficulty_int() {
		
	}
	
	public static int intid(World world) {
		int en = 0;
		if(world.func_175659_aa() == EnumDifficulty.PEACEFUL) {
			en = 0;
		}
		if(world.func_175659_aa() == EnumDifficulty.EASY) {
			en = 1;
		}
		if(world.func_175659_aa() == EnumDifficulty.NORMAL) {
			en = 2;
		}
		if(world.func_175659_aa() == EnumDifficulty.HARD) {
			en = 3;
		}
		
		return en;
	}
}
