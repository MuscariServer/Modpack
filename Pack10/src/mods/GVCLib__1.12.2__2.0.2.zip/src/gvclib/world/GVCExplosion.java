package gvclib.world;

import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import gvclib.entity.EntityBBase;
import gvclib.entity.EntityTNTBase;
import gvclib.entity.EntityT_Flash;
import gvclib.mod_GVCLib;
import javax.annotation.Nullable;
import net.minecraft.block.Block;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.enchantment.EnchantmentProtection;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.item.EntityTNTPrimed;
import net.minecraft.entity.item.EntityXPOrb;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.SoundEvents;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.Explosion;
import net.minecraft.world.World;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;


import javax.annotation.Nullable;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;

import gvclib.mod_GVCLib;
import gvclib.entity.EntityBBase;
import gvclib.entity.EntityTNTBase;
import gvclib.entity.EntityT_Flash;
import net.minecraft.block.Block;
import net.minecraft.block.BlockStone;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.enchantment.EnchantmentProtection;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.item.EntityTNTPrimed;
import net.minecraft.entity.item.EntityXPOrb;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.SoundEvents;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.Explosion;
import net.minecraft.world.World;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public class GVCExplosion extends Explosion
{
	 /** whether or not the explosion sets fire to blocks around it */
    private final boolean causesFire;
    /** whether or not this explosion spawns smoke particles */
    private final boolean damagesTerrain;
    private final Random random;
    private final World world;
    private final double x;
    private final double y;
    private final double z;
    private final Entity exploder;
    private final float size;
    /** A list of ChunkPositions of blocks affected by this explosion */
    private final List<BlockPos> affectedBlockPositions;
    /** Maps players to the knockback vector applied by the explosion, to send to the client */
    private final Map<EntityPlayer, Vec3d> playerKnockbackMap;
    private final Vec3d position;

    @SideOnly(Side.CLIENT)
    public GVCExplosion(World worldIn, Entity entityIn, double x, double y, double z, float size, List<BlockPos> affectedPositions)
    {
        this(worldIn, entityIn, x, y, z, size, false, true, affectedPositions);
    }

    @SideOnly(Side.CLIENT)
    public GVCExplosion(World worldIn, Entity entityIn, double x, double y, double z, float size, boolean causesFire, boolean damagesTerrain, List<BlockPos> affectedPositions)
    {
        this(worldIn, entityIn, x, y, z, size, causesFire, damagesTerrain);
        this.affectedBlockPositions.addAll(affectedPositions);
    }

    public GVCExplosion(World worldIn, Entity entityIn, double x, double y, double z, float size, boolean flaming, boolean damagesTerrain)
    {
    	super(worldIn, entityIn, x, y, z, size, flaming, damagesTerrain);
        this.random = new Random();
        this.affectedBlockPositions = Lists.<BlockPos>newArrayList();
        this.playerKnockbackMap = Maps.<EntityPlayer, Vec3d>newHashMap();
        this.world = worldIn;
        this.exploder = entityIn;
        this.size = size;
        this.x = x;
        this.y = y;
        this.z = z;
        this.causesFire = flaming;
        this.damagesTerrain = damagesTerrain;
        this.position = new Vec3d(this.x, this.y, this.z);
    }

    /**
     * Does the first part of the explosion (destroy blocks)
     */
    public void func_77278_a()
    {
        Set<BlockPos> set = Sets.<BlockPos>newHashSet();
        int i = 16;

        for (int j = 0; j < 16; ++j)
        {
            for (int k = 0; k < 16; ++k)
            {
                for (int l = 0; l < 16; ++l)
                {
                    if (j == 0 || j == 15 || k == 0 || k == 15 || l == 0 || l == 15)
                    {
                        double d0 = (double)((float)j / 15.0F * 2.0F - 1.0F);
                        double d1 = (double)((float)k / 15.0F * 2.0F - 1.0F);
                        double d2 = (double)((float)l / 15.0F * 2.0F - 1.0F);
                        double d3 = Math.sqrt(d0 * d0 + d1 * d1 + d2 * d2);
                        d0 = d0 / d3;
                        d1 = d1 / d3;
                        d2 = d2 / d3;
                        float f = this.size * (0.7F + this.world.field_73012_v.nextFloat() * 0.6F);
                        double d4 = this.x;
                        double d6 = this.y;
                        double d8 = this.z;

                        for (float f1 = 0.3F; f > 0.0F; f -= 0.22500001F)
                        {
                            BlockPos blockpos = new BlockPos(d4, d6, d8);
                            IBlockState iblockstate = this.world.func_180495_p(blockpos);

                            if (iblockstate.func_185904_a() != Material.field_151579_a)
                            {
                                float f2 = this.exploder != null ? this.exploder.func_180428_a(this, this.world, blockpos, iblockstate) : iblockstate.func_177230_c().getExplosionResistance(world, blockpos, (Entity)null, this);
                                f -= (f2 + 0.3F) * 0.3F;
                            }

                            if (f > 0.0F && (this.exploder == null || this.exploder.func_174816_a(this, this.world, blockpos, iblockstate, f)))
                            {
                                set.add(blockpos);
                            }

                            d4 += d0 * 0.30000001192092896D;
                            d6 += d1 * 0.30000001192092896D;
                            d8 += d2 * 0.30000001192092896D;
                        }
                    }
                }
            }
        }

        this.affectedBlockPositions.addAll(set);
        float f3 = this.size * 2.0F;
        int k1 = MathHelper.func_76128_c(this.x - (double)f3 - 1.0D);
        int l1 = MathHelper.func_76128_c(this.x + (double)f3 + 1.0D);
        int i2 = MathHelper.func_76128_c(this.y - (double)f3 - 1.0D);
        int i1 = MathHelper.func_76128_c(this.y + (double)f3 + 1.0D);
        int j2 = MathHelper.func_76128_c(this.z - (double)f3 - 1.0D);
        int j1 = MathHelper.func_76128_c(this.z + (double)f3 + 1.0D);
        List<Entity> list = this.world.func_72839_b(this.exploder, new AxisAlignedBB((double)k1, (double)i2, (double)j2, (double)l1, (double)i1, (double)j1));
        net.minecraftforge.event.ForgeEventFactory.onExplosionDetonate(this.world, this, list, f3);
        Vec3d vec3d = new Vec3d(this.x, this.y, this.z);

        for (int k2 = 0; k2 < list.size(); ++k2)
        {
            Entity entity = list.get(k2);

            if (!entity.func_180427_aV())
            {
            	if (entity instanceof EntityItem) continue;
            	if (entity instanceof EntityBBase) continue;
            	if (entity instanceof EntityTNTBase) continue;
            	if (entity instanceof EntityXPOrb) continue;
            	if (entity instanceof EntityT_Flash) continue;
                double d12 = entity.func_70011_f(this.x, this.y, this.z) / (double)f3;

                if (d12 <= 1.0D)
                {
                    double d5 = entity.field_70165_t - this.x;
                    double d7 = entity.field_70163_u + (double)entity.func_70047_e() - this.y;
                    double d9 = entity.field_70161_v - this.z;
                    double d13 = (double)MathHelper.func_76133_a(d5 * d5 + d7 * d7 + d9 * d9);

                    if (d13 != 0.0D)
                    {
                        d5 = d5 / d13;
                        d7 = d7 / d13;
                        d9 = d9 / d13;
                        double d14 = (double)this.world.func_72842_a(vec3d, entity.func_174813_aQ());
                        double d10 = (1.0D - d12) * d14;
                        entity.field_70172_ad = 0;//add
                        entity.func_70097_a(DamageSource.func_94539_a(this), (float)((int)((d10 * d10 + d10) / 2.0D * 7.0D * (double)f3 + 1.0D)));
                        entity.field_70172_ad = 0;//add
                        double d11 = d10;

                        if (entity instanceof EntityLivingBase)
                        {
                            d11 = EnchantmentProtection.func_92092_a((EntityLivingBase)entity, d10);
                        }

                        entity.field_70159_w += d5 * d11;
                        entity.field_70181_x += d7 * d11;
                        entity.field_70179_y += d9 * d11;

                        if (entity instanceof EntityPlayer)
                        {
                            EntityPlayer entityplayer = (EntityPlayer)entity;

                            if (!entityplayer.func_175149_v() && (!entityplayer.func_184812_l_() || !entityplayer.field_71075_bZ.field_75100_b))
                            {
                                this.playerKnockbackMap.put(entityplayer, new Vec3d(d5 * d10, d7 * d10, d9 * d10));
                            }
                        }
                    }
                }
            }
        }
    }

    /**
     * Does the second part of the explosion (sound, particles, drop spawn)
     */
    public void func_77279_a(boolean spawnParticles)
    {
        this.world.func_184148_a((EntityPlayer)null, this.x, this.y, this.z, SoundEvents.field_187539_bB, SoundCategory.BLOCKS, 4.0F, (1.0F + (this.world.field_73012_v.nextFloat() - this.world.field_73012_v.nextFloat()) * 0.2F) * 0.7F);

        if (this.size >= 2.0F && this.damagesTerrain)
        {
            this.world.func_175688_a(EnumParticleTypes.EXPLOSION_HUGE, this.x, this.y, this.z, 1.0D, 0.0D, 0.0D);
        }
        else
        {
            this.world.func_175688_a(EnumParticleTypes.EXPLOSION_LARGE, this.x, this.y, this.z, 1.0D, 0.0D, 0.0D);
        }

        if (this.damagesTerrain)
        {
            for (BlockPos blockpos : this.affectedBlockPositions)
            {
            	
                IBlockState iblockstate = this.world.func_180495_p(blockpos);
                Block block = iblockstate.func_177230_c();
                if(mod_GVCLib.cfg_explotion_breakdirt) {
                	if (block.func_185467_w() == SoundType.field_185849_b) continue;
                    if (block.func_185467_w() == SoundType.field_185855_h) continue;
                    //if (block instanceof BlockStone) continue;
                    //if (block instanceof BlockDirt) continue;
                    if (block == Blocks.field_150348_b && block.func_176201_c(iblockstate) == 0) continue;
                }
                
                
                if (spawnParticles)
                {
                    double d0 = (double)((float)blockpos.func_177958_n() + this.world.field_73012_v.nextFloat());
                    double d1 = (double)((float)blockpos.func_177956_o() + this.world.field_73012_v.nextFloat());
                    double d2 = (double)((float)blockpos.func_177952_p() + this.world.field_73012_v.nextFloat());
                    double d3 = d0 - this.x;
                    double d4 = d1 - this.y;
                    double d5 = d2 - this.z;
                    double d6 = (double)MathHelper.func_76133_a(d3 * d3 + d4 * d4 + d5 * d5);
                    d3 = d3 / d6;
                    d4 = d4 / d6;
                    d5 = d5 / d6;
                    double d7 = 0.5D / (d6 / (double)this.size + 0.1D);
                    d7 = d7 * (double)(this.world.field_73012_v.nextFloat() * this.world.field_73012_v.nextFloat() + 0.3F);
                    d3 = d3 * d7;
                    d4 = d4 * d7;
                    d5 = d5 * d7;
                    this.world.func_175688_a(EnumParticleTypes.EXPLOSION_NORMAL, (d0 + this.x) / 2.0D, (d1 + this.y) / 2.0D, (d2 + this.z) / 2.0D, d3, d4, d5);
                    this.world.func_175688_a(EnumParticleTypes.SMOKE_NORMAL, d0, d1, d2, d3, d4, d5);
                }

                if (iblockstate.func_185904_a() != Material.field_151579_a)
                {
                    if (block.func_149659_a(this))
                    {
                    	if(block == Blocks.field_150354_m || block == Blocks.field_150346_d || block == Blocks.field_150349_c || block == Blocks.field_150424_aL) {
                    		//block.dropBlockAsItemWithChance(this.world, blockpos, this.world.getBlockState(blockpos), 1.0F / this.size, 0);
                    		block.func_180653_a(this.world, blockpos, this.world.func_180495_p(blockpos), 0, 0);
                    	}else {
                    		block.func_180653_a(this.world, blockpos, this.world.func_180495_p(blockpos), 1.0F * (float)mod_GVCLib.cfg_explotion_drop, 0);
                    	}
                        
                    }

                    block.onBlockExploded(this.world, blockpos, this);
                }
            }
        }

        if (this.causesFire)
        {
        	 if (this.damagesTerrain)
             {
        		 for (BlockPos blockpos1 : this.affectedBlockPositions)
                 {
                     if (this.world.func_180495_p(blockpos1).func_185904_a() == Material.field_151579_a && this.world.func_180495_p(blockpos1.func_177977_b()).func_185913_b() && this.random.nextInt(3) == 0)
                     {
                         this.world.func_175656_a(blockpos1, Blocks.field_150480_ab.func_176223_P());
                     }
                 }
             }else {
            	 for (BlockPos blockpos1 : this.affectedBlockPositions)
                 {
                     if (this.world.func_180495_p(blockpos1).func_185904_a() == Material.field_151579_a && this.world.func_180495_p(blockpos1.func_177977_b()).func_185913_b() && this.random.nextInt(3) == 0)
                     {
                         this.world.func_175656_a(blockpos1, mod_GVCLib.b_fire.func_176223_P());
                     }
                 }
             }
        }
    }

    public Map<EntityPlayer, Vec3d> func_77277_b()
    {
        return this.playerKnockbackMap;
    }

    /**
     * Returns either the entity that placed the explosive block, the entity that caused the explosion or null.
     */
    @Nullable
    public EntityLivingBase func_94613_c()
    {
        if (this.exploder == null)
        {
            return null;
        }
        else if (this.exploder instanceof EntityTNTPrimed)
        {
            return ((EntityTNTPrimed)this.exploder).func_94083_c();
        }
        else
        {
            return this.exploder instanceof EntityLivingBase ? (EntityLivingBase)this.exploder : null;
        }
    }

    public void func_180342_d()
    {
        this.affectedBlockPositions.clear();
    }

    public List<BlockPos> func_180343_e()
    {
        return this.affectedBlockPositions;
    }

    public Vec3d getPosition(){ return this.position; }
}
