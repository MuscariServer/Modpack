package gvclib.entity.living;

public interface ISoldier
{
}