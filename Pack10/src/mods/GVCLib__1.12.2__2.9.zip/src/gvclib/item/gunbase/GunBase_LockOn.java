package gvclib.item.gunbase;

import java.util.List;

import gvclib.item.ItemGunBase;
import gvclib.network.GVCLClientMessageKeyPressed;
import gvclib.network.GVCLPacketHandler;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.monster.IMob;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.MobEffects;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.Slot;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

public class GunBase_LockOn {

	public static void load(ItemGunBase gun, ItemStack itemstack, World world, Entity entity, int i, boolean flag) {

		if(gun.mitarget != null){
			//if(flag)System.out.println(String.format("mitarget"));
		}else {
			//if(flag)System.out.println(String.format("mitarget_null"));
		}
		
		
    	if(world.isRemote)return;
    	
    	if (gun.gun_type == 4 && entity instanceof EntityPlayer) {
    		EntityPlayer entityplayer = (EntityPlayer)entity;
    		NBTTagCompound nbt = entityplayer.getEntityData();
    		++gun.lockt;
    		Vec3d locken = entityplayer.getLookVec();
    		float d = 120;
    		if(gun.mitarget != null){
    //			gun.mitarget.addPotionEffect(new PotionEffect(MobEffects.GLOWING, 2, 1));
    			NBTTagCompound target_nbt = gun.mitarget.getEntityData();
    			if(target_nbt != null) {
    				target_nbt.setInteger("lockon", 100);
 //   				 System.out.println("1");
    				 GVCLPacketHandler.INSTANCE2.sendToAll(new GVCLClientMessageKeyPressed(61, gun.mitarget.getEntityId()));
    			}else {
    				//gun.mitarget.customEntityData = new NBTTagCompound();
    				//gun.mitarget.writeToNBT(new NBTTagCompound());
    				//gun.mitarget.set
    				//NBTTagCompound target_nbt2 = gun.mitarget.getEntityData();
    			}
			}
    		if(gun.lockt > 80) {
				boolean lock = false;
				for(int xxx = 0; xxx < d; ++xxx) {
					entityplayer.world.spawnParticle(EnumParticleTypes.CLOUD, entity.posX + locken.x * xxx-1, entity.posY + locken.y * xxx-1, entity.posZ + locken.z * xxx-1, 0.0D, 0.0D, 0.0D, new int[0]);
					AxisAlignedBB axisalignedbb = (new AxisAlignedBB(entity.posX + locken.x * xxx-1, entity.posY + locken.y * xxx-1, entity.posZ + locken.z * xxx-1, 
							entity.posX + locken.x * xxx+1, entity.posY + locken.y * xxx+1, entity.posZ + locken.z * xxx+1))
                    		.grow(1);
					List<Entity> llist = entityplayer.world.getEntitiesWithinAABBExcludingEntity(entityplayer,axisalignedbb);
    				if (llist != null) {
    					for (int lj = 0; lj < llist.size(); lj++) {
    						Entity entity1 = (Entity) llist.get(lj);
    						if (entity1.canBeCollidedWith()) {
    							//boolean flag = entity.getEntitySenses().canSee(entity1);
    							if (entity1 instanceof IMob && entity1 != null && entity1 != entityplayer
    									&& entity1 != entity && flag && entity1 == gun.mitarget) {
    								lock = true;
    								break;
    							}
    						}
    					}
    				}
				}
				/*{
					//List llist = entityplayer.world.getEntitiesWithinAABBExcludingEntity(entityplayer, entityplayer.getEntityBoundingBox()
			        //		.expand(entityplayer.motionX, entityplayer.motionY, entityplayer.motionZ).grow(120.0D));
					List<Entity> llist = entityplayer.world.getEntitiesWithinAABBExcludingEntity(entityplayer,
    						entityplayer.getEntityBoundingBox()
    								.expand(locken.x * d, locken.y * d, locken.z * d)
    								.grow(0.2D));
    				if (llist != null) {
    					for (int lj = 0; lj < llist.size(); lj++) {
    						Entity entity1 = (Entity) llist.get(lj);
    						if (entity1.canBeCollidedWith() && entity1 != null) {
    							if (entity1 instanceof Entity)
    	                        {
    								if (entity1 ==  gun.mitarget) 
    								//if (entity1 instanceof IMob) 
    								{
    						//			this.mitarget = (EntityLivingBase) entity1;
        								lock = true;
        								break;
        							}
    	                        }
    						}
    					}
    				}
    			}*/
				if(!lock) {
					gun.mitarget =null;
					GVCLPacketHandler.INSTANCE2.sendToAll(new GVCLClientMessageKeyPressed(62));
				}
			}
    		if(entity.isSneaking()){
    			
    			if(gun.mitarget ==null)
    			{
    				//GVCLPacketHandler.INSTANCE2.sendToAll(new GVCLClientMessageKeyPressed(62));
    				Entity getTarget = null;
    				for(int xxx = 0; xxx < d; ++xxx) {
    					//entityplayer.world.spawnParticle(EnumParticleTypes.CLOUD, entity.posX + locken.x * xxx-1, entity.posY + locken.y * xxx-1, entity.posZ + locken.z * xxx-1, 0.0D, 0.0D, 0.0D, new int[0]);
    					AxisAlignedBB axisalignedbb = (new AxisAlignedBB(entity.posX + locken.x * xxx-1, entity.posY + locken.y * xxx-1, entity.posZ + locken.z * xxx-1, 
    							entity.posX + locken.x * xxx+1, entity.posY + locken.y * xxx+1, entity.posZ + locken.z * xxx+1))
                        		.grow(1);
    					List<Entity> llist = entityplayer.world.getEntitiesWithinAABBExcludingEntity(entityplayer,axisalignedbb);
        				if (llist != null) {
        					for (int lj = 0; lj < llist.size(); lj++) {
        						Entity entity1 = (Entity) llist.get(lj);
        						if (entity1.canBeCollidedWith()) {
        							//boolean flag = entity.getEntitySenses().canSee(entity1);
        							if (entity1 instanceof IMob && entity1 != null && entity1 != entityplayer
        									&& entity1 != entity && flag) {
        								getTarget = entity1;
        								break;
        							}
        						}
        					}
        				}
    				}
    				if(getTarget != null) {
						if(getTarget.isRiding() && getTarget.getRidingEntity() != null && getTarget.getRidingEntity() instanceof EntityLivingBase) {
							EntityLivingBase en = (EntityLivingBase) getTarget.getRidingEntity();
							BlockPos bp = en.world.getHeight(new BlockPos(en.posX, en.posY, en.posZ));
							if(gun.aam && en.posY > bp.getY() + 5 && !en.onGround){
								gun.mitarget = (EntityLivingBase) en;
								gun.lockt = 0;
							}else if(en.posY < bp.getY() + 5){
								gun.mitarget = (EntityLivingBase) en;
								gun.lockt = 0;
							}
						}else {
							BlockPos bp = getTarget.world.getHeight(new BlockPos(getTarget.posX, getTarget.posY, getTarget.posZ));
							if(gun.aam && getTarget.posY > bp.getY() + 10 && !getTarget.onGround){
								gun.mitarget = (EntityLivingBase) getTarget;
								gun.lockt = 0;
							}else if(getTarget.posY < bp.getY() + 5){
								gun.mitarget = (EntityLivingBase) getTarget;
								gun.lockt = 0;
							}
						}
    				}
    				/*
    				//List llist = entity.world.getEntitiesWithinAABBExcludingEntity(entity, axisalignedbb);
    				List<Entity> llist = entityplayer.world.getEntitiesWithinAABBExcludingEntity(entityplayer,
    						entityplayer.getEntityBoundingBox()
    								.expand(locken.x * d, locken.y * d, locken.z * d)
    								.grow(0.002D));
    				if (llist != null) {
    					for (int lj = 0; lj < llist.size(); lj++) {
    						Entity entity1 = (Entity) llist.get(lj);
    						if (entity1.canBeCollidedWith()) {
    							//boolean flag = entity.getEntitySenses().canSee(entity1);
    							if (entity1 instanceof IMob && entity1 != null && entity1 != entityplayer
    									&& entity1 != entity && flag) {
    								if(entity1.isRiding() && entity1.getRidingEntity() != null && entity1.getRidingEntity() instanceof EntityLivingBase) {
    									EntityLivingBase en = (EntityLivingBase) entity1.getRidingEntity();
    									BlockPos bp = en.world.getHeight(new BlockPos(en.posX, en.posY, en.posZ));
        								if(gun.aam && en.posY > bp.getY() + 10 && !en.onGround){
        									gun.mitarget = (EntityLivingBase) en;
        									gun.lockt = 0;
        									break;
        								}else if(en.posY < bp.getY() + 5){
        									gun.mitarget = (EntityLivingBase) en;
        									gun.lockt = 0;
        									break;
        								}
    								}else {
    									BlockPos bp = entity1.world.getHeight(new BlockPos(entity1.posX, entity1.posY, entity1.posZ));
        								if(gun.aam && entity1.posY > bp.getY() + 10 && !entity1.onGround){
        									gun.mitarget = (EntityLivingBase) entity1;
        									gun.lockt = 0;
        									break;
        								}else if(entity1.posY < bp.getY() + 5){
        									gun.mitarget = (EntityLivingBase) entity1;
        									gun.lockt = 0;
        									break;
        								}
    								}
    							}
    						}
    					}
    				}*/
    			}
    			
    		}else {
    			
    		}
    		if (entity instanceof EntityPlayerMP) {
				EntityPlayerMP lep = (EntityPlayerMP) entity;
				Container lctr = lep.openContainer;
				for (int li2 = 0; li2 < lctr.inventorySlots.size(); li2++) {
					ItemStack li2s = ((Slot) lctr.getSlot(li2)).getStack();
					if (li2s == itemstack) {
						lctr.inventoryItemStacks.set(li2, itemstack.copy());
						break;
					}
				}
			}
			/*boolean lockon = false;
			if (flag && entityplayer.isSneaking()) {
				{
					{// 1
						List<Entity> llist = world.getEntitiesWithinAABBExcludingEntity(entityplayer,
								entityplayer.getEntityBoundingBox()
										.expand(entityplayer.motionX, entityplayer.motionY, entityplayer.motionZ)
										.grow(200.0D));
						if (llist != null) {
							for (int lj = 0; lj < llist.size(); lj++) {
								Entity entity1 = (Entity) llist.get(lj);
								if (entity1.canBeCollidedWith()) {
									if (entity1 != null)
									// if (entity1 instanceof EntityPlayer &&
									// entity1 != null )
									{
										// boolean flag =
										// this.getEntitySenses().canSee(entity1);
										if (entity1 instanceof IMob) {
											NBTTagCompound nbt = entity1.getEntityData();
											if (nbt.getInteger("LockOnTime") > 0) {
												lockon = true;
												break;
											} else {
												lockon = false;
											}
										}
									}
								}
							}
						}
					}
				}
				if (!lockon) {
					for (int l1 = 0; l1 < 100; l1++) {
						double x2 = 0;
						double z2 = 0;
						x2 -= MathHelper.sin(entityplayer.rotationYaw * 0.01745329252F) * l1;
						z2 += MathHelper.cos(entityplayer.rotationYaw * 0.01745329252F) * l1;
						double k = entityplayer.posX;
						double l = entityplayer.posY;
						double i1 = entityplayer.posZ;
						Vec3d looken = entityplayer.getLookVec();
						double yy = looken.y * l1;
						AxisAlignedBB axisalignedbb = (new AxisAlignedBB((double) (k), (double) (l), (double) (i1),
								(double) (k + x2), (double) (l + yy), (double) (i1 + z2))).grow(0.5);
						{
							List llist = world.getEntitiesWithinAABBExcludingEntity(entityplayer, axisalignedbb);
							if (llist != null) {
								for (int lj = 0; lj < llist.size(); lj++) {

									Entity entity1 = (Entity) llist.get(lj);
									if (entity1.canBeCollidedWith()) {
										// boolean flag =
										// this.getEntitySenses().canSee(entity1);
										if (entity1 instanceof IMob && entity1 != null) {
											if (!entity1.onGround) {
												EntityLivingBase en = (EntityLivingBase) entity1;
												NBTTagCompound nbt = entity1.getEntityData();
												// nbt.setBoolean("LockOn",
												// true);
												nbt.setInteger("LockOnTime", 200);
												en.addPotionEffect(new PotionEffect(MobEffects.GLOWING, 200, 10));
												this.mitarget = (EntityLivingBase) entity1;
												break;
											}
										}
									}
								}
							}
						}
					}
				}
			}*/
		}
	}
	
	
	public static EntityLivingBase getMissileTarget(ItemGunBase gun, ItemStack itemstack, World world, EntityPlayer entityplayer) {
		EntityLivingBase target = null;
		if(gun.mitarget != null) {
			target = gun.mitarget;
			System.out.println(String.format("mitarget"));
		}
		
		return target;
	}
	public static int getMissileTarget_ID(ItemGunBase gun, ItemStack itemstack, World world, EntityPlayer entityplayer) {
		int targetid = 0;
		if(gun.mitarget != null && world != null) {
			targetid = gun.mitarget.getEntityId();
		}
		
		return targetid;
	}
	
}
